"""Standalone updater helper (stdlib only -> tiny updater.exe).

Started by the main app, which then exits. This process:
  1. waits for the app (by PID) to exit,
  2. copies the staged files over the install folder, keeping a .old backup of every file it
     replaces so a failure rolls everything back,
  3. relaunches the app.
"""
import argparse
import ctypes
import os
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path

_LOG = None


def log(msg: str) -> None:
    line = time.strftime("%Y-%m-%d %H:%M:%S ") + msg
    if _LOG:
        try:
            with open(_LOG, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError:
            pass


def wait_for_pid(pid: int, timeout: int = 90) -> None:
    if os.name == "nt":
        SYNCHRONIZE = 0x00100000
        handle = ctypes.windll.kernel32.OpenProcess(SYNCHRONIZE, False, pid)
        if handle:
            ctypes.windll.kernel32.WaitForSingleObject(handle, timeout * 1000)
            ctypes.windll.kernel32.CloseHandle(handle)
    else:
        end = time.time() + timeout
        while time.time() < end:
            try:
                os.kill(pid, 0)
            except OSError:
                break
            time.sleep(0.3)
    time.sleep(1.0)  # let the OS release file handles


def retry(fn, *args, tries: int = 15, delay: float = 1.0):
    """Antivirus / indexers briefly lock freshly written files; retry on PermissionError."""
    for attempt in range(tries):
        try:
            return fn(*args)
        except PermissionError:
            if attempt == tries - 1:
                raise
            time.sleep(delay)


def rollback(done: list) -> None:
    for dest, backup in reversed(done):
        try:
            if dest.exists():
                dest.unlink()
            if backup is not None and backup.exists():
                os.replace(backup, dest)
        except OSError as exc:
            log(f"rollback problem on {dest}: {exc}")


def apply_update(source: Path, target: Path) -> None:
    done = []  # (dest, backup|None)
    try:
        for src in sorted(source.rglob("*")):
            dest = target / src.relative_to(source)
            if src.is_dir():
                dest.mkdir(parents=True, exist_ok=True)
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            backup = None
            if dest.exists():
                backup = dest.with_name(dest.name + ".old")
                if backup.exists():
                    retry(backup.unlink)
                retry(os.replace, dest, backup)
            try:
                retry(shutil.copy2, src, dest)
            except Exception:
                if dest.exists():
                    try:
                        dest.unlink()
                    except OSError:
                        pass
                if backup is not None:
                    os.replace(backup, dest)
                raise
            done.append((dest, backup))
    except Exception:
        log("update failed, rolling back")
        rollback(done)
        raise
    for _dest, backup in done:
        if backup is not None:
            try:
                backup.unlink()
            except OSError:
                pass


def relaunch(target: Path, exe: str) -> None:
    flags = 0
    if os.name == "nt":
        flags = (getattr(subprocess, "DETACHED_PROCESS", 0)
                 | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
    subprocess.Popen([str(target / exe)], cwd=str(target), creationflags=flags,
                     close_fds=True, stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def main() -> int:
    global _LOG
    ap = argparse.ArgumentParser()
    ap.add_argument("--pid", type=int, required=True)
    ap.add_argument("--source", required=True)
    ap.add_argument("--target", required=True)
    ap.add_argument("--exe", required=True)
    ap.add_argument("--log", default="")
    ap.add_argument("--cleanup", default="")
    a = ap.parse_args()
    _LOG = a.log or None
    source, target = Path(a.source), Path(a.target)
    ok = False
    try:
        log(f"waiting for pid {a.pid}")
        wait_for_pid(a.pid)
        log(f"applying {source} -> {target}")
        apply_update(source, target)
        ok = True
        log("update applied")
    except Exception:  # noqa: BLE001
        log("ERROR:\n" + traceback.format_exc())
    finally:
        if ok and a.cleanup:
            shutil.rmtree(a.cleanup, ignore_errors=True)
        try:
            relaunch(target, a.exe)  # new version on success, old (rolled back) version on failure
            log("relaunched")
        except OSError:
            log("relaunch failed:\n" + traceback.format_exc())
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
