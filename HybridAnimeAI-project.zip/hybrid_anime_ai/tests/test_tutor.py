import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.core.tutor import Tutor, split_reply, find_lang, LANGS
from app.core.ai_engine import AIEngine
from app.voice import neural

def ok(c, m):
    print(("ok   " if c else "FAIL ") + m)
    if not c:
        raise SystemExit(1)

cfg = {}
t = Tutor(cfg)
ok(t.command("hello how are you") is None and not t.on, "normal chat ignored while off")
msg, lesson = t.command("spanish sikhao")
ok(t.on and t.code == "es" and t.level == "beginner" and "Spanish" in lesson, "spanish sikhao starts tutor")
ok(cfg["tutor"]["lang"] == "spanish", "state kept in cfg (saved by the controller)")
ok(t.command("level advanced")[0].endswith("kar diya.") and t.level == "advanced", "level change")
ok("5 new useful Spanish" in t.command("aaj ka word")[1] and "quiz" in t.command("quiz lo")[1], "word of the day + quiz")
ok("restaurant" in t.command("roleplay restaurant me order")[1], "roleplay")
ok(t.command("yo quiero agua") is None, "normal sentence passes to the tutor turn")
ok(t.stt_languages() == ["es", "hi", "en"], "listens for the target language, Hindi and English")
p = t.prompt("Aiko", "Rahul")
ok("Spanish" in p and "|||" in p and "ADVANCED" in p, "prompt names the language, level and separator")
e = AIEngine(cfg); e.tutor = t
ok("language tutor" in e._system_prompt("", "hola"), "engine uses the tutor prompt while on")
ok(t.command("tutor mode band karo") is not None and not t.on, "tutor band")
ok("Aiko" in e._system_prompt("", "x") and "language tutor" not in e._system_prompt("", "x"), "normal prompt is back after stop")
t.command("japanese sikhao"); ok("Padho" in t.prompt("A", "B"), "non-Latin language asks for Roman pronunciation")
t.command("english sikhao intermediate"); ok(t.code == "en" and t.level == "intermediate", "english + level in one sentence")
ok(find_lang("mujhe hindi seekhni hai").code if False else find_lang("mujhe hindi seekhni hai")[0] == "hindi", "hindi alias")
ok(t.command("tutor mode kya hota hai") is None or True, "no crash on odd input")
ok(split_reply("¡Hola! ¿Cómo estás? ||| Sahi: x") == ("¡Hola! ¿Cómo estás?", "Sahi: x") and split_reply("Hi") == ("Hi", ""), "split spoken part / coaching note")
ok(all(neural.voice_name(l[3], "female") for l in LANGS) and neural.voice_name("ja", "male") == "ja-JP-KeitaNeural", "a voice for every language")
ok(len(LANGS) >= 25, f"{len(LANGS)} languages")
print("ALL OK")
