import sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.core.expenses import Expenses

def ok(c, m):
    print(("ok   " if c else "FAIL ") + m)
    if not c:
        raise SystemExit(1)

p = Path(tempfile.mkdtemp()) / "exp.json"
e = Expenses(lambda: p)
ok("200" in e.try_execute("kharcha 200 chai") and "samosa" in e.try_execute("50 rupaye samosa pe kharch kiye"), "adds entries")
r = e.try_execute("aaj ka kharcha")
ok("₹250" in r and "2 entries" in r, "today total")
ok("₹250" in e.try_execute("is mahine ka kharcha"), "month total")
ok("Hata diya" in e.try_execute("kharcha hatao") and "₹200" in e.try_execute("aaj ka kharcha"), "undo last")
ok(e.try_execute("hello") is None and e.try_execute("downloads folder dikhao") is None, "other text ignored")
print("ALL OK")
