"""Render characters with the SVG-recording Qt shim -> PNG (visual check). Run: python tests/render_preview.py"""
import json, sys, pathlib, math
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tests" / "qtshim"))
sys.path.insert(1, str(ROOT))
from PyQt6.QtGui import QPainter
from app.avatar.state import AvatarState, CANVAS_W, CANVAS_H
from app.avatar.vector import VectorAvatar

def svg_for(spec, **kw):
    p = QPainter(int(CANVAS_W), int(CANVAS_H))
    st = AvatarState(t=1.3, **kw)
    VectorAvatar(spec).paint(p, CANVAS_W, CANVAS_H, st)
    return p.to_svg()

def main(out_png):
    chars = [json.loads(f.read_text()) for f in sorted((ROOT/"assets"/"characters").glob("*/character.json"))]
    cells = []
    for c in chars:
        cells.append(svg_for(c))
    html = "<body style='margin:0;display:flex;flex-wrap:wrap;width:1500px;background:#c8d2e6'>" + "".join(cells) + "</body>"
    pathlib.Path(out_png).with_suffix(".html").write_text(html)
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch(); pg = b.new_page(viewport={"width":1500,"height":820})
        pg.set_content(html); pg.screenshot(path=out_png); b.close()

def states(out_png, cid="sakura"):
    spec = json.loads((ROOT/"assets"/"characters"/cid/"character.json").read_text())
    combos = [dict(emotion=e) for e in ("neutral","happy","love","sad","angry","surprised","thinking","embarrassed","sleepy","confused","listening")]
    combos += [dict(pose="walk", walk_phase=1.0), dict(pose="sit_edge"), dict(pose="sit_ground"), dict(pose="wave"), dict(pose="held"), dict(pose="sleep", emotion="sleepy"), dict(emotion="happy", speaking=True, mouth=0.8, look=(1,-0.5))]
    html = "<body style='margin:0;display:flex;flex-wrap:wrap;width:1500px;background:#c8d2e6'>" + "".join(svg_for(spec, **k) for k in combos) + "</body>"
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch(); pg = b.new_page(viewport={"width":1500,"height":1650})
        pg.set_content(html); pg.screenshot(path=out_png); b.close()

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    out = sys.argv[2] if len(sys.argv) > 2 else "/tmp/preview.png"
    (main if mode == "all" else states)(out) if mode == "all" else states(out, sys.argv[3] if len(sys.argv) > 3 else "sakura")
