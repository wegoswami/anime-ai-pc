import sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import version as V, config as C
from app.core import license as L

def ok(c, m):
    print(("ok   " if c else "FAIL ") + m)
    if not c:
        raise SystemExit(1)

C.save_config = lambda cfg: None
cfg = {"analytics": True}
ok(L.allowed(cfg, "agent") and "free" in L.status(cfg) or "free" in L.status(cfg), "no server set: everything free, nothing crashes")
ok(L.activate(cfg, "EV-AAAA-BBBB-CCCC-DDDD").startswith("Pro abhi shuru nahi hua"), "activate is inert without a server")
V.LICENSE_API = "https://api.test"
sent = []
answers = {"/v1/license/verify": {"valid": True, "plan": "yearly", "expires": int((time.time() + 86400) * 1000)}, "/v1/ping": {"ok": True}}
L._post = lambda path, body, timeout=8.0: (sent.append((path, body)), answers.get(path))[1]
ok("Pro chalu" in L.activate(cfg, "ev-aaaa-bbbb-cccc-dddd") and cfg["license_key"] == "EV-AAAA-BBBB-CCCC-DDDD" and L.is_pro(cfg), "valid key activates (key upper-cased) and cache is saved")
V.PRO_ENFORCED = True
ok(L.allowed(cfg, "agent") and L.allowed(cfg, "anything_else"), "Pro user can use Pro features")
cfg2 = {"analytics": True}
ok(not L.allowed(cfg2, "agent") and L.allowed(cfg2, "weather") and "Pro feature" in L.locked_message("agent"), "free user: Pro feature locked, others open")
V.PRO_ENFORCED = False
ok(L.allowed(cfg2, "agent"), "enforcement off: still free for everyone")
answers["/v1/license/verify"] = {"valid": False, "reason": "device_limit"}
cfg3 = {}
ok("limit" in L.activate(cfg3, "EV-1111-2222-3333-4444") and cfg3["license_key"] == "" and not L.is_pro(cfg3), "rejected key is not kept, reason explained")
# offline grace: server unreachable keeps a recent OK answer, drops an old one
L._post = lambda *a, **k: None
cfg["license_cache"]["checked"] = time.time() - 3 * 86400
ok(L.is_pro(cfg), "3 days offline: still Pro")
cfg["license_cache"]["checked"] = time.time() - 20 * 86400
ok(not L.is_pro(cfg), "20 days without checking: Pro lapses")
ok(L.install_id({}) and len(L.install_id({"install_id": ""})) == 32, "install id is a random 32-char token")
print("ALL OK")
