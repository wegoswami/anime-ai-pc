import json, sys, tempfile, zipfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.core import backup as B

def ok(c, m):
    print(("ok   " if c else "FAIL ") + m)
    if not c:
        raise SystemExit(1)

data = Path(tempfile.mkdtemp()); dest = Path(tempfile.mkdtemp())
(data / "config.json").write_text(json.dumps({"assistant_name": "Mia", "gemini_api_key": "SECRET123"}))
(data / "memory.db").write_bytes(b"mem")
(data / "plugins").mkdir(); (data / "plugins" / "p.py").write_text("x=1")
c = B.BackupCommands(lambda: data, dest)
r = c.try_execute("backup karo")
z = B.latest(dest)
ok(z is not None and "Backup ban gaya" in r, "backup created")
names = zipfile.ZipFile(z).namelist()
ok({"config.json", "memory.db", "plugins/p.py"} <= set(names), "files included")
ok("SECRET123" not in zipfile.ZipFile(z).read("config.json").decode(), "API key not in backup")
(data / "memory.db").write_bytes(b"changed")
(data / "config.json").write_text(json.dumps({"assistant_name": "Other", "gemini_api_key": "NEWKEY"}))
ok("haan/nahi" in c.try_execute("backup wapas lao"), "restore asks first")
c.try_execute("haan")
cfg = json.loads((data / "config.json").read_text())
ok((data / "memory.db").read_bytes() == b"mem" and cfg["assistant_name"] == "Mia" and cfg["gemini_api_key"] == "NEWKEY", "restore keeps current key")
ok(c.try_execute("hello") is None, "other text ignored")
print("ALL OK")
