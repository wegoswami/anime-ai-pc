import random, sys, pathlib, tempfile, time, unittest
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from app.behavior.brain import PetBrain, Env, Surface
from app.behavior.emotion import parse_tag, guess_emotion, EmotionState
from app.behavior.chatter import Chatter
from app.system.activity import ActivityTracker, friendly_app, clean_title
from app.system.screens import ScreenInfo, native_to_logical, rect_to_logical

SCREEN = (0, 0, 1920, 1040)


def run(brain, env_fn, seconds, dt=1 / 30):
    t, frames = 0.0, []
    while t < seconds:
        frames.append(brain.tick(env_fn(t, dt)))
        t += dt
    return frames


def env(t, dt, **kw):
    base = dict(now=t, dt=dt, screen=SCREEN)
    base.update(kw)
    return Env(**base)


class BrainTests(unittest.TestCase):
    def test_falls_and_lands_on_ground(self):
        b = PetBrain(500, 100, random.Random(1))
        fr = run(b, lambda t, dt: env(t, dt), 2.5)
        self.assertEqual(fr[-1].surface_id, "ground")
        self.assertAlmostEqual(fr[-1].y, 1040, delta=1)
        self.assertEqual(fr[0].pose, "fall")

    def test_lands_on_window_top_and_follows_it(self):
        win = Surface("w1", 300, 900, 500, "Chrome")
        b = PetBrain(600, 100, random.Random(2))
        fr = run(b, lambda t, dt: env(t, dt, surfaces=[win]), 1.5)
        self.assertEqual(fr[-1].surface_id, "w1")
        win.y = 420                                  # user drags the window up
        fr = run(b, lambda t, dt: env(10 + t, dt, surfaces=[win]), 0.5)
        self.assertAlmostEqual(fr[-1].y, 420, delta=1)

    def test_falls_when_window_disappears(self):
        win = Surface("w1", 300, 900, 500)
        b = PetBrain(600, 100, random.Random(2))
        run(b, lambda t, dt: env(t, dt, surfaces=[win]), 1.5)
        fr = run(b, lambda t, dt: env(10 + t, dt, surfaces=[]), 2.0)
        self.assertEqual(fr[-1].surface_id, "ground")

    def test_drag_and_drop(self):
        b = PetBrain(500, 1040, random.Random(3))
        run(b, lambda t, dt: env(t, dt), 1.0)
        b.grab(700, 300, 2.0)
        self.assertEqual(b.tick(env(2.0, 0.03)).pose, "held")
        b.release(2.1)
        fr = run(b, lambda t, dt: env(2.2 + t, dt), 2.0)
        self.assertEqual(fr[-1].pose in ("stand", "walk", "sit_ground", "wave"), True)
        self.assertEqual(fr[-1].surface_id, "ground")

    def test_wanders_and_walks(self):
        b = PetBrain(900, 1040, random.Random(6))
        fr = run(b, lambda t, dt: env(t, dt, cursor=(100, 100)), 240)
        self.assertTrue(any(f.pose == "walk" for f in fr))
        self.assertTrue(any(f.pose.startswith("sit") for f in fr))
        xs = [f.x for f in fr]
        self.assertTrue(24 <= min(xs) and max(xs) <= 1920 - 24)

    def test_sleeps_when_user_away_and_wakes(self):
        b = PetBrain(900, 1040, random.Random(5))
        fr = run(b, lambda t, dt: env(t, dt, user_idle_s=300), 3)
        self.assertEqual(fr[-1].pose, "sleep")
        self.assertEqual(fr[-1].emotion, "sleepy")
        self.assertTrue(any(i[0] == "fell_asleep" for f in fr for i in f.intents))
        fr = run(b, lambda t, dt: env(5 + t, dt, user_idle_s=0), 1)
        self.assertTrue(any(i[0] == "woke_up" for f in fr for i in f.intents))

    def test_jumps_to_window_where_cursor_rests(self):
        win = Surface("w1", 300, 1100, 400, "VS Code")
        b = PetBrain(1500, 1040, random.Random(7), walk=False)
        run(b, lambda t, dt: env(t, dt, surfaces=[win]), 1.0)
        fr = run(b, lambda t, dt: env(2 + t, dt, surfaces=[win], cursor=(700, 600), cursor_still_s=8,
                                       cursor_surface_id="w1"), 3.0)
        self.assertEqual(fr[-1].surface_id, "w1")
        self.assertAlmostEqual(fr[-1].y, 400, delta=1)
        self.assertTrue(any(i[0] == "perched" and i[1] == "VS Code" for f in fr for i in f.intents))
        self.assertTrue(any(f.pose == "jump" for f in fr))

    def test_does_not_jump_if_perch_disabled(self):
        win = Surface("w1", 300, 1100, 400)
        b = PetBrain(1500, 1040, random.Random(7), walk=False, perch=False)
        fr = run(b, lambda t, dt: env(t, dt, surfaces=[win], cursor=(700, 600), cursor_still_s=20,
                                       cursor_surface_id="w1"), 5)
        self.assertEqual(fr[-1].surface_id, "ground")

    def test_cursor_near_reaction_and_gaze(self):
        b = PetBrain(900, 1040, random.Random(9))
        fr = run(b, lambda t, dt: env(t, dt, cursor=(1000, 900)), 4)
        self.assertTrue(any(i[0] == "cursor_near" for f in fr for i in f.intents))
        fr = run(b, lambda t, dt: env(20 + t, dt, cursor=(1700, 700)), 1)
        self.assertGreater(fr[-1].look[0] * fr[-1].facing, 0.3)

    def test_silent_while_speaking(self):
        b = PetBrain(900, 1040, random.Random(5))
        fr = run(b, lambda t, dt: env(t, dt, speaking=True), 30)
        self.assertTrue(all(f.pose in ("stand", "sit_ground") for f in fr[5:]))


class EmotionTests(unittest.TestCase):
    def test_tag(self):
        self.assertEqual(parse_tag("[happy] Hi there!"), ("Hi there!", "happy"))
        self.assertEqual(parse_tag("[Shy] ok"), ("ok", "embarrassed"))
        self.assertEqual(parse_tag("[weird] x"), ("x", None))
        self.assertEqual(parse_tag("plain"), ("plain", None))

    def test_guess(self):
        self.assertEqual(guess_emotion("Sorry, I can't do that"), "sad")
        self.assertEqual(guess_emotion("Haha nice"), "happy")
        self.assertEqual(guess_emotion("It is 5 pm."), "neutral")

    def test_expiry(self):
        e = EmotionState(); e.set("sad", 2, 10)
        self.assertEqual(e.get(11), "sad"); self.assertEqual(e.get(13), "neutral")


class ChatterTests(unittest.TestCase):
    def mk(self, **cfg):
        c = {"user_name": "Suraj", "assistant_name": "Aiko", "proactive_level": "high", "language_pref": "auto"}
        c.update(cfg)
        ch = Chatter(lambda: c, None, random.Random(1))
        return ch

    def test_greeting_languages(self):
        ch = self.mk(); self.assertIn("Suraj", ch.greeting(0, 9)[0])
        ch.user_lang = "hinglish"; txt = ch.greeting(0, 9)[0]; self.assertIn("Suraj", txt)
        ch2 = self.mk(language_pref="hi"); self.assertTrue(any("ऀ" <= c <= "ॿ" for c in ch2.greeting(0, 9)[0]))

    def test_perched_mentions_app_with_cooldown(self):
        ch = self.mk(language_pref="hinglish")
        r = ch.on_intent("perched", "Chrome", 1000)
        self.assertIn("Chrome", r[0])
        self.assertIsNone(ch.on_intent("perched", "Chrome", 1010))

    def test_off_is_silent(self):
        ch = self.mk(proactive_level="off")
        self.assertIsNone(ch.on_intent("cursor_near", "", 1000))
        self.assertIsNone(ch.tick(5000, 14, "chrome.exe", False, False, 0))

    def test_busy_or_fullscreen_silent(self):
        ch = self.mk()
        self.assertIsNone(ch.tick(99999, 14, "", True, False, 0))
        self.assertIsNone(ch.tick(99999, 14, "", False, True, 0))

    def test_random_chat_after_interval(self):
        ch = self.mk(); ch.last_spoke = 0
        self.assertIsNotNone(ch.tick(5000, 14, "", False, False, 0))


class ActivityTests(unittest.TestCase):
    def test_journal(self):
        d = tempfile.mkdtemp(); tr = ActivityTracker(pathlib.Path(d) / "a.json")
        t = time.time()
        for i in range(200):
            tr.sample(t + i, "code.exe", "main.py - Visual Studio Code", 0)
        for i in range(200, 330):
            tr.sample(t + i, "chrome.exe", "YouTube - Google Chrome", 0)
        rec = tr.recent(3)
        self.assertEqual(rec[0][0], "Google Chrome"); self.assertEqual(rec[1][0], "VS Code")
        self.assertEqual(rec[0][1], "YouTube")
        self.assertIn("Google Chrome", tr.describe("en")); self.assertIn("mein", tr.describe("hinglish"))
        self.assertGreater(tr.active_minutes(t + 330), 5)
        tr.sample(t + 400, "chrome.exe", "x", 500)          # user away
        self.assertEqual(tr.active_minutes(t + 400), 0)
        tr.save(); tr2 = ActivityTracker(pathlib.Path(d) / "a.json"); self.assertTrue(tr2.recent(1))
        tr2.clear(); self.assertEqual(tr2.recent(1), [])

    def test_names(self):
        self.assertEqual(friendly_app("WINWORD.EXE"), "Word"); self.assertEqual(friendly_app("foo_bar.exe"), "Foo Bar")
        self.assertEqual(clean_title("Inbox - Google Chrome"), "Inbox")


class ScreenTests(unittest.TestCase):
    def test_mixed_dpi(self):
        s = [ScreenInfo(0, 0, 1280, 720, 1.5), ScreenInfo(1920, 0, 1920, 1080, 1.0)]
        self.assertEqual(native_to_logical(s, 960, 540), (640, 360))
        self.assertEqual(native_to_logical(s, 2000, 100), (2000, 100))
        l = rect_to_logical(s, 300, 150, 900, 600)
        self.assertEqual(l, (200, 100, 600, 400))

class PinTests(unittest.TestCase):
    def test_pinned_stays_where_dropped(self):
        b = PetBrain(500, 300, rng=random.Random(1)); b.pinned = True
        b.grab(500, 300, 0.0); b.drag(640, 250); b.release(1.0)
        self.assertEqual(b.mode, "pinned")
        t = 1.0
        for _ in range(600):                       # 10 seconds of ticks: no fall, no walking
            t += 1 / 60
            f = b.tick(env(t, 1 / 60))
        self.assertEqual((round(b.x), round(b.y)), (640, 250))
        self.assertEqual(f.pose, "stand")

    def test_unpinned_falls(self):
        b = PetBrain(500, 300, rng=random.Random(1)); b.pinned = False
        b.grab(500, 300, 0.0); b.drag(640, 250); b.release(1.0)
        self.assertEqual(b.mode, "fall")

    def test_unpin_drops_it(self):
        b = PetBrain(500, 300, rng=random.Random(1)); b.set_pinned(True)
        self.assertEqual(b.mode, "pinned"); b.set_pinned(False)
        self.assertEqual(b.mode, "fall")

if __name__ == "__main__":
    unittest.main()
