"""Tiny stand-in for the PyQt6 drawing API (subset), used ONLY by tests to record drawing as SVG.

It deliberately mimics PyQt6's strictness: only the overloads the real library accepts are provided
(e.g. drawEllipse(QPointF, rx, ry), never drawLine(float, float, float, float)).
"""


class QPointF:
    def __init__(self, x=0.0, y=0.0):
        self._x, self._y = float(x), float(y)

    def x(self):
        return self._x

    def y(self):
        return self._y


class QRectF:
    def __init__(self, x=0.0, y=0.0, w=0.0, h=0.0):
        self._r = (float(x), float(y), float(w), float(h))

    def x(self): return self._r[0]
    def y(self): return self._r[1]
    def width(self): return self._r[2]
    def height(self): return self._r[3]


class _Enum:
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return self.name


class _NS:
    def __init__(self, *names):
        for n in names:
            setattr(self, n, _Enum(n))


class Qt:
    PenStyle = _NS("NoPen", "SolidLine")
    BrushStyle = _NS("NoBrush", "SolidPattern")
    PenCapStyle = _NS("RoundCap", "FlatCap")
    PenJoinStyle = _NS("RoundJoin", "MiterJoin")
    GlobalColor = _NS("transparent", "white", "black")
