"""SVG-recording stand-in for QtGui (subset). See QtCore shim docstring."""
from .QtCore import QPointF, Qt  # noqa: F401


class QColor:
    def __init__(self, *a):
        if len(a) == 1 and isinstance(a[0], str):
            h = a[0].lstrip("#")
            self.r, self.g, self.b, self.a = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255
        elif len(a) in (3, 4):
            for v in a:
                assert isinstance(v, int), "QColor needs ints in PyQt6"
            self.r, self.g, self.b = a[:3]
            self.a = a[3] if len(a) == 4 else 255
        else:
            raise TypeError("bad QColor args")

    def css(self):
        return f"rgb({self.r},{self.g},{self.b})"

    def opacity(self):
        return self.a / 255.0


class QGradient:
    _n = 0

    def __init__(self):
        QGradient._n += 1
        self.id = f"g{QGradient._n}"
        self.stops = []

    def setColorAt(self, pos, color):
        self.stops.append((float(pos), color))

    def _stops_svg(self):
        return "".join(f'<stop offset="{p}" stop-color="{c.css()}" stop-opacity="{c.opacity()}"/>'
                       for p, c in sorted(self.stops, key=lambda s: s[0]))


class QLinearGradient(QGradient):
    def __init__(self, x1, y1, x2, y2):
        super().__init__()
        self.g = (float(x1), float(y1), float(x2), float(y2))

    def svg(self):
        x1, y1, x2, y2 = self.g
        return (f'<linearGradient id="{self.id}" gradientUnits="userSpaceOnUse" x1="{x1}" y1="{y1}" '
                f'x2="{x2}" y2="{y2}">{self._stops_svg()}</linearGradient>')


class QRadialGradient(QGradient):
    def __init__(self, cx, cy, r):
        super().__init__()
        self.g = (float(cx), float(cy), float(r))

    def svg(self):
        cx, cy, r = self.g
        return (f'<radialGradient id="{self.id}" gradientUnits="userSpaceOnUse" cx="{cx}" cy="{cy}" '
                f'r="{r}">{self._stops_svg()}</radialGradient>')


class QBrush:
    def __init__(self, src):
        self.src = src


class QPen:
    def __init__(self, color, width=1.0):
        self.color, self.width = color, float(width)
        self.cap, self.join = "butt", "miter"

    def setCapStyle(self, c):
        self.cap = "round" if c.name == "RoundCap" else "butt"

    def setJoinStyle(self, j):
        self.join = "round" if j.name == "RoundJoin" else "miter"


class QPainterPath:
    def __init__(self):
        self.d = []

    def moveTo(self, x, y): self.d.append(f"M{x:.2f} {y:.2f}")
    def lineTo(self, x, y): self.d.append(f"L{x:.2f} {y:.2f}")
    def quadTo(self, cx, cy, x, y): self.d.append(f"Q{cx:.2f} {cy:.2f} {x:.2f} {y:.2f}")
    def cubicTo(self, a, b, c, d, x, y): self.d.append(f"C{a:.2f} {b:.2f} {c:.2f} {d:.2f} {x:.2f} {y:.2f}")
    def closeSubpath(self): self.d.append("Z")

    def addEllipse(self, x, y, w, h):
        rx, ry, cx, cy = w / 2, h / 2, x + w / 2, y + h / 2
        self.d.append(f"M{cx - rx:.2f} {cy:.2f}A{rx:.2f} {ry:.2f} 0 1 0 {cx + rx:.2f} {cy:.2f}"
                      f"A{rx:.2f} {ry:.2f} 0 1 0 {cx - rx:.2f} {cy:.2f}Z")

    def addRoundedRect(self, x, y, w, h, xr, yr):
        xr, yr = min(xr, w / 2), min(yr, h / 2)
        self.d.append(f"M{x + xr:.2f} {y:.2f}H{x + w - xr:.2f}A{xr:.2f} {yr:.2f} 0 0 1 {x + w:.2f} {y + yr:.2f}"
                      f"V{y + h - yr:.2f}A{xr:.2f} {yr:.2f} 0 0 1 {x + w - xr:.2f} {y + h:.2f}H{x + xr:.2f}"
                      f"A{xr:.2f} {yr:.2f} 0 0 1 {x:.2f} {y + h - yr:.2f}V{y + yr:.2f}"
                      f"A{xr:.2f} {yr:.2f} 0 0 1 {x + xr:.2f} {y:.2f}Z")

    def addPath(self, other): self.d.extend(other.d)

    def svg_d(self): return "".join(self.d)


class QPainter:
    class RenderHint:
        Antialiasing = "aa"
        SmoothPixmapTransform = "smooth"

    def __init__(self, w=300, h=400):
        self.w, self.h = w, h
        self.out, self.defs, self.stack = [], [], []
        self.depth = 0
        self.pen, self.brush, self.opacity = None, None, 1.0

    def setRenderHint(self, *_): pass

    def save(self): self.stack.append((self.depth, self.pen, self.brush, self.opacity))

    def restore(self):
        depth, self.pen, self.brush, self.opacity = self.stack.pop()
        while self.depth > depth:
            self.out.append("</g>")
            self.depth -= 1

    def _open(self, t):
        self.out.append(f'<g transform="{t}">')
        self.depth += 1

    def translate(self, dx, dy): self._open(f"translate({float(dx)},{float(dy)})")
    def scale(self, sx, sy): self._open(f"scale({float(sx)},{float(sy)})")
    def rotate(self, a): self._open(f"rotate({float(a)})")
    def setOpacity(self, o): self.opacity = float(o)
    def setPen(self, p): self.pen = None if getattr(p, "name", "") == "NoPen" else p
    def setBrush(self, b): self.brush = None if getattr(b, "name", "") == "NoBrush" else b

    def _paint_attrs(self):
        a = []
        if self.brush is None:
            a.append('fill="none"')
        else:
            src = self.brush.src
            if isinstance(src, QGradient):
                self.defs.append(src.svg())
                a.append(f'fill="url(#{src.id})"')
            else:
                a.append(f'fill="{src.css()}" fill-opacity="{src.opacity()}"')
        if self.pen is not None:
            c = self.pen.color
            a.append(f'stroke="{c.css()}" stroke-opacity="{c.opacity()}" stroke-width="{self.pen.width}" '
                     f'stroke-linecap="{self.pen.cap}" stroke-linejoin="{self.pen.join}"')
        if self.opacity != 1.0:
            a.append(f'opacity="{self.opacity}"')
        return " ".join(a)

    def drawPath(self, path):
        self.out.append(f'<path d="{path.svg_d()}" fill-rule="evenodd" {self._paint_attrs()}/>')

    def drawEllipse(self, c, rx, ry):
        assert isinstance(c, QPointF), "PyQt6: use drawEllipse(QPointF, rx, ry)"
        self.out.append(f'<ellipse cx="{c.x()}" cy="{c.y()}" rx="{rx}" ry="{ry}" {self._paint_attrs()}/>')

    def to_svg(self, bg="#c8d2e6"):
        body = "".join(self.out) + "</g>" * self.depth
        return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" '
                f'viewBox="0 0 {self.w} {self.h}"><rect width="100%" height="100%" fill="{bg}"/>'
                f'<defs>{"".join(self.defs)}</defs>{body}</svg>')
