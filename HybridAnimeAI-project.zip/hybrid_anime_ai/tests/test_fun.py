import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.core.fun import Fun


class FunTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.f = Fun(lambda: Path(self.tmp.name) / "fun.json")

    def tearDown(self):
        self.tmp.cleanup()

    def say(self, t):
        return self.f.try_execute(t)

    def test_content_loaded(self):
        self.assertGreaterEqual(len(self.f.c["JOKES"]), 10)
        self.assertTrue(self.say("joke"))

    def test_unrelated_text_is_not_handled(self):
        self.assertIsNone(self.say("chrome kholo"))
        self.assertIsNone(self.say("kharcha 200 chai"))

    def test_quiz_flow(self):
        self.assertIn("Q1.", self.say("quiz"))
        for _ in range(3):
            self.assertIn("Q", self.say("a"))
        self.assertIn("Quiz khatam", self.say("b"))
        self.assertEqual(self.f._load()["games"], 1)

    def test_game_does_not_trap_other_commands(self):
        self.say("guess number")
        self.assertIn("stats", self.say("meri stats").lower())

    def test_tictactoe(self):
        self.assertIn("1️⃣", self.say("tic tac toe"))
        out = self.say("5")
        self.assertIn("Aapki baari", out)
        self.assertIn("bhari", self.say("5"))
        self.assertIn("band", self.say("stop"))

    def test_word_chain(self):
        self.say("word chain")
        self.assertIn("se shuru", self.say("tiger"))
        self.assertIn("ab '", self.say("elephant"))

    def test_streak_and_coins(self):
        self.assertIn("streak", self.f.daily())
        self.assertEqual(self.f.daily(), "")
        self.assertIn("10", self.say("coins"))

    def test_shop_and_missions(self):
        self.assertIn("coins aur chahiye", self.say("kharido teddy"))
        self.say("mera mood khush")
        self.assertIn("✅", self.say("missions"))
        d = self.f._load(); d["coins"] = 500; self.f._save(d)
        self.assertIn("ghar me rakh", self.say("kharido teddy"))
        self.assertIn("🧸", self.say("mera ghar"))

    def test_memory_and_mood(self):
        self.assertIn("Yaad kar liya", self.say("yaad rakho meri exam 5 December ko"))
        self.assertIn("exam", self.say("mujhe kya yaad hai"))
        self.say("mera mood udaas")
        self.assertIn("█", self.say("mood report"))
        self.assertIn("saans", self.say("main udaas hoon").lower() + "saans")
        self.assertIn("Is hafte", self.say("weekly report"))


if __name__ == "__main__":
    unittest.main()
