"""Soul profile, tone mirroring, auto-skill safety, local RAG, web search parsing, hotkey parsing."""
import os, sys, tempfile
from pathlib import Path
from unittest import mock

root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root))
os.environ["APPDATA"] = tempfile.mkdtemp()
from app.core import hotkey, websearch
from app.core.evolution import AutoSkills, Soul, validate_skill
from app.core.knowledge import Knowledge

tmp = Path(tempfile.mkdtemp())
ok = lambda c, m: (print(("ok   " if c else "FAIL ") + m), c or sys.exit(1))

# soul profile
s = Soul(tmp / "soul.json")
due = [s.observe(t) for t in ["mera naam Rahul hai", "yaar kya haal hai bhai", "mujhe cricket pasand hai", "kal ka plan batao",
        "acha theek hai 😀", "I love pizza", "bhai help kro", "kya kr rha hai", "mai Earthvasi app pe kaam kar rha hu", "ok bolo"]]
ok(due[-1] and not any(due[:-1]), "reflection due on the 10th message")
s.reflect(lambda p: "Casual Hinglish, short messages, friendly.")
sp = s.style_prompt()
ok(s.data["name"] == "Rahul" and "cricket" in " ".join(s.data["likes"]).lower(), "name and likes learned")
ok(s.data["language"] == "hinglish" and s.data["style"]["emoji"], "hinglish + emoji style detected")
ok("Mirror their style" in sp and "Rahul" in sp, "style fed into the system prompt")
ok(Soul(tmp / "soul.json").data["name"] == "Rahul", "profile persisted to JSON")
(tmp / "bad.json").write_text("{not json")
ok(Soul(tmp / "bad.json").data["interactions"] == 0, "corrupt profile does not crash")
s.reflect(lambda p: (_ for _ in ()).throw(RuntimeError("offline")))
ok(True, "reflection survives an LLM failure")

# skill validation
good = 'NAME="Dice"\nTRIGGERS=[r"roll a dice"]\nimport random\ndef run(text, ctx):\n    return str(random.randint(1,6))\n'
ok(validate_skill(good)[0], "good skill accepted")
for label, code in [("os import", "import os\nNAME='x'\nTRIGGERS=['x']\ndef run(t,c): return os.getcwd()"),
                    ("open()", "NAME='x'\nTRIGGERS=['x']\ndef run(t,c): return open('a').read()"),
                    ("eval", "NAME='x'\nTRIGGERS=['x']\ndef run(t,c): return eval('1')"),
                    ("dunder", "NAME='x'\nTRIGGERS=['x']\ndef run(t,c): return ().__class__.__bases__"),
                    ("subprocess", "from subprocess import run as r\nNAME='x'\nTRIGGERS=['x']\ndef run(t,c): return ''"),
                    ("no run", "NAME='x'\nTRIGGERS=['x']")]:
    ok(not validate_skill(code)[0], f"rejects {label}")

# auto skills flow
installed = []
plug = tmp / "plugins"
a = AutoSkills(plug, lambda p: "```python\n" + good + "```", lambda: installed.append(1))
msg = a.handle_command("skill banao: dice roll karne wali")
ok("Install karun" in msg and a.staged, "draft validated and staged, not installed yet")
ok(not list(plug.glob("*.py")) if plug.exists() else True, "nothing written before confirmation")
ok("install ho gayi" in a.handle_command("yes") and len(list(plug.glob("auto_*.py"))) == 1 and installed, "installed after yes")
evil = AutoSkills(plug, lambda p: "import os\nNAME='x'\nTRIGGERS=['x']\ndef run(t,c): return os.getcwd()", lambda: None)
ok("install nahi ki" in evil.handle_command("skill banao: kuch bhi"), "unsafe draft refused")
down = AutoSkills(plug, lambda p: (_ for _ in ()).throw(RuntimeError("x")), lambda: None)
ok("nahi bana" in down.handle_command("skill banao: kuch"), "LLM failure handled")
rep = AutoSkills(plug, lambda p: "", lambda: None)
offers = [rep.watch("open notepad 1", True) for _ in range(3)]
ok(offers[0] is None and offers[2] and "skill banao" in offers[2], "offers a skill on the 3rd repeat")

# knowledge base
docs = tmp / "docs"; docs.mkdir()
(docs / "a.txt").write_text("Gaya Ji is a city in Bihar, India. The Vishnupad temple is famous for pind daan rituals.")
(docs / "b.md").write_text("Recipe notes: aloo paratha needs wheat flour, boiled potatoes and green chilli.")
import zipfile
with zipfile.ZipFile(docs / "c.docx", "w") as z:
    z.writestr("word/document.xml", "<w:p><w:t>Project Earthvasi launch date is 15 December.</w:t></w:p>")
kb = Knowledge(tmp / "k.db")
f, c = kb.index_folder(str(docs))
ok(f == 3 and c >= 3, f"indexed {f} files / {c} chunks")
ok("Vishnupad" in kb.context_for("which temple is in Gaya"), "RAG finds the temple note")
ok("December" in kb.context_for("when is the Earthvasi launch"), "RAG reads .docx")
ok(kb.index_folder(str(docs)) == (0, 0), "re-index skips unchanged files")
ok(kb.parse_index("index folder C:\\Users\\me\\Notes") == "C:\\Users\\me\\Notes" and kb.parse_ask("from my docs: launch date?"), "chat commands parse")
try:
    kb.index_folder(str(tmp / "nope")); ok(False, "missing folder")
except FileNotFoundError:
    ok(True, "missing folder raises cleanly")

# web search
html = '<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fx">Title <b>One</b></a> <a class="result__snippet" href="x">Snippet &amp; more</a>'
with mock.patch("app.core.websearch.requests.post", return_value=mock.Mock(text=html, raise_for_status=lambda: None)):
    r = websearch.search("q")
ok(r == [("Title One", "Snippet & more", "https://example.com/x")], "DuckDuckGo result parsed")
with mock.patch("app.core.websearch.requests.post", side_effect=OSError):
    ok(websearch.search("q") == [] and websearch.context_for("latest news x") == "", "web search failure is silent")
ok(websearch.WEB_Q.search("search the web for python 3.13 features"), "web question detected")

# bridge
import json as _j, urllib.request as _u
from app.core.bridge import Bridge
facts, got = ["likes tea"], []
b = Bridge(lambda: facts, got.append, lambda: {"name": "Rahul"}, lambda d: got.append(d), lambda t: "ran " + t)
tok = b.start(18765)
def call(path, data=None, token=tok):
    r = _u.Request("http://127.0.0.1:18765" + path, data=_j.dumps(data).encode() if data is not None else None, headers={"X-Token": token, "Content-Type": "application/json"})
    return _j.loads(_u.urlopen(r, timeout=3).read())
ok(call("/ping")["ok"], "bridge ping with the pairing code")
try:
    call("/sync", token="wrong"); ok(False, "wrong code rejected")
except Exception:
    ok(True, "wrong code rejected")
ok(call("/sync")["facts"] == ["likes tea"], "PC -> phone sync")
call("/sync", {"facts": ["likes cricket"], "soul": {"name": "R"}})
ok("likes cricket" in got and {"name": "R"} in got, "phone -> PC sync")
ok(call("/cmd", {"text": "open notepad"})["reply"] == "ran open notepad", "phone runs a command on the PC")
b.queue_for_phone("open youtube")
ok(call("/poll")["cmds"] == ["open youtube"] and call("/poll")["cmds"] == [], "PC queues a command for the phone (delivered once)")
b.stop()
try:
    call("/ping"); ok(False, "stopped")
except Exception:
    ok(True, "bridge stops cleanly")

# hotkey
ok(hotkey.parse("alt+space") == (0x4001, 0x20) and hotkey.parse("ctrl+shift+k") == (0x4006, ord("K")) and hotkey.parse("") is None, "hotkey spec parsed")
ok(hotkey.install(None, "alt+space", lambda: None) is False, "hotkey is a safe no-op off Windows")
print("ALL OK")
