import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from unittest import mock
from app.core import access
f = 0
def ok(c, m):
    global f; print(("ok   " if c else "FAIL ") + m); f += (not c)
with mock.patch.object(access, "check", lambda: {"mic": False, "screen": True, "admin": False}), mock.patch.object(access, "open_page", lambda w: w == "mic") as op:
    ok("Mic band" in access.setup(), "blocked mic -> tells what to tap")
    ok("❌ Microphone" in access.report() and "ON karo" in access.report(), "report shows the fix")
with mock.patch.object(access, "check", lambda: {"mic": True, "screen": True, "admin": True}):
    ok("koi permission block nahi" in access.setup(), "all fine -> says so")
ok(isinstance(access.check(), dict), "check() runs on this OS")
sys.exit(1 if f else 0)
