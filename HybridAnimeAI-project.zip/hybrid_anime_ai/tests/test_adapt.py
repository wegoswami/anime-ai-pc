import sys, tempfile, time
from datetime import datetime, timedelta
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.core.adapt import Adapt


def ok(c, m):
    print(("ok   " if c else "FAIL ") + m)
    if not c:
        raise SystemExit(1)


d = Path(tempfile.mkdtemp())
cfg = {"assistant_name": "Aiko", "user_name": "", "language_pref": "auto"}
saved = []
a = Adapt(d / "adapt.json", cfg, lambda: saved.append(1))
H = lambda t: a.handle(t, "hinglish")

# ---- prefs
ok("chhote" in H("chhota jawab do.").reply and a.prefs["len"] == "short", "short replies")
ok("ONE short sentence" in a.prompt(), "short rule in AI prompt")
H("formal ho jao")
ok(a.prefs["tone"] == "formal" and "formally" in a.prompt(), "formal tone")
H("style reset")
ok(a.prompt() == "", "reset clears the prompt")
H("mujhe Boss bulao")
ok(cfg["user_name"] == "Boss" and saved, "call me X")
H("tumhara naam Mochi rakh do")
ok(cfg["assistant_name"] == "Mochi", "rename assistant")
H("hindi me baat karo")
ok(cfg["language_pref"] == "hi" and "Hindi" in a.prompt(), "language to Hindi")
H("meri bhasha auto")
ok(cfg["language_pref"] == "auto" and a.prompt() == "", "language back to auto")
ok("Boss" in H("meri style").reply and "Mochi" in H("meri style").reply, "style summary")
ok(H("mujhe pasta pasand hai") is None and H("what is the capital of france") is None, "normal text is not hijacked")
ok(H("mujhe Rahul ko bulao") is None, "'X ko' is not a nickname")

# ---- teach
o = H("jab main good morning bolu to time kya hua phir aaj kya date hai")
ok(o and len(a.teach) == 1 and a.teach[0]["steps"] == ["time kya hua", "aaj kya date hai"], "teach 'jab main … bolu'")
o = H("good morning")
ok(o and o.steps == ("time kya hua", "aaj kya date hai"), "trigger returns its steps")
a.running = True
ok(H("good morning") is None, "steps of a running routine do not re-trigger")
a.running = False
H("routine banao subah: news batao, weather batao")
ok(len(a.teach) == 2, "colon form")
ok("subah" in H("meri routines").reply, "list routines")
H("routine hatao subah")
ok(len(a.teach) == 1, "delete routine")
ok("andar routine" in H("routine banao xx: routine banao yy: zz").reply, "no nested routines")
a2 = Adapt(d / "adapt.json", cfg)
ok(len(a2.teach) == 1 and a2.prefs["len"] == "", "survives restart")

# ---- auto
H("roz subah 7 baje news batao")
ok(a.auto[-1]["at"] == "07:00" and a.auto[-1]["kind"] == "cmd" and a.auto[-1]["text"] == "news batao", f"daily cmd {a.auto[-1]}")
H("roz shaam 6:30 baje yaad dilao paani piyo")
ok(a.auto[-1]["at"] == "18:30" and a.auto[-1]["kind"] == "say" and a.auto[-1]["text"] == "paani piyo", f"daily reminder {a.auto[-1]}")
H("every day at 9 pm remind me to sleep")
ok(a.auto[-1]["at"] == "21:00" and a.auto[-1]["kind"] == "say" and a.auto[-1]["text"] == "sleep", f"english daily {a.auto[-1]}")
ok("07:00" in H("mere roz ke kaam").reply, "list daily jobs")
a.auto = []
t = datetime.now() - timedelta(minutes=3)
if t.date() != datetime.now().date():
    t = datetime.now()
a.add_auto(t.strftime("%H:%M"), "cmd", "time kya hua")
ok(len(a.due()) == 1 and a.due() == [], "due once per day")
a.add_auto((datetime.now() + timedelta(hours=2)).strftime("%H:%M"), "cmd", "later")
ok(all(j["text"] != "later" for j in a.due()), "future job not due")
H("auto hatao sab")
ok(a.auto == [], "clear daily jobs")

# ---- habits
today = datetime.now()
mins = today.hour * 60 + today.minute
a.habit_data = {"news batao": {"s": [[(today - timedelta(days=k)).strftime("%Y-%m-%d"), mins + 5 * k] for k in (3, 2, 1)]}}
ok(a.find_habit() is not None, "habit detected after 3 days")
q = a.suggest()
ok(q and "news batao" in q and a.pending, "suggestion asked")
ok(a.suggest() is None, "asks at most once a day")
ok(H("haan").reply.startswith("Ho gaya") and a.auto and a.auto[0]["text"] == "news batao", "yes creates the daily job")
a.note("mom ko call karo")
ok("mom ko call karo" not in a.habit_data, "sensitive commands never tracked")
a.habit_data = {"joke sunao": {"s": [[(today - timedelta(days=k)).strftime("%Y-%m-%d"), mins] for k in (3, 2, 1)]}}
a.habit_ask = 0
a.suggest()
ok("nahi puchungi" in H("nahi").reply and "joke sunao" in a.habit_no, "no = never ask again")
H("habits band")
ok(cfg["habits"] is False and a.habit_data == {}, "habits off wipes data")
a.note("time kya hua")
ok(a.habit_data == {}, "nothing tracked while off")

# ---- draft
o = H("draft whatsapp to mom: late aaunga dinner mat banana")
ok(o and o.draft == ("whatsapp", "mom", "late aaunga dinner mat banana"), "draft parsed")
o = H("mom ko whatsapp likho: main late aaunga")
ok(o and o.draft[1] == "mom", "second draft form")
ok("Here's the draft" in a.set_draft("whatsapp", "Mom, late aaunga"), "draft stored")
o = H("bhejo")
ok(o and o.open_url.startswith("https://wa.me/?text=") and a.draft_last is None, "send opens WhatsApp with the text")
a.set_draft("email", "Subject: Leave\nHi boss, I need leave tomorrow.")
o = H("send")
ok(o.open_url.startswith("mailto:?subject=Leave&body="), "email splits subject")
ok(H("bhejo") is None, "bhejo alone does nothing without a draft")
print("ALL OK")
