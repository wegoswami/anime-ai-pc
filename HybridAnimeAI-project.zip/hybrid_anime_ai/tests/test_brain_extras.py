"""Memory, multi-provider brain, hardware tiers, plugins, routines, screen-question detection (no Qt needed)."""
import io, json, os, sys, tempfile, time, zipfile
from pathlib import Path
from unittest import mock

root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root))
os.environ["APPDATA"] = tempfile.mkdtemp()

from app.core import ai_engine, hardware, providers, vision
from app.core.memory import Memory, embed, cosine
from app.core.plugins import PluginManager
from app.core.routines import Routines

tmp = Path(tempfile.mkdtemp())
ok = lambda c, m: (print(("ok   " if c else "FAIL ") + m), c or sys.exit(1))

# ---------------------------------------------------------------- memory
m = Memory(tmp / "m.db")
for t in ["mera naam Suraj hai", "I love pizza and cricket", "my birthday is 5 March", "I work as a designer in Pune",
          "remember that my wifi password hint is blue", "mujhe horror movies pasand nahi hai"]:
    m.learn(t)
f = " | ".join(m.facts())
ok("suraj" in f.lower() and "pizza" in f.lower() and "march" in f.lower() and "designer" in f.lower(), "facts learned: " + f[:90])
m.add_turn("kal mera interview hai", "All the best! Tum kar loge.")
m.add_turn("what's the capital of France", "Paris.")
top = m.search("interview kal")[0][1]
ok("interview" in top, "vector search finds the right memory")
ok("cricket" in m.context("which sport do I like").lower(), "context() feeds relevant facts into the prompt")
ok(cosine(embed("pizza pasta"), embed("pizza pasta")) > .99 and cosine(embed("pizza"), embed("aeroplane ticket")) < .3, "embedding similarity sane")
ok("remember" in (m.handle_command("what do you remember about me", "en") or "").lower(), "recall command")
ok("forgotten" in (m.handle_command("forget everything", "en") or ""), "forget command")
ok(m.facts() == [], "memory wiped")
bad = Memory(tmp / "nonexistent_dir" / "x.db")                 # broken path must not raise
ok(bad.search("x") == [] and bad.add("note", "abc") is False, "memory survives a broken database")

# ---------------------------------------------------------------- hardware
ok(hardware.recommend_model(hardware.Hardware(4, 2))[0] == "qwen2.5:0.5b", "4 GB RAM -> tiny model")
ok(hardware.recommend_model(hardware.Hardware(8, 4))[0] == "gemma2:2b", "8 GB RAM -> gemma2:2b")
ok(hardware.recommend_model(hardware.Hardware(16, 8))[0] == "llama3.2:3b", "16 GB RAM -> llama3.2:3b")
ok(hardware.recommend_model(hardware.Hardware(16, 8, "RTX 4070", 12))[0] == "llama3.1:8b", "big GPU -> 8b model")
ok(hardware.effective_model({"auto_model": False, "ollama_model": "phi3"}) == "phi3", "manual model respected")

# ---------------------------------------------------------------- providers + fallback
class Resp:
    def __init__(self, code, js): self.status_code, self._j = code, js
    def json(self): return self._j
    def raise_for_status(self):
        if self.status_code >= 400: raise RuntimeError(f"http {self.status_code}")
calls = []
def fake_post(url, **kw):
    calls.append(url)
    if "googleapis" in url: return Resp(429, {})
    if "openai.com" in url: return Resp(200, {"choices": [{"message": {"content": "[happy] Hello from OpenAI"}}]})
    return Resp(200, {"content": [{"type": "text", "text": "[love] Hello from Claude"}]})
cfg = {"gemini_api_key": "g", "openai_api_key": "o", "anthropic_api_key": "c", "provider_order": ["gemini", "openai", "claude"], "auto_model": False}
providers.reset()
with mock.patch.object(providers.requests, "post", fake_post), mock.patch.object(ai_engine, "is_online", lambda: True):
    e = ai_engine.AIEngine(cfg); e.memory = None
    r = e.ask("hi")
    ok(r.mode == "cloud" and "OpenAI" in r.text and r.emotion == "happy", "Gemini quota error -> falls to OpenAI")
    n = len(calls); r = e.ask("again")
    ok(not any("googleapis" in u for u in calls[n:]), "failed provider is skipped for a minute (low latency)")
    providers.reset(); cfg["provider_order"] = ["claude", "openai", "gemini"]; e.reload(cfg)
    ok("Claude" in e.ask("hey").text, "preferred order is respected")
    # vision payload shape
    seen = {}
    def cap(url, **kw): seen[url] = kw.get("json"); return fake_post(url, **kw)
    providers.reset()
    with mock.patch.object(providers.requests, "post", cap):
        providers.ask("claude", cfg, "sys", [], "what is this", image=b"\x89PNG")
        providers.ask("openai", cfg, "sys", [], "what is this", image=b"\x89PNG")
    ok(seen["https://api.anthropic.com/v1/messages"]["messages"][0]["content"][0]["type"] == "image", "Claude image payload")
    ok(seen["https://api.openai.com/v1/chat/completions"]["messages"][-1]["content"][1]["type"] == "image_url", "OpenAI image payload")
def boom(url, **kw): raise ConnectionError("dns")
providers.reset()
with mock.patch.object(providers.requests, "post", boom), mock.patch.object(ai_engine, "is_online", lambda: True), \
     mock.patch.object(ai_engine.AIEngine, "_ask_local", lambda self, t, l: "[neutral] local answer"):
    e = ai_engine.AIEngine(cfg)
    r = e.ask("hello")
    ok(r.mode == "local" and "local answer" in r.text, "all clouds down -> offline model answers (never crashes)")
ok(not providers.available({}) and providers.available({"openai_api_key": "x"}) == ["openai"], "available() only lists keyed providers")
e = ai_engine.AIEngine({"auto_model": False}); mem = Memory(tmp / "m2.db"); mem.learn("my name is Raj"); e.memory = mem
ok("raj" in e._system_prompt("en", "what is my name").lower(), "memory injected into the system prompt")

# ---------------------------------------------------------------- plugins
pdir = tmp / "plugins"; pdir.mkdir()
(pdir / "coin.py").write_text('import random\nNAME="Coin"\nVERSION="1.2"\nTRIGGERS=[r"\\bflip a coin\\b"]\ndef run(text, ctx):\n    ctx.remember("flipped a coin"); return "Heads! " + str(sorted(ctx.cfg)[:1])\n')
(pdir / "broken.py").write_text("def run(:\n")
(pdir / "slow.py").write_text('import time\nNAME="Slow"\nTRIGGERS=[r"slowpoke"]\ndef run(t, c):\n    time.sleep(60)\n')
(pdir / "crashy.py").write_text('NAME="Crashy"\nTRIGGERS=[r"crashme"]\ndef run(t, c):\n    raise RuntimeError("x")\n')
remembered = []
pm = PluginManager(pdir, lambda: {"user_name": "Sam", "gemini_api_key": "SECRET", "anthropic_api_key": "S2"}, {"remember": remembered.append})
ok("Coin" in " ".join(pm.names()) and "broken.py" in pm.errors, "good plugin loads, broken one is reported not fatal")
out = pm.try_handle("please flip a coin", "en")
ok(out and out.startswith("Heads") and "SECRET" not in out and remembered == ["flipped a coin"], "plugin runs with a key-free context")
ok("gemini_api_key" not in out, "API keys hidden from plugins")
for _ in range(3): pm.try_handle("crashme", "en")
ok(not [p for p in pm.plugins if p.name == "Crashy"][0].enabled, "a plugin that keeps crashing gets disabled")
import app.core.plugins as pl
pl.RUN_TIMEOUT = 0.3
t0 = time.time(); r = pm.try_handle("slowpoke", "en")
ok(r is None and time.time() - t0 < 2, "a hanging plugin is cut off")
# install from GitHub (mocked) needs confirmation
plugin_src = b'NAME="Joke"\nTRIGGERS=[r"tell me a joke plugin"]\ndef run(text, ctx):\n    return "Why did the PC sleep? It was tired."\n'
class R2:
    status_code = 200
    def __init__(self, c): self.content = c
    def raise_for_status(self): pass
buf = io.BytesIO()
with zipfile.ZipFile(buf, "w") as z:
    z.writestr("repo-main/plugins/joke.py", plugin_src); z.writestr("repo-main/plugins/../evil.py", b"import os"); z.writestr("repo-main/README.md", b"x")
with mock.patch.object(pl.requests, "get", lambda url, **kw: R2(buf.getvalue())):
    msg = pm.handle_command("install plugin https://github.com/someone/repo", "en")
    ok("Say yes" in msg and "joke.py" in msg and not (pdir / "joke.py").exists(), "install asks for confirmation first")
    ok("Installed" in pm.handle_command("yes", "en") and (pdir / "joke.py").exists(), "confirm installs the plugin")
    ok(pm.try_handle("tell me a joke plugin", "en") and "tired" in pm.try_handle("tell me a joke plugin", "en"), "freshly installed plugin works (hot load)")
    ok(not (tmp / "evil.py").exists() and not (pdir / "evil.py").exists(), "path tricks ignored")
ok("github.com" in pm.handle_command("install plugin https://evil.example.com/x.py", "en"), "non-GitHub hosts refused")

# ---------------------------------------------------------------- routines
log = []
rt = Routines(tmp / "r.json", {k: (lambda v, k=k: log.append((k, v))) for k in ("say", "open", "url", "focus", "lock", "command", "search", "screen")})
ok(rt.match("start work mode") == "work mode" and rt.match("kaam shuru karo") == "work mode", "routine phrases matched")
ok(rt.match("how does the work mode setting of my car engine behave when it is very cold outside") is None, "long sentences are not routines")
ok(rt.handle_command("work mode", "en") == "", "routine started")
time.sleep(3.5)
kinds = [k for k, _ in log]
ok("say" in kinds and "open" in kinds and "focus" in kinds, "routine steps executed: " + ",".join(kinds))
ok("work mode" in rt.handle_command("my routines", "en"), "routines list")

# ---------------------------------------------------------------- screen awareness trigger
for q in ["what's on my screen", "screen par kya hai", "analyze my screen please", "is screen ko samjhao", "स्क्रीन पर क्या है"]:
    ok(bool(vision.SCREEN_Q.search(q)), "screen question: " + q)
ok(not vision.SCREEN_Q.search("open chrome") and not vision.SCREEN_Q.search("tell me a story"), "normal chat is not a screen question")
from PIL import Image
with mock.patch("PIL.ImageGrab.grab", lambda **kw: Image.new("RGB", (3000, 1800), "blue")):
    png = vision.capture_png()
    ok(png[:4] == b"\x89PNG" and Image.open(io.BytesIO(png)).size[0] <= 1280, "screenshot captured and downscaled")
print("ALL OK")
