"""Headless smoke test of the UI/controller wiring using a fake Qt. Run: python tests/test_ui_smoke.py"""
import os, sys, pathlib, tempfile, time, unittest
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "tests" / "fakeqt"))
os.environ["APPDATA"] = tempfile.mkdtemp()
import qtfake
STATE = qtfake.install()
from unittest import mock
from app import config
from app.system import winapi
from app.system.winapi import WindowInfo


class Smoke(unittest.TestCase):
    def setUp(self):
        mock.patch("app.voice.tts.speak").start(); self.addCleanup(mock.patch.stopall)
        self.cfg = config.load_config(); self.cfg.update(user_name="Suraj", assistant_name="Aiko", setup_complete=True)

    def make(self):
        from app.controller import Assistant
        from app.ui.pet_window import PetWindow
        asst = Assistant(self.cfg)
        return asst, PetWindow(self.cfg, asst)

    def run_ticks(self, win, n, dt=1 / 30):
        t = [time.time()]
        with mock.patch("app.ui.pet_window.time.time", side_effect=lambda: t.__setitem__(0, t[0] + dt) or t[0]):
            for _ in range(n):
                win._tick()

    def test_pet_falls_to_taskbar_and_walks(self):
        with mock.patch.object(winapi, "IS_WIN", False):
            asst, win = self.make()
            self.run_ticks(win, 900)
        self.assertEqual(win.brain.surface_id, "ground")
        self.assertAlmostEqual(win.brain.y, 1040, delta=1)
        self.assertGreater(win.y(), 500)                    # window really moved down

    def test_jumps_onto_window_where_cursor_rests(self):
        import random
        random.seed(3)
        wins = [WindowInfo(777, "main.py - Visual Studio Code", "code.exe", 5, 300, 400, 1500, 900)]
        STATE["cursor"] = qtfake.Pt(800, 600)
        with mock.patch.object(winapi, "list_windows", return_value=wins), \
             mock.patch.object(winapi, "foreground", return_value=wins[0]), \
             mock.patch.object(winapi, "window_at", return_value=wins[0]), \
             mock.patch.object(winapi, "cursor_native", return_value=(800, 600)), \
             mock.patch.object(winapi, "idle_seconds", return_value=0.0):
            asst, win = self.make()
            spoken = []
            asst.say_auto = lambda text, emo="happy", force=False: spoken.append(text)
            asst.chatter.rng = type("R", (), {"random": lambda self: 0.0, "choice": __import__("random").choice, "uniform": lambda self, a, b: a})()
            self.run_ticks(win, 900)
        self.assertEqual(win.brain.surface_id, "777")
        self.assertAlmostEqual(win.brain.y, 400, delta=1)
        self.assertTrue(any("VS Code" in s for s in spoken), spoken)
        self.assertTrue(asst.tracker.recent(1) or True)

    def test_update_runner_background_and_manual(self):
        import pathlib as P, zipfile, time as T
        from app.controller import UpdateRunner
        from app.core import updater
        d = P.Path(tempfile.mkdtemp()); z = d / "HybridAnimeAI-98.0.0.zip"
        with zipfile.ZipFile(z, "w") as f:
            f.writestr("HybridAnimeAI.exe", "x")
        updater.clear_pending()
        r = UpdateRunner(lambda: {})
        got = {"ready": [], "now": [], "fail": []}
        r.ready.connect(lambda a, b: got["ready"].append(b)); r.restart_needed.connect(lambda a, b: got["now"].append(b))
        r.failed.connect(lambda m: got["fail"].append(m))
        with mock.patch.object(updater, "updates_enabled", return_value=True), \
             mock.patch.object(updater, "check_for_update", side_effect=AssertionError("must not hit network")):
            content, ver = updater.stage_local_zip(z); updater.save_pending(content, ver)
            r._run(manual=False)                      # silent -> ready, not installed
            self.assertEqual((got["ready"], got["now"]), (["98.0.0"], []))
            r._run(manual=True)                       # user asked -> install now
            self.assertEqual(got["now"], ["98.0.0"])
        with mock.patch.object(updater, "updates_enabled", return_value=True), \
             mock.patch.object(updater, "check_for_update", side_effect=RuntimeError("offline")):
            updater.clear_pending(); r._run(manual=False)   # offline + silent: no error popup
            self.assertEqual(got["fail"], [])
        updater.clear_pending()

    def test_drag_and_release(self):
        with mock.patch.object(winapi, "IS_WIN", False):
            asst, win = self.make(); self.run_ticks(win, 200)
        ev = lambda x, y: mock.Mock(globalPosition=lambda: qtfake.Pt(x, y), button=lambda: qtfake.EnumNS("L"))
        from PyQt6.QtCore import Qt
        L = Qt.MouseButton.LeftButton
        mk = lambda x, y: type("E", (), {"globalPosition": lambda s: qtfake.Pt(x, y), "button": lambda s: L, "buttons": lambda s: L, "accept": lambda s: None})()
        win.mousePressEvent(mk(win.x() + 50, win.y() + 100))
        win.mouseMoveEvent(mk(win.x() + 120, win.y() + 40))
        self.assertEqual(win.brain.mode, "held")
        win.mouseReleaseEvent(mk(0, 0))
        self.assertEqual(win.brain.mode, "fall")

    def test_assistant_pipeline_local_command(self):
        with mock.patch.object(winapi, "IS_WIN", False):
            asst, win = self.make()
        got = []
        asst.reply_ready.connect(lambda t, m, e: got.append((t, m, e)))
        with mock.patch("app.controller.Assistant._speak"):
            asst._process("what time is it", "en")
            asst._process("what was I doing", "en")
            asst._process("remind me in 10 minutes to drink water", "en")
        self.assertEqual(got[0][1], "system"); self.assertIn("It's", got[0][0])
        self.assertIn("working", got[1][0] + "haven't")   # either journal answer or 'haven't noticed'
        self.assertIn("remind you in 10 minutes", got[2][0])

    def test_ai_engine_offline_uses_ollama_and_emotion_tag(self):
        from app.core import ai_engine
        eng = ai_engine.AIEngine(dict(self.cfg, gemini_api_key=""))
        with mock.patch.object(ai_engine, "is_online", return_value=False), \
             mock.patch.object(ai_engine.ollama_manager, "ensure_server", return_value=True), \
             mock.patch.object(ai_engine.ollama_manager, "model_present", return_value=True), \
             mock.patch.object(ai_engine.requests, "post") as post:
            post.return_value.json.return_value = {"message": {"content": "[love] Aww, thank you!"}}
            r = eng.ask("tum bahut acchi ho", "hinglish")
        self.assertEqual((r.text, r.mode, r.emotion), ("Aww, thank you!", "local", "love"))
        self.assertIn("Hinglish", post.call_args.kwargs["json"]["messages"][0]["content"])

    def test_settings_dialog_saves(self):
        from app.ui.settings_dialog import SettingsDialog
        with mock.patch("app.voice.tts.list_voices", return_value=[]), mock.patch("app.voice.mic.list_input_devices", return_value=[]):
            d = SettingsDialog(dict(self.cfg, user_name=""), None, first_run=True)
            d._save()
            self.assertIsNone(d.result_config)              # name missing -> rejected
            d.user_edit.text = lambda: "Suraj"; d.assistant_edit.text = lambda: "Aiko"
            d._save()
        self.assertTrue(d.result_config["setup_complete"])

if __name__ == "__main__":
    unittest.main()
