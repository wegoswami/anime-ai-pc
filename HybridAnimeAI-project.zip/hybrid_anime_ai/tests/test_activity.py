"""Gestures: every kind of work has a prop, a body gesture, an emotion and labels; guesses are sane; the controller announces activity."""
import math, sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "tests" / "qtshim"))
from app.core import activity as A
from app.avatar.state import EMOTIONS

fails = 0
def ok(c, m):
    global fails
    print(("ok   " if c else "FAIL ") + m); fails += (not c)

ok(all(k in A.ACTS and len(A.ACTS[k]) == 4 for k in A.ACTS), "every activity has icon, gesture, emotion, labels")
ok(all(A.ACTS[k][2] in EMOTIONS for k in A.ACTS), "every activity maps to a real face")
for text, want in [("google pe python search karo", "search"), ("aaj ki news batao", "news"), ("kal 5 baje yaad dilao", "remind"), ("mom ko whatsapp likho: late", "write"),
                   ("mausam kaisa hai", "weather"), ("2+2*5", "calc"), ("call 9876543210", "call"), ("whatsapp call record karo", "record"), ("gaana chalao", "music"),
                   ("pc cleaner chalao", "clean"), ("kaise ho tum", None), ("tum kaun ho", None)]:
    ok(A.guess(text) == want, f"guess({text!r}) = {want}")
gs = {v[1] for v in A.ACTS.values()}
for g in gs:
    for t in (0.0, 0.3, 1.7, 9.9):
        v = A.gesture_xform(g, t)
        ok(len(v) == 5 and all(isinstance(x, (int, float)) and math.isfinite(x) for x in v) and 0.9 < v[3] < 1.1 and 0.9 < v[4] < 1.1 and abs(v[2]) < 12 and abs(v[1]) < 30, f"gesture {g} at {t}s is gentle and finite") if t == 0.3 else None
ok(A.gesture_xform("none", 1) == (0, 0, 0, 1, 1), "unknown gesture = standing still")
ok(A.label("search", 1) != A.label("search", 1, 1), "label rotates")
ok("slow" in A.label("search", 20) and "time lag" in A.label("search", 8), "long waits explain themselves")
ok(A.label("done", 3) == "Ho gaya!", "done label")
sys.exit(1 if fails else 0)
