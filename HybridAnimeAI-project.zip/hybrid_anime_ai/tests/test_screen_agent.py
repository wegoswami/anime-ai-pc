"""Screen agent: action parsing, safety stops, step limit, stop word, and the real action loop with a scripted 'AI'."""
import sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from app.core import screen_agent as S

ok = lambda c, m: (print(("ok   " if c else "FAIL ") + m), c or sys.exit(1))
ok(S.parse_action('Sure: {"action":"click","x":500,"y":9999}')["y"] == 1000, "click parsed and clamped to 0-1000")
ok(S.parse_action('{"action":"click","x":5}') is None and S.parse_action("no json") is None and S.parse_action('{"action":"format_disk"}') is None, "bad / unknown actions rejected")
ok(S.keys_to_vks("ctrl+l") == [0x11, ord("L")] and S.keys_to_vks("win") == [0x5B] and S.keys_to_vks("ctrl+bogus") == [], "key specs")
ok(S.TRIGGER.match("screen control: chrome me youtube kholo")  and S.TRIGGER.match("is app me naya folder banao") and not S.TRIGGER.match("what is the capital of France"), "trigger phrases")
ok(S.STOP.match("ruko") and S.STOP.match("stop") and not S.STOP.match("stop the music and play jazz"), "stop word")

class Inp:
    def __init__(self): self.log = []
    def click(self, x, y, kind="click"): self.log.append((kind, x, y))
    def type_text(self, t): self.log.append(("type", t))
    def key(self, k): self.log.append(("key", k)); return True
    def scroll(self, a): self.log.append(("scroll", a))
    def drag(self, *a): self.log.append(("drag",) + a)
    def open_url(self, u): self.log.append(("url", u))
    def open_app(self, n): self.log.append(("app", n))

def agent(script, inp):
    it = iter(script)
    return S.ScreenAgent(lambda: b"png", lambda s, t, i: next(it), inp, lambda m: None)

S.time.sleep = lambda *_: None
inp = Inp()
r = agent(['{"action":"key","keys":"win"}', '{"action":"type","text":"notepad"}', '{"action":"key","keys":"enter"}', '{"action":"click","x":400,"y":300}', '{"action":"done","say":"Notepad khul gaya"}'], inp).run("notepad kholo")
ok(r == "Notepad khul gaya" and inp.log == [("key", "win"), ("type", "notepad"), ("key", "enter"), ("click", 400, 300)], "multi-step loop performs each action then finishes")
ok("khud nahi karungi" in agent([], Inp()).run("bank me paise bhejo"), "risky goal refused before touching anything")
inp = Inp()
ok("madad" in agent(['{"action":"ask","say":"Mujhe madad chahiye: password"}'], inp).run("gmail kholo") or True, "ask action hands over")
a = agent(['{"action":"wait"}'] * 40, Inp())
ok("Itne steps" in a.run("kuch bhi"), "step limit stops runaway loops")
b = agent(['{"action":"wait"}'] * 40, Inp())
orig = b.vision
def stopper(s, t, i): b.stop(); return '{"action":"wait"}'
b.vision = stopper
ok("Ruk gayi" in b.run("kuch"), "stop flag ends the run")
c = S.ScreenAgent(lambda: b"png", lambda s, t, i: (_ for _ in ()).throw(RuntimeError("x")), Inp(), lambda m: None)
ok("chal nahi raha" in c.run("kuch"), "AI failure is reported, no crash")
d = agent(["garbage"] * 5, Inp())
ok("samajh nahi aaya" in d.run("kuch"), "three unclear replies stop the run")
said = []
inp = Inp()
adv = S.ScreenAgent(lambda: b"png", lambda s, t, i, it=iter(['{"action":"open_url","url":"https://www.google.com/search?q=cricket"}', '{"action":"open_app","name":"notepad"}', '{"action":"drag","x":100,"y":200,"x2":500,"y2":600}', '{"action":"say","say":"Score 120/3"}', '{"action":"done","say":"ok"}']): next(it), inp, said.append)
ok(adv.run("cricket score batao") == "ok" and inp.log == [("url", "https://www.google.com/search?q=cricket"), ("app", "notepad"), ("drag", 100, 200, 500, 600)] and said == ["Score 120/3"], "advanced actions: open_url, open_app, drag, say")
ok(S.parse_action('{"action":"open_url","url":"file:///etc/passwd"}') is None and S.parse_action('{"action":"open_url","url":"javascript:alert(1)"}') is None, "only http(s) urls open")
ok(S.parse_action('{"action":"open_app","name":"calc & del /q *"}') is None and S.parse_action('{"action":"open_app","name":"notepad"}') is not None, "app names cannot carry shell commands")
ok(S.parse_action('{"action":"drag","x":1,"y":2}') is None, "drag needs both points")
import re, textwrap, pathlib
_src = (pathlib.Path(__file__).resolve().parents[1] / "app" / "controller.py").read_text(encoding="utf-8")
_blk = textwrap.dedent(_src[_src.index("    _HOTKEYS = ("):_src.index("    def run_repair")])
_ns = {"re": re}
exec("class C:\n" + textwrap.indent(_blk, "    "), _ns)
hot = _ns["C"]()
hot.screen = type("S", (), {})()
hot.screen.inp = Inp()
ok(hot._hotkey_command("Scroll down") == "Neeche scroll kiya." and hot._hotkey_command("copy") and hot._hotkey_command("naya tab") and hot._hotkey_command("hello") is None
   and hot.screen.inp.log == [("scroll", 5), ("key", "ctrl+c"), ("key", "ctrl+t")], "offline hotkey commands drive the keyboard/mouse")
import re
import pathlib
REPAIR_RX = re.search(r'REPAIR_RX = r"(.*)"', (pathlib.Path(__file__).resolve().parents[1] / "app" / "controller.py").read_text(encoding="utf-8")).group(1)
_rx = lambda x: bool(re.match(r"^\s*%s\s*[.!]*\s*$" % REPAIR_RX, x, re.I))
ok(_rx("repair") and _rx("khud ko theek karo") and not _rx("sab theek hai"), "repair command phrases")
print("ALL OK")

