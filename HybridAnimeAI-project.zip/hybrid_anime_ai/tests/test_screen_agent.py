"""Screen agent: action parsing, safety stops, step limit, stop word, and the real action loop with a scripted 'AI'."""
import sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from app.core import screen_agent as S

ok = lambda c, m: (print(("ok   " if c else "FAIL ") + m), c or sys.exit(1))
ok(S.parse_action('Sure: {"action":"click","x":500,"y":9999}')["y"] == 1000, "click parsed and clamped to 0-1000")
ok(S.parse_action('{"action":"click","x":5}') is None and S.parse_action("no json") is None and S.parse_action('{"action":"format_disk"}') is None, "bad / unknown actions rejected")
ok(S.keys_to_vks("ctrl+l") == [0x11, ord("L")] and S.keys_to_vks("win") == [0x5B] and S.keys_to_vks("ctrl+bogus") == [], "key specs")
ok(S.TRIGGER.match("screen control: chrome me youtube kholo")  and S.TRIGGER.match("is app me naya folder banao") and not S.TRIGGER.match("what is the capital of France"), "trigger phrases")
ok(S.STOP.match("ruko") and S.STOP.match("stop") and not S.STOP.match("stop the music and play jazz"), "stop word")

class Inp:
    def __init__(self): self.log = []
    def click(self, x, y, kind="click"): self.log.append((kind, x, y))
    def type_text(self, t): self.log.append(("type", t))
    def key(self, k): self.log.append(("key", k)); return True
    def scroll(self, a): self.log.append(("scroll", a))

def agent(script, inp):
    it = iter(script)
    return S.ScreenAgent(lambda: b"png", lambda s, t, i: next(it), inp, lambda m: None)

S.time.sleep = lambda *_: None
inp = Inp()
r = agent(['{"action":"key","keys":"win"}', '{"action":"type","text":"notepad"}', '{"action":"key","keys":"enter"}', '{"action":"click","x":400,"y":300}', '{"action":"done","say":"Notepad khul gaya"}'], inp).run("notepad kholo")
ok(r == "Notepad khul gaya" and inp.log == [("key", "win"), ("type", "notepad"), ("key", "enter"), ("click", 400, 300)], "multi-step loop performs each action then finishes")
ok("khud nahi karungi" in agent([], Inp()).run("bank me paise bhejo"), "risky goal refused before touching anything")
inp = Inp()
ok("madad" in agent(['{"action":"ask","say":"Mujhe madad chahiye: password"}'], inp).run("gmail kholo") or True, "ask action hands over")
a = agent(['{"action":"wait"}'] * 40, Inp())
ok("Itne steps" in a.run("kuch bhi"), "step limit stops runaway loops")
b = agent(['{"action":"wait"}'] * 40, Inp())
orig = b.vision
def stopper(s, t, i): b.stop(); return '{"action":"wait"}'
b.vision = stopper
ok("Ruk gayi" in b.run("kuch"), "stop flag ends the run")
c = S.ScreenAgent(lambda: b"png", lambda s, t, i: (_ for _ in ()).throw(RuntimeError("x")), Inp(), lambda m: None)
ok("chal nahi raha" in c.run("kuch"), "AI failure is reported, no crash")
d = agent(["garbage"] * 5, Inp())
ok("samajh nahi aaya" in d.run("kuch"), "three unclear replies stop the run")
import re
import pathlib
REPAIR_RX = re.search(r'REPAIR_RX = r"(.*)"', (pathlib.Path(__file__).resolve().parents[1] / "app" / "controller.py").read_text(encoding="utf-8")).group(1)
_rx = lambda x: bool(re.match(r"^\s*%s\s*[.!]*\s*$" % REPAIR_RX, x, re.I))
ok(_rx("repair") and _rx("khud ko theek karo") and not _rx("sab theek hai"), "repair command phrases")
print("ALL OK")

