import sys, pathlib, unittest
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import numpy as np
from app.voice.mic import Segmenter, to_16k
from app.voice import lang, tts


def tone(sec, amp, sr=16000, f=180):
    t = np.arange(int(sec * sr)) / sr
    return (amp * np.sin(2 * np.pi * f * t) * (0.6 + 0.4 * np.sin(2 * np.pi * 4 * t))).astype(np.float32)


def noise(sec, amp, sr=16000):
    rng = np.random.default_rng(1)
    return (rng.standard_normal(int(sec * sr)) * amp).astype(np.float32)


def feed_all(seg, x, sr=16000):
    n, out = int(sr * 0.03), []
    for i in range(0, len(x) - n + 1, n):
        r = seg.feed(x[i:i + n])
        if r is not None:
            out.append(r)
    return out


class VadTests(unittest.TestCase):
    def test_detects_one_phrase_with_preroll(self):
        sig = np.concatenate([noise(1.0, 0.003), tone(1.4, 0.25), noise(1.5, 0.003)])
        got = feed_all(Segmenter(), sig)
        self.assertEqual(len(got), 1)
        self.assertTrue(1.4 < len(got[0]) / 16000 < 3.0, len(got[0]) / 16000)

    def test_ignores_silence_and_clicks(self):
        sig = np.concatenate([noise(2.0, 0.004), tone(0.06, 0.4), noise(2.0, 0.004)])
        self.assertEqual(feed_all(Segmenter(), sig), [])

    def test_two_phrases(self):
        sig = np.concatenate([noise(0.6, 0.003), tone(1.0, 0.2), noise(1.3, 0.003), tone(1.2, 0.2), noise(1.3, 0.003)])
        self.assertEqual(len(feed_all(Segmenter(), sig)), 2)

    def test_noisy_room_still_works(self):
        sig = np.concatenate([noise(1.0, 0.01), tone(1.2, 0.3) + noise(1.2, 0.01), noise(1.5, 0.01)])
        self.assertEqual(len(feed_all(Segmenter(), sig)), 1)

    def test_resample(self):
        x = tone(1.0, 0.3, sr=48000)
        y = to_16k(x, 48000)
        self.assertEqual(len(y), 16000)


class LangTests(unittest.TestCase):
    def test_detect(self):
        self.assertEqual(lang.detect_lang("मुझे नोटपैड खोलो"), "hi")
        self.assertEqual(lang.detect_lang("bhai notepad kholo na"), "hinglish")
        self.assertEqual(lang.detect_lang("open the calculator please"), "en")
        self.assertEqual(lang.detect_lang("こんにちは"), "ja")
        self.assertEqual(lang.detect_lang("hola amigo", "es"), "es")
        self.assertEqual(lang.line_lang("fr"), "en")
        self.assertEqual(lang.tts_lang("नमस्ते दोस्त", "en"), "hi")
        self.assertEqual(lang.tts_lang("Hello there", "hinglish"), "en")


class TtsTests(unittest.TestCase):
    V = [("TTS_MS_EN-US_ZIRA_11.0", "Microsoft Zira Desktop", "en-US"),
         ("TTS_MS_EN-US_DAVID_11.0", "Microsoft David Desktop", "en-US"),
         ("TTS_MS_HI-IN_KALPANA_11.0", "Microsoft Kalpana Desktop", "hi-IN"),
         ("TTS_MS_HI-IN_HEMANT_11.0", "Microsoft Hemant Desktop", "hi-IN")]

    def test_locale_parse(self):
        self.assertEqual(tts._locale_of("HKEY\\Tokens\\TTS_MS_HI-IN_KALPANA_11.0", "x"), "hi-IN")

    def test_pick(self):
        self.assertEqual(tts.pick_voice(self.V, "hi", "male", ""), "TTS_MS_HI-IN_HEMANT_11.0")
        self.assertEqual(tts.pick_voice(self.V, "hi", "female", ""), "TTS_MS_HI-IN_KALPANA_11.0")
        self.assertEqual(tts.pick_voice(self.V, "en", "male", ""), "TTS_MS_EN-US_DAVID_11.0")
        self.assertEqual(tts.pick_voice(self.V, "en", "female", "TTS_MS_EN-US_DAVID_11.0"), "TTS_MS_EN-US_DAVID_11.0")
        self.assertEqual(tts.pick_voice(self.V, "ja", "female", "TTS_MS_EN-US_ZIRA_11.0"), "TTS_MS_EN-US_ZIRA_11.0")

if __name__ == "__main__":
    unittest.main()
