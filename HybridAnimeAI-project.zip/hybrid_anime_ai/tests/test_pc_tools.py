"""Files, documents (docx/pdf/csv), system info, multi-step splitting, plan parsing."""
import os, sys, tempfile, zipfile
from pathlib import Path

root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root))
home = tempfile.mkdtemp()
os.environ["HOME"] = home
os.environ["USERPROFILE"] = home
from app.core import pc_tools as P

ok = lambda c, m: (print(("ok   " if c else "FAIL ") + m), c or sys.exit(1))
t = P.PCTools()
r = t.try_execute("create folder Projects on desktop")
ok(Path(home, "Desktop", "Projects").is_dir() and "bana diya" in r, "create folder")
r = t.try_execute("create file notes.txt on desktop with buy milk")
ok(Path(home, "Desktop", "notes.txt").read_text() == "buy milk", "create file with text")
ok("notes.txt" in t.try_execute("list desktop"), "list folder")
ok("notes" in t.try_execute("find file notes"), "find file")
ok(t.try_execute("create folder ../../evil") is not None and not Path(home).parent.joinpath("evil").exists(), "path traversal blocked")
Path(home, "Downloads").mkdir(); Path(home, "Downloads", "report.txt").write_text("x")
ok("move ho gayi" in t.try_execute("move report to desktop") and Path(home, "Desktop", "report.txt").exists(), "move file")
ok("Recycle Bin" in t.try_execute("delete notes.txt") and t._pending, "delete asks for confirmation first")
ok(Path(home, "Desktop", "notes.txt").exists(), "nothing deleted before 'haan'")
ok("delete nahi kiya" in t.try_execute("nahi"), "delete can be cancelled")
ok(t.try_execute("delete task 2") is None, "'delete task' is not a file delete")
ok("RAM" in t.try_execute("pc ki halat batao") and "Disk" in t.try_execute("system info"), "system info")
ok(t.try_execute("Ram ji ki kahani sunao") is None and t.try_execute("what is the capital of France") is None, "normal chat is not hijacked")

# documents
d = P.create_document("docx", "Meeting Notes", "Line one\nLine two & <more>")
with zipfile.ZipFile(d) as z:
    ok("Line two &amp; &lt;more&gt;" in z.read("word/document.xml").decode() and z.testzip() is None, "docx is a valid zip with escaped text")
pdf = P.create_document("pdf", "Report", "Hello world\n" + "word " * 60 * 30)
b = pdf.read_bytes()
ok(b.startswith(b"%PDF-1.4") and b.rstrip().endswith(b"%%EOF") and b.count(b"/Type /Page ") >= 2, "pdf has header, trailer and several pages")
try:
    P.create_document("pdf", "Hindi", "नमस्ते"); ok(False, "hindi pdf")
except ValueError:
    ok(True, "non-Latin text refuses the simple PDF (caller falls back to docx)")
c = P.create_document("csv", "Table", "Name|Age\nRahul|20")
ok("Rahul,20" in c.read_text(encoding="utf-8-sig"), "csv table")
ok(P.create_document("txt", "Table", "x").name == "Table.txt" and P.create_document("csv", "Table", "a|b").name == "Table (2).csv", "unique file names")
ok(P.doc_request("word file banao: meri company ka introduction") == ("docx", "meri company ka introduction"), "doc request: word")
ok(P.doc_request("create a pdf about solar energy")[0] == "pdf" and P.doc_request("what is a pdf") is None, "doc request: pdf, no false positive")

# multi-step
ok(P.split_steps("open chrome phir youtube search karo lofi") == ["open chrome", "youtube search karo lofi"], "split on 'phir'")
ok(len(P.split_steps("open notepad and then open calculator, then volume 30")) == 3, "split on 'and then' and ','")
ok(P.split_steps("open chrome aur search python tutorial") == ["open chrome", "search python tutorial"], "'aur' splits only before a verb")
ok(P.split_steps("tell me about salt and pepper") == [] and P.split_steps("what is the difference between java and python") == [], "plain sentences are not split")
ok(P.parse_plan('Here: ["open chrome", "search lofi", "shutdown now", "volume 30"]') == ["open chrome", "search lofi", "volume 30"], "plan parsing drops dangerous steps")
ok(P.parse_plan("no json") == [] and P.parse_plan("[1,2]") == [], "bad plan -> empty")
print("ALL OK")
