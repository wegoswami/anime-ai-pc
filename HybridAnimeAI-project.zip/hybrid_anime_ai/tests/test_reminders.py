import sys
from datetime import datetime
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.core import reminders as r

def ok(c, m):
    print(("ok   " if c else "FAIL ") + m)
    if not c:
        raise SystemExit(1)

now = datetime(2026, 11, 17, 12, 0)
def mins(t):
    x = r.parse_clock(t, now) if not r._DUR.search(t) else r.parse(t)
    return (round(x[0] / 60), x[1]) if x else None

ok(mins("remind me in 5 minutes to drink water") == (5, "drink water"), "in 5 minutes")
ok(mins("10 minute baad chai yaad dilana") == (10, "chai"), "hinglish delay")
ok(mins("remind me at 6 pm to call mom") == (360, "call mom"), "at 6 pm")
ok(mins("set an alarm for 6 am")[0] == 1080, "alarm for 6 am -> next morning")
ok(mins("remind me tomorrow at 9 to call dad") == (1260, "call dad"), "tomorrow at 9")
ok(mins("kal subah 7 baje alarm")[0] == 1140, "kal subah 7 baje")
ok(mins("wake me up at 6")[0] == 1080, "wake me up")
ok(r.parse("what time is it") is None and r.parse("open chrome") is None, "normal sentences ignored")
print("ALL OK")
