"""A minimal fake of PyQt6 so the UI code (pet window, settings dialog, controller) can run headless in tests.

It checks OUR logic (names, wiring, brain<->window integration) - not real Qt behaviour.
"""
import sys
import types


class EnumNS:
    """Qt.Something.Anything -> cached child objects that support | and &."""
    def __init__(self, name=""):
        self._n, self._kids = name, {}

    def __getattr__(self, item):
        if item.startswith("__"):
            raise AttributeError(item)
        return self._kids.setdefault(item, EnumNS(f"{self._n}.{item}"))

    def __or__(self, o): return self
    def __ror__(self, o): return self
    def __and__(self, o): return self
    def __repr__(self): return self._n
    def __call__(self, *a, **k): return EnumNS(self._n + "()")


class StubMeta(type):
    def __getattr__(cls, item):
        if item.startswith("__"):
            raise AttributeError(item)
        return EnumNS(f"{cls.__name__}.{item}")


class _Bound:
    def __init__(self): self.slots = []
    def connect(self, f): self.slots.append(f)
    def disconnect(self, *a): self.slots.clear()
    def emit(self, *a):
        for f in list(self.slots):
            try:
                f(*a)
            except TypeError:
                f()


class pyqtSignal:
    def __init__(self, *a): self.name = None
    def __set_name__(self, owner, name): self.name = name
    def __get__(self, obj, owner):
        if obj is None:
            return self
        return obj.__dict__.setdefault("_sigs", {}).setdefault(self.name, _Bound())


class Stub(metaclass=StubMeta):
    def __init__(self, *a, **k):
        self.__dict__.setdefault("_props", {})
    def __getattr__(self, item):
        if item.startswith("__") or item in ("_sigs", "_props"):
            raise AttributeError(item)
        sig = self.__dict__.setdefault("_sigs", {})
        if item in ("timeout", "triggered", "clicked", "activated", "returnPressed", "valueChanged",
                    "currentIndexChanged", "accepted", "rejected", "aboutToShow", "aboutToQuit", "frameChanged"):
            return sig.setdefault(item, _Bound())
        if item in ("findData", "findText", "currentIndex", "count"):
            return lambda *a, **k: 0
        if item in ("currentData", "currentItem"):
            return lambda *a, **k: None
        if item in ("text", "toPlainText"):
            return lambda *a, **k: ""
        if item in ("isChecked",):
            return lambda *a, **k: False
        if item == "value":
            return lambda *a, **k: 100
        return lambda *a, **k: Stub()
    def __call__(self, *a, **k): return Stub()
    def __iter__(self): return iter(())
    def __or__(self, o): return self


class Pt:
    def __init__(self, x=0, y=0): self._x, self._y = int(x), int(y)
    def x(self): return self._x
    def y(self): return self._y
    def __sub__(self, o): return Pt(self._x - o._x, self._y - o._y)
    def __add__(self, o): return Pt(self._x + o._x, self._y + o._y)
    def manhattanLength(self): return abs(self._x) + abs(self._y)
    def toPoint(self): return self


class Rect:
    def __init__(self, x, y, w, h): self._r = (x, y, w, h)
    def x(self): return self._r[0]
    def y(self): return self._r[1]
    def width(self): return self._r[2]
    def height(self): return self._r[3]
    def left(self): return self._r[0]
    def top(self): return self._r[1]
    def right(self): return self._r[0] + self._r[2] - 1
    def bottom(self): return self._r[1] + self._r[3] - 1
    def topLeft(self): return Pt(self._r[0], self._r[1])
    def contains(self, p): return self.left() <= p.x() <= self.right() and self.top() <= p.y() <= self.bottom()


class FakeScreen:
    def __init__(self, w=1920, h=1080, bar=40): self.w, self.h, self.bar = w, h, bar
    def availableGeometry(self): return Rect(0, 0, self.w, self.h - self.bar)
    def geometry(self): return Rect(0, 0, self.w, self.h)
    def devicePixelRatio(self): return 1.0


STATE = {"cursor": Pt(500, 500), "screens": [FakeScreen()]}


class QGuiApplication(Stub):
    @staticmethod
    def screenAt(p): return STATE["screens"][0]
    @staticmethod
    def primaryScreen(): return STATE["screens"][0]
    @staticmethod
    def screens(): return STATE["screens"]


class QCursor(Stub):
    @staticmethod
    def pos(): return STATE["cursor"]


class QObject(Stub):
    def __init__(self, *a, **k):
        super().__init__()


class QTimer(QObject):
    def __init__(self, *a, **k): super().__init__()
    def start(self, *a): pass
    def stop(self): pass


class QWidget(QObject):
    def __init__(self, *a, **k):
        super().__init__()
        self._g, self._vis, self._cur = [0, 0, 100, 100], False, None
    def x(self): return self._g[0]
    def y(self): return self._g[1]
    def width(self): return self._g[2]
    def height(self): return self._g[3]
    def move(self, *a):
        if len(a) == 1:
            self._g[0], self._g[1] = a[0].x(), a[0].y()
        else:
            self._g[0], self._g[1] = int(a[0]), int(a[1])
    def resize(self, w, h): self._g[2], self._g[3] = w, h
    def setGeometry(self, x, y, w, h): self._g = [x, y, w, h]
    def setFixedWidth(self, w): self._g[2] = w
    def frameGeometry(self): return Rect(*self._g)
    def isVisible(self): return self._vis
    def show(self): self._vis = True
    def hide(self): self._vis = False
    def sizeHint(self): return Rect(0, 0, 120, 40)
    def setCursor(self, c): self._cur = c


class QDialog(QWidget):
    def exec(self): return 1
    def accept(self): self._accepted = True
    def reject(self): self._accepted = False


class QPoint(Pt):
    pass


class QFile:
    pass


def install():
    """Replace PyQt6 in sys.modules with the fake."""
    core = types.ModuleType("PyQt6.QtCore")
    gui = types.ModuleType("PyQt6.QtGui")
    widgets = types.ModuleType("PyQt6.QtWidgets")
    cache = {}

    def gen(mod):
        def __getattr__(name):
            if name.startswith("__"):
                raise AttributeError(name)
            return cache.setdefault((mod.__name__, name), type(name, (Stub,), {}))
        return __getattr__

    for m in (core, gui, widgets):
        m.__getattr__ = gen(m)
    core.Qt = EnumNS("Qt")
    core.pyqtSignal = pyqtSignal
    core.QObject, core.QTimer, core.QPoint = QObject, QTimer, QPoint
    core.QPointF = type("QPointF", (Stub,), {})
    core.QRectF = type("QRectF", (Stub,), {})
    gui.QGuiApplication, gui.QCursor = QGuiApplication, QCursor
    widgets.QWidget, widgets.QDialog = QWidget, QDialog
    pkg = types.ModuleType("PyQt6")
    pkg.QtCore, pkg.QtGui, pkg.QtWidgets = core, gui, widgets
    sys.modules.update({"PyQt6": pkg, "PyQt6.QtCore": core, "PyQt6.QtGui": gui, "PyQt6.QtWidgets": widgets})
    return STATE
