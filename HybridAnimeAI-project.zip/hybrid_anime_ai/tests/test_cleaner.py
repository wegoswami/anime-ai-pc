import os, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.core import cleaner as C

def ok(c, m):
    print(("ok   " if c else "FAIL ") + m)
    if not c:
        raise SystemExit(1)

d = Path(tempfile.mkdtemp()); (d / "sub").mkdir()
old = d / "a.tmp"; old.write_bytes(b"x" * 2048)
new = d / "sub" / "b.tmp"; new.write_bytes(b"y" * 100)
t = time.time() - 3 * 86400; os.utime(old, (t, t))
c = C.Cleaner(roots={"Temp files": d})
r = c.try_execute("pc clean karo")
ok("Safai kar du" in r and old.exists(), "scan previews and deletes nothing yet")
ok(c.try_execute("nahi") and old.exists(), "'nahi' cancels")
c.try_execute("speed badhao")
r = c.try_execute("haan")
ok(not old.exists() and new.exists(), "only old files removed, fresh ones kept")
ok("zaroori system" in c.try_execute("close explorer"), "system apps are protected")
ok(c.try_execute("downloads folder clean karo") is None, "folder requests are not treated as cleaner")
ok(c.try_execute("hello") is None, "other text ignored")
ok(C.human(1536) == "1.5 KB", "human sizes")
print("ALL OK")
