import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import unittest
from unittest import mock
from app.core import news

RSS = "<rss><channel><item><title>A &amp; B</title></item><item><title>Second</title></item></channel></rss>"


class NewsTest(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(news.parse_titles(RSS), ["A & B", "Second"])

    def test_trigger(self):
        for s in ("news", "aaj ki news batao", "latest news on cricket", "khabar sunao"):
            self.assertTrue(news.TRIGGER.match(s), s)
        self.assertFalse(news.TRIGGER.match("news channel kholo"))

    def test_reply_and_offline(self):
        with mock.patch.object(news, "fetch", return_value=["x", "y"]):
            self.assertIn("1. x", news.try_execute("news"))
        with mock.patch.object(news, "fetch", side_effect=OSError):
            self.assertIn("nahi la paayi", news.try_execute("news"))
        self.assertEqual(news.try_execute("hello"), "")


if __name__ == "__main__":
    unittest.main()
