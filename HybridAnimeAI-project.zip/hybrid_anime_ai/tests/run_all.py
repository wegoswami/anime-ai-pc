"""Run every headless test:  python tests/run_all.py"""
import pathlib, subprocess, sys
here = pathlib.Path(__file__).resolve().parent
files = ["test_voice_logic.py", "test_behavior.py", "test_automation.py", "test_ui_smoke.py", "test_importer.py", "test_updater.py", "test_brain_extras.py", "test_evolution.py", "test_pc_tools.py", "test_creatures.py", "test_screen_agent.py", "test_cleaner.py", "test_backup.py", "test_expenses.py", "test_license.py", "test_tutor.py", "test_reminders.py", "test_recorder.py", "test_tiers.py", "test_access.py", "test_adapt.py", "test_adapt_controller.py", "test_activity.py", "test_pack.py"]
bad = 0
for f in files:
    r = subprocess.run([sys.executable, str(here / f)], capture_output=True, text=True)
    ok = r.returncode == 0
    bad += not ok
    print(("PASS " if ok else "FAIL ") + f)
    if not ok:
        print(r.stdout[-1500:], r.stderr[-2500:])
sys.exit(1 if bad else 0)
