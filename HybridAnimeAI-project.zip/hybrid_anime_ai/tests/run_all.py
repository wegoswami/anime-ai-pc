"""Run every headless test:  python tests/run_all.py"""
import pathlib, subprocess, sys
here = pathlib.Path(__file__).resolve().parent
files = ["test_voice_logic.py", "test_behavior.py", "test_automation.py", "test_ui_smoke.py", "test_importer.py", "test_updater.py", "test_brain_extras.py"]
bad = 0
for f in files:
    r = subprocess.run([sys.executable, str(here / f)], capture_output=True, text=True)
    ok = r.returncode == 0
    bad += not ok
    print(("PASS " if ok else "FAIL ") + f)
    if not ok:
        print(r.stdout[-1500:], r.stderr[-2500:])
sys.exit(1 if bad else 0)
