"""Tier routing: Free = local only (once enforced), BYOK = own key, Managed = our server proxy."""
import sys, time, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from unittest import mock
from app import version as V
from app.core import license as lic, providers


def cfg(plan=None, tier="", key=""):
    c = {"gemini_api_key": key, "install_id": "x" * 16, "license_key": "EV-AAAA-BBBB-CCCC-DDDD" if plan else ""}
    if plan:
        c["license_cache"] = {"valid": True, "plan": plan, "tier": tier, "expires": 0, "checked": time.time()}
    return c


class R:
    def __init__(self, code, js): self.status_code, self._j = code, js
    def json(self): return self._j
    def raise_for_status(self):
        if self.status_code >= 400: raise RuntimeError(str(self.status_code))


fails = 0
def ok(c, m):
    global fails
    print(("ok   " if c else "FAIL ") + m); fails += (not c)


V.LICENSE_API = "https://api.test"
V.PRO_ENFORCED = True
ok(lic.tier(cfg()) == "free" and providers.available(cfg(key="k")) == [], "enforced: Free with a key still gets no cloud AI")
ok(lic.tier(cfg("byok_monthly", "byok")) == "byok" and providers.available(cfg("byok_monthly", "byok", "k")) == ["gemini"], "BYOK uses its own key")
m = cfg("managed_monthly", "managed")
ok(lic.managed(m) and providers.available(m) == ["gemini"], "Managed needs no key")
seen = {}
def post(url, json=None, **kw):
    seen["url"], seen["body"] = url, json
    return R(200, {"candidates": [{"content": {"parts": [{"text": "proxy ok"}]}}]})
with mock.patch("requests.post", post):
    out = providers.ask("gemini", m, "sys", [], "hello")
ok(out == "proxy ok" and seen["url"].endswith("/v1/ai") and seen["body"]["kind"] == "chat" and "key" in seen["body"] and "generativelanguage" not in seen["url"], "Managed request goes to our server, not Google")
with mock.patch("requests.post", lambda *a, **k: R(429, {})):
    try: providers.ask("gemini", m, "s", [], "hi"); e = ""
    except RuntimeError as x: e = str(x)
ok("limit khatam" in e, "daily quota gives a clear message")
V.PRO_ENFORCED = False
ok(providers.available(cfg(key="k")) == ["gemini"], "before launch everyone keeps cloud AI with their key")
# ---- support: tickets, announcements, replies, block
V.LICENSE_API = "https://api.test"
c = cfg()
said = []
class R2(R):
    pass
posts = []
def post2(url, json=None, **kw):
    posts.append((url, json))
    if url.endswith("/v1/ticket"):
        return R(200, {"ok": True, "ticket": 5})
    return R(200, {"ok": True, "blocked": False, "config": {"min_version": "99.0.0"}, "announcements": [{"id": 1, "body": "Naya feature"}], "tickets": [{"id": 5, "kind": "bug", "body": "crash hota hai", "status": "done", "reply": "fix ho gaya"}]})
with mock.patch("requests.post", post2), mock.patch("app.config.save_config", lambda c: None):
    ok("#5" in lic.send_ticket(c, "bug", "crash hota hai") and posts[-1][1]["platform"] == "pc", "PC can send a query/bug to the owner")
    lic.sync(c, said.append)
    ok(any("Naya feature" in x for x in said) and any("update kar lo" in x for x in said), "announcement + update notice shown")
    said.clear(); c["support_state"]["tk"]["5"] = "open|"; lic.sync(c, said.append)
    ok(any("fix ho gaya" in x for x in said), "owner's reply reaches the user")
    ok("done" in lic.tickets_text(c), "'meri requests' lists tickets")
with mock.patch("requests.post", lambda *a, **k: R(200, {"ok": True, "blocked": True, "config": {}, "announcements": [], "tickets": []})), mock.patch("app.config.save_config", lambda c: None):
    c2 = cfg("managed_monthly", "managed"); lic.sync(c2, lambda t: None)
    ok(c2["blocked"] and not lic.managed(c2) and not lic.cloud_ok(c2), "blocked install loses cloud/managed AI")
sys.exit(1 if fails else 0)
