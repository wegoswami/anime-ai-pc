import os, sys, pathlib, tempfile, unittest
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
os.environ["APPDATA"] = tempfile.mkdtemp()
from PIL import Image, ImageDraw
from app.avatar.importer import import_image
from app.characters import list_characters, delete_user_character
from app.paths import user_characters_dir


class ImporterTests(unittest.TestCase):
    def test_formats_and_background_removal(self):
        d = pathlib.Path(tempfile.mkdtemp())
        im = Image.new("RGB", (400, 500), "white"); dr = ImageDraw.Draw(im)
        dr.ellipse((100, 100, 300, 400), fill=(200, 40, 60))
        for ext in ("jpg", "png", "webp", "bmp", "tiff"):
            im.save(d / f"a.{ext}")
            s = import_image(str(d / f"a.{ext}"), "Hero " + ext, "boy")
            out = Image.open(user_characters_dir() / s["id"] / "avatar.png")
            self.assertEqual(out.mode, "RGBA")
            self.assertLess(out.getpixel((0, 0))[3], 30, ext)
            self.assertEqual(out.getpixel((out.width // 2, out.height // 2))[3], 255)
        frames = [Image.new("RGB", (80, 80), c) for c in ("red", "green", "blue")]
        frames[0].save(d / "a.gif", save_all=True, append_images=frames[1:], duration=100, loop=0)
        self.assertEqual(import_image(str(d / "a.gif"), "anim")["type"], "gif")

    def test_busy_background_kept_as_card(self):
        import random
        random.seed(1)
        im = Image.new("RGB", (300, 300))
        im.putdata([(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)) for _ in range(90000)])
        d = pathlib.Path(tempfile.mkdtemp()); im.save(d / "n.png")
        s = import_image(str(d / "n.png"), "noisy")
        out = Image.open(user_characters_dir() / s["id"] / "avatar.png")
        self.assertEqual(out.getpixel((150, 150))[3], 255)   # subject untouched
        self.assertLess(out.getpixel((0, 0))[3], 255)        # rounded soft corner

    def test_registry_and_delete(self):
        d = pathlib.Path(tempfile.mkdtemp()); Image.new("RGBA", (50, 50), (255, 0, 0, 255)).save(d / "p.png")
        s = import_image(str(d / "p.png"), "Mine", "girl")
        chars = {c["id"]: c for c in list_characters()}
        self.assertIn(s["id"], chars); self.assertFalse(chars[s["id"]]["builtin"])
        b = [c for c in chars.values() if c["builtin"]]
        self.assertGreaterEqual(len(b), 25)
        self.assertGreaterEqual(sum(1 for c in b if c["gender"] == "boy"), 10)
        self.assertGreaterEqual(sum(1 for c in b if c["gender"] == "girl"), 5)
        for c in b:
            if c["type"] == "image":
                self.assertTrue((pathlib.Path(c["dir"]) / c["file"]).exists(), c["id"])
        self.assertTrue(delete_user_character(s["id"])); self.assertNotIn(s["id"], {c["id"] for c in list_characters()})

if __name__ == "__main__":
    unittest.main()
