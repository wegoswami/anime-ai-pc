"""Every creature companion paints in every emotion and pose, and exposes original, complete character specs."""
import json, sys, pathlib, itertools
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tests" / "qtshim")); sys.path.insert(1, str(ROOT))
from PyQt6.QtGui import QPainter
from app.avatar.state import AvatarState, CANVAS_W, CANVAS_H, EMOTIONS, POSES
from app.avatar.factory import create_avatar
from app.avatar.creature import CreatureAvatar, SPECIES

ok = lambda c, m: (print(("ok   " if c else "FAIL ") + m), c or sys.exit(1))
specs = [json.loads(f.read_text()) for f in sorted((ROOT / "assets" / "characters").glob("*/character.json"))]
cre = [s for s in specs if s.get("type") == "creature"]
ok(len(cre) == 8 and {s["species"] for s in cre} == set(SPECIES), "8 creature characters, one per species")
for s in cre:
    av = create_avatar(s)
    ok(isinstance(av, CreatureAvatar), f"factory builds {s['id']}")
    for emo, pose in itertools.product(EMOTIONS, POSES):
        p = QPainter(int(CANVAS_W), int(CANVAS_H))
        av.paint(p, CANVAS_W, CANVAS_H, AvatarState(emotion=emo, pose=pose, t=2.1, walk_phase=1.2, mouth=0.6, speaking=True, blink=0.5, look=(0.5, -0.5)))
        assert "<svg" in p.to_svg()
    ok(True, f"{s['id']}: {len(EMOTIONS) * len(POSES)} emotion/pose combos paint")
    m = ROOT / "mobile" / "chars" / s["id"]
    ok(all((m / f"{n}.svg").exists() for n in ("neutral", "happy", "talk", "talk2", "walk1", "walk2", "sit", "sleep", "wave", "held", "listening", "love", "sad", "angry", "surprised", "thinking", "embarrassed", "sleepy", "confused")), f"{s['id']}: mobile sprites complete")
ok(not any(c.get("type") == "image" for c in specs), "no third-party image avatars remain")
mj = json.load(open(ROOT / "mobile" / "characters.json"))
ok({c["id"] for c in mj} == {s["id"] for s in specs}, "mobile and PC character lists match")
print("ALL OK")
