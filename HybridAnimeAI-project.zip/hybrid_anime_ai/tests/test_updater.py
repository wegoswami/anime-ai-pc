import os, sys, pathlib, tempfile, unittest, zipfile
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
os.environ["APPDATA"] = tempfile.mkdtemp()
from app import build_info
from app.core import updater
from app.version import APP_VERSION, UPDATE_MANIFEST_URL


def mkzip(path, files):
    with zipfile.ZipFile(path, "w") as z:
        for n, d in files.items():
            z.writestr(n, d)
    return pathlib.Path(path)


class UpdaterTests(unittest.TestCase):
    def test_manifest_url_priority(self):
        old = build_info.GITHUB_REPO
        try:
            build_info.GITHUB_REPO = ""
            self.assertEqual(updater.manifest_url(), UPDATE_MANIFEST_URL)
            build_info.GITHUB_REPO = "me/app"
            self.assertEqual(updater.manifest_url(), "https://github.com/me/app/releases/latest/download/version.json")
            self.assertEqual(updater.manifest_url(" https://x.y/v.json "), "https://x.y/v.json")
        finally:
            build_info.GITHUB_REPO = old

    def test_versions(self):
        self.assertEqual(updater.version_from_name("HybridAnimeAI-9.1.0.zip"), "9.1.0")
        self.assertGreater(updater.parse_version("2.10.0"), updater.parse_version("2.9.9"))

    def test_local_zip_stage_and_pending(self):
        d = pathlib.Path(tempfile.mkdtemp())
        z = mkzip(d / "HybridAnimeAI-99.0.0.zip", {"HybridAnimeAI.exe": "x", "_internal/a.dll": "y"})
        content, ver = updater.stage_local_zip(z)
        self.assertEqual(ver, "99.0.0")
        self.assertTrue((content / "HybridAnimeAI.exe").exists())
        self.assertTrue(z.exists())                       # copy=True keeps the user's file
        updater.save_pending(content, ver)
        self.assertEqual(updater.load_pending(), (content, "99.0.0"))
        updater.clear_pending()
        self.assertIsNone(updater.load_pending())

    def test_rejects_old_bad_and_unsafe(self):
        d = pathlib.Path(tempfile.mkdtemp())
        with self.assertRaises(updater.UpdateError):
            updater.stage_local_zip(mkzip(d / f"HybridAnimeAI-{APP_VERSION}.zip", {"a": "b"}))
        (d / "x.zip").write_text("not a zip")
        with self.assertRaises(updater.UpdateError):
            updater.stage_local_zip(d / "x.zip")
        with self.assertRaises(updater.UpdateError):
            updater.stage_local_zip(mkzip(d / "HybridAnimeAI-98.0.0.zip", {"../evil.txt": "x"}))

    def test_inbox_picks_newest(self):
        inbox = updater.inbox_dir()
        for v in ("97.0.0", "98.5.0", "1.0.0"):
            mkzip(inbox / f"HybridAnimeAI-{v}.zip", {"a": "b"})
        self.assertEqual(updater.find_inbox_update().name, "HybridAnimeAI-98.5.0.zip")

if __name__ == "__main__":
    unittest.main()
