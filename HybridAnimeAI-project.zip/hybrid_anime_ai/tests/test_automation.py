import sys, pathlib, unittest
from unittest import mock
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from app.core import automation as A
from app.core import reminders


class AutomationTests(unittest.TestCase):
    def setUp(self):
        self.popen = mock.patch.object(A.subprocess, "Popen").start()
        self.web = mock.patch.object(A.webbrowser, "open").start()
        self.key = mock.patch.object(A, "press_key").start()
        self.combo = mock.patch.object(A, "press_combo").start()
        mock.patch.object(A, "IS_WIN", True).start()
        mock.patch.object(A, "_chrome_path", return_value="C:/chrome.exe").start()
        self.a = A.SystemAutomation()
        self.addCleanup(mock.patch.stopall)

    def cmd(self):
        return self.popen.call_args[0][0] if self.popen.called else None

    def test_english_open(self):
        for text, exe in [("open notepad", "notepad.exe"), ("Launch the Calculator please", "calc.exe"),
                          ("start task manager", "taskmgr.exe"), ("open paint", "mspaint.exe")]:
            self.popen.reset_mock(); r = self.a.try_execute(text)
            self.assertEqual(self.cmd(), [exe], text); self.assertIn("Opening", r)

    def test_hinglish_and_hindi_open(self):
        for text in ["notepad kholo", "bhai calculator chalao na", "नोटपैड खोलो", "कैलकुलेटर चलाओ"]:
            self.popen.reset_mock(); r = self.a.try_execute(text, "hinglish")
            self.assertIsNotNone(self.cmd(), text)
        self.assertIn("khol diya", self.a.try_execute("notepad kholo", "hinglish"))
        self.assertIn("खोल दिया", self.a.try_execute("नोटपैड खोलो", "hi"))

    def test_chrome_and_sites(self):
        self.a.try_execute("open chrome"); self.assertEqual(self.cmd(), ["C:/chrome.exe"])
        self.popen.reset_mock(); self.a.try_execute("क्रोम खोलो"); self.assertEqual(self.cmd(), ["C:/chrome.exe"])
        self.a.try_execute("youtube kholo"); self.web.assert_called_with("https://www.youtube.com")

    def test_no_false_positives(self):
        for text in ["tell me about chrome", "what is a calculator", "I paint every weekend",
                     "how are you today", "mera mood kharab hai", "who opened the first school"]:
            self.assertIsNone(self.a.try_execute(text), text)
        self.assertFalse(self.popen.called)

    def test_shutdown_needs_confirmation(self):
        r = self.a.try_execute("shutdown computer"); self.assertIn("Shut down", r); self.assertFalse(self.popen.called)
        self.assertIn("cancelled", self.a.try_execute("no").lower())
        self.a.try_execute("computer band karo", "hinglish")
        r = self.a.try_execute("haan kar do", "hinglish")
        self.assertEqual(self.cmd(), ["shutdown", "/s", "/t", "10"])
        self.a.try_execute("cancel shutdown"); self.assertEqual(self.cmd(), ["shutdown", "/a"])

    def test_hindi_shutdown(self):
        self.assertIn("बंद", self.a.try_execute("कंप्यूटर बंद करो", "hi"))
        self.a.try_execute("हाँ", "hi"); self.assertEqual(self.cmd(), ["shutdown", "/s", "/t", "10"])

    def test_restart_and_lock(self):
        self.a.try_execute("restart computer"); self.a.try_execute("yes"); self.assertEqual(self.cmd(), ["shutdown", "/r", "/t", "10"])
        with mock.patch.object(A.ctypes, "windll", create=True) as w:
            self.assertIn("Locking", self.a.try_execute("lock the computer")); w.user32.LockWorkStation.assert_called()

    def test_volume_media(self):
        self.a.try_execute("volume up"); self.key.assert_called_with(0xAF, 5)
        self.a.try_execute("volume kam karo", "hinglish"); self.key.assert_called_with(0xAE, 5)
        self.a.try_execute("mute"); self.key.assert_called_with(0xAD)
        self.a.try_execute("next song"); self.key.assert_called_with(0xB0)
        self.a.try_execute("take a screenshot"); self.combo.assert_called_with(0x5B, 0x2C)

    def test_search_and_play(self):
        self.a.try_execute("search for python tutorials"); self.assertIn("python+tutorials", self.web.call_args[0][0])
        self.a.try_execute("taj mahal search karo", "hinglish"); self.assertIn("taj+mahal", self.web.call_args[0][0])
        self.a.try_execute("play lofi hip hop"); self.assertIn("youtube.com/results", self.web.call_args[0][0])

    def test_time_date(self):
        self.assertIn("It's", self.a.try_execute("what time is it")); self.assertIn("Abhi", self.a.try_execute("time kya hai", "hinglish"))
        self.assertIn("Today is", self.a.try_execute("what's the date"))


class ReminderTests(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(reminders.parse("remind me in 10 minutes to drink water"), (600.0, "drink water"))
        self.assertEqual(reminders.parse("remind me in an hour to call mom"), (3600.0, "call mom"))
        s, w = reminders.parse("10 minute baad paani peene ka yaad dilana"); self.assertEqual(s, 600.0); self.assertIn("paani", w)
        s, w = reminders.parse("2 ghante baad meeting yaad dilao"); self.assertEqual(s, 7200.0); self.assertIn("meeting", w)
        self.assertIsNone(reminders.parse("what is the time")); self.assertIsNone(reminders.parse("remind me later"))

class WeatherBatteryTests(unittest.TestCase):
    def test_weather_text_and_failure(self):
        def ok(url):
            return {"latitude": 28.6, "longitude": 77.2, "city": "Delhi"} if "ipapi" in url else {"current": {"temperature_2m": 31.4, "weather_code": 61}}
        self.assertEqual(A.weather_text("en", ok), "31°C, raining (Delhi)")
        self.assertEqual(A.weather_text("hinglish", ok), "31°C, barish (Delhi)")
        def boom(url):
            raise OSError("offline")
        self.assertIsNone(A.weather_text("en", boom))

    def test_commands(self):
        a = A.SystemAutomation()
        with mock.patch.object(A, "weather_text", return_value="30°C"):
            self.assertIn("30°C", a.try_execute("mausam kaisa hai", "hinglish"))
            self.assertIn("30°C", a.try_execute("what's the weather", "en"))
        with mock.patch.object(A, "weather_text", return_value=None):
            self.assertIn("couldn't", a.try_execute("weather today", "en"))
        from app.system import winapi
        with mock.patch.object(winapi, "battery", return_value=(76, True)):
            self.assertIn("76%", a.try_execute("battery kitni hai", "hinglish"))
            self.assertIn("charging", a.try_execute("how is the battery", "en"))
        with mock.patch.object(winapi, "battery", return_value=None):
            self.assertIn("no battery", a.try_execute("battery", "en"))


if __name__ == "__main__":
    unittest.main()
