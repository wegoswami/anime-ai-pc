import subprocess
import sys
import tempfile
import wave
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.core import recorder as R

def ok(c, m):
    print(("ok   " if c else "FAIL ") + m)
    if not c:
        raise SystemExit(1)

FF = R.ffmpeg_exe()
if not FF:
    print("SKIP no ffmpeg"); raise SystemExit(0)


class Fake:
    """Writes 2 s of tone like the real backend would write loopback + mic."""
    def start_audio(self, sp, mp):
        subprocess.run([FF, "-y", "-f", "lavfi", "-i", "sine=frequency=440:duration=2", "-ac", "2", "-ar", "48000", str(sp)], capture_output=True)
        subprocess.run([FF, "-y", "-f", "lavfi", "-i", "sine=frequency=880:duration=2", "-ac", "1", "-ar", "48000", str(mp)], capture_output=True)
    def stop_audio(self): pass
    def start_video(self, p): subprocess.run([FF, "-y", "-f", "lavfi", "-i", "testsrc=size=320x240:rate=10:duration=2", "-pix_fmt", "yuv420p", str(p)], capture_output=True)
    def stop_video(self): pass

d = Path(tempfile.mkdtemp())
rc = R.RecordCommands(backend=Fake(), folder=d / "out", work=d / "tmp"); (d / "out").mkdir()
ok(rc.try_execute("hello how are you") is None and rc.try_execute("world record kya hai") is None and rc.try_execute("kharcha record karo 50 chai") is None, "normal sentences ignored")
ok("Kaise save" in rc.try_execute("whatsapp call record karo"), "asks which format")
ok("ijazat" in rc.try_execute("mp3"), "then asks consent")
ok("jawab" in rc.try_execute("pata nahi kuch"), "does not start without a clear yes")
ok(rc.try_execute("haan").startswith("🔴") and rc.recording, "starts after consent")
ok(rc.try_execute("kuch aur baat") is None, "other commands pass through while recording")
msg = rc.try_execute("record band karo")
ok("save ho gayi" in msg and not rc.recording, "stops and saves")
mp3 = list((d / "out").glob("*.mp3"))
ok(len(mp3) == 1 and mp3[0].stat().st_size > 2000, "mp3 file created")
info = subprocess.run([FF, "-i", str(mp3[0])], capture_output=True, text=True).stderr
ok("mp3" in info and "Duration: 00:00:02" in info, "mp3 is ~2 s and really mp3")
ok("wav" in rc.try_execute("wav bhi do") or list((d / "out").glob("*.wav")), "wav on request")
ok(len(list((d / "out").glob("*.wav"))) == 1, "wav file created")
ok("sirf awaaz" in rc.try_execute("mp4 bhi do"), "video on request refused honestly when it was audio only")
# video mode
import time; time.sleep(1.1)
ok("ijazat" in rc.try_execute("video record karo"), "video mode asks consent")
rc.try_execute("haan"); msg = rc.try_execute("stop recording")
mp4 = list((d / "out").glob("*.mp4"))
ok(len(mp4) == 1 and len(list((d / "out").glob("*.mp3"))) == 2, "video mode gives mp4 + mp3")
info = subprocess.run([FF, "-i", str(mp4[0])], capture_output=True, text=True).stderr
ok("Video: h264" in info and "Audio: aac" in info, "mp4 has h264 video and aac audio")
# decline
rc.try_execute("record karo mp3"); ok("nahi ki" in rc.try_execute("nahi"), "declined consent = no recording")
ok("nahi hai" in rc.stop(), "stop when idle is harmless")
print("ALL OK")
