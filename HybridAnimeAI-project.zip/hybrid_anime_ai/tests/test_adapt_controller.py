"""Controller wiring for Adapt: style, taught routine run end-to-end, drafts gated by Premium, AI prompt carries the style."""
import os, sys, pathlib, tempfile, time
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "tests" / "fakeqt"))
os.environ["APPDATA"] = tempfile.mkdtemp()
import qtfake
qtfake.install()
from unittest import mock
from app import config
mock.patch("app.voice.tts.speak").start()
from app.controller import Assistant

fails = 0
def ok(c, m):
    global fails
    print(("ok   " if c else "FAIL ") + m); fails += (not c)

cfg = config.load_config(); cfg.update(user_name="Suraj", assistant_name="Aiko", setup_complete=True)
a = Assistant(cfg)
got = []
a.reply_ready.connect(lambda t, m, e: got.append(t)) if hasattr(a.reply_ready, "connect") else None
replies = []
orig_emit = a.reply_ready.emit
a.reply_ready.emit = lambda t, m, e: replies.append(t)

ok(a.adapt is not None and a.engine.prefs is a.adapt, "adapt attached to controller and engine")
a._process("chhota jawab do", "hinglish")
ok(any("chhote" in r for r in replies) and "ONE short sentence" in a.engine._system_prompt("en", "x"), "style command reaches the AI prompt")
a._process("jab main good morning bolu to time kya hua phir aaj kya date hai", "hinglish")
ok(len(a.adapt.teach) == 1, "routine learned through _process")
seen = []
orig = a._process
def spy(text, lang):
    seen.append(text)
    if text == "good morning":
        return orig(text, lang)
    return None
a._process = spy
a._run_steps(["time kya hua", "aaj kya date hai"])
ok(seen == ["time kya hua", "aaj kya date hai"] and not a.adapt.running, "steps run in order and the lock is released")
a._process = orig
n0 = len(replies)
a._process("draft whatsapp to mom: late aaunga", "hinglish")
ok(a.adapt.draft_last is None, "draft needs Premium: nothing was drafted on Free")
with mock.patch("app.core.license.managed", return_value=True), mock.patch.object(a.engine, "ask") as ask:
    ask.return_value = mock.Mock(text="Mom, late aaunga.", mode="cloud", emotion="happy")
    a._process("draft whatsapp to mom: late aaunga", "hinglish")
    ok(a.adapt.draft_last and a.adapt.draft_last["text"] == "Mom, late aaunga." and "Here's the draft" in replies[-1], "Premium drafts through the AI")
with mock.patch("webbrowser.open") as wb:
    a._process("bhejo", "hinglish")
    ok(wb.called and wb.call_args[0][0].startswith("https://wa.me/?text=Mom%2C%20late"), "send opens the prepared message")
sys.exit(1 if fails else 0)
