import json, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from PIL import Image
from app.avatar.importer import import_pack, pack_key


class PackTests(unittest.TestCase):
    def test_pack(self):
        with tempfile.TemporaryDirectory() as d:
            ps = []
            for n, c in [("meera_neutral.png", "red"), ("meera_happy.png", "orange"), ("meera_talk.png", "blue"), ("x.png", "green")]:
                Image.new("RGB", (120, 160), c).save(Path(d) / n); ps.append(str(Path(d) / n))
            spec = import_pack(ps, "Meera", "girl", False, dest_root=Path(d) / "out")
            self.assertEqual(sorted(spec["states"]), ["happy", "neutral", "talk"])
            self.assertTrue((Path(d) / "out" / spec["id"] / "talk.png").exists())
            self.assertEqual(pack_key("Aarav_SAD.jpg"), "sad")
            self.assertIsNone(pack_key("holiday.jpg"))


if __name__ == "__main__":
    unittest.main()
