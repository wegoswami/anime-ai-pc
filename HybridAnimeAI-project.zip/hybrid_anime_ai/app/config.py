"""config.json handling. Lives in %APPDATA%\\HybridAnimeAI\\config.json."""
import json
import os
import tempfile

from .paths import config_path
from .version import DEFAULT_GEMINI_MODEL, DEFAULT_OLLAMA_MODEL

DEFAULTS = {
    # profile
    "assistant_name": "Aiko",
    "user_name": "",
    "language_pref": "auto",        # auto | en | hinglish | hi  (language of the pet's own remarks)
    "character": "sakura",
    "avatar_scale": 1.0,
    # voice
    "voice_id": "",
    "voice_rate": 175,
    "voice_volume": 1.0,
    "mic_device": None,             # None = Windows default microphone
    "stt_model": "small",           # tiny | base | small | medium  (offline Whisper)
    "stt_languages": [],            # [] = detect any language automatically
    "hands_free": False,
    "wake_word_required": True,
    # behaviour
    "proactive_level": "normal",    # off | low | normal | high
    "behavior_walk": True,
    "behavior_perch": True,
    "activity_awareness": True,
    "hide_in_fullscreen": True,
    # AI
    "gemini_api_key": "",
    "gemini_model": DEFAULT_GEMINI_MODEL,
    "ollama_model": DEFAULT_OLLAMA_MODEL,
    "auto_setup_offline": True,
    "auto_update": True,            # download updates silently, install when you are away
    "update_url": "",               # optional custom version.json URL (default: this app's GitHub releases)
    "last_model_refresh": 0,        # epoch seconds of the last offline-model refresh
    "offline_ready": False,
    # internal
    "pos": None,
    "setup_complete": False,
}


def config_exists() -> bool:
    p = config_path()
    return p.exists() and p.stat().st_size > 0


def load_config() -> dict:
    cfg = dict(DEFAULTS)
    try:
        with open(config_path(), "r", encoding="utf-8") as f:
            cfg.update(json.load(f))
    except (OSError, ValueError):
        pass
    cfg.pop("stt_engine", None)      # removed in v2 (Whisper replaced SpeechRecognition)
    if not cfg.get("gemini_api_key"):
        cfg["gemini_api_key"] = os.environ.get("GEMINI_API_KEY", "")
    return cfg


def save_config(cfg: dict) -> None:
    p = config_path()
    fd, tmp = tempfile.mkstemp(dir=str(p.parent), suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    os.replace(tmp, p)
