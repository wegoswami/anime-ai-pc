"""Windows window/cursor/idle probes via ctypes (no pywin32). On other systems everything returns "nothing".

All rectangles are NATIVE screen pixels; screens.py converts them to Qt logical coordinates.
"""
import ctypes
import logging
import os
import sys
from dataclasses import dataclass
from typing import Optional

log = logging.getLogger(__name__)
IS_WIN = sys.platform == "win32"


@dataclass
class WindowInfo:
    hwnd: int
    title: str
    process: str          # e.g. "chrome.exe"
    pid: int
    left: int
    top: int
    right: int
    bottom: int
    maximized: bool = False
    fullscreen: bool = False

    @property
    def width(self) -> int:
        return self.right - self.left

    @property
    def height(self) -> int:
        return self.bottom - self.top


_SKIP_CLASSES = {"Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd", "NotifyIconOverflowWindow",
                 "Windows.UI.Core.CoreWindow", "XamlExplorerHostIslandWindow", "TopLevelWindowForOverflowXamlIsland"}
_SKIP_PROCESSES = {"textinputhost.exe", "searchhost.exe", "startmenuexperiencehost.exe", "shellexperiencehost.exe",
                   "applicationframehost.exe"}

if IS_WIN:
    from ctypes import wintypes

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    try:
        dwmapi = ctypes.WinDLL("dwmapi")
    except OSError:
        dwmapi = None

    HWND = wintypes.HWND

    class LASTINPUTINFO(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.UINT), ("dwTime", wintypes.DWORD)]

    class MONITORINFO(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT), ("rcWork", wintypes.RECT),
                    ("dwFlags", wintypes.DWORD)]

    user32.GetForegroundWindow.restype = HWND
    user32.GetWindowTextLengthW.argtypes = [HWND]
    user32.GetWindowTextW.argtypes = [HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowThreadProcessId.argtypes = [HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.IsWindowVisible.argtypes = [HWND]
    user32.IsIconic.argtypes = [HWND]
    user32.IsZoomed.argtypes = [HWND]
    user32.GetWindowRect.argtypes = [HWND, ctypes.POINTER(wintypes.RECT)]
    user32.GetClassNameW.argtypes = [HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowLongW.argtypes = [HWND, ctypes.c_int]
    user32.GetWindowLongW.restype = ctypes.c_long
    user32.WindowFromPoint.argtypes = [wintypes.POINT]
    user32.WindowFromPoint.restype = HWND
    user32.GetAncestor.argtypes = [HWND, wintypes.UINT]
    user32.GetAncestor.restype = HWND
    user32.GetCursorPos.argtypes = [ctypes.POINTER(wintypes.POINT)]
    user32.GetLastInputInfo.argtypes = [ctypes.POINTER(LASTINPUTINFO)]
    user32.MonitorFromWindow.argtypes = [HWND, wintypes.DWORD]
    user32.MonitorFromWindow.restype = wintypes.HANDLE
    user32.GetMonitorInfoW.argtypes = [wintypes.HANDLE, ctypes.POINTER(MONITORINFO)]
    user32.IsWindow.argtypes = [HWND]
    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, HWND, wintypes.LPARAM)
    user32.EnumWindows.argtypes = [WNDENUMPROC, wintypes.LPARAM]
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR,
                                                    ctypes.POINTER(wintypes.DWORD)]
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.GetTickCount.restype = wintypes.DWORD
    if dwmapi:
        dwmapi.DwmGetWindowAttribute.argtypes = [HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD]

    GWL_EXSTYLE, WS_EX_TOOLWINDOW, WS_EX_APPWINDOW, WS_EX_NOACTIVATE = -20, 0x80, 0x40000, 0x08000000
    DWMWA_CLOAKED, DWMWA_EXTENDED_FRAME_BOUNDS = 14, 9
    GA_ROOT = 2
    _proc_cache: dict = {}

    def _title(hwnd) -> str:
        n = user32.GetWindowTextLengthW(hwnd)
        if n <= 0:
            return ""
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        return buf.value

    def _class(hwnd) -> str:
        buf = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, buf, 256)
        return buf.value

    def _pid(hwnd) -> int:
        pid = wintypes.DWORD(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return pid.value

    def _process_name(pid: int) -> str:
        if pid in _proc_cache:
            return _proc_cache[pid]
        name = ""
        h = kernel32.OpenProcess(0x1000, False, pid)      # PROCESS_QUERY_LIMITED_INFORMATION
        if h:
            try:
                buf = ctypes.create_unicode_buffer(1024)
                size = wintypes.DWORD(1024)
                if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                    name = os.path.basename(buf.value).lower()
            finally:
                kernel32.CloseHandle(h)
        if len(_proc_cache) > 500:
            _proc_cache.clear()
        _proc_cache[pid] = name
        return name

    def _cloaked(hwnd) -> bool:
        if not dwmapi:
            return False
        val = wintypes.DWORD(0)
        if dwmapi.DwmGetWindowAttribute(hwnd, DWMWA_CLOAKED, ctypes.byref(val), 4) == 0:
            return val.value != 0
        return False

    def _rect(hwnd) -> Optional[tuple]:
        r = wintypes.RECT()
        if dwmapi and dwmapi.DwmGetWindowAttribute(hwnd, DWMWA_EXTENDED_FRAME_BOUNDS, ctypes.byref(r),
                                                   ctypes.sizeof(r)) == 0:
            return r.left, r.top, r.right, r.bottom
        if user32.GetWindowRect(hwnd, ctypes.byref(r)):
            return r.left, r.top, r.right, r.bottom
        return None

    def _is_fullscreen(hwnd, rect) -> bool:
        mon = user32.MonitorFromWindow(hwnd, 2)           # MONITOR_DEFAULTTONEAREST
        if not mon:
            return False
        mi = MONITORINFO()
        mi.cbSize = ctypes.sizeof(MONITORINFO)
        if not user32.GetMonitorInfoW(mon, ctypes.byref(mi)):
            return False
        m = mi.rcMonitor
        return rect[0] <= m.left and rect[1] <= m.top and rect[2] >= m.right and rect[3] >= m.bottom

    def _info(hwnd, with_process=True) -> Optional[WindowInfo]:
        rect = _rect(hwnd)
        if rect is None:
            return None
        pid = _pid(hwnd)
        return WindowInfo(int(hwnd or 0), _title(hwnd), _process_name(pid) if with_process else "", pid, *rect,
                          maximized=bool(user32.IsZoomed(hwnd)), fullscreen=_is_fullscreen(hwnd, rect))


def foreground() -> Optional[WindowInfo]:
    if not IS_WIN:
        return None
    try:
        hwnd = user32.GetForegroundWindow()
        if not hwnd or _class(hwnd) in _SKIP_CLASSES:
            return None
        return _info(hwnd)
    except Exception:  # noqa: BLE001
        log.exception("foreground() failed")
        return None


def window_at(x: int, y: int) -> Optional[WindowInfo]:
    """Top-level window under NATIVE point (x, y)."""
    if not IS_WIN:
        return None
    try:
        h = user32.WindowFromPoint(wintypes.POINT(int(x), int(y)))
        if not h:
            return None
        root = user32.GetAncestor(h, GA_ROOT) or h
        if _class(root) in _SKIP_CLASSES:
            return None
        return _info(root)
    except Exception:  # noqa: BLE001
        return None


def window_rect(hwnd: int) -> Optional[tuple]:
    """Current native rect of a window, or None if it is gone / minimised / hidden."""
    if not IS_WIN:
        return None
    try:
        h = HWND(hwnd)
        if not user32.IsWindow(h) or not user32.IsWindowVisible(h) or user32.IsIconic(h) or _cloaked(h):
            return None
        return _rect(h)
    except Exception:  # noqa: BLE001
        return None


def list_windows(exclude_pid: int = 0, min_w: int = 240, min_h: int = 120) -> list:
    """Visible, normal, top-level windows ordered from the top of the z-order to the bottom."""
    if not IS_WIN:
        return []
    found = []

    def cb(hwnd, _lp):
        try:
            if not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
                return True
            ex = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            if (ex & WS_EX_TOOLWINDOW and not ex & WS_EX_APPWINDOW) or ex & WS_EX_NOACTIVATE:
                return True
            if _class(hwnd) in _SKIP_CLASSES or _cloaked(hwnd):
                return True
            rect = _rect(hwnd)
            if rect is None:
                return True
            w, h = rect[2] - rect[0], rect[3] - rect[1]
            if w < min_w or h < min_h:
                return True
            pid = _pid(hwnd)
            if exclude_pid and pid == exclude_pid:
                return True
            title = _title(hwnd)
            proc = _process_name(pid)
            if not title or proc in _SKIP_PROCESSES:
                return True
            found.append(WindowInfo(int(hwnd), title, proc, pid, *rect, maximized=bool(user32.IsZoomed(hwnd)),
                                    fullscreen=_is_fullscreen(hwnd, rect)))
        except Exception:  # noqa: BLE001
            pass
        return True

    try:
        user32.EnumWindows(WNDENUMPROC(cb), 0)
    except Exception:  # noqa: BLE001
        log.exception("EnumWindows failed")
    return found


class _PowerStatus(ctypes.Structure):
    _fields_ = [("ACLineStatus", ctypes.c_ubyte), ("BatteryFlag", ctypes.c_ubyte), ("BatteryLifePercent", ctypes.c_ubyte),
                ("SystemStatusFlag", ctypes.c_ubyte), ("BatteryLifeTime", ctypes.c_ulong), ("BatteryFullLifeTime", ctypes.c_ulong)]


def battery() -> Optional[tuple]:
    """(percent, charging) or None when there is no battery / not Windows."""
    if not IS_WIN:
        return None
    try:
        st = _PowerStatus()
        if not kernel32.GetSystemPowerStatus(ctypes.byref(st)):
            return None
        if st.BatteryLifePercent == 255 or st.BatteryFlag == 128:      # unknown / no battery (desktop PC)
            return None
        return int(st.BatteryLifePercent), st.ACLineStatus == 1
    except Exception:  # noqa: BLE001
        return None


def idle_seconds() -> float:
    """Seconds since the last keyboard / mouse input."""
    if not IS_WIN:
        return 0.0
    try:
        li = LASTINPUTINFO()
        li.cbSize = ctypes.sizeof(LASTINPUTINFO)
        if not user32.GetLastInputInfo(ctypes.byref(li)):
            return 0.0
        return ((kernel32.GetTickCount() - li.dwTime) & 0xFFFFFFFF) / 1000.0
    except Exception:  # noqa: BLE001
        return 0.0


def cursor_native() -> Optional[tuple]:
    if not IS_WIN:
        return None
    pt = wintypes.POINT()
    if user32.GetCursorPos(ctypes.byref(pt)):
        return pt.x, pt.y
    return None
