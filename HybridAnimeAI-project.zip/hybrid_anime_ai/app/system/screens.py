"""Native Windows pixels <-> Qt logical coordinates (mixed-DPI multi-monitor safe). Pure Python.

Qt keeps each screen's origin in native coordinates and scales only the size, so for a native point:
    logical = screen.origin + (native - screen.origin) / dpr
"""
from dataclasses import dataclass


@dataclass
class ScreenInfo:
    x: float          # Qt logical origin (== native origin)
    y: float
    w: float          # Qt logical size
    h: float
    dpr: float = 1.0

    def contains_native(self, px: float, py: float) -> bool:
        return self.x <= px < self.x + self.w * self.dpr and self.y <= py < self.y + self.h * self.dpr


def native_to_logical(screens: list, px: float, py: float) -> tuple:
    for s in screens:
        if s.contains_native(px, py):
            return s.x + (px - s.x) / s.dpr, s.y + (py - s.y) / s.dpr
    if screens:                      # outside every screen: use the nearest one by origin
        s = min(screens, key=lambda s: abs(px - s.x) + abs(py - s.y))
        return s.x + (px - s.x) / s.dpr, s.y + (py - s.y) / s.dpr
    return px, py


def rect_to_logical(screens: list, l: float, t: float, r: float, b: float) -> tuple:
    x1, y1 = native_to_logical(screens, l, t)
    # the bottom-right corner belongs to the same screen as the top-left one
    s = next((s for s in screens if s.contains_native(l, t)), None)
    if s is None:
        x2, y2 = native_to_logical(screens, r, b)
    else:
        x2, y2 = s.x + (r - s.x) / s.dpr, s.y + (b - s.y) / s.dpr
    return x1, y1, x2, y2
