"""Local activity journal: which app/window you worked in and for how long. Stays on this PC (activity.json).

Only used to let the assistant answer "what was I doing?" and to comment on what you are working on.
"""
import json
import logging
import os
import re
import tempfile
import time
from typing import Optional

log = logging.getLogger(__name__)

FRIENDLY = {
    "chrome.exe": "Google Chrome", "msedge.exe": "Microsoft Edge", "firefox.exe": "Firefox",
    "brave.exe": "Brave", "opera.exe": "Opera", "code.exe": "VS Code", "devenv.exe": "Visual Studio",
    "pycharm64.exe": "PyCharm", "idea64.exe": "IntelliJ", "sublime_text.exe": "Sublime Text",
    "notepad.exe": "Notepad", "notepad++.exe": "Notepad++", "winword.exe": "Word", "excel.exe": "Excel",
    "powerpnt.exe": "PowerPoint", "onenote.exe": "OneNote", "outlook.exe": "Outlook", "teams.exe": "Teams",
    "ms-teams.exe": "Teams", "explorer.exe": "File Explorer", "discord.exe": "Discord",
    "whatsapp.exe": "WhatsApp", "telegram.exe": "Telegram", "spotify.exe": "Spotify", "vlc.exe": "VLC",
    "zoom.exe": "Zoom", "slack.exe": "Slack", "photoshop.exe": "Photoshop", "blender.exe": "Blender",
    "windowsterminal.exe": "Terminal", "cmd.exe": "Command Prompt", "powershell.exe": "PowerShell",
    "calculatorapp.exe": "Calculator", "mspaint.exe": "Paint", "acrobat.exe": "Acrobat",
    "obs64.exe": "OBS", "steam.exe": "Steam", "taskmgr.exe": "Task Manager",
}
BROWSERS = {"chrome.exe", "msedge.exe", "firefox.exe", "brave.exe", "opera.exe"}
_SUFFIX = re.compile(r"\s+[-–—]\s+(Google Chrome|Microsoft​? Edge|Mozilla Firefox|Brave|Opera|"
                     r"Visual Studio Code|Notepad|Microsoft Word|Excel|PowerPoint)\s*$", re.I)


def friendly_app(process: str) -> str:
    p = (process or "").lower()
    if p in FRIENDLY:
        return FRIENDLY[p]
    stem = p[:-4] if p.endswith(".exe") else p
    return stem.replace("_", " ").replace("-", " ").title() or "an app"


def clean_title(title: str, process: str = "") -> str:
    t = _SUFFIX.sub("", title or "").strip()
    return t[:70]


class ActivityTracker:
    IDLE_BREAK = 120.0          # no input for this long => you stepped away

    def __init__(self, path, enabled: bool = True):
        self.path = path
        self.enabled = enabled
        self.segments = []      # {"app","title","start","end"}
        self.daily = {}         # "YYYY-MM-DD" -> {app: seconds}
        self.active_since: Optional[float] = None
        self._last_sample = None
        self._last_save = time.time()
        self.load()

    # ------------------------------------------------------------- persistence
    def load(self) -> None:
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                d = json.load(f)
            self.segments = d.get("segments", [])[-300:]
            self.daily = d.get("daily", {})
        except (OSError, ValueError):
            pass

    def save(self) -> None:
        try:
            keep = sorted(self.daily)[-14:]
            data = {"segments": self.segments[-300:], "daily": {k: self.daily[k] for k in keep}}
            fd, tmp = tempfile.mkstemp(dir=os.path.dirname(str(self.path)), suffix=".tmp")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError:
            log.warning("Could not save activity journal")

    def clear(self) -> None:
        self.segments, self.daily, self.active_since = [], {}, None
        try:
            os.remove(self.path)
        except OSError:
            pass

    # ---------------------------------------------------------------- sampling
    def sample(self, now: float, process: str, title: str, idle_s: float) -> None:
        """Call about once per second with the foreground window."""
        if not self.enabled:
            return
        dt = 0.0 if self._last_sample is None else min(5.0, now - self._last_sample)
        self._last_sample = now
        if idle_s >= self.IDLE_BREAK or not process:
            self.active_since = None
            return
        if self.active_since is None:
            self.active_since = now
        app = friendly_app(process)
        title = clean_title(title, process)
        day = time.strftime("%Y-%m-%d", time.localtime(now))
        d = self.daily.setdefault(day, {})
        d[app] = d.get(app, 0.0) + dt
        seg = self.segments[-1] if self.segments else None
        if seg and seg["app"] == app and now - seg["end"] < 20 and seg["title"] == title:
            seg["end"] = now
        else:
            self.segments.append({"app": app, "title": title, "start": now, "end": now})
        if now - self._last_save > 60:
            self._last_save = now
            self.save()

    # ------------------------------------------------------------------ queries
    def active_minutes(self, now: Optional[float] = None) -> float:
        if self.active_since is None:
            return 0.0
        return ((now or time.time()) - self.active_since) / 60.0

    def current(self) -> Optional[dict]:
        return self.segments[-1] if self.segments else None

    def today_summary(self, top: int = 4) -> list:
        day = time.strftime("%Y-%m-%d")
        items = sorted(self.daily.get(day, {}).items(), key=lambda kv: -kv[1])
        return [(a, s) for a, s in items if s >= 60][:top]

    def recent(self, n: int = 3, min_s: float = 30.0) -> list:
        """Last n distinct (app, title, seconds) work blocks, newest first."""
        out, seen = [], set()
        for seg in reversed(self.segments):
            dur = seg["end"] - seg["start"]
            key = (seg["app"], seg["title"])
            if dur < min_s or key in seen:
                continue
            seen.add(key)
            out.append((seg["app"], seg["title"], dur))
            if len(out) >= n:
                break
        return out

    def describe(self, lang: str = "en") -> str:
        """Plain sentence answering 'what was I working on?'."""
        rec = self.recent(3)
        if not rec:
            return {"en": "I haven't noticed what you were working on yet.",
                    "hinglish": "Abhi tak mujhe pata nahi chala ki aap kya kar rahe the.",
                    "hi": "अभी तक मुझे नहीं पता चला कि आप क्या कर रहे थे।"}.get(lang, "I haven't noticed yet.")

        def fmt(app, title, s):
            m = max(1, int(round(s / 60)))
            what = f"{app}" + (f" ({title})" if title and title.lower() not in app.lower() else "")
            return what, m

        first, m1 = fmt(*rec[0])
        rest = [fmt(*r) for r in rec[1:]]
        today = self.today_summary(3)
        if lang == "hinglish":
            s = f"Abhi aap {first} mein kaam kar rahe the, lagbhag {m1} minute se."
            if rest:
                s += " Usse pehle: " + ", ".join(f"{a} ({m} min)" for a, m in rest) + "."
            if today:
                s += " Aaj sabse zyada: " + ", ".join(f"{a} {int(sec // 60)} min" for a, sec in today) + "."
        elif lang == "hi":
            s = f"अभी आप {first} में काम कर रहे थे, करीब {m1} मिनट से।"
            if rest:
                s += " इससे पहले: " + ", ".join(f"{a} ({m} मिनट)" for a, m in rest) + "।"
        else:
            s = f"You were working in {first} for about {m1} minute{'s' if m1 != 1 else ''}."
            if rest:
                s += " Before that: " + ", ".join(f"{a} ({m} min)" for a, m in rest) + "."
            if today:
                s += " Today so far: " + ", ".join(f"{a} {int(sec // 60)} min" for a, sec in today) + "."
        return s
