"""Glue between the UI and the backend. All slow work runs in daemon threads; results come back to the UI
thread through Qt signals."""
import difflib
import logging
import re
import threading
from pathlib import Path
import time

from PyQt6.QtCore import QObject, pyqtSignal

from . import config as config_mod
from .behavior.chatter import Chatter
from .behavior.lines import LINES
from .core import hardware, ollama_manager, reminders, updater, vision
from .core.memory import Memory
from .core.plugins import PluginManager
from .core.routines import Routines
from .core.ai_engine import AIEngine
from .core.automation import SystemAutomation
from .core.network import is_online
from .paths import activity_path, memory_path, plugins_dir, routines_path
from .system.activity import ActivityTracker
from .voice import mic, tts
from .voice.lang import detect_lang, line_lang
from .voice.stt import Transcriber, cloud_transcribe

log = logging.getLogger(__name__)

_ACTIVITY_Q = re.compile(
    r"what (?:was|am|have) i (?:been )?(?:doing|working on)|what did i do|where was i working|my activity|"
    r"main kya kar raha tha|mai kya kar rah[ai] tha|kya kaam kar raha tha|kya kar rah[ai] thi|aaj kya kiya|"
    r"maine kya kiya|kaha kaam kar raha tha|मैं क्या कर रहा था|मैं क्या कर रही थी|मै क्या कर रहा था|आज क्या किया|"
    r"कहाँ काम कर रहा था", re.I)


def _fmt_duration(secs: float, lang: str) -> str:
    if secs >= 3600:
        n = round(secs / 3600, 1)
        n = int(n) if n == int(n) else n
        return f"{n} {'ghante' if lang == 'hinglish' else 'घंटे' if lang == 'hi' else 'hour' + ('s' if n != 1 else '')}"
    if secs >= 60:
        n = int(round(secs / 60))
        return f"{n} {'minute' if lang == 'hinglish' else 'मिनट' if lang == 'hi' else 'minute' + ('s' if n != 1 else '')}"
    n = int(secs)
    return f"{n} {'second' if lang != 'hi' else 'सेकंड'}{'s' if lang == 'en' and n != 1 else ''}"


class Assistant(QObject):
    reply_ready = pyqtSignal(str, str, str)    # text, mode ("cloud"/"local"/"system"/"auto"/"error"), emotion
    status = pyqtSignal(str)
    speaking_changed = pyqtSignal(bool)
    listening_changed = pyqtSignal(bool)
    mic_level = pyqtSignal(float)
    progress = pyqtSignal(str, int, str)       # title, percent, detail
    progress_done = pyqtSignal(str)
    hands_free_changed = pyqtSignal(bool)

    def __init__(self, cfg: dict, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.engine = AIEngine(cfg)
        self.automation = SystemAutomation()
        self._init_brain_extras()
        self.transcriber = Transcriber()
        self.tracker = ActivityTracker(activity_path(), enabled=bool(cfg.get("activity_awareness", True)))
        self.chatter = Chatter(lambda: self.cfg, self.tracker)
        self.gender = "female"
        self.speaking = False
        self._tts_lock = threading.Lock()
        self._busy = threading.Lock()
        self._stop_hf = threading.Event()
        self._hf_thread = None
        self._conv_until = 0.0
        self._level_n = 0

    def _init_brain_extras(self) -> None:
        """Memory, plugins and routines. Each is optional: if one can't start, the assistant still works."""
        self.memory = self.plugins = self.routines = None
        try:
            self.memory = Memory(memory_path())
            self.engine.memory = self.memory
        except Exception:  # noqa: BLE001
            log.exception("memory unavailable")
        try:
            api = {"say": lambda t: self.say_auto(t, "happy", force=True),
                   "remember": lambda t: self.memory and self.memory.add("note", t),
                   "search_memory": lambda t: [x for _s, x in (self.memory.search(t) if self.memory else [])],
                   "run_command": lambda t: self.automation.try_execute(t, "en")}
            self.plugins = PluginManager(plugins_dir(), lambda: self.cfg, api)
        except Exception:  # noqa: BLE001
            log.exception("plugins unavailable")
        try:
            def focus(minutes):
                self.chatter.quiet_until = time.time() + float(minutes) * 60 if float(minutes) > 0 else 0.0

            def screen(question):
                self._screen_answer(str(question), "en")

            self.routines = Routines(routines_path(), {
                "say": lambda t: self.say_auto(str(t), "happy", force=True),
                "command": lambda t: self.automation.try_execute(str(t), "en"),
                "open": lambda t: self.automation.try_execute(f"open {t}", "en"),
                "search": lambda t: self.automation.try_execute(f"search {t}", "en"),
                "url": lambda u: __import__("webbrowser").open(str(u)),
                "lock": lambda _v: self.automation.try_execute("lock the computer screen", "en"),
                "focus": focus, "screen": screen})
        except Exception:  # noqa: BLE001
            log.exception("routines unavailable")

    def _screen_answer(self, question: str, ll: str) -> str:
        """Screen awareness: screenshot on command -> cloud brain describes it."""
        try:
            png = vision.capture_png()
        except Exception:  # noqa: BLE001
            log.exception("screenshot failed")
            return "I couldn't take a screenshot on this PC."
        r = self.engine.ask("The attached image is my current screen. " + question + " Answer briefly and helpfully.",
                            ll if ll != "en" else "", image=png)
        self.reply_ready.emit(r.text, r.mode, r.emotion)
        self._speak(r.text)
        return r.text

    # ------------------------------------------------------------- configuration
    def update_config(self, cfg: dict, character: dict = None) -> None:
        self.cfg = cfg
        self.engine.reload(cfg)
        self.tracker.enabled = bool(cfg.get("activity_awareness", True))
        if character:
            self.apply_character(character)

    def apply_character(self, spec: dict) -> None:
        self.engine.persona = spec.get("personality", "")
        self.gender = spec.get("voice_gender", "female")

    def lang(self) -> str:
        return self.chatter.lang()

    # ---------------------------------------------------------------- entry points
    def greet(self) -> None:
        msg = self.chatter.greeting(time.time(), time.localtime().tm_hour)
        if msg:
            self.say_auto(*msg)

    def say_auto(self, text: str, emotion: str = "happy", force: bool = False) -> None:
        """Speak something the pet decided to say by itself."""
        if self.speaking and not force:
            return
        self.reply_ready.emit(text, "auto", emotion)
        self._spawn(self._speak, text, self.chatter.user_lang)

    def submit_text(self, text: str, lang: str = "") -> None:
        text = text.strip()
        if text:
            self._spawn(self._process, text, lang or detect_lang(text))

    def listen_once(self) -> None:
        self._spawn(self._listen_worker)

    def _spawn(self, fn, *args) -> None:
        threading.Thread(target=fn, args=args, daemon=True).start()

    # ------------------------------------------------------------------- listening
    def _level(self, v: float) -> None:
        self._level_n += 1
        if self._level_n % 3 == 0:
            self.mic_level.emit(v)

    def _listen_worker(self) -> None:
        if self.speaking:
            return
        self.listening_changed.emit(True)
        self.status.emit("Listening…")
        try:
            audio = mic.record_phrase(self.cfg.get("mic_device"), self._level, timeout=8.0)
        except mic.NoSpeech:
            self.status.emit("I didn't hear anything. Click me and speak again.")
            return
        except mic.MicError as exc:
            self.status.emit(str(exc))
            return
        except Exception:  # noqa: BLE001
            log.exception("Microphone failure")
            self.status.emit(mic.PRIVACY_HELP)
            return
        finally:
            self.listening_changed.emit(False)
        self.status.emit("Understanding…")
        text, lang = self._transcribe(audio)
        if not text:
            return
        self.status.emit(f"You: {text}")
        self._conv_until = time.time() + 25
        self._process(text, lang)

    def _transcribe(self, audio) -> tuple:
        size = self.cfg.get("stt_model", "small")
        if self.transcriber.is_ready(size):
            try:
                text, wl = self.transcriber.transcribe(audio, size, self.cfg.get("stt_languages") or None)
                if text:
                    return text, detect_lang(text, wl)
                self.status.emit("Sorry, I couldn't catch that.")
                return "", ""
            except Exception:  # noqa: BLE001
                log.exception("Whisper failed")
        if self.cfg.get("gemini_api_key") and is_online():
            try:
                text, lang = cloud_transcribe(self.cfg, audio)
                if text:
                    return text, lang
                self.status.emit("Sorry, I couldn't catch that.")
                return "", ""
            except Exception:  # noqa: BLE001
                log.exception("Cloud transcription failed")
        self.status.emit("My offline ears are still downloading. Try again in a few minutes, or type to me.")
        return "", ""

    # ------------------------------------------------------------------ hands free
    def set_hands_free(self, on: bool) -> None:
        self.cfg["hands_free"] = on
        if on and not (self._hf_thread and self._hf_thread.is_alive()):
            self._stop_hf.clear()
            self._hf_thread = threading.Thread(target=self._hands_free_loop, daemon=True)
            self._hf_thread.start()
        elif not on:
            self._stop_hf.set()

    def _wake_match(self, text: str):
        """Return the text with the assistant's name removed if the name was said, else None."""
        name = (self.cfg.get("assistant_name") or "").lower().strip()
        if not name:
            return text
        words = re.findall(r"[\wऀ-ॿ']+", text.lower())
        for w in words:
            if difflib.SequenceMatcher(None, w, name).ratio() >= 0.78:
                return re.sub(re.escape(w), "", text, count=1, flags=re.I).strip(" ,.!?") or text
        return None

    def _hands_free_loop(self) -> None:
        self.listening_changed.emit(False)
        try:
            for audio in mic.capture(self.cfg.get("mic_device"), self._stop_hf, self._level,
                                     paused=lambda: self.speaking or self._busy.locked()):
                text, lang = self._transcribe(audio)
                if not text:
                    continue
                if self.cfg.get("wake_word_required", True) and time.time() > self._conv_until:
                    stripped = self._wake_match(text)
                    if stripped is None:
                        continue
                    text = stripped
                self._conv_until = time.time() + 25
                self.status.emit(f"You: {text}")
                self._process(text, lang)
        except mic.MicError as exc:
            self.status.emit(str(exc))
        except Exception:  # noqa: BLE001
            log.exception("Hands-free loop crashed")
        finally:
            self.cfg["hands_free"] = False
            self.hands_free_changed.emit(False)

    # ------------------------------------------------------------------ processing
    def _process(self, text: str, lang: str) -> None:
        if not self._busy.acquire(blocking=False):
            self.status.emit("One moment, I'm still thinking…")
            return
        emotion = "neutral"
        try:
            self.chatter.user_lang = lang or self.chatter.user_lang
            ll = line_lang(lang)
            self.status.emit("Thinking…")
            reply, mode = None, "system"
            if _ACTIVITY_Q.search(text.lower()):
                reply, emotion = self.tracker.describe(ll), "thinking"
            if reply is None:
                rem = reminders.parse(text)
                if rem:
                    reply, emotion = self._set_reminder(rem[0], rem[1], ll), "happy"
            if reply is None and self.memory:
                reply = self.memory.handle_command(text, ll)          # "remember that…", "what do you remember?"
                emotion = "happy" if reply else emotion
            if reply is None and self.plugins:
                reply = self.plugins.handle_command(text, ll) or self.plugins.try_handle(text, ll)
                emotion = "happy" if reply else emotion
            if reply is None and self.routines:
                reply = self.routines.handle_command(text, ll)
                if reply == "":                                       # a routine started; it speaks by itself
                    self.reply_ready.emit("On it!", "system", "happy")
                    return
                emotion = "happy" if reply else emotion
            if reply is None:   # local commands are checked BEFORE any LLM routing (works offline)
                reply = self.automation.try_execute(text, ll)
                emotion = "happy" if reply else emotion
            if reply is None and vision.SCREEN_Q.search(text):
                self._screen_answer(text, ll)
                return
            if reply is None:
                if self.memory and self.cfg.get("memory_enabled", True):
                    self.memory.learn(text)
                r = self.engine.ask(text, ll if ll != "en" else "")
                reply, mode, emotion = r.text, r.mode, r.emotion
                if self.memory and self.cfg.get("memory_enabled", True) and mode != "error":
                    self.memory.add_turn(text, reply)
            self.reply_ready.emit(reply, mode, emotion)
        except Exception:  # noqa: BLE001
            log.exception("Processing failed")
            reply = "Sorry, something went wrong."
            self.reply_ready.emit(reply, "error", "sad")
        finally:
            self._busy.release()
        self._speak(reply, lang)

    def _set_reminder(self, secs: float, what: str, ll: str) -> str:
        def fire():
            pool = LINES[ll]["reminder"]
            line = pool[0].format(name=self.cfg.get("user_name") or "friend", what=what or "your reminder")
            self.say_auto(line, "happy", force=True)

        t = threading.Timer(secs, fire)
        t.daemon = True
        t.start()
        d = _fmt_duration(secs, ll)
        if ll == "hinglish":
            return f"Done! {d} baad reminder laga diya{': ' + what if what else ''}."
        if ll == "hi":
            return f"ठीक है! {d} बाद याद दिला दिया जाएगा{': ' + what if what else ''}।"
        return f"Done! I'll remind you in {d}{' to ' + what if what else ''}."

    def _speak(self, text: str, user_lang: str = "") -> None:
        with self._tts_lock:
            self.speaking = True
            self.speaking_changed.emit(True)
            try:
                tts.speak(text, self.cfg, user_lang, self.gender)
            except Exception:  # noqa: BLE001
                log.exception("TTS failed")
            finally:
                self.speaking = False
                self.speaking_changed.emit(False)

    # ---------------------------------------------------- speed: warm everything up
    def warm_up(self) -> None:
        """Load models into memory in the background so the first answer is fast."""
        self._spawn(self._warm_worker)

    def _warm_worker(self) -> None:
        size = self.cfg.get("stt_model", "small")
        try:
            if self.transcriber.is_ready(size):
                self.transcriber._load(size)                     # Whisper into RAM
        except Exception:  # noqa: BLE001
            log.debug("Whisper warm-up skipped", exc_info=True)
        try:
            if self.cfg.get("offline_ready"):
                ollama_manager.warm(hardware.effective_model(self.cfg))   # Ollama model into RAM
        except Exception:  # noqa: BLE001
            log.debug("Ollama warm-up skipped", exc_info=True)
        try:
            if self.cfg.get("gemini_api_key") and is_online():
                import google.generativeai  # noqa: F401  (heavy import done ahead of time)
        except Exception:  # noqa: BLE001
            pass

    def refresh_models(self) -> None:
        """About once a week, while online, let Ollama fetch a newer build of the offline model."""
        if time.time() - float(self.cfg.get("last_model_refresh", 0) or 0) < 7 * 86400:
            return
        if self.cfg.get("offline_ready") and self.cfg.get("auto_update", True):
            self._spawn(self._refresh_worker)

    def _refresh_worker(self) -> None:
        if not is_online() or not ollama_manager.ensure_server(wait=8):
            return
        try:
            ollama_manager.pull_model(hardware.effective_model(self.cfg), lambda *_: None)   # no-op when current
            self.cfg["last_model_refresh"] = time.time()
            config_mod.save_config(self.cfg)
            log.info("Offline model refreshed")
        except Exception:  # noqa: BLE001
            log.debug("Model refresh failed", exc_info=True)

    # ---------------------------------------------------- background downloads
    def provision(self) -> None:
        """One-time background downloads: offline speech model (Whisper) then offline chat model (Ollama)."""
        self._spawn(self._provision_worker)

    def _provision_worker(self) -> None:
        if not is_online():
            return
        last = {"pct": -10}

        def cb(title: str, pct: int):
            if pct == 0 or pct >= last["pct"] + 2:
                last["pct"] = pct
                self.progress.emit(title, pct, f"{pct}%" if pct else "")

        messages = []
        size = self.cfg.get("stt_model", "small")
        if not self.transcriber.is_ready(size):
            try:
                self.transcriber.ensure_model(size, cb)
                messages.append("Offline voice recognition is ready.")
            except ImportError:
                log.warning("faster-whisper not installed; skipping voice model")
            except Exception:  # noqa: BLE001
                log.exception("Voice model download failed")
                messages.append("Voice model download failed. I'll retry next time.")
        last["pct"] = -10
        if self.cfg.get("auto_setup_offline") and not self.cfg.get("offline_ready"):
            ok, msg = ollama_manager.provision(hardware.effective_model(self.cfg), cb)
            if ok:
                self.cfg["offline_ready"] = True
                config_mod.save_config(self.cfg)
            messages.append(msg)
        if messages:
            self.progress_done.emit(" ".join(messages))


class UpdateRunner(QObject):
    """Checks GitHub (or a custom URL) for a newer version; also handles offline zips.

    manual=True  : user asked -> shows progress and installs straight away.
    manual=False : background  -> downloads silently, then emits `ready` so the app can install when idle.
    """
    progress = pyqtSignal(str, int, str)     # title, percent, detail
    failed = pyqtSignal(str)
    no_update = pyqtSignal()
    restart_needed = pyqtSignal(str, str)    # staged folder, new version  (install now)
    ready = pyqtSignal(str, str)             # staged folder, new version  (install when idle)

    def __init__(self, cfg_getter=None, parent=None):
        super().__init__(parent)
        self._cfg = cfg_getter or (lambda: {})
        self._lock = threading.Lock()

    def start(self, manual: bool = False) -> None:
        threading.Thread(target=self._run, args=(manual,), daemon=True).start()

    def install_local(self, path: str) -> None:
        threading.Thread(target=self._local, args=(path,), daemon=True).start()

    def _local(self, path: str) -> None:
        try:
            self.progress.emit("Reading update file", 20, "")
            content, version = updater.stage_local_zip(Path(path))
            updater.save_pending(content, version)
            self.restart_needed.emit(str(content), version)
        except Exception as exc:  # noqa: BLE001
            log.warning("Local update failed: %s", exc)
            self.failed.emit(f"Update failed: {exc}")

    def _run(self, manual: bool) -> None:
        if not self._lock.acquire(blocking=False):
            return                                  # a check/download is already running
        started = False  # noqa: F841
        try:
            if not updater.updates_enabled():
                if manual:
                    self.failed.emit("Updates are disabled when running from source.")
                return
            # 1) something already staged earlier, or dropped into the offline inbox folder
            pend = updater.load_pending()
            if pend is None:
                inbox = updater.find_inbox_update()
                if inbox is not None:
                    try:
                        pend = updater.stage_local_zip(inbox, copy=False)
                        updater.save_pending(*pend)
                    except Exception as exc:  # noqa: BLE001
                        log.warning("Inbox update unusable: %s", exc)
            if pend is not None:
                (self.restart_needed if manual else self.ready).emit(str(pend[0]), pend[1])
                return
            # 2) online check
            info = updater.check_for_update(str(self._cfg().get("update_url", "")))
            if info is None:
                if manual:
                    self.no_update.emit()
                return
            started = True
            title = f"Updating to v{info.version}"
            if manual:
                self.progress.emit(title, 0, "Starting download…")

            def on_chunk(done: int, total: int):
                if not manual:
                    return
                pct = int(done * 100 / total) if total else 0
                detail = f"{done / 1_048_576:.1f} / {total / 1_048_576:.1f} MB" if total \
                    else f"{done / 1_048_576:.1f} MB"
                self.progress.emit(title, pct, detail)

            zip_path = updater.download_update(info, on_chunk)
            if manual:
                self.progress.emit(title, 100, "Verifying and unpacking…")
            staged = updater.stage_update(zip_path, info)
            updater.save_pending(staged, info.version)
            (self.restart_needed if manual else self.ready).emit(str(staged), info.version)
        except Exception as exc:  # noqa: BLE001
            log.warning("Update check/apply failed: %s", exc)
            if manual:
                self.failed.emit(f"Update failed: {exc}")
        finally:
            self._lock.release()
