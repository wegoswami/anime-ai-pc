"""Glue between the UI and the backend. All slow work runs in daemon threads; results come back to the UI
thread through Qt signals."""
import difflib
import logging
import os
import re
import sys
import threading
from pathlib import Path
import time

from PyQt6.QtCore import QObject, pyqtSignal

from . import config as config_mod
from .behavior.chatter import Chatter
from .behavior.lines import LINES
from .core import hardware, ollama_manager, reminders, updater, vision
from .core.memory import Memory
from .core import health, pc_tools, screen_agent, websearch
from .core.bridge import Bridge, PORT as BRIDGE_PORT, local_ip
from .core.evolution import AutoSkills, Soul
from .core.knowledge import Knowledge
from .core.plugins import PluginManager
from .core.routines import Routines
from .core.ai_engine import AIEngine
from .core.automation import SystemAutomation
from .core.network import is_online
from .version import APP_VERSION
from .paths import activity_path, knowledge_path, memory_path, plugins_dir, routines_path, soul_path
from .system.activity import ActivityTracker
from .voice import mic, tts
from .voice.lang import detect_lang, line_lang
from .voice.stt import Transcriber, cloud_transcribe

log = logging.getLogger(__name__)

_ACTIVITY_Q = re.compile(
    r"what (?:was|am|have) i (?:been )?(?:doing|working on)|what did i do|where was i working|my activity|"
    r"main kya kar raha tha|mai kya kar rah[ai] tha|kya kaam kar raha tha|kya kar rah[ai] thi|aaj kya kiya|"
    r"maine kya kiya|kaha kaam kar raha tha|मैं क्या कर रहा था|मैं क्या कर रही थी|मै क्या कर रहा था|आज क्या किया|"
    r"कहाँ काम कर रहा था", re.I)


def _fmt_duration(secs: float, lang: str) -> str:
    if secs >= 3600:
        n = round(secs / 3600, 1)
        n = int(n) if n == int(n) else n
        return f"{n} {'ghante' if lang == 'hinglish' else 'घंटे' if lang == 'hi' else 'hour' + ('s' if n != 1 else '')}"
    if secs >= 60:
        n = int(round(secs / 60))
        return f"{n} {'minute' if lang == 'hinglish' else 'मिनट' if lang == 'hi' else 'minute' + ('s' if n != 1 else '')}"
    n = int(secs)
    return f"{n} {'second' if lang != 'hi' else 'सेकंड'}{'s' if lang == 'en' and n != 1 else ''}"


class Assistant(QObject):
    reply_ready = pyqtSignal(str, str, str)    # text, mode ("cloud"/"local"/"system"/"auto"/"error"), emotion
    status = pyqtSignal(str)
    hide_requested = pyqtSignal()               # "ab hat jao" - the window hides itself (tray / Alt+Space brings it back)
    speaking_changed = pyqtSignal(bool)
    listening_changed = pyqtSignal(bool)
    mic_level = pyqtSignal(float)
    progress = pyqtSignal(str, int, str)       # title, percent, detail
    progress_done = pyqtSignal(str)
    hands_free_changed = pyqtSignal(bool)

    def __init__(self, cfg: dict, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.engine = AIEngine(cfg)
        self.automation = SystemAutomation()
        self._init_brain_extras()
        self.transcriber = Transcriber()
        self.tracker = ActivityTracker(activity_path(), enabled=bool(cfg.get("activity_awareness", True)))
        self.chatter = Chatter(lambda: self.cfg, self.tracker)
        self.gender = "female"
        self.speaking = False
        self._tts_lock = threading.Lock()
        self._busy = threading.Lock()
        self._stop_hf = threading.Event()
        self._hf_thread = None
        self._conv_until = 0.0
        self._level_n = 0

    def _init_brain_extras(self) -> None:
        """Memory, plugins and routines. Each is optional: if one can't start, the assistant still works."""
        self.memory = self.plugins = self.routines = self.soul = self.skills = self.kb = self.bridge = None
        self.pc = pc_tools.PCTools()
        self.screen = None
        try:
            if sys.platform == "win32":
                self.screen = screen_agent.ScreenAgent(self._capture, self._vision, screen_agent.WinInput(), lambda m: None)
        except Exception:  # noqa: BLE001
            log.exception("screen agent unavailable")
        try:
            self.soul = Soul(soul_path())
            self.engine.soul = self.soul
        except Exception:  # noqa: BLE001
            log.exception("soul profile unavailable")
        try:
            def merge_soul(d: dict) -> None:
                if not self.soul:
                    return
                for k in ("likes", "dislikes", "projects"):
                    for v in (d.get(k) or [])[:12]:
                        self.soul._push(k, str(v))
                if d.get("name") and not self.soul.data.get("name"):
                    self.soul.data["name"] = str(d["name"])[:30]
                self.soul.save()

            self.bridge = Bridge(lambda: self.memory.facts(20) if self.memory else [],
                                 lambda t: self.memory and self.memory.add("note", t),
                                 lambda: {k: self.soul.data.get(k) for k in ("name", "likes", "dislikes", "projects")} if self.soul else {},
                                 merge_soul, lambda t: self.automation.try_execute(t, "en"))
        except Exception:  # noqa: BLE001
            log.exception("bridge unavailable")
        try:
            self.kb = Knowledge(knowledge_path())
        except Exception:  # noqa: BLE001
            log.exception("knowledge base unavailable")
        try:
            self.memory = Memory(memory_path())
            self.engine.memory = self.memory
        except Exception:  # noqa: BLE001
            log.exception("memory unavailable")
        try:
            api = {"say": lambda t: self.say_auto(t, "happy", force=True),
                   "remember": lambda t: self.memory and self.memory.add("note", t),
                   "search_memory": lambda t: [x for _s, x in (self.memory.search(t) if self.memory else [])],
                   "run_command": lambda t: self.automation.try_execute(t, "en")}
            self.plugins = PluginManager(plugins_dir(), lambda: self.cfg, api)
            self.skills = AutoSkills(plugins_dir(), self._llm_raw, self.plugins.load_all)
        except Exception:  # noqa: BLE001
            log.exception("plugins unavailable")
        try:
            def focus(minutes):
                self.chatter.quiet_until = time.time() + float(minutes) * 60 if float(minutes) > 0 else 0.0

            def screen(question):
                self._screen_answer(str(question), "en")

            self.routines = Routines(routines_path(), {
                "say": lambda t: self.say_auto(str(t), "happy", force=True),
                "command": lambda t: self.automation.try_execute(str(t), "en"),
                "open": lambda t: self.automation.try_execute(f"open {t}", "en"),
                "search": lambda t: self.automation.try_execute(f"search {t}", "en"),
                "url": lambda u: __import__("webbrowser").open(str(u)),
                "lock": lambda _v: self.automation.try_execute("lock the computer screen", "en"),
                "focus": focus, "screen": screen})
        except Exception:  # noqa: BLE001
            log.exception("routines unavailable")

    def _screen_answer(self, question: str, ll: str) -> str:
        """Screen awareness: screenshot on command -> cloud brain describes it."""
        try:
            png = vision.capture_png()
        except Exception:  # noqa: BLE001
            log.exception("screenshot failed")
            return "I couldn't take a screenshot on this PC."
        r = self.engine.ask("The attached image is my current screen. " + question + " Answer briefly and helpfully.",
                            ll if ll != "en" else "", image=png)
        self.reply_ready.emit(r.text, r.mode, r.emotion)
        self._speak(r.text)
        return r.text

    # ------------------------------------------------------------- configuration
    def update_config(self, cfg: dict, character: dict = None) -> None:
        self.cfg = cfg
        self.engine.reload(cfg)
        self.tracker.enabled = bool(cfg.get("activity_awareness", True))
        if character:
            self.apply_character(character)

    def apply_character(self, spec: dict) -> None:
        self.engine.persona = spec.get("personality", "")
        self.gender = spec.get("voice_gender", "female")

    def lang(self) -> str:
        return self.chatter.lang()

    # ---------------------------------------------------------------- entry points
    def greet(self) -> None:
        msg = self.chatter.greeting(time.time(), time.localtime().tm_hour)
        if msg:
            self.say_auto(*msg)

    def say_auto(self, text: str, emotion: str = "happy", force: bool = False) -> None:
        """Speak something the pet decided to say by itself."""
        if self.speaking and not force:
            return
        self.reply_ready.emit(text, "auto", emotion)
        self._spawn(self._speak, text, self.chatter.user_lang)

    def submit_text(self, text: str, lang: str = "") -> None:
        text = text.strip()
        if text:
            self._spawn(self._process, text, lang or detect_lang(text))

    def listen_once(self) -> None:
        self._spawn(self._listen_worker)

    def _spawn(self, fn, *args) -> None:
        threading.Thread(target=fn, args=args, daemon=True).start()

    # ------------------------------------------------------------------- listening
    def _level(self, v: float) -> None:
        self._level_n += 1
        if self._level_n % 3 == 0:
            self.mic_level.emit(v)

    def _listen_worker(self) -> None:
        if self.speaking:
            return
        self.listening_changed.emit(True)
        self.status.emit("Listening…")
        try:
            audio = mic.record_phrase(self.cfg.get("mic_device"), self._level, timeout=8.0)
        except mic.NoSpeech:
            self.status.emit("I didn't hear anything. Click me and speak again.")
            return
        except mic.MicError as exc:
            self.status.emit(str(exc))
            return
        except Exception:  # noqa: BLE001
            log.exception("Microphone failure")
            self.status.emit(mic.PRIVACY_HELP)
            return
        finally:
            self.listening_changed.emit(False)
        self.status.emit("Understanding…")
        text, lang = self._transcribe(audio)
        if not text:
            return
        self.status.emit(f"You: {text}")
        self._conv_until = time.time() + 25
        self._process(text, lang)

    def _transcribe(self, audio) -> tuple:
        size = self.cfg.get("stt_model", "small")
        if self.transcriber.is_ready(size):
            try:
                text, wl = self.transcriber.transcribe(audio, size, self.cfg.get("stt_languages") or None)
                if text:
                    return text, detect_lang(text, wl)
                self.status.emit("Sorry, I couldn't catch that.")
                return "", ""
            except Exception:  # noqa: BLE001
                log.exception("Whisper failed")
        if self.cfg.get("gemini_api_key") and is_online():
            try:
                text, lang = cloud_transcribe(self.cfg, audio)
                if text:
                    return text, lang
                self.status.emit("Sorry, I couldn't catch that.")
                return "", ""
            except Exception:  # noqa: BLE001
                log.exception("Cloud transcription failed")
        self.status.emit("My offline ears are still downloading. Try again in a few minutes, or type to me.")
        return "", ""

    # ------------------------------------------------------------------ hands free
    def set_hands_free(self, on: bool) -> None:
        self.cfg["hands_free"] = on
        if on and not (self._hf_thread and self._hf_thread.is_alive()):
            self._stop_hf.clear()
            self._hf_thread = threading.Thread(target=self._hands_free_loop, daemon=True)
            self._hf_thread.start()
        elif not on:
            self._stop_hf.set()

    def _wake_match(self, text: str):
        """Return the text with the assistant's name removed if the name was said, else None."""
        name = (self.cfg.get("assistant_name") or "").lower().strip()
        if not name:
            return text
        words = re.findall(r"[\wऀ-ॿ']+", text.lower())
        for w in words:
            if difflib.SequenceMatcher(None, w, name).ratio() >= 0.78:
                return re.sub(re.escape(w), "", text, count=1, flags=re.I).strip(" ,.!?") or text
        return None

    def _hands_free_loop(self) -> None:
        self.listening_changed.emit(False)
        try:
            for audio in mic.capture(self.cfg.get("mic_device"), self._stop_hf, self._level,
                                     paused=lambda: self.speaking or self._busy.locked()):
                text, lang = self._transcribe(audio)
                if not text:
                    continue
                if self.cfg.get("wake_word_required", True) and time.time() > self._conv_until:
                    stripped = self._wake_match(text)
                    if stripped is None:
                        continue
                    text = stripped
                self._conv_until = time.time() + 25
                self.status.emit(f"You: {text}")
                self._process(text, lang)
        except mic.MicError as exc:
            self.status.emit(str(exc))
        except Exception:  # noqa: BLE001
            log.exception("Hands-free loop crashed")
        finally:
            self.cfg["hands_free"] = False
            self.hands_free_changed.emit(False)

    # ------------------------------------------------------------------ processing
    def _llm_raw(self, prompt: str, max_tokens: int = 900) -> str:
        """One plain completion on the first working cloud provider (used for reflection and skill drafting)."""
        from .core import providers
        last = None
        for p in providers.usable(self.cfg):
            try:
                return providers.ask(p, self.cfg, "You are a precise assistant. Follow the format exactly.", [], prompt, None, max_tokens)
            except Exception as exc:  # noqa: BLE001
                last = exc
                providers.mark_down(p)
        raise RuntimeError(f"no provider: {last}")

    def _reflect_async(self) -> None:
        """Background reflection: never blocks the UI, never raises."""
        if not self.soul:
            return
        online = is_online()
        threading.Thread(target=lambda: self.soul.reflect(self._llm_raw if online else None), daemon=True).start()

    def _capture(self) -> bytes:
        from .core import vision
        return vision.capture_png(1280)

    def _vision(self, system: str, text: str, png: bytes) -> str:
        from .core import providers
        last = None
        for p in providers.usable(self.cfg):
            try:
                return providers.ask(p, self.cfg, system, [], text, png, 220)
            except Exception as exc:  # noqa: BLE001
                last = exc
                providers.mark_down(p)
        raise RuntimeError(f"no vision provider: {last}")

    def run_health_check(self) -> str:
        """Runs every check, writes health_report.txt (opened in Notepad) and returns a short spoken summary."""
        import socket
        from .core import hotkey
        from .paths import data_dir

        def port_free() -> bool:
            if self.bridge and self.bridge.running:
                return True
            with socket.socket() as s:
                return s.connect_ex(("127.0.0.1", BRIDGE_PORT)) != 0
        info = f"{len(self.plugins.plugins) if self.plugins and hasattr(self.plugins, 'plugins') else 0} loaded"
        res = health.run(self.cfg, APP_VERSION, bool(getattr(hotkey.install, "active", False)), info, port_free)
        text = health.format_report(res)
        path = data_dir() / "health_report.txt"
        try:
            path.write_text(text, encoding="utf-8")
            if sys.platform == "win32":
                os.startfile(str(path))                        # noqa: S606
        except OSError:
            pass
        bad = [r for r in res if r[0] is False]
        return ("Sab kuch theek hai ✅" if not bad else f"{len(bad)} cheezein theek karni hain: " + ", ".join(r[1] for r in bad[:3]) + ". Poori list Notepad me khuli hai.")

    def _run_step(self, step: str, ll: str):
        return self.pc.try_execute(step, ll) or self.automation.try_execute(step, ll)

    def _run_plan(self, steps, ll: str) -> None:
        """Runs the remaining steps in the background, one every ~1.5 s, then says how it went."""
        done = failed = 0
        for s in steps:
            time.sleep(1.5)
            try:
                if self._run_step(s, ll):
                    done += 1
                else:
                    failed += 1
            except Exception:  # noqa: BLE001
                log.exception("step failed: %s", s)
                failed += 1
        self.say_auto("Sab ho gaya!" if not failed else f"{done} kaam ho gaye, {failed} samajh nahi aaye.", "happy", force=True)

    def _multi_step(self, t: str, ll: str):
        """'open chrome phir youtube search karo ...' and 'kaam karo: <goal>' (AI plans the steps when online)."""
        m = re.match(r"^\s*(?:kaam karo|agent mode|do this|plan)\s*[:\-]\s*(.{6,300})$", t, re.I)
        if m:
            try:
                steps = pc_tools.parse_plan(self.engine.long_form(pc_tools.PLAN_PROMPT + m.group(1), 300))
            except Exception:  # noqa: BLE001
                return "Plan banane ke liye mujhe internet ya offline AI chahiye."
            if not steps:
                return "Iska plan nahi ban paaya. Thoda aasaan karke bolo."
        else:
            steps = [s for s in pc_tools.split_steps(t)]
            if len(steps) < 2 or any(pc_tools.BLOCKED_IN_PLAN.search(s) for s in steps):
                return None
        first = self._run_step(steps[0], ll)
        if not first:
            return None if not m else "Pehla step nahi ho paaya, isliye ruk gayi."
        threading.Thread(target=self._run_plan, args=(steps[1:], ll), daemon=True).start()
        return f"{first} Phir {len(steps) - 1} aur kaam karti hoon…"

    def _make_document(self, kind: str, topic: str) -> str:
        try:
            if kind == "csv":
                prompt = f"Create a small table about: {topic}. Output ONLY rows, one per line, columns separated by |, first row = headers."
            else:
                prompt = f"Write a clear, well-organized {'document' if kind != 'txt' else 'note'} about: {topic}. Plain text, short paragraphs, no markdown symbols."
            body = self.engine.long_form(prompt)
            title = topic.split(".")[0][:50]
            try:
                p = pc_tools.create_document(kind, title, body)
            except ValueError:                                  # Hindi text can't go into the simple PDF: use Word instead
                p = pc_tools.create_document("docx", title, body)
            if sys.platform == "win32":
                os.startfile(str(p))                            # noqa: S606
            self.pc.last_file = p
            return f"Ho gaya! {p.name} Documents/Earthvasi me bana di."
        except Exception:  # noqa: BLE001
            log.exception("document failed")
            return "Document nahi ban paaya. Internet ya offline AI chahiye."

    def _special(self, text: str, ll: str):
        """Soul / skills / knowledge base / plugin chat commands. Returns (reply, extra_context)."""
        t = text.strip()
        low = t.lower()
        if re.match(r"^\s*(?:self ?check|health ?check|diagnos\w*|sab check karo|sab kuch check karo|kya kya kharab hai|kaam nahi kar raha)\s*$", t, re.I):
            return self.run_health_check(), ""
        if self.screen:
            if screen_agent.STOP.match(t) and self.screen.running:
                self.screen.stop()
                return "Ruk rahi hoon. 🛑", ""
            m = screen_agent.TRIGGER.match(t)
            if m:
                goal = m.group(1).strip()
                threading.Thread(target=lambda: self.say_auto(self.screen.run(goal), "happy", force=True), daemon=True).start()
                return "Screen dekh kar karti hoon. Rokna ho to 'ruko' bolo.", ""
        if re.match(r"^\s*(?:ab\s+|abhi\s+)?(?:hat\s*jao|hat\s*ja|hato|chhup\s*jao|chup\s*jao|gayab\s*ho\s*jao|go away|hide( yourself| now)?|disappear|ab\s+jao)\s*(?:please|plz|yaar)?\s*[.!]*\s*$", t, re.I):
            threading.Timer(2.2, self.hide_requested.emit).start()
            return "Theek hai, hat gayi. 👋 Wapas bulane ke liye Alt+Space ya tray icon dabao.", ""
        if re.match(r"^\s*(?:apne (?:bare|baare) (?:me|mein) (?:batao|bataiye|bolo)|tum kaun ho|aap kaun ho|who are you|introduce yourself|about yourself|tumhara naam kya hai)\s*[?.!]*\s*$", t, re.I):
            me = self.cfg.get("assistant_name") or "Earthvasi"
            who = self.cfg.get("user_name") or "aapki"
            return (f"Main {me} hoon, {who} ki personal AI assistant, Gaya, India me Earthvasi ne banayi hai. "
                    "Main baat karti hoon, sawaalon ke jawab deti hoon, apps aur files sambhalti hoon, likhti aur padhkar sunati hoon, "
                    "reminder lagati hoon, aapki pasand yaad rakhti hoon aur screen bhi chala sakti hoon. "
                    "Internet na ho tab bhi offline kaam karti hoon. Bas bolo kya karna hai!"), ""
        dm = re.match(r"^\s*(?:(?:yaha|yahan|isme|ispe|active window me)\s+)?(?:likho|likh do|type karo|type kro|type|dictate|bolkar likho)\s*[:\-]?\s+(.+)$", t, re.I | re.S)
        if dm and self.screen:                                  # dictate into whatever app has focus
            txt = dm.group(1).strip()
            def _type():
                import time
                time.sleep(1.2)                                 # let the focus return to the other app
                self.screen.inp.type_text(txt)
            threading.Thread(target=_type, daemon=True).start()
            return "Likh rahi hoon - jis app me cursor hai wahan. ✍️", ""
        rd = re.match(r"^\s*(?:(?:ye|yeh|is|screen|ise)\s+)?(?:screen\s+)?(padho|padh do|read this|read screen|samjhao|samjha do|explain this|batao ye kya hai|screen me kya hai)\b.*$", t, re.I)
        if rd and self.screen:
            def _read():
                try:
                    q = ("Read the visible text on this screen aloud in a natural way." if re.match(r"pad|read", rd.group(1), re.I)
                         else "Explain simply what is on this screen.")
                    ans = self._vision("You are a friendly voice assistant. Answer in the user's language (Hinglish ok), max 5 short sentences, no markdown.", q, self._capture())
                except Exception as exc:  # noqa: BLE001
                    ans = f"Screen padh nahi paayi ({exc}). Internet aur API key check karo."
                self.say_auto(ans, "happy", force=True)
            threading.Thread(target=_read, daemon=True).start()
            return "Screen dekh rahi hoon…", ""
        r = self._multi_step(t, ll)
        if r:
            return r, ""
        r = self.pc.try_execute(t, ll)
        if r:
            return r, ""
        dr = pc_tools.doc_request(t)
        if dr:
            return self._make_document(dr[0], dr[1]), ""
        if self.soul and re.search(r"(mera profile|my profile|soul profile|tum mere baare me)", low):
            d = self.soul.data
            return (f"Naam: {d.get('name') or '?'}, bhasha: {d.get('language')}, pasand: {', '.join(d['likes'][-4:]) or '-'}, "
                    f"projects: {', '.join(d['projects'][-2:]) or '-'}. Ye sirf is PC par saved hai."), ""
        if self.soul and re.search(r"(profile (?:delete|clear|reset)|meri profile (?:delete|mita))", low):
            self.soul.forget()
            return "Meri profile mita di.", ""
        if self.bridge:
            if re.search(r"\b(phone jodo|pair (?:my )?phone|link (?:my )?phone|mobile jodo)\b", low):
                try:
                    tok = self.bridge.start()
                    return (f"Phone me bolo: pc se jodo {local_ip()} {tok}  (dono ek hi Wi-Fi par hone chahiye). "
                            "Band karne ke liye: phone band."), ""
                except OSError:
                    return "Bridge start nahi ho paaya (port busy ya firewall).", ""
            if re.search(r"\b(phone band|unpair phone|stop bridge)\b", low):
                self.bridge.stop()
                return "Phone se connection band kar diya.", ""
            m = re.match(r"^(?:phone par|mobile par|on phone)\s+(.{2,200})$", t, re.I)
            if m and self.bridge.running:
                self.bridge.queue_for_phone(m.group(1))
                return "Phone ko bhej diya.", ""
        if self.skills:
            r = self.skills.handle_command(t)
            if r:
                return r, ""
        if self.kb:
            folder = self.kb.parse_index(t)
            if folder:
                def work():
                    try:
                        f, c = self.kb.index_folder(folder)
                        self.say_auto(f"Ho gaya! {f} files, {c} hisse yaad kar liye.", "happy", force=True)
                    except FileNotFoundError:
                        self.say_auto("Ye folder mujhe mila nahi.", "sad", force=True)
                    except Exception:  # noqa: BLE001
                        log.exception("index failed")
                        self.say_auto("Index karte waqt dikkat aayi.", "sad", force=True)
                threading.Thread(target=work, daemon=True).start()
                return "Folder padh rahi hoon, thoda time lagega…", ""
            q = self.kb.parse_ask(t)
            if q:
                ctx = self.kb.context_for(q)
                return (None, ctx + f"\nQuestion: {q}") if ctx else ("Tumhari files me iska jawab nahi mila. Pehle “index folder <path>” bolo.", "")
        if websearch.WEB_Q.search(t) and is_online():
            ctx = websearch.context_for(t)
            if ctx:
                return None, ctx + f"\nQuestion: {t}"
        return None, ""

    def _process(self, text: str, lang: str) -> None:
        if not self._busy.acquire(blocking=False):
            self.status.emit("One moment, I'm still thinking…")
            return
        emotion = "neutral"
        try:
            self.chatter.user_lang = lang or self.chatter.user_lang
            ll = line_lang(lang)
            self.status.emit("Thinking…")
            reply, mode = None, "system"
            if _ACTIVITY_Q.search(text.lower()):
                reply, emotion = self.tracker.describe(ll), "thinking"
            if reply is None:
                rem = reminders.parse(text)
                if rem:
                    reply, emotion = self._set_reminder(rem[0], rem[1], ll), "happy"
            if reply is None and self.memory:
                reply = self.memory.handle_command(text, ll)          # "remember that…", "what do you remember?"
                emotion = "happy" if reply else emotion
            extra = ""
            if reply is None:
                reply, extra = self._special(text, ll)
                emotion = "happy" if reply else emotion
            if reply is None and self.plugins:
                reply = self.plugins.handle_command(text, ll) or self.plugins.try_handle(text, ll)
                emotion = "happy" if reply else emotion
            if reply is None and self.routines:
                reply = self.routines.handle_command(text, ll)
                if reply == "":                                       # a routine started; it speaks by itself
                    self.reply_ready.emit("On it!", "system", "happy")
                    return
                emotion = "happy" if reply else emotion
            if reply is None:   # local commands are checked BEFORE any LLM routing (works offline)
                reply = self.automation.try_execute(text, ll)
                emotion = "happy" if reply else emotion
            if reply is None and vision.SCREEN_Q.search(text):
                self._screen_answer(text, ll)
                return
            if reply is None:
                if self.memory and self.cfg.get("memory_enabled", True):
                    self.memory.learn(text)
                if self.soul and self.soul.observe(text):
                    self._reflect_async()
                r = self.engine.ask(extra or text, ll if ll != "en" else "")
                reply, mode, emotion = r.text, r.mode, r.emotion
                if self.memory and self.cfg.get("memory_enabled", True) and mode != "error":
                    self.memory.add_turn(text, reply)
            if self.skills and mode == "system" and reply:
                offer = self.skills.watch(text, True)
                if offer:
                    reply = f"{reply} {offer}"
            self.reply_ready.emit(reply, mode, emotion)
        except Exception:  # noqa: BLE001
            log.exception("Processing failed")
            reply = "Sorry, something went wrong."
            self.reply_ready.emit(reply, "error", "sad")
        finally:
            self._busy.release()
        self._speak(reply, lang)

    def _set_reminder(self, secs: float, what: str, ll: str) -> str:
        def fire():
            pool = LINES[ll]["reminder"]
            line = pool[0].format(name=self.cfg.get("user_name") or "friend", what=what or "your reminder")
            self.say_auto(line, "happy", force=True)

        t = threading.Timer(secs, fire)
        t.daemon = True
        t.start()
        d = _fmt_duration(secs, ll)
        if ll == "hinglish":
            return f"Done! {d} baad reminder laga diya{': ' + what if what else ''}."
        if ll == "hi":
            return f"ठीक है! {d} बाद याद दिला दिया जाएगा{': ' + what if what else ''}।"
        return f"Done! I'll remind you in {d}{' to ' + what if what else ''}."

    def _speak(self, text: str, user_lang: str = "") -> None:
        with self._tts_lock:
            self.speaking = True
            self.speaking_changed.emit(True)
            try:
                tts.speak(text, self.cfg, user_lang, self.gender)
            except Exception:  # noqa: BLE001
                log.exception("TTS failed")
            finally:
                self.speaking = False
                self.speaking_changed.emit(False)

    # ---------------------------------------------------- speed: warm everything up
    def warm_up(self) -> None:
        """Load models into memory in the background so the first answer is fast."""
        self._spawn(self._warm_worker)

    def _warm_worker(self) -> None:
        size = self.cfg.get("stt_model", "small")
        try:
            if self.transcriber.is_ready(size):
                self.transcriber._load(size)                     # Whisper into RAM
        except Exception:  # noqa: BLE001
            log.debug("Whisper warm-up skipped", exc_info=True)
        try:
            if self.cfg.get("offline_ready"):
                ollama_manager.warm(hardware.effective_model(self.cfg))   # Ollama model into RAM
        except Exception:  # noqa: BLE001
            log.debug("Ollama warm-up skipped", exc_info=True)
        try:
            if self.cfg.get("gemini_api_key") and is_online():
                import google.generativeai  # noqa: F401  (heavy import done ahead of time)
        except Exception:  # noqa: BLE001
            pass

    def refresh_models(self) -> None:
        """About once a week, while online, let Ollama fetch a newer build of the offline model."""
        if time.time() - float(self.cfg.get("last_model_refresh", 0) or 0) < 7 * 86400:
            return
        if self.cfg.get("offline_ready") and self.cfg.get("auto_update", True):
            self._spawn(self._refresh_worker)

    def _refresh_worker(self) -> None:
        if not is_online() or not ollama_manager.ensure_server(wait=8):
            return
        try:
            ollama_manager.pull_model(hardware.effective_model(self.cfg), lambda *_: None)   # no-op when current
            self.cfg["last_model_refresh"] = time.time()
            config_mod.save_config(self.cfg)
            log.info("Offline model refreshed")
        except Exception:  # noqa: BLE001
            log.debug("Model refresh failed", exc_info=True)

    # ---------------------------------------------------- background downloads
    def provision(self) -> None:
        """One-time background downloads: offline speech model (Whisper) then offline chat model (Ollama)."""
        self._spawn(self._provision_worker)

    def _provision_worker(self) -> None:
        if not is_online():
            return
        last = {"pct": -10}

        def cb(title: str, pct: int):
            if pct == 0 or pct >= last["pct"] + 2:
                last["pct"] = pct
                self.progress.emit(title, pct, f"{pct}%" if pct else "")

        messages = []
        size = self.cfg.get("stt_model", "small")
        if not self.transcriber.is_ready(size):
            try:
                self.transcriber.ensure_model(size, cb)
                messages.append("Offline voice recognition is ready.")
            except ImportError:
                log.warning("faster-whisper not installed; skipping voice model")
            except Exception:  # noqa: BLE001
                log.exception("Voice model download failed")
                messages.append("Voice model download failed. I'll retry next time.")
        last["pct"] = -10
        if self.cfg.get("auto_setup_offline") and not self.cfg.get("offline_ready"):
            ok, msg = ollama_manager.provision(hardware.effective_model(self.cfg), cb)
            if ok:
                self.cfg["offline_ready"] = True
                config_mod.save_config(self.cfg)
            messages.append(msg)
        if messages:
            self.progress_done.emit(" ".join(messages))


class UpdateRunner(QObject):
    """Checks GitHub (or a custom URL) for a newer version; also handles offline zips.

    manual=True  : user asked -> shows progress and installs straight away.
    manual=False : background  -> downloads silently, then emits `ready` so the app can install when idle.
    """
    progress = pyqtSignal(str, int, str)     # title, percent, detail
    failed = pyqtSignal(str)
    no_update = pyqtSignal()
    restart_needed = pyqtSignal(str, str)    # staged folder, new version  (install now)
    ready = pyqtSignal(str, str)             # staged folder, new version  (install when idle)

    def __init__(self, cfg_getter=None, parent=None):
        super().__init__(parent)
        self._cfg = cfg_getter or (lambda: {})
        self._lock = threading.Lock()

    def start(self, manual: bool = False) -> None:
        threading.Thread(target=self._run, args=(manual,), daemon=True).start()

    def install_local(self, path: str) -> None:
        threading.Thread(target=self._local, args=(path,), daemon=True).start()

    def _local(self, path: str) -> None:
        try:
            self.progress.emit("Reading update file", 20, "")
            content, version = updater.stage_local_zip(Path(path))
            updater.save_pending(content, version)
            self.restart_needed.emit(str(content), version)
        except Exception as exc:  # noqa: BLE001
            log.warning("Local update failed: %s", exc)
            self.failed.emit(f"Update failed: {exc}")

    def _run(self, manual: bool) -> None:
        if not self._lock.acquire(blocking=False):
            return                                  # a check/download is already running
        started = False  # noqa: F841
        try:
            if not updater.updates_enabled():
                if manual:
                    self.failed.emit("Updates are disabled when running from source.")
                return
            # 1) something already staged earlier, or dropped into the offline inbox folder
            pend = updater.load_pending()
            if pend is None:
                inbox = updater.find_inbox_update()
                if inbox is not None:
                    try:
                        pend = updater.stage_local_zip(inbox, copy=False)
                        updater.save_pending(*pend)
                    except Exception as exc:  # noqa: BLE001
                        log.warning("Inbox update unusable: %s", exc)
            if pend is not None:
                (self.restart_needed if manual else self.ready).emit(str(pend[0]), pend[1])
                return
            # 2) online check
            info = updater.check_for_update(str(self._cfg().get("update_url", "")))
            if info is None:
                if manual:
                    self.no_update.emit()
                return
            started = True
            title = f"Updating to v{info.version}"
            if manual:
                self.progress.emit(title, 0, "Starting download…")

            def on_chunk(done: int, total: int):
                if not manual:
                    return
                pct = int(done * 100 / total) if total else 0
                detail = f"{done / 1_048_576:.1f} / {total / 1_048_576:.1f} MB" if total \
                    else f"{done / 1_048_576:.1f} MB"
                self.progress.emit(title, pct, detail)

            zip_path = updater.download_update(info, on_chunk)
            if manual:
                self.progress.emit(title, 100, "Verifying and unpacking…")
            staged = updater.stage_update(zip_path, info)
            updater.save_pending(staged, info.version)
            (self.restart_needed if manual else self.ready).emit(str(staged), info.version)
        except Exception as exc:  # noqa: BLE001
            log.warning("Update check/apply failed: %s", exc)
            if manual:
                self.failed.emit(f"Update failed: {exc}")
        finally:
            self._lock.release()
