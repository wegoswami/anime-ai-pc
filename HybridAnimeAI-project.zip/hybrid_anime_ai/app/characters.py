"""Character registry (no Qt).

Built-in characters:  assets/characters/<id>/character.json   (type "vector")
Imported by the user: %APPDATA%/HybridAnimeAI/characters/<id>/character.json  (type "image" / "gif")
"""
import json
import shutil
from pathlib import Path
from typing import Optional

from .paths import characters_dir, user_characters_dir


def _load_dir(root: Path, builtin: bool) -> list:
    out = []
    if not root.is_dir():
        return out
    for d in sorted(p for p in root.iterdir() if p.is_dir()):
        f = d / "character.json"
        if not f.exists():
            continue
        try:
            spec = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        spec.setdefault("id", d.name)
        spec.setdefault("name", d.name.replace("_", " ").title())
        spec.setdefault("type", "vector")
        spec.setdefault("gender", "girl")
        spec.setdefault("voice_gender", "female" if spec["gender"] == "girl" else "male")
        spec["builtin"] = builtin
        spec["dir"] = str(d)
        out.append(spec)
    return out


def list_characters() -> list:
    return _load_dir(characters_dir(), True) + _load_dir(user_characters_dir(), False)


def get_character(char_id: str) -> Optional[dict]:
    chars = list_characters()
    for c in chars:
        if c["id"] == char_id:
            return c
    return chars[0] if chars else None


def delete_user_character(char_id: str) -> bool:
    d = user_characters_dir() / char_id
    if d.is_dir():
        shutil.rmtree(d, ignore_errors=True)
        return True
    return False
