"""Floating speech bubble / progress card and the type-to-chat bar (separate frameless windows)."""
from PyQt6.QtCore import QTimer, Qt, pyqtSignal
from PyQt6.QtWidgets import QFrame, QLabel, QLineEdit, QProgressBar, QVBoxLayout, QWidget

CARD_CSS = ("QFrame#card { background: rgba(24,24,44,238); border-radius: 16px; "
            "border: 1px solid rgba(139,123,255,170); } QLabel { color: white; background: transparent; "
            "font-size: 13px; }")


class Bubble(QWidget):
    def __init__(self):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
                         | Qt.WindowType.Tool | Qt.WindowType.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.card = QFrame(objectName="card")
        self.card.setStyleSheet(CARD_CSS)
        outer.addWidget(self.card)
        lay = QVBoxLayout(self.card)
        lay.setContentsMargins(14, 10, 14, 10)
        lay.setSpacing(5)
        self.label = QLabel("")
        self.label.setWordWrap(True)
        self.label.setMaximumWidth(270)
        self.bar = QProgressBar()
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(8)
        self.bar.setRange(0, 100)
        self.bar.setStyleSheet("QProgressBar { background: #2a2a4a; border: none; border-radius: 4px; }"
                               "QProgressBar::chunk { border-radius: 4px; background: qlineargradient("
                               "x1:0,y1:0,x2:1,y2:0, stop:0 #6b5bff, stop:1 #ff6bd5); }")
        self.detail = QLabel("")
        self.detail.setStyleSheet("color: #b9b5e8; font-size: 11px;")
        for w in (self.label, self.bar, self.detail):
            lay.addWidget(w)
        self.bar.hide()
        self.detail.hide()
        self._timer = QTimer(self, singleShot=True)
        self._timer.timeout.connect(self.hide_all)
        self.sticky = False         # progress cards stay until finished

    def _fit(self) -> None:
        self.adjustSize()
        self.setFixedWidth(max(120, min(300, self.sizeHint().width())))
        self.adjustSize()

    def show_text(self, text: str, ms: int = 0) -> None:
        if self.sticky:
            return
        shown = text if len(text) <= 280 else text[:277] + "…"
        self.label.setText(shown)
        self.bar.hide()
        self.detail.hide()
        self._fit()
        self.show()
        self._timer.start(ms or max(3500, len(shown) * 70))

    def show_level(self, level: float) -> None:
        """Mic level meter while listening (level = RMS 0..~0.3)."""
        if self.sticky:
            return
        self.label.setText("🎤 Listening…")
        self.bar.setRange(0, 100)
        self.bar.setValue(min(100, int(level * 600)))
        self.bar.show()
        self._fit()
        self.show()
        self._timer.start(1500)

    def show_progress(self, title: str, pct: int, detail: str = "") -> None:
        self.sticky = True
        self._timer.stop()
        self.label.setText(title)
        self.bar.show()
        if pct < 0:
            self.bar.setRange(0, 0)
        else:
            self.bar.setRange(0, 100)
            self.bar.setValue(min(100, pct))
        self.detail.setText(detail)
        self.detail.setVisible(bool(detail))
        self._fit()
        self.show()

    def finish(self, text: str, ms: int = 4000) -> None:
        self.sticky = False
        self.show_text(text, ms)

    def hide_all(self) -> None:
        if not self.sticky:
            self.hide()


class InputBar(QWidget):
    submitted = pyqtSignal(str)

    def __init__(self):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
                         | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.edit = QLineEdit()
        self.edit.setFixedSize(280, 38)
        self.edit.setPlaceholderText("Type to me in any language…  (Enter = send, Esc = close)")
        self.edit.setStyleSheet("QLineEdit { background: rgba(24,24,44,245); color: white; "
                                "border: 1px solid rgba(139,123,255,200); border-radius: 12px; "
                                "padding: 6px 12px; font-size: 13px; }")
        lay.addWidget(self.edit)
        self.edit.returnPressed.connect(self._send)

    def _send(self) -> None:
        t = self.edit.text().strip()
        self.edit.clear()
        if t:
            self.submitted.emit(t)

    def open_at(self, x: int, y: int) -> None:
        self.move(x, y)
        self.show()
        self.raise_()
        self.activateWindow()
        self.edit.setFocus()

    dismissed = pyqtSignal()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape:
            self.hide()
            self.dismissed.emit()
        else:
            super().keyPressEvent(e)
