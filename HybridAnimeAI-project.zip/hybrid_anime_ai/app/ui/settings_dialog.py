"""First-run onboarding and Settings: profile, characters (+ import your own image), voice/mic, behaviour, AI."""
import threading
import time

from PyQt6.QtCore import QObject, QSize, Qt, pyqtSignal
from PyQt6.QtGui import QIcon, QPixmap
from PyQt6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QHBoxLayout,
                             QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QProgressBar, QPushButton,
                             QSlider, QTabWidget, QVBoxLayout, QWidget)

from ..avatar.importer import SUPPORTED, import_image
from ..avatar.view import preview_image
from ..characters import delete_user_character, list_characters
from ..version import APP_NAME
from ..voice import mic, tts
from ..voice.stt import MODEL_CHOICES, Transcriber

STYLE = """
QDialog { background: #1b1b2f; }
QWidget { color: #e8e6ff; font-size: 13px; }
QTabWidget::pane { border: 1px solid #3b3566; border-radius: 10px; top: -1px; }
QTabBar::tab { background: #24244a; color: #b9b5e8; padding: 9px 16px; border-top-left-radius: 8px;
               border-top-right-radius: 8px; margin-right: 3px; }
QTabBar::tab:selected { background: #6b5bff; color: white; }
QLabel#title { font-size: 22px; font-weight: 700; color: white; }
QLabel#sub, QLabel#hint { color: #a9a5d6; font-size: 12px; }
QLabel#err { color: #ff8a9b; }
QLineEdit, QComboBox { background: #14142a; color: white; border: 1px solid #3b3566; border-radius: 9px;
                       padding: 7px 10px; }
QLineEdit:focus, QComboBox:focus { border: 1px solid #8b7bff; }
QComboBox QAbstractItemView { background: #14142a; color: white; selection-background-color: #6b5bff; }
QListWidget { background: #14142a; border: 1px solid #3b3566; border-radius: 10px; }
QListWidget::item { color: #e8e6ff; border-radius: 10px; padding: 4px; }
QListWidget::item:selected { background: #3d3485; border: 1px solid #8b7bff; }
QSlider::groove:horizontal { height: 6px; background: #14142a; border-radius: 3px; }
QSlider::sub-page:horizontal { background: #6b5bff; border-radius: 3px; }
QSlider::handle:horizontal { background: #b0a5ff; width: 16px; margin: -5px 0; border-radius: 8px; }
QCheckBox { spacing: 8px; }
QProgressBar { background: #14142a; border: none; border-radius: 4px; height: 8px; }
QProgressBar::chunk { background: #6b5bff; border-radius: 4px; }
QPushButton { background: #2c2c58; color: white; border: 1px solid #3b3566; border-radius: 10px; padding: 8px 14px; }
QPushButton:hover { border-color: #8b7bff; }
QPushButton#primary { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #6b5bff, stop:1 #b05bff);
                      border: none; font-weight: 600; font-size: 14px; padding: 11px 22px; }
"""

LANG_CHOICES = [("auto", "Automatic - follow the language I use"), ("en", "English"),
                ("hinglish", "Hinglish (Hindi in English letters)"), ("hi", "हिन्दी (Devanagari)")]
LEVEL_CHOICES = [("off", "Off - only talk when I talk"), ("low", "Low - now and then"),
                 ("normal", "Normal"), ("high", "High - very chatty")]


class DropList(QListWidget):
    filesDropped = pyqtSignal(list)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)

    def dragEnterEvent(self, e):
        e.acceptProposedAction() if e.mimeData().hasUrls() else e.ignore()

    def dragMoveEvent(self, e):
        e.acceptProposedAction() if e.mimeData().hasUrls() else e.ignore()

    def dropEvent(self, e):
        paths = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.filesDropped.emit(paths)
            e.acceptProposedAction()


class _Worker(QObject):
    level = pyqtSignal(int)
    done = pyqtSignal(bool, str)
    progress = pyqtSignal(str, int)


class ImportDialog(QDialog):
    """Ask for name / gender / background removal for an imported picture."""

    def __init__(self, path: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add my own character")
        self.setStyleSheet(STYLE)
        lay = QVBoxLayout(self)
        pic = QLabel()
        pm = QPixmap(path)
        if not pm.isNull():
            pic.setPixmap(pm.scaled(160, 160, Qt.AspectRatioMode.KeepAspectRatio,
                                    Qt.TransformationMode.SmoothTransformation))
        pic.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(pic)
        form = QFormLayout()
        self.name = QLineEdit(path.replace("\\", "/").rsplit("/", 1)[-1].rsplit(".", 1)[0])
        self.gender = QComboBox()
        self.gender.addItem("Girl (female voice)", "girl")
        self.gender.addItem("Boy (male voice)", "boy")
        self.persona = QLineEdit()
        self.persona.setPlaceholderText("e.g. shy, loves music (optional)")
        form.addRow("Name", self.name)
        form.addRow("Voice", self.gender)
        form.addRow("Personality", self.persona)
        lay.addLayout(form)
        self.remove_bg = QCheckBox("Remove the plain background automatically")
        self.remove_bg.setChecked(True)
        lay.addWidget(self.remove_bg)
        hint = QLabel("PNG with transparency works best. Any image format is accepted; animated GIFs stay animated.")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        lay.addWidget(box)


class SettingsDialog(QDialog):
    def __init__(self, cfg: dict, tracker=None, first_run: bool = False, parent=None):
        super().__init__(parent)
        self.cfg = dict(cfg)
        self.tracker = tracker
        self.first_run = first_run
        self.result_config = None
        self._chars = []
        self.setWindowTitle(f"{APP_NAME} - " + ("Welcome" if first_run else "Settings"))
        self.setStyleSheet(STYLE)
        self.setMinimumSize(640, 640)

        root = QVBoxLayout(self)
        title = QLabel("Welcome ✨  Let's set up your companion" if first_run else "Settings", objectName="title")
        root.addWidget(title)
        if first_run:
            root.addWidget(QLabel("Everything can be changed later from my right-click menu.", objectName="sub"))
        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)
        self.tabs.addTab(self._tab_profile(), "Profile")
        self.tabs.addTab(self._tab_character(), "Character")
        self.tabs.addTab(self._tab_voice(), "Voice")
        self.tabs.addTab(self._tab_behavior(), "Behaviour")
        self.tabs.addTab(self._tab_ai(), "AI")
        self.err = QLabel("", objectName="err")
        root.addWidget(self.err)
        row = QHBoxLayout()
        row.addStretch()
        if not first_run:
            cancel = QPushButton("Cancel")
            cancel.clicked.connect(self.reject)
            row.addWidget(cancel)
        save = QPushButton("Save && Start" if first_run else "Save", objectName="primary")
        save.setDefault(True)
        save.clicked.connect(self._save)
        row.addWidget(save)
        root.addLayout(row)

    # ------------------------------------------------------------------- tabs
    def _tab_profile(self) -> QWidget:
        w = QWidget()
        f = QFormLayout(w)
        f.setContentsMargins(18, 18, 18, 18)
        f.setSpacing(12)
        self.assistant_edit = QLineEdit(self.cfg.get("assistant_name", ""))
        self.assistant_edit.setPlaceholderText("e.g. Aiko")
        self.user_edit = QLineEdit(self.cfg.get("user_name", ""))
        self.user_edit.setPlaceholderText("What should I call you?")
        self.lang_combo = QComboBox()
        for code, label in LANG_CHOICES:
            self.lang_combo.addItem(label, code)
        self.lang_combo.setCurrentIndex(max(0, self.lang_combo.findData(self.cfg.get("language_pref", "auto"))))
        f.addRow("Assistant name", self.assistant_edit)
        f.addRow("Your name", self.user_edit)
        f.addRow("Language of my remarks", self.lang_combo)
        note = QLabel("I understand your speech and typing in any language automatically. This only "
                      "chooses the language of the things I say on my own.", objectName="hint")
        note.setWordWrap(True)
        f.addRow(note)
        return w

    def _tab_character(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(14, 14, 14, 14)
        self.char_list = DropList()
        self.char_list.setViewMode(QListWidget.ViewMode.IconMode)
        self.char_list.setIconSize(QSize(96, 132))
        self.char_list.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.char_list.setMovement(QListWidget.Movement.Static)
        self.char_list.setSpacing(8)
        self.char_list.setWordWrap(True)
        self.char_list.filesDropped.connect(self._import_paths)
        lay.addWidget(self.char_list, 1)
        row = QHBoxLayout()
        add = QPushButton("＋ Add my own image / GIF…")
        add.clicked.connect(self._pick_image)
        rm = QPushButton("Remove selected (mine only)")
        rm.clicked.connect(self._remove_selected)
        row.addWidget(add)
        row.addWidget(rm)
        row.addStretch()
        lay.addLayout(row)
        hint = QLabel("Tip: drag any picture (PNG, JPG, WEBP, GIF …) onto this list. It becomes a character with "
                      "emotions, walking, sitting and voice.", objectName="hint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        size_row = QHBoxLayout()
        size_row.addWidget(QLabel("Size"))
        self.scale = QSlider(Qt.Orientation.Horizontal, minimum=60, maximum=170)
        self.scale.setValue(int(float(self.cfg.get("avatar_scale", 1.0)) * 100))
        self.scale_lbl = QLabel(f"{self.scale.value()}%")
        self.scale.valueChanged.connect(lambda v: self.scale_lbl.setText(f"{v}%"))
        size_row.addWidget(self.scale, 1)
        size_row.addWidget(self.scale_lbl)
        lay.addLayout(size_row)
        self._fill_characters(self.cfg.get("character"))
        return w

    def _tab_voice(self) -> QWidget:
        w = QWidget()
        f = QFormLayout(w)
        f.setContentsMargins(18, 18, 18, 18)
        f.setSpacing(10)
        self.voice_combo = QComboBox()
        voices = tts.list_voices()
        self.voice_combo.addItem("Automatic (best voice for the language)", "")
        for vid, name, loc in voices:
            self.voice_combo.addItem(f"{name}  [{loc or '?'}]", vid)
        self.voice_combo.setCurrentIndex(max(0, self.voice_combo.findData(self.cfg.get("voice_id", ""))))
        self.vgender = QComboBox()
        for label, val in (("Follow the character", "auto"), ("👩 Female voice", "female"), ("👨 Male voice", "male")):
            self.vgender.addItem(label, val)
        self.vgender.setCurrentIndex(max(0, self.vgender.findData(self.cfg.get("voice_gender", "auto"))))
        self.vengine = QComboBox()
        self.vengine.addItem("Natural human voice (internet needed)", "natural")
        self.vengine.addItem("System voice (offline)", "system")
        self.vengine.setCurrentIndex(max(0, self.vengine.findData(self.cfg.get("voice_engine", "natural"))))
        self.rate = QSlider(Qt.Orientation.Horizontal, minimum=100, maximum=260)
        self.rate.setValue(int(self.cfg.get("voice_rate", 175)))
        self.volume = QSlider(Qt.Orientation.Horizontal, minimum=0, maximum=100)
        self.volume.setValue(int(float(self.cfg.get("voice_volume", 1.0)) * 100))
        test = QPushButton("▶  Test voice")
        test.clicked.connect(self._test_voice)
        f.addRow("Voice type", self.vengine)
        f.addRow("Male / Female", self.vgender)
        f.addRow("Offline voice", self.voice_combo)
        f.addRow("Speed", self.rate)
        f.addRow("Volume", self.volume)
        f.addRow("", test)
        hint = QLabel("Need a Hindi voice? Windows Settings > Time & language > Speech > Add voices.",
                      objectName="hint")
        hint.setWordWrap(True)
        f.addRow(hint)

        self.mic_combo = QComboBox()
        self.mic_combo.addItem("System default microphone", None)
        for idx, name in mic.list_input_devices():
            self.mic_combo.addItem(name, idx)
        self.mic_combo.setCurrentIndex(max(0, self.mic_combo.findData(self.cfg.get("mic_device"))))
        f.addRow("Microphone", self.mic_combo)
        mrow = QHBoxLayout()
        self.mic_btn = QPushButton("🎤  Test microphone")
        self.mic_btn.clicked.connect(self._test_mic)
        priv = QPushButton("Windows mic privacy…")
        priv.clicked.connect(mic.open_privacy_settings)
        mrow.addWidget(self.mic_btn)
        mrow.addWidget(priv)
        mrow.addStretch()
        f.addRow("", mrow)
        self.mic_bar = QProgressBar()
        self.mic_bar.setRange(0, 100)
        self.mic_bar.setTextVisible(False)
        f.addRow("", self.mic_bar)
        self.mic_msg = QLabel("", objectName="hint")
        self.mic_msg.setWordWrap(True)
        f.addRow(self.mic_msg)

        self.stt_combo = QComboBox()
        for code, label in MODEL_CHOICES:
            self.stt_combo.addItem(label, code)
        self.stt_combo.setCurrentIndex(max(0, self.stt_combo.findData(self.cfg.get("stt_model", "small"))))
        self.stt_combo.currentIndexChanged.connect(self._refresh_stt_status)
        f.addRow("Offline listening model", self.stt_combo)
        srow = QHBoxLayout()
        self.stt_status = QLabel("", objectName="hint")
        self.stt_btn = QPushButton("Download now")
        self.stt_btn.clicked.connect(self._download_stt)
        srow.addWidget(self.stt_status, 1)
        srow.addWidget(self.stt_btn)
        f.addRow("", srow)
        self.stt_bar = QProgressBar()
        self.stt_bar.setRange(0, 100)
        self.stt_bar.setTextVisible(False)
        self.stt_bar.hide()
        f.addRow("", self.stt_bar)
        self.hands_free = QCheckBox("Hands-free: keep listening and answer when I say her name")
        self.hands_free.setChecked(bool(self.cfg.get("hands_free")))
        self.wake_req = QCheckBox("Only react when my name is said (recommended)")
        self.wake_req.setChecked(bool(self.cfg.get("wake_word_required", True)))
        f.addRow(self.hands_free)
        f.addRow(self.wake_req)
        self._refresh_stt_status()
        return w

    def _tab_behavior(self) -> QWidget:
        w = QWidget()
        f = QFormLayout(w)
        f.setContentsMargins(18, 18, 18, 18)
        f.setSpacing(12)
        self.level = QComboBox()
        for code, label in LEVEL_CHOICES:
            self.level.addItem(label, code)
        self.level.setCurrentIndex(max(0, self.level.findData(self.cfg.get("proactive_level", "normal"))))
        f.addRow("Talking by herself", self.level)
        self.walk = QCheckBox("Walk around the screen on her own")
        self.walk.setChecked(bool(self.cfg.get("behavior_walk", True)))
        self.perch = QCheckBox("Jump onto the window I'm working in and sit on its edge")
        self.perch.setChecked(bool(self.cfg.get("behavior_perch", True)))
        self.aware = QCheckBox("Notice which app I'm using (kept only on this PC, never uploaded)")
        self.aware.setChecked(bool(self.cfg.get("activity_awareness", True)))
        self.fullscreen = QCheckBox("Hide while a game or video is full screen")
        self.fullscreen.setChecked(bool(self.cfg.get("hide_in_fullscreen", True)))
        for c in (self.walk, self.perch, self.aware, self.fullscreen):
            f.addRow(c)
        clear = QPushButton("Clear my activity history")
        clear.clicked.connect(self._clear_activity)
        f.addRow(clear)
        return w

    def _tab_ai(self) -> QWidget:
        w = QWidget()
        f = QFormLayout(w)
        f.setContentsMargins(18, 18, 18, 18)
        f.setSpacing(12)
        self.key_edit = QLineEdit(self.cfg.get("gemini_api_key", ""))
        self.key_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.key_edit.setPlaceholderText("Paste a free key from aistudio.google.com")
        self.model_edit = QLineEdit(self.cfg.get("gemini_model", ""))
        self.offline_check = QCheckBox("Prepare offline chat (downloads a local AI model, about 1.6 GB)")
        self.offline_check.setChecked(bool(self.cfg.get("auto_setup_offline", True)))
        self.ollama_edit = QLineEdit(self.cfg.get("ollama_model", ""))
        self.auto_update = QCheckBox("Update automatically (downloads in the background, installs when you're away)")
        self.auto_update.setChecked(bool(self.cfg.get("auto_update", True)))
        self.openai_edit = QLineEdit(self.cfg.get("openai_api_key", ""))
        self.openai_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.openai_edit.setPlaceholderText("Optional: sk-… (OpenAI)")
        self.claude_edit = QLineEdit(self.cfg.get("anthropic_api_key", ""))
        self.claude_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.claude_edit.setPlaceholderText("Optional: sk-ant-… (Claude)")
        self.order_combo = QComboBox()
        for label, val in (("Gemini → OpenAI → Claude", ["gemini", "openai", "claude"]),
                           ("OpenAI → Claude → Gemini", ["openai", "claude", "gemini"]),
                           ("Claude → OpenAI → Gemini", ["claude", "openai", "gemini"]),
                           ("Claude → Gemini → OpenAI", ["claude", "gemini", "openai"])):
            self.order_combo.addItem(label, val)
        cur = list(self.cfg.get("provider_order") or ["gemini", "openai", "claude"])
        for i in range(self.order_combo.count()):
            if self.order_combo.itemData(i) == cur:
                self.order_combo.setCurrentIndex(i)
        self.auto_model = QCheckBox("Pick the offline model that fits this PC automatically")
        self.auto_model.setChecked(bool(self.cfg.get("auto_model", True)))
        try:
            from ..core import hardware
            hw = hardware.cached()
            rec, size = hardware.recommend_model(hw)
            hw_text = f"This PC: {hw.summary()}. Best offline model: {rec} (~{size})."
        except Exception:  # noqa: BLE001
            hw_text = ""
        self.hw_label = QLabel(hw_text, objectName="hint")
        self.hw_label.setWordWrap(True)
        self.memory_check = QCheckBox("Remember our conversations and what I tell her (stored only on this PC)")
        self.memory_check.setChecked(bool(self.cfg.get("memory_enabled", True)))
        self.analytics_check = QCheckBox("Share anonymous usage counts to improve the app (random ID, version, features used - never chats, files or keys)")
        self.analytics_check.setChecked(bool(self.cfg.get("analytics", True)))
        f.addRow("Gemini API key", self.key_edit)
        f.addRow("Gemini model", self.model_edit)
        f.addRow("OpenAI API key", self.openai_edit)
        f.addRow("Claude API key", self.claude_edit)
        f.addRow("Which AI first?", self.order_combo)
        f.addRow(self.offline_check)
        f.addRow(self.auto_model)
        f.addRow(self.hw_label)
        f.addRow("Offline model (Ollama)", self.ollama_edit)
        f.addRow(self.memory_check)
        f.addRow(self.analytics_check)
        f.addRow(self.auto_update)
        note = QLabel("Online: your first available AI (Gemini, OpenAI or Claude) answers; if one fails the next is tried. "
                      "Offline (no internet): the local model answers. "
                      "Opening apps and system commands always work without internet.", objectName="hint")
        note.setWordWrap(True)
        f.addRow(note)
        return w

    # ------------------------------------------------------------- characters
    def _fill_characters(self, select_id=None) -> None:
        self.char_list.clear()
        self._chars = list_characters()
        for c in self._chars:
            item = QListWidgetItem(QIcon(QPixmap.fromImage(preview_image(c, 96, 132))),
                                   c["name"] + ("" if c.get("builtin") else " ★"))
            item.setData(Qt.ItemDataRole.UserRole, c["id"])
            item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
            item.setSizeHint(QSize(112, 170))
            self.char_list.addItem(item)
            if c["id"] == select_id:
                self.char_list.setCurrentItem(item)
        if self.char_list.currentItem() is None and self.char_list.count():
            self.char_list.setCurrentRow(0)

    def _pick_image(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(self, "Choose pictures (select many)", "", f"Images ({SUPPORTED});;All files (*)")
        if paths:
            self._import_paths(list(paths))

    def _import_paths(self, paths: list) -> None:
        last = None
        for path in paths:
            dlg = ImportDialog(path, self)
            if not dlg.exec():
                continue
            try:
                spec = import_image(path, dlg.name.text().strip(), dlg.gender.currentData(),
                                    dlg.remove_bg.isChecked(), dlg.persona.text().strip())
                last = spec["id"]
            except Exception as exc:  # noqa: BLE001 - corrupt / unsupported file
                QMessageBox.warning(self, "Couldn't use that picture", f"{path}\n\n{exc}")
        if last:
            self._fill_characters(last)

    def _remove_selected(self) -> None:
        it = self.char_list.currentItem()
        if not it:
            return
        cid = it.data(Qt.ItemDataRole.UserRole)
        c = next((c for c in self._chars if c["id"] == cid), None)
        if not c or c.get("builtin"):
            QMessageBox.information(self, "Built-in character", "Built-in characters can't be removed.")
            return
        if QMessageBox.question(self, "Remove character", f"Remove '{c['name']}'?") == QMessageBox.StandardButton.Yes:
            delete_user_character(cid)
            self._fill_characters()

    # ----------------------------------------------------------------- actions
    def _test_voice(self) -> None:
        cfg = dict(self.cfg, voice_id=self.voice_combo.currentData() or "", voice_rate=self.rate.value(),
                   voice_gender=self.vgender.currentData(), voice_engine=self.vengine.currentData(),
                   voice_volume=self.volume.value() / 100)
        name = self.assistant_edit.text().strip() or "your assistant"
        threading.Thread(target=lambda: tts.speak(f"Hi! I'm {name}. Nice to meet you!", cfg), daemon=True).start()

    def _test_mic(self) -> None:
        self.mic_btn.setEnabled(False)
        self.mic_msg.setText("Speak now…")
        w = _Worker(self)
        w.level.connect(self.mic_bar.setValue)
        w.done.connect(lambda ok, msg: (self.mic_msg.setText(("✅ " if ok else "⚠ ") + msg),
                                        self.mic_btn.setEnabled(True), self.mic_bar.setValue(0)))
        device = self.mic_combo.currentData()

        def run():
            ok, msg = mic.diagnose(device)
            if not ok:
                w.done.emit(False, msg)
                return
            try:
                sd = mic._sd()
                peak = [0.0]

                def cb(indata, *_):
                    import numpy as np
                    peak[0] = float(np.sqrt(np.mean(np.square(indata))))
                    w.level.emit(min(100, int(peak[0] * 600)))

                loudest = 0.0
                with sd.InputStream(samplerate=mic.SR, channels=1, dtype="float32", device=device, callback=cb):
                    end = time.time() + 3.0
                    while time.time() < end:
                        loudest = max(loudest, peak[0])
                        time.sleep(0.05)
                w.done.emit(True, "Microphone works and I can hear you." if loudest > 0.015
                            else "Microphone opens, but it's very quiet. Speak louder or pick another microphone.")
            except Exception as exc:  # noqa: BLE001
                w.done.emit(False, mic.PRIVACY_HELP if "host error" in str(exc).lower() else str(exc))

        threading.Thread(target=run, daemon=True).start()

    def _refresh_stt_status(self) -> None:
        size = self.stt_combo.currentData()
        ready = Transcriber().is_ready(size)
        self.stt_status.setText("✅ Downloaded - works offline" if ready else
                                "Not downloaded yet. It downloads automatically when you're online.")
        self.stt_btn.setEnabled(not ready)

    def _download_stt(self) -> None:
        size = self.stt_combo.currentData()
        self.stt_btn.setEnabled(False)
        self.stt_bar.show()
        w = _Worker(self)
        w.progress.connect(lambda t, p: (self.stt_bar.setValue(p), self.stt_status.setText(f"{t}… {p}%")))
        w.done.connect(lambda ok, msg: (self.stt_status.setText(msg), self.stt_bar.hide(),
                                        self._refresh_stt_status() if ok else self.stt_btn.setEnabled(True)))

        def run():
            try:
                Transcriber().ensure_model(size, lambda t, p: w.progress.emit(t, p))
                w.done.emit(True, "✅ Downloaded - works offline")
            except Exception as exc:  # noqa: BLE001
                w.done.emit(False, f"Download failed: {exc}")

        threading.Thread(target=run, daemon=True).start()

    def _clear_activity(self) -> None:
        if self.tracker is not None:
            self.tracker.clear()
        QMessageBox.information(self, "Done", "Your activity history was deleted.")

    # -------------------------------------------------------------------- save
    def _save(self) -> None:
        me, user = self.assistant_edit.text().strip(), self.user_edit.text().strip()
        if not me or not user:
            self.tabs.setCurrentIndex(0)
            self.err.setText("Please fill in both names.")
            return
        item = self.char_list.currentItem()
        cfg = dict(self.cfg)
        cfg.update({
            "assistant_name": me, "user_name": user, "language_pref": self.lang_combo.currentData(),
            "character": item.data(Qt.ItemDataRole.UserRole) if item else cfg.get("character"),
            "avatar_scale": self.scale.value() / 100,
            "voice_id": self.voice_combo.currentData() or "", "voice_rate": self.rate.value(),
            "voice_gender": self.vgender.currentData(), "voice_engine": self.vengine.currentData(),
            "voice_volume": self.volume.value() / 100, "mic_device": self.mic_combo.currentData(),
            "stt_model": self.stt_combo.currentData(), "hands_free": self.hands_free.isChecked(),
            "wake_word_required": self.wake_req.isChecked(),
            "proactive_level": self.level.currentData(), "behavior_walk": self.walk.isChecked(),
            "behavior_perch": self.perch.isChecked(), "activity_awareness": self.aware.isChecked(),
            "hide_in_fullscreen": self.fullscreen.isChecked(),
            "gemini_api_key": self.key_edit.text().strip(), "gemini_model": self.model_edit.text().strip() or cfg.get("gemini_model"),
            "openai_api_key": self.openai_edit.text().strip(), "anthropic_api_key": self.claude_edit.text().strip(),
            "provider_order": self.order_combo.currentData(), "auto_model": self.auto_model.isChecked(),
            "memory_enabled": self.memory_check.isChecked(),
            "analytics": self.analytics_check.isChecked(),
            "auto_setup_offline": self.offline_check.isChecked(),
            "auto_update": self.auto_update.isChecked(),
            "ollama_model": self.ollama_edit.text().strip() or cfg.get("ollama_model"),
            "setup_complete": True,
        })
        self.result_config = cfg
        self.accept()
