"""Little status chip next to the character: an animated prop + what it is doing ("🔍 Dhundh rahi hoon…")."""
import math
import time

from PyQt6.QtCore import QPointF, QRectF, QTimer, Qt
from PyQt6.QtGui import QColor, QFont, QPainter
from PyQt6.QtWidgets import QWidget

from ..core import activity

W, H = 250, 46


class ActChip(QWidget):
    def __init__(self):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
                         | Qt.WindowType.Tool | Qt.WindowType.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setFixedSize(W, H)
        self.kind = ""
        self.t0 = 0.0
        self.tick_i = 0
        self._label_t = 0.0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._step)
        self._end = QTimer(self, singleShot=True)
        self._end.timeout.connect(self.stop)

    def start(self, kind: str, max_s: float = 60.0) -> None:
        if kind not in activity.ACTS:
            return
        self.kind, self.t0, self.tick_i, self._label_t = kind, time.time(), 0, time.time()
        self._end.start(int(max_s * 1000))
        self._timer.start(40)
        self.show()
        self.update()

    def finish(self) -> None:
        """Job done: show a green tick for a moment (only if the job was visible long enough to notice)."""
        if not self.kind or self.kind == "done":
            return
        took = time.time() - self.t0
        QTimer.singleShot(int(max(0.0, 0.9 - took) * 1000), self._show_done)

    def _show_done(self) -> None:
        if not self.kind:
            return
        self.kind, self.t0 = "done", time.time()
        self._end.start(1100)
        self.update()

    def stop(self) -> None:
        self.kind = ""
        self._timer.stop()
        self._end.stop()
        self.hide()

    def _step(self) -> None:
        if time.time() - self._label_t > 2.4:
            self._label_t = time.time()
            self.tick_i += 1
        self.update()

    def paintEvent(self, _e) -> None:
        if not self.kind:
            return
        t = time.time() - self.t0
        ico, g, _emo, _labs = activity.ACTS[self.kind]
        text = activity.label(self.kind, t, self.tick_i)
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        ok = self.kind == "done"
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(223, 255, 233, 240) if ok else QColor(255, 255, 255, 240))
        p.drawRoundedRect(QRectF(2, 2, W - 4, H - 4), 18, 18)
        # the prop moves according to its gesture
        dx, dy, rot, sx, sy = activity.gesture_xform(g, t)
        p.save()
        p.translate(26, H / 2)
        p.rotate(rot * 4)
        p.scale(sx, sy)
        f = QFont("Segoe UI Emoji")
        f.setPointSize(16)
        p.setFont(f)
        p.drawText(QPointF(-13 + dx * 0.5, 9 + dy * 0.5), ico)
        p.restore()
        p.setPen(QColor(20, 90, 47) if ok else QColor(42, 36, 56))
        f2 = QFont("Segoe UI")
        f2.setPointSize(9)
        f2.setBold(True)
        p.setFont(f2)
        p.drawText(QRectF(48, 0, W - 80, H), int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft), text)
        if not ok:                                                    # three bouncing dots
            for i in range(3):
                y = H / 2 - 3 * max(0.0, math.sin(t * 6 - i * 0.7))
                p.setBrush(QColor(255, 143, 192))
                p.setPen(Qt.PenStyle.NoPen)
                p.drawEllipse(QPointF(W - 26 + i * 8, y), 2.5, 2.5)
        p.end()
