"""The desktop pet window: frameless, transparent, always on top. Walks, sits on windows, follows the cursor."""
import logging
import os
import time

from PyQt6.QtCore import QPoint, QTimer, Qt, pyqtSignal
from PyQt6.QtGui import QAction, QCursor, QGuiApplication, QIcon, QPixmap
from PyQt6.QtWidgets import QMenu, QSystemTrayIcon, QWidget

from .. import config as config_mod
from ..avatar.state import CANVAS_H, CANVAS_W, CENTER_X, GROUND_Y
from ..avatar.view import AvatarView, preview_image
from ..behavior.brain import Env, PetBrain, Surface
from ..characters import get_character, list_characters
from ..system import winapi
from ..system.activity import friendly_app
from ..system.screens import ScreenInfo, rect_to_logical
from ..version import APP_NAME, APP_VERSION
from .bubble import Bubble, InputBar

log = logging.getLogger(__name__)
BASE = 0.8                  # canvas units -> pixels at 100 % size
MENU_CSS = ("QMenu { background: #1b1b2f; color: white; border: 1px solid #3b3566; border-radius: 8px; "
            "padding: 6px; } QMenu::item { padding: 6px 22px; border-radius: 6px; } "
            "QMenu::item:selected { background: #6b5bff; } QMenu::separator { height: 1px; background: #3b3566; "
            "margin: 4px 8px; }")


class PetWindow(QWidget):
    check_updates = pyqtSignal()
    update_from_file = pyqtSignal(str)
    open_settings = pyqtSignal()
    quit_app = pyqtSignal()

    def __init__(self, cfg: dict, assistant):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
                         | Qt.WindowType.Tool | Qt.WindowType.WindowDoesNotAcceptFocus)
        self.cfg = cfg
        self.assistant = assistant
        self.setWindowTitle(APP_NAME)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)

        self.bubble = Bubble()
        self.input = InputBar()
        self.input.submitted.connect(self._typed)

        self.char = get_character(cfg.get("character", "")) or {"type": "vector"}
        self.view = AvatarView(self.char, self)
        self.k = BASE
        self._apply_scale()

        self.brain = PetBrain(0, 0, walk=cfg.get("behavior_walk", True), perch=cfg.get("behavior_perch", True))
        self._place_initially()

        # interaction state
        self._press = None
        self._moved = False
        self._click_timer = QTimer(self, singleShot=True, interval=260)
        self._click_timer.timeout.connect(self._single_click)
        self._user_hidden = False

        # system sampling
        self._last_probe = 0.0
        self._last_sec = 0.0
        self._surfaces = []
        self._cursor_surface = None
        self._fg = None
        self._idle = 0.0
        self._cursor_prev = QCursor.pos()
        self._cursor_move_t = time.time()
        self._cursor_speed = 0.0
        self._last_t = time.time()
        self._fullscreen = False

        a = assistant
        a.reply_ready.connect(self._on_reply)
        a.status.connect(lambda s: self.bubble.show_text(s, 2600))
        a.speaking_changed.connect(self._on_speaking)
        a.listening_changed.connect(self._on_listening)
        a.mic_level.connect(self.bubble.show_level)
        a.progress.connect(lambda t, p, d: self.bubble.show_progress(t, p, d))
        a.progress_done.connect(lambda m: self.bubble.finish(m, 6000))

        self.tray = None
        self._build_tray()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(33)

    # ----------------------------------------------------------------- geometry
    def _apply_scale(self) -> None:
        self.k = BASE * float(self.cfg.get("avatar_scale", 1.0))
        self.resize(int(CANVAS_W * self.k), int(CANVAS_H * self.k))
        self.view.setGeometry(0, 0, self.width(), self.height())

    def _screen_at(self, x: float, y: float):
        return QGuiApplication.screenAt(QPoint(int(x), int(y))) or QGuiApplication.primaryScreen()

    def _place_initially(self) -> None:
        pos = self.cfg.get("pos")
        scr = QGuiApplication.primaryScreen().availableGeometry()
        if pos and len(pos) == 2:
            fx, fy = float(pos[0]), float(pos[1])
            if not any(s.availableGeometry().contains(QPoint(int(fx), int(fy - 5))) for s in QGuiApplication.screens()):
                fx, fy = scr.right() - 140, scr.top() + 60
        else:
            fx, fy = scr.right() - 140, scr.top() + 60       # drops in from the top, lands on the taskbar
        self.brain.x, self.brain.y = fx, fy
        self._sync_window()

    def _sync_window(self) -> None:
        self.move(int(self.brain.x - CENTER_X * self.k), int(self.brain.y - GROUND_Y * self.k))

    def feet(self) -> tuple:
        return self.x() + CENTER_X * self.k, self.y() + GROUND_Y * self.k

    # ------------------------------------------------------------------- tick
    def _screens(self) -> list:
        return [ScreenInfo(s.geometry().x(), s.geometry().y(), s.geometry().width(), s.geometry().height(),
                           s.devicePixelRatio()) for s in QGuiApplication.screens()]

    def _probe(self, now: float, avail) -> None:
        """Ask Windows about windows / cursor / idle time (4x per second)."""
        self._last_probe = now
        self._idle = winapi.idle_seconds()
        fg = winapi.foreground()
        self._fg = fg
        self._fullscreen = bool(fg and fg.fullscreen)
        screens = self._screens()
        wins = winapi.list_windows(exclude_pid=os.getpid())
        pet_h = self.height()
        surfaces, rects = [], []
        for w in wins:
            l, t, r, b = rect_to_logical(screens, w.left, w.top, w.right, w.bottom)
            rects.append((str(w.hwnd), l, t, r, b))
            if w.maximized or w.fullscreen:
                continue
            cx = (l + r) / 2
            if not (avail.left() <= cx <= avail.right() and t >= avail.top() + pet_h * 0.8 and t < avail.bottom() - 60):
                continue
            # skip windows whose top edge is hidden under a window that is higher in the z-order
            covered = any(oid != str(w.hwnd) and ol <= cx <= or_ and ot <= t + 3 <= ob
                          for (oid, ol, ot, or_, ob) in rects[:-1])
            if covered:
                continue
            surfaces.append(Surface(str(w.hwnd), max(l, avail.left()), min(r, avail.right()), t,
                                    friendly_app(w.process)))
        self._surfaces = surfaces
        # which window is the cursor in? (that is "where the user is working")
        self._cursor_surface = None
        native = winapi.cursor_native()
        if native:
            under = winapi.window_at(*native)
            if under and under.pid != os.getpid():
                if any(s.id == str(under.hwnd) for s in surfaces):
                    self._cursor_surface = str(under.hwnd)
                elif under.maximized or under.fullscreen or any(
                        str(under.hwnd) == oid for (oid, *_r) in rects):
                    self._cursor_surface = "ground-work"

    def _tick(self) -> None:
        now = time.time()
        dt = max(0.001, now - self._last_t)
        self._last_t = now
        fx, fy = self.brain.x, self.brain.y
        scr = self._screen_at(fx, fy - 10)
        g = scr.availableGeometry()
        avail = g
        screen = (g.left(), g.top(), g.right() + 1, g.bottom() + 1)

        if now - self._last_probe > 0.25:
            self._probe(now, avail)
        if now - self._last_sec > 1.0:
            self._last_sec = now
            self._once_per_second(now)

        cur = QCursor.pos()
        moved = abs(cur.x() - self._cursor_prev.x()) + abs(cur.y() - self._cursor_prev.y())
        if moved > 6:
            self._cursor_move_t = now
        self._cursor_speed = moved / dt if moved else self._cursor_speed * 0.8
        self._cursor_prev = cur

        env = Env(now=now, dt=dt, screen=screen, surfaces=self._surfaces, cursor=(cur.x(), cur.y()),
                  cursor_still_s=now - self._cursor_move_t, cursor_speed=self._cursor_speed,
                  cursor_surface_id=self._cursor_surface, user_idle_s=self._idle,
                  speaking=self.assistant.speaking, listening=self.view.state.listening,
                  head_offset=(GROUND_Y - 128) * self.k)
        frame = self.brain.tick(env)

        st = self.view.state
        st.pose, st.facing, st.walk_phase, st.look = frame.pose, frame.facing, frame.walk_phase, frame.look
        self.view.set_emotion(frame.emotion)
        if self.brain.mode != "held":
            self._sync_window()

        for kind, arg in frame.intents:
            msg = self.assistant.chatter.on_intent(kind, arg, now)
            if msg:
                self.assistant.say_auto(*msg)

        # hide while a game / video is full screen
        if self.cfg.get("hide_in_fullscreen", True) and self._fullscreen:
            if self.isVisible():
                self.hide()
                self.bubble.hide()
        elif not self.isVisible() and not self._user_hidden:
            self.show()
        self._place_bubble()

    def _once_per_second(self, now: float) -> None:
        fg = self._fg
        if fg is not None:
            self.assistant.tracker.sample(now, fg.process, fg.title, self._idle)
        msg = self.assistant.chatter.tick(now, time.localtime().tm_hour, fg.process if fg else "",
                                          self.assistant.speaking or self.view.state.listening,
                                          self._fullscreen, self._idle)
        if msg:
            self.assistant.say_auto(*msg)

    # ------------------------------------------------------------------ events
    def _on_reply(self, text: str, mode: str, emotion: str) -> None:
        self.bubble.show_text(text)
        secs = max(4.0, min(12.0, len(text) * 0.07))
        self.brain.set_emotion(emotion if emotion else "neutral", secs, time.time())

    def _on_speaking(self, on: bool) -> None:
        self.view.state.speaking = on

    def _on_listening(self, on: bool) -> None:
        self.view.state.listening = on

    def _typed(self, text: str) -> None:
        self.bubble.show_text(f"You: {text}", 1800)
        self.assistant.submit_text(text)

    def _place_bubble(self) -> None:
        if self.bubble.isVisible():
            head_y = self.y() + (GROUND_Y - 215) * self.k
            bx = int(self.x() + self.width() / 2 - self.bubble.width() / 2)
            by = int(head_y - self.bubble.height())
            scr = self._screen_at(self.x() + self.width() / 2, self.y() + self.height() / 2).availableGeometry()
            bx = max(scr.left() + 4, min(scr.right() - self.bubble.width() - 4, bx))
            if by < scr.top() + 4:          # no room above (pet at the top): show beside/below the head
                by = int(self.y() + (GROUND_Y - 20) * self.k)
            self.bubble.move(bx, by)
        if self.input.isVisible():
            self.input.move(int(self.x() + self.width() / 2 - self.input.width() / 2),
                            int(self.y() + self.height() + 4))

    # ---------------------------------------------------------- mouse: drag/click
    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._press = e.globalPosition().toPoint()
            self._grab_off = self._press - self.frameGeometry().topLeft()
            self._moved = False
            e.accept()

    def mouseMoveEvent(self, e):
        if self._press is None or not (e.buttons() & Qt.MouseButton.LeftButton):
            return
        gp = e.globalPosition().toPoint()
        if not self._moved and (gp - self._press).manhattanLength() > 6:
            self._moved = True
            fx, fy = self.feet()
            self.brain.grab(fx, fy, time.time())
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
        if self._moved:
            tl = gp - self._grab_off
            self.move(tl)
            fx, fy = self.feet()
            self.brain.drag(fx, fy)

    def mouseReleaseEvent(self, e):
        if e.button() != Qt.MouseButton.LeftButton or self._press is None:
            return
        self.setCursor(Qt.CursorShape.ArrowCursor)
        if self._moved:
            self.brain.release(time.time())
            QTimer.singleShot(2500, self._save_pos)
        else:
            self._click_timer.start()
        self._press = None

    def _single_click(self) -> None:
        self.brain.poke(time.time())
        self.assistant.listen_once()

    def mouseDoubleClickEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._click_timer.stop()
            self.toggle_input()

    def toggle_input(self) -> None:
        if self.input.isVisible():
            self.input.hide()
        else:
            self.input.open_at(int(self.x() + self.width() / 2 - self.input.width() / 2),
                               int(self.y() + self.height() + 4))

    def _save_pos(self) -> None:
        self.cfg["pos"] = [int(self.brain.x), int(self.brain.y)]
        try:
            config_mod.save_config(self.cfg)
        except OSError:
            pass

    # ------------------------------------------------------------ menu and tray
    def set_character(self, char_id: str) -> None:
        self.cfg["character"] = char_id
        ch = get_character(char_id)
        if ch:
            self.char = ch
            self.view.set_avatar(ch)
            self.assistant.apply_character(ch)
        config_mod.save_config(self.cfg)
        self._refresh_tray_icon()

    def apply_config(self, cfg: dict) -> None:
        self.cfg = cfg
        self._apply_scale()
        self.brain.walk_enabled = cfg.get("behavior_walk", True)
        self.brain.perch_enabled = cfg.get("behavior_perch", True)
        ch = get_character(cfg.get("character", ""))
        if ch:
            self.char = ch
            self.view.set_avatar(ch)
            self.assistant.apply_character(ch)
        self._refresh_tray_icon()

    def _make_menu(self, parent=None) -> QMenu:
        menu = QMenu(parent)
        menu.setStyleSheet(MENU_CSS)
        a = self.assistant

        def add(text, fn, checked=None):
            act = QAction(text, menu)
            if checked is not None:
                act.setCheckable(True)
                act.setChecked(checked)
            act.triggered.connect(fn)
            menu.addAction(act)
            return act

        add("🎤  Talk to me (or just click me)", lambda: a.listen_once())
        add("💬  Type a message (double-click)", lambda: self.toggle_input())
        add("🎧  Hands-free listening (say my name)", lambda on: a.set_hands_free(on),
            checked=bool(self.cfg.get("hands_free")))
        add("🕘  What was I doing?", lambda: a.submit_text("what was I doing"))
        menu.addSeparator()
        sub = menu.addMenu("🧑‍🎤  Change character")
        sub.setStyleSheet(MENU_CSS)
        for c in list_characters():
            act = QAction(("★ " if c["id"] == self.cfg.get("character") else "") + c["name"]
                          + ("  (mine)" if not c.get("builtin") else ""), sub)
            act.triggered.connect(lambda _=False, cid=c["id"]: self.set_character(cid))
            sub.addAction(act)
        quiet = self.cfg.get("proactive_level") == "off"
        add("🤫  Quiet mode (don't talk by yourself)", self._toggle_quiet, checked=quiet)
        menu.addSeparator()
        add("⟳  Check for updates", lambda: self.check_updates.emit())
        add("📦  Update from a file (offline)…", lambda: self._pick_update_file())
        add("⚙  Settings / add my own character", lambda: self.open_settings.emit())
        ver = QAction(f"{APP_NAME} v{APP_VERSION}", menu)
        ver.setEnabled(False)
        menu.addAction(ver)
        menu.addSeparator()
        add("✕  Quit", lambda: self.quit_app.emit())
        return menu

    def _pick_update_file(self) -> None:
        from PyQt6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(self, "Choose an update package", "", "Update package (*.zip)")
        if path:
            self.update_from_file.emit(path)

    def _toggle_quiet(self, on: bool) -> None:
        self.cfg["proactive_level"] = "off" if on else "normal"
        config_mod.save_config(self.cfg)

    def contextMenuEvent(self, e):
        self._make_menu(self).exec(e.globalPos())

    def _tray_pixmap(self) -> QPixmap:
        return QPixmap.fromImage(preview_image(self.char, 64, 88))

    def _refresh_tray_icon(self) -> None:
        if self.tray:
            self.tray.setIcon(QIcon(self._tray_pixmap()))

    def _build_tray(self) -> None:
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self.tray = QSystemTrayIcon(QIcon(self._tray_pixmap()), self)
        self.tray.setToolTip(APP_NAME)
        self.tray.activated.connect(self._tray_clicked)
        self.tray.show()

    def _tray_clicked(self, reason) -> None:
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            self._toggle_visible()
        elif reason == QSystemTrayIcon.ActivationReason.Context:
            menu = self._make_menu()
            show = QAction("Show / hide me", menu)
            show.triggered.connect(lambda: self._toggle_visible())
            menu.insertAction(menu.actions()[0], show)
            menu.exec(QCursor.pos())

    def _toggle_visible(self) -> None:
        self._user_hidden = self.isVisible()
        if self._user_hidden:
            self.hide()
            self.bubble.hide()
        else:
            self.show()
