"""Filesystem locations that work both from source and from a PyInstaller build."""
import os
import sys
from pathlib import Path

from .version import APP_ID


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def bundle_dir() -> Path:
    """Read-only resources (assets). PyInstaller unpacks them to _MEIPASS."""
    if is_frozen():
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent.parent


def install_dir() -> Path:
    """Folder that holds the running executable (this is what updates overwrite)."""
    if is_frozen():
        return Path(sys.executable).resolve().parent
    return bundle_dir()


def data_dir() -> Path:
    """Per-user writable data (config, logs, characters, models). Survives updates and reinstalls."""
    base = os.environ.get("APPDATA") or str(Path.home() / ".config")
    p = Path(base) / APP_ID
    p.mkdir(parents=True, exist_ok=True)
    return p


def _sub(name: str) -> Path:
    p = data_dir() / name
    p.mkdir(parents=True, exist_ok=True)
    return p


def config_path() -> Path:
    return data_dir() / "config.json"


def updates_dir() -> Path:
    return _sub("updates")


def models_dir() -> Path:
    return _sub("models")


def user_characters_dir() -> Path:
    return _sub("characters")


def activity_path() -> Path:
    return data_dir() / "activity.json"


def characters_dir() -> Path:
    """Built-in characters shipped with the app."""
    return bundle_dir() / "assets" / "characters"


def updater_helper_path() -> Path:
    if is_frozen():
        return install_dir() / "updater.exe"
    return bundle_dir() / "updater" / "updater_helper.py"
