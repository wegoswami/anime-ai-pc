"""Local system automation (English, Hinglish and Hindi). Runs BEFORE any LLM routing, needs no internet."""
import ctypes
import datetime
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.parse
import webbrowser
from typing import Optional

IS_WIN = sys.platform == "win32"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
NEW_CONSOLE = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)

OPEN_WORDS = ["open", "launch", "start", "run", "kholo", "khol", "kholna", "chalao", "chala", "chalana",
              "shuru", "खोलो", "खोल", "चलाओ", "चला", "शुरू"]

# key -> (names people say, label, command, needs_console)
APPS = {
    "notepad": (["notepad", "note pad", "नोटपैड"], "Notepad", ["notepad.exe"], False),
    "calculator": (["calculator", "calc", "कैलकुलेटर", "केलकुलेटर"], "Calculator", ["calc.exe"], False),
    "paint": (["mspaint", "ms paint", "paint", "पेंट"], "Paint", ["mspaint.exe"], False),
    "explorer": (["file explorer", "windows explorer", "explorer", "this pc", "my computer", "फाइल एक्सप्लोरर"],
                 "File Explorer", ["explorer.exe"], False),
    "taskmgr": (["task manager", "टास्क मैनेजर"], "Task Manager", ["taskmgr.exe"], False),
    "cmd": (["command prompt", "cmd", "कमांड प्रॉम्प्ट"], "Command Prompt", ["cmd.exe"], True),
    "settings": (["settings", "सेटिंग्स", "सेटिंग"], "Settings", ["cmd", "/c", "start", "ms-settings:"], False),
    "camera": (["camera", "कैमरा"], "Camera", ["cmd", "/c", "start", "microsoft.windows.camera:"], False),
}
SITES = {
    "youtube": (["youtube", "यूट्यूब"], "https://www.youtube.com"),
    "gmail": (["gmail", "जीमेल"], "https://mail.google.com"),
    "google": (["google", "गूगल"], "https://www.google.com"),
}
CHROME_NAMES = ["google chrome", "chrome", "क्रोम"]

COMPUTER = ["computer", "pc", "laptop", "system", "machine", "कंप्यूटर", "लैपटॉप", "सिस्टम"]
YES = ["yes", "yeah", "yep", "confirm", "proceed", "do it", "haan", "han", "ha", "kar do", "kardo", "pakka",
       "theek hai", "हाँ", "हां", "पक्का", "कर दो"]
NO = ["no", "nope", "don't", "do not", "nahi", "nahin", "mat", "cancel", "ruk", "रुको", "नहीं", "मत", "रोको"]

MSG = {
    "opened": {"en": "Opening {x}.", "hinglish": "{x} khol diya.", "hi": "{x} खोल दिया।"},
    "chrome_missing": {"en": "I couldn't find Chrome, so I opened your default browser.",
                       "hinglish": "Chrome nahi mila, isliye default browser khol diya.",
                       "hi": "क्रोम नहीं मिला, इसलिए डिफ़ॉल्ट ब्राउज़र खोल दिया।"},
    "only_win": {"en": "That only works on Windows.", "hinglish": "Ye sirf Windows par chalta hai.",
                 "hi": "यह केवल विंडोज़ पर चलता है।"},
    "fail": {"en": "Sorry, I couldn't do that: {x}", "hinglish": "Sorry, ye nahi ho paya: {x}",
             "hi": "माफ़ कीजिए, यह नहीं हो पाया: {x}"},
    "ask_shutdown": {"en": "Shut down the computer? Say 'yes' within {x} seconds, or ignore me to cancel.",
                     "hinglish": "Computer band kar du? {x} second mein 'haan' bolo, warna main cancel kar dungi.",
                     "hi": "कंप्यूटर बंद कर दूँ? {x} सेकंड में 'हाँ' बोलिए, वरना रद्द कर दूँगी।"},
    "ask_restart": {"en": "Restart the computer? Say 'yes' within {x} seconds.",
                    "hinglish": "Computer restart kar du? {x} second mein 'haan' bolo.",
                    "hi": "कंप्यूटर रीस्टार्ट कर दूँ? {x} सेकंड में 'हाँ' बोलिए।"},
    "shutting": {"en": "Shutting down in 10 seconds. Say 'cancel shutdown' to stop.",
                 "hinglish": "10 second mein band ho raha hai. Rokna ho to 'cancel shutdown' bolo.",
                 "hi": "10 सेकंड में बंद हो रहा है। रोकना हो तो 'cancel shutdown' बोलिए।"},
    "restarting": {"en": "Restarting in 10 seconds. Say 'cancel shutdown' to stop.",
                   "hinglish": "10 second mein restart ho raha hai. Rokna ho to 'cancel shutdown' bolo.",
                   "hi": "10 सेकंड में रीस्टार्ट हो रहा है।"},
    "cancelled": {"en": "Okay, cancelled.", "hinglish": "Theek hai, cancel kar diya.", "hi": "ठीक है, रद्द कर दिया।"},
    "locked": {"en": "Locking the screen.", "hinglish": "Screen lock kar di.", "hi": "स्क्रीन लॉक कर दी।"},
    "vol_up": {"en": "Volume up.", "hinglish": "Volume badha diya.", "hi": "आवाज़ बढ़ा दी।"},
    "vol_down": {"en": "Volume down.", "hinglish": "Volume kam kar diya.", "hi": "आवाज़ कम कर दी।"},
    "mute": {"en": "Toggled mute.", "hinglish": "Mute toggle kar diya.", "hi": "म्यूट बदल दिया।"},
    "media": {"en": "Done.", "hinglish": "Ho gaya.", "hi": "हो गया।"},
    "shot": {"en": "Screenshot saved in Pictures > Screenshots.", "hinglish": "Screenshot Pictures > Screenshots mein save ho gaya.",
             "hi": "स्क्रीनशॉट Pictures > Screenshots में सेव हो गया।"},
    "search": {"en": "Searching for {x}.", "hinglish": "{x} search kar diya.", "hi": "{x} खोज दिया।"},
    "play": {"en": "Playing {x} on YouTube.", "hinglish": "YouTube par {x} laga diya.", "hi": "YouTube पर {x} चला दिया।"},
    "time": {"en": "It's {x}.", "hinglish": "Abhi {x} hue hain.", "hi": "अभी {x} हुए हैं।"},
    "battery": {"en": "Battery is at {x}.", "hinglish": "Battery {x} hai.", "hi": "बैटरी {x} है।"},
    "no_battery": {"en": "This PC has no battery (it's a desktop).", "hinglish": "Is PC me battery nahi hai (desktop hai).",
                   "hi": "इस पीसी में बैटरी नहीं है।"},
    "weather": {"en": "It's {x} right now.", "hinglish": "Abhi {x} hai.", "hi": "अभी {x} है।"},
    "weather_fail": {"en": "I couldn't get the weather (are you online?).", "hinglish": "Mausam nahi mil paaya (internet hai?).",
                     "hi": "मौसम नहीं मिल पाया (इंटरनेट है?)।"},
    "date": {"en": "Today is {x}.", "hinglish": "Aaj {x} hai.", "hi": "आज {x} है।"},
}


def _m(key: str, lang: str, x: str = "") -> str:
    lang = lang if lang in ("hinglish", "hi") else "en"
    return MSG[key][lang].format(x=x)


def _normalize(text: str) -> str:
    t = text.lower()
    t = re.sub(r"[!\"#$%&()*+,\-./:;<=>?@\[\\\]^_`{|}~।॥]", " ", t)   # keep letters AND combining marks
    return re.sub(r"\s+", " ", t).strip()


def has(t: str, words) -> bool:
    """Whole-word match for Latin words, substring match for Devanagari (matras break \\b)."""
    for w in words:
        if w.isascii():
            if re.search(r"(?<![a-z0-9'])" + re.escape(w) + r"(?![a-z0-9'])", t):
                return True
        elif w in t:
            return True
    return False


def _chrome_path() -> Optional[str]:
    found = shutil.which("chrome") or shutil.which("chrome.exe")
    if found:
        return found
    for env in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
        base = os.environ.get(env)
        if base:
            c = os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")
            if os.path.exists(c):
                return c
    return None


def press_key(vk: int, times: int = 1) -> None:
    for _ in range(times):
        ctypes.windll.user32.keybd_event(vk, 0, 0, 0)
        ctypes.windll.user32.keybd_event(vk, 0, 2, 0)


def press_combo(*vks: int) -> None:
    for vk in vks:
        ctypes.windll.user32.keybd_event(vk, 0, 0, 0)
    for vk in reversed(vks):
        ctypes.windll.user32.keybd_event(vk, 0, 2, 0)


WX_CODES = [
    ((0,), ("clear sky", "saaf aasman", "साफ़ आसमान")), ((1, 2, 3), ("partly cloudy", "thode badal", "थोड़े बादल")),
    ((45, 48), ("foggy", "kohra", "कोहरा")), ((51, 53, 55, 56, 57), ("drizzling", "halki bundabandi", "हल्की बूंदाबांदी")),
    ((61, 63, 65, 66, 67, 80, 81, 82), ("raining", "barish", "बारिश")), ((71, 73, 75, 77, 85, 86), ("snowing", "barf", "बर्फ़")),
    ((95, 96, 99), ("stormy", "toofan", "तूफ़ान")),
]


def weather_text(lang: str, get=None) -> Optional[str]:
    """Current weather for the PC's rough (IP-based) location via free, key-less services. None on any failure."""
    import requests
    get = get or (lambda url: requests.get(url, timeout=6).json())
    try:
        loc = get("https://ipapi.co/json/")
        cur = get("https://api.open-meteo.com/v1/forecast?latitude=%.2f&longitude=%.2f&current=temperature_2m,weather_code"
                  % (float(loc["latitude"]), float(loc["longitude"])))["current"]
    except Exception:  # noqa: BLE001 - offline, blocked, malformed ...
        return None
    idx = 1 if lang == "hinglish" else 2 if lang == "hi" else 0
    desc = next((names[idx] for codes, names in WX_CODES if cur.get("weather_code") in codes), "")
    city = loc.get("city") or ""
    t = round(cur["temperature_2m"])
    return f"{t}°C" + (f", {desc}" if desc else "") + (f" ({city})" if city else "")


class SystemAutomation:
    CONFIRM_WINDOW = 20

    def __init__(self):
        self._pending = None      # ("shutdown" | "restart", expires_at)

    # ------------------------------------------------------------------ public
    def try_execute(self, text: str, lang: str = "en") -> Optional[str]:
        """Return a reply if `text` was a local command, else None (-> LLM)."""
        t = _normalize(text)
        if not t:
            return None
        now = time.time()
        if self._pending and now > self._pending[1]:
            self._pending = None

        is_power_word = has(t, ["shutdown", "shut down", "restart", "reboot", "power off"]) or \
            (has(t, COMPUTER) and has(t, ["band", "off", "बंद"]))
        if has(t, ["cancel", "abort", "stop", "ruk", "रोक", "रुक"]) and is_power_word:
            return self._cancel(lang)
        if self._pending:
            if has(t, NO):
                self._pending = None
                return _m("cancelled", lang)
            if has(t, YES):
                return self._power(self._pending[0], lang)
        if has(t, ["restart", "reboot", "रीस्टार्ट"]) and has(t, COMPUTER + ["windows"]):
            self._pending = ("restart", now + self.CONFIRM_WINDOW)
            return _m("ask_restart", lang, str(self.CONFIRM_WINDOW))
        if is_power_word:
            self._pending = ("shutdown", now + self.CONFIRM_WINDOW)
            return _m("ask_shutdown", lang, str(self.CONFIRM_WINDOW))
        if has(t, ["lock", "लॉक"]) and has(t, COMPUTER + ["screen", "स्क्रीन"]):
            return self._lock(lang)

        r = self._media(t, lang)
        if r:
            return r

        if has(t, OPEN_WORDS):
            if has(t, CHROME_NAMES):
                return self._open_chrome(lang)
            for _k, (names, label, cmd, console) in APPS.items():
                if has(t, names):
                    return self._launch(label, cmd, console, lang)
            for key, (names, url) in SITES.items():
                if has(t, names):
                    webbrowser.open(url)
                    return _m("opened", lang, key.title())

        r = self._search(t, lang)
        if r:
            return r

        if has(t, ["battery", "charge kitna", "charging", "बैटरी"]):
            from ..system import winapi
            b = winapi.battery()
            if b is None:
                return _m("no_battery", lang)
            return _m("battery", lang, f"{b[0]}%" + {"en": " and charging", "hinglish": " aur charge ho rahi hai",
                                                    "hi": " और चार्ज हो रही है"}[lang if lang in ("hinglish", "hi") else "en"] * bool(b[1]))
        if has(t, ["weather", "mausam", "temperature", "tapman", "मौसम", "तापमान"]):
            txt = weather_text(lang)
            return _m("weather", lang, txt) if txt else _m("weather_fail", lang)
        if re.search(r"what(?:'s| is)? the time|what time is it|current time|time kya|kitne baje|samay kya|कितने बजे|टाइम क्या|समय क्या", t):
            return _m("time", lang, datetime.datetime.now().strftime("%I:%M %p").lstrip("0"))
        if re.search(r"what(?:'s| is)? (?:the )?(?:date|day)|today's date|aaj kya (?:tarikh|date|din)|aaj ki date|आज की तारीख|आज कौन सा दिन|तारीख क्या", t):
            return _m("date", lang, datetime.datetime.now().strftime("%A, %B %d, %Y"))
        return None

    # ----------------------------------------------------------------- helpers
    def _launch(self, label, cmd, new_console, lang) -> str:
        if not IS_WIN:
            return _m("only_win", lang)
        try:
            subprocess.Popen(cmd, close_fds=True, creationflags=NEW_CONSOLE if new_console else 0)
            return _m("opened", lang, label)
        except OSError as exc:
            return _m("fail", lang, str(exc))

    def _open_chrome(self, lang) -> str:
        path = _chrome_path()
        if path:
            try:
                subprocess.Popen([path], close_fds=True)
                return _m("opened", lang, "Chrome")
            except OSError:
                pass
        webbrowser.open("https://www.google.com")
        return _m("chrome_missing", lang)

    def _power(self, what: str, lang: str) -> str:
        self._pending = None
        if not IS_WIN:
            return _m("only_win", lang)
        flag = "/s" if what == "shutdown" else "/r"
        try:
            subprocess.Popen(["shutdown", flag, "/t", "10"], creationflags=NO_WINDOW)
            return _m("shutting" if what == "shutdown" else "restarting", lang)
        except OSError as exc:
            return _m("fail", lang, str(exc))

    def _cancel(self, lang: str) -> str:
        self._pending = None
        if IS_WIN:
            try:
                subprocess.Popen(["shutdown", "/a"], creationflags=NO_WINDOW)
            except OSError:
                pass
        return _m("cancelled", lang)

    def _lock(self, lang: str) -> str:
        if not IS_WIN:
            return _m("only_win", lang)
        ctypes.windll.user32.LockWorkStation()
        return _m("locked", lang)

    def _media(self, t: str, lang: str) -> Optional[str]:
        if not (re.search(r"volume|awaaz|awaz|sound|आवाज़|आवाज|वॉल्यूम|mute|unmute|म्यूट", t)
                or re.search(r"\b(next|previous|skip)\b.*\b(song|track|music|gana)\b|\b(pause|resume|play)\b.*\b(music|song|gana|gaana)\b|"
                             r"gana (?:roko|chalao|badlo)|screenshot|screen shot|स्क्रीनशॉट", t)):
            return None
        if not IS_WIN:
            return _m("only_win", lang)
        VK_MUTE, VK_DOWN, VK_UP, VK_NEXT, VK_PREV, VK_PLAY = 0xAD, 0xAE, 0xAF, 0xB0, 0xB1, 0xB3
        if re.search(r"screenshot|screen shot|स्क्रीनशॉट", t):
            press_combo(0x5B, 0x2C)                     # Win + PrintScreen
            return _m("shot", lang)
        if re.search(r"\bmute\b|unmute|म्यूट|awaaz band|आवाज़ बंद", t):
            press_key(VK_MUTE)
            return _m("mute", lang)
        if re.search(r"\bup\b|increase|raise|louder|badha|zyada|ज़्यादा|तेज़|तेज|बढ़ा|\bhigh\b", t):
            press_key(VK_UP, 5)
            return _m("vol_up", lang)
        if re.search(r"down|decrease|lower|quieter|\bkam\b|kum|कम|धीमा|घटा", t):
            press_key(VK_DOWN, 5)
            return _m("vol_down", lang)
        if re.search(r"next|skip|agla|अगला", t):
            press_key(VK_NEXT)
            return _m("media", lang)
        if re.search(r"previous|pichla|पिछला", t):
            press_key(VK_PREV)
            return _m("media", lang)
        if re.search(r"pause|resume|play|roko|chalao|रोको", t):
            press_key(VK_PLAY)
            return _m("media", lang)
        return None

    def _search(self, t: str, lang: str) -> Optional[str]:
        m = re.match(r"^(?:please |zara )?(?:search|google)(?: for)? (.+)$", t) or \
            re.match(r"^(.+?) (?:search karo|search kar do|search kar|google karo|dhundo|dhoondo|khojo)$", t)
        if m:
            q = m.group(1).strip()
            webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote_plus(q))
            return _m("search", lang, q)
        m = re.match(r"^(?:play|youtube(?: pe| par)?) (.+?)(?: on youtube)?$", t) or \
            re.match(r"^(.+?) (?:youtube (?:pe|par) )?(?:play karo|play kar|chalao|laga do|lagao)$", t)
        if m and not has(m.group(1), ["music", "song", "gana"]) or (m and len(m.group(1).split()) > 1):
            q = m.group(1).strip()
            if q in ("it", "that", "this") or has(q, [x for names, *_ in APPS.values() for x in names]):
                return None
            webbrowser.open("https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(q))
            return _m("play", lang, q)
        return None
