"""Backup / restore of the assistant's own data (memory, soul profile, routines, notes, settings, plugins, own characters).

API keys are never written into a backup. A restore keeps the keys currently saved on this PC.
"""
import json
import re
import time
import zipfile
from pathlib import Path
from typing import Callable, Optional

FILES = ("config.json", "memory.db", "user_soul_profile.json", "knowledge.db", "routines.json", "activity.json", "expenses.json")
DIRS = ("plugins", "characters")
SECRET = re.compile(r"(api_?key|token|password|secret)", re.I)


def default_dir() -> Path:
    return Path.home() / "Documents" / "Earthvasi-Backups"


def _strip(cfg: dict) -> dict:
    return {k: ("" if SECRET.search(k) else v) for k, v in cfg.items()}


def make_backup(data: Path, dest: Optional[Path] = None) -> Path:
    dest = Path(dest) if dest else default_dir()
    dest.mkdir(parents=True, exist_ok=True)
    out = dest / time.strftime("Earthvasi-backup-%Y%m%d-%H%M%S.zip")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for name in FILES:
            f = data / name
            if not f.is_file():
                continue
            if name == "config.json":
                try:
                    z.writestr(name, json.dumps(_strip(json.loads(f.read_text(encoding="utf-8"))), indent=2, ensure_ascii=False))
                except (OSError, ValueError):
                    pass
            else:
                z.write(f, name)
        for d in DIRS:
            root = data / d
            if root.is_dir():
                for p in root.rglob("*"):
                    if p.is_file() and p.stat().st_size < 20 * 1024 * 1024:
                        z.write(p, f"{d}/{p.relative_to(root).as_posix()}")
    return out


def latest(dest: Optional[Path] = None) -> Optional[Path]:
    d = Path(dest) if dest else default_dir()
    z = sorted(d.glob("Earthvasi-backup-*.zip")) if d.is_dir() else []
    return z[-1] if z else None


def restore(zip_path: Path, data: Path) -> int:
    """Returns how many files were restored. Current API keys are kept."""
    n = 0
    old = {}
    try:
        old = json.loads((data / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            name = info.filename
            if info.is_dir() or ".." in name or name.startswith("/") or not (name in FILES or name.split("/")[0] in DIRS):
                continue
            target = data / name
            target.parent.mkdir(parents=True, exist_ok=True)
            raw = z.read(name)
            if name == "config.json":
                try:
                    cfg = json.loads(raw.decode("utf-8"))
                    for k, v in old.items():
                        if SECRET.search(k):
                            cfg[k] = v
                    raw = json.dumps(cfg, indent=2, ensure_ascii=False).encode("utf-8")
                except ValueError:
                    continue
            target.write_bytes(raw)
            n += 1
    return n


class BackupCommands:
    MAKE = re.compile(r"^\s*(?:data |meri )?(?:backup|back up)(?: karo| kro| lo| bana(?:o| do)| le lo)?\s*[.!]*\s*$", re.I)
    RESTORE = re.compile(r"^\s*(?:backup (?:wapas|restore|se)\b.*|restore(?: backup)?|purana data wapas.*|data wapas lao)\s*[.!]*\s*$", re.I)
    YES = re.compile(r"^\s*(yes|haan|han|ha|kar do|kardo|ok|okay|confirm)\s*[.!]*\s*$", re.I)
    NO = re.compile(r"^\s*(no|nahi|nhi|cancel|mat)\s*[.!]*\s*$", re.I)

    def __init__(self, data_getter: Callable[[], Path], dest: Optional[Path] = None):
        self.data, self.dest, self.pending = data_getter, dest, None

    def try_execute(self, text: str) -> Optional[str]:
        t = text.strip()
        if self.pending and time.time() > self.pending[1]:
            self.pending = None
        if self.pending:
            if self.YES.match(t):
                z = self.pending[0]
                self.pending = None
                try:
                    return f"Restore ho gaya: {restore(z, self.data())} files wapas aayi. Pet ko ek baar band karke dobara kholo. ✅ (API keys aapki purani hi rakhi hain)"
                except (OSError, zipfile.BadZipFile) as exc:
                    return f"Restore nahi ho paaya: {exc}"
            if self.NO.match(t):
                self.pending = None
                return "Theek hai, restore nahi kiya."
        if self.MAKE.match(t):
            try:
                p = make_backup(self.data(), self.dest)
                return f"Backup ban gaya: {p} (API keys isme nahi hain). Naye PC par ye file Documents/Earthvasi-Backups me rakhkar 'backup wapas lao' bolo."
            except OSError as exc:
                return f"Backup nahi ban paaya: {exc}"
        if self.RESTORE.match(t):
            z = latest(self.dest)
            if not z:
                return "Koi backup nahi mila. Pehle 'backup karo' bolo (ya file Documents/Earthvasi-Backups me rakho)."
            self.pending = (z, time.time() + 60)
            return f"{z.name} se data wapas laun? Abhi ka memory/settings isse badal jayega (API keys nahi). (haan/nahi)"
        return None
