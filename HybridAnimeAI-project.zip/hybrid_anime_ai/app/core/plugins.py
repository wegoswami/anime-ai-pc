"""Plugin system: drop a .py file into the plugins folder (or fetch one from GitHub) and the assistant learns a new skill.

A plugin is a normal Python file:

    NAME = "Coin flip"
    VERSION = "1.0"
    TRIGGERS = [r"\\bflip a coin\\b", r"\\bsikka uchhalo\\b"]       # regexes, case-insensitive
    def run(text, ctx):                                          # return the reply (str) or None to pass
        return "Heads!" if random.random() < .5 else "Tails!"

`ctx` gives a safe toolbox: ctx.lang, ctx.cfg (a copy WITHOUT API keys), ctx.say(text), ctx.open_url(url),
ctx.remember(text), ctx.search_memory(text), ctx.run_command(text) (any normal assistant command, e.g. "open chrome").

Safety: every plugin runs isolated - an error, a hang (15 s limit) or a crash only disables that plugin, never the app.
Plugins are ordinary code with the app's permissions, so installing from a URL only works for github.com hosts and
always asks for confirmation first.
"""
import hashlib
import importlib.util
import io
import json
import logging
import re
import threading
import time
import zipfile
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import requests

from ..version import USER_AGENT

log = logging.getLogger(__name__)
RUN_TIMEOUT = 15.0
MAX_FILE = 200_000
MAX_FAILS = 3
ALLOWED_HOSTS = ("github.com", "raw.githubusercontent.com", "gist.githubusercontent.com", "codeload.github.com")
_SECRET_KEYS = ("api_key", "anthropic", "password", "token", "secret")


class Context:
    def __init__(self, cfg: dict, lang: str, api: dict):
        self.lang = lang
        self.cfg = {k: v for k, v in cfg.items() if not any(s in k.lower() for s in _SECRET_KEYS)}
        self._api = api

    def say(self, text: str) -> None:
        f = self._api.get("say")
        f and f(text)

    def open_url(self, url: str) -> None:
        if str(url).startswith(("http://", "https://")):
            import webbrowser
            webbrowser.open(url)

    def remember(self, text: str) -> None:
        f = self._api.get("remember")
        f and f(text)

    def search_memory(self, text: str) -> List[str]:
        f = self._api.get("search_memory")
        return f(text) if f else []

    def run_command(self, text: str) -> Optional[str]:
        f = self._api.get("run_command")
        return f(text) if f else None


class Plugin:
    def __init__(self, path: Path, mod):
        self.path = path
        self.mod = mod
        self.name = str(getattr(mod, "NAME", path.stem))
        self.version = str(getattr(mod, "VERSION", "1.0"))
        self.triggers = [re.compile(t, re.I) for t in getattr(mod, "TRIGGERS", [])]
        self.fails = 0
        self.enabled = True

    def matches(self, text: str) -> bool:
        m = getattr(self.mod, "match", None)
        if callable(m):
            try:
                return bool(m(text))
            except Exception:  # noqa: BLE001
                return False
        return any(t.search(text) for t in self.triggers)


class PluginManager:
    def __init__(self, folder: Path, get_cfg: Callable[[], dict], api: Optional[dict] = None):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.get_cfg = get_cfg
        self.api = api or {}
        self.plugins: List[Plugin] = []
        self.errors: Dict[str, str] = {}
        self._staged: List[Tuple[str, bytes, str]] = []     # (filename, data, source_url)
        self.load_all()

    # ------------------------------------------------------------------ loading
    def load_all(self) -> List[str]:
        self.plugins, self.errors = [], {}
        for f in sorted(self.folder.glob("*.py")):
            if f.name.startswith("_"):
                continue
            try:
                spec = importlib.util.spec_from_file_location(f"haa_plugin_{f.stem}", f)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)           # type: ignore[union-attr]
                if not callable(getattr(mod, "run", None)):
                    raise ValueError("no run(text, ctx) function")
                self.plugins.append(Plugin(f, mod))
            except Exception as exc:  # noqa: BLE001 - a broken plugin is skipped, the app goes on
                self.errors[f.name] = f"{type(exc).__name__}: {exc}"
                log.warning("Plugin %s failed to load: %s", f.name, exc)
        return [p.name for p in self.plugins]

    def names(self) -> List[str]:
        return [f"{p.name} {p.version}" for p in self.plugins if p.enabled]

    # ------------------------------------------------------------------ running
    def try_handle(self, text: str, lang: str = "en") -> Optional[str]:
        for p in self.plugins:
            if not p.enabled or not p.matches(text):
                continue
            out: list = []

            def work(p=p, out=out):
                try:
                    out.append(p.mod.run(text, Context(self.get_cfg(), lang, self.api)))
                except Exception as exc:  # noqa: BLE001
                    out.append(exc)

            t = threading.Thread(target=work, daemon=True)
            t.start()
            t.join(RUN_TIMEOUT)
            if t.is_alive() or (out and isinstance(out[0], Exception)):
                p.fails += 1
                log.warning("Plugin %s failed (%s)", p.name, out[0] if out else "timeout")
                if p.fails >= MAX_FAILS:
                    p.enabled = False
                continue
            p.fails = 0
            if out and out[0]:
                return str(out[0])
        return None

    # ------------------------------------------------------------------ install / update from GitHub
    @staticmethod
    def _host_ok(url: str) -> bool:
        m = re.match(r"^https://([^/]+)/", url)
        return bool(m) and m.group(1).lower() in ALLOWED_HOSTS

    def stage(self, url: str) -> List[Tuple[str, str]]:
        """Download plugin file(s) but do NOT install yet. Returns [(filename, sha256-prefix)]."""
        url = url.strip().rstrip("/")
        if not self._host_ok(url + "/"):
            raise ValueError("For safety I only install plugins from github.com")
        files: List[Tuple[str, bytes]] = []
        h = {"User-Agent": USER_AGENT}
        m = re.match(r"^https://github\.com/([^/]+)/([^/]+?)(?:\.git)?(?:/(?:tree|blob)/([^/]+)(/.*)?)?$", url)
        if url.endswith(".py"):
            raw = url.replace("https://github.com/", "https://raw.githubusercontent.com/").replace("/blob/", "/")
            r = requests.get(raw, headers=h, timeout=20)
            r.raise_for_status()
            files.append((Path(raw).name, r.content))
        elif m:
            user, repo, branch = m.group(1), m.group(2), m.group(3) or "HEAD"
            r = requests.get(f"https://codeload.github.com/{user}/{repo}/zip/{branch}", headers=h, timeout=40)
            r.raise_for_status()
            with zipfile.ZipFile(io.BytesIO(r.content)) as z:
                for info in z.infolist():
                    parts = info.filename.split("/")[1:]
                    if info.is_dir() or not parts or not parts[-1].endswith(".py") or parts[-1].startswith("_"):
                        continue
                    if len(parts) > 2 or (len(parts) == 2 and parts[0] != "plugins") or info.file_size > MAX_FILE:
                        continue
                    files.append((parts[-1], z.read(info)))
        else:
            raise ValueError("Give me a github.com link to a .py file or a repository")
        good = []
        for name, data in files[:20]:
            if len(data) > MAX_FILE or not re.fullmatch(r"[\w\-]+\.py", name):
                continue
            src = data.decode("utf-8", "replace")
            try:
                compile(src, name, "exec")
            except SyntaxError:
                continue
            if "def run(" not in src:
                continue
            good.append((name, data, url))
        if not good:
            raise ValueError("I couldn't find a valid plugin there (needs NAME and a run(text, ctx) function)")
        self._staged = good
        return [(n, hashlib.sha256(d).hexdigest()[:10]) for n, d, _ in good]

    def commit(self) -> List[str]:
        done = []
        src_file = self.folder / "_sources.json"
        try:
            sources = json.loads(src_file.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            sources = {}
        for name, data, url in self._staged:
            (self.folder / name).write_bytes(data)
            sources[name] = url
            done.append(name)
        src_file.write_text(json.dumps(sources, indent=1), encoding="utf-8")
        self._staged = []
        self.load_all()
        return done

    def cancel(self) -> None:
        self._staged = []

    def has_staged(self) -> bool:
        return bool(self._staged)

    def stage_updates(self) -> List[Tuple[str, str]]:
        try:
            sources = json.loads((self.folder / "_sources.json").read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            sources = {}
        allf: List[Tuple[str, bytes, str]] = []
        for url in sorted(set(sources.values())):
            try:
                self.stage(url)
                allf += self._staged
            except Exception as exc:  # noqa: BLE001
                log.warning("Plugin update check failed for %s: %s", url, exc)
        self._staged = allf
        return [(n, hashlib.sha256(d).hexdigest()[:10]) for n, d, _ in allf]

    # ------------------------------------------------------------------ chat commands
    def handle_command(self, text: str, lang: str = "en") -> Optional[str]:
        t = text.strip()
        if self._staged and re.fullmatch(r"(?i)\s*(yes|yeah|haan|ha|han|ok|okay|install|kar do|हाँ|हां)\s*[.!]*", t):
            names = self.commit()
            return (f"Installed: {', '.join(names)}." if lang == "en" else f"Install ho gaya: {', '.join(names)}.")
        if self._staged and re.fullmatch(r"(?i)\s*(no|nahi|nahin|cancel|stop|mat karo|नहीं)\s*[.!]*", t):
            self.cancel()
            return "Okay, cancelled." if lang == "en" else "Theek hai, cancel kar diya."
        m = re.match(r"(?i)^\s*(?:install|add)\s+(?:the\s+)?plugin\s+(https://\S+)", t)
        if m:
            try:
                info = self.stage(m.group(1))
            except Exception as exc:  # noqa: BLE001
                return f"I couldn't use that: {exc}"
            lst = ", ".join(f"{n} ({h})" for n, h in info)
            return (f"I found {lst}. Plugins run with full app permissions, so only install ones you trust. Say yes to install."
                    if lang == "en" else f"Mujhe ye mila: {lst}. Plugin ko poori permission milti hai, bharosemand ho tabhi install karo. Install karun? 'yes' bolo.")
        if re.match(r"(?i)^\s*(?:update|upgrade)\s+(?:my\s+)?plugins?\b", t):
            info = self.stage_updates()
            if not info:
                return "No plugin updates found." if lang == "en" else "Koi plugin update nahi mila."
            return "Updates ready: " + ", ".join(n for n, _ in info) + ". Say yes to install them."
        if re.match(r"(?i)^\s*(?:reload plugins|plugins reload|plugins dikhao|list plugins|show plugins|my plugins)\s*$", t):
            if "reload" in t.lower():
                self.load_all()
            n = self.names()
            bad = f" (couldn't load: {', '.join(self.errors)})" if self.errors else ""
            return ("Skills: " + ", ".join(n) + bad) if n else "No plugins installed yet." + bad
        return None
