"""Language tutor: practise any language by talking. The AI replies in the target language (spoken aloud) and adds a short
Hinglish coaching note after a `|||` separator (shown on screen, not spoken). State lives in cfg["tutor"]."""
import re

# id, English name, native name, ISO code (2 letters, used for speech + Whisper), spoken aliases
LANGS = [
    ("english", "English", "English", "en", "english|angrezi|angreji|inglish|इंग्लिश|अंग्रेज़ी|अंग्रेजी"),
    ("hindi", "Hindi", "हिन्दी", "hi", "hindi|हिंदी|हिन्दी"),
    ("spanish", "Spanish", "Español", "es", "spanish|espanol|स्पेनिश"),
    ("french", "French", "Français", "fr", "french|francais|फ्रेंच"),
    ("german", "German", "Deutsch", "de", "german|deutsch|जर्मन"),
    ("japanese", "Japanese", "日本語", "ja", "japanese|japani|जापानी"),
    ("korean", "Korean", "한국어", "ko", "korean|कोरियन"),
    ("chinese", "Chinese (Mandarin)", "中文", "zh", "chinese|mandarin|chini|चीनी|चाइनीज"),
    ("arabic", "Arabic", "العربية", "ar", "arabic|arbi|अरबी"),
    ("portuguese", "Portuguese", "Português", "pt", "portuguese|पुर्तगाली"),
    ("russian", "Russian", "Русский", "ru", "russian|रशियन|रूसी"),
    ("italian", "Italian", "Italiano", "it", "italian|इटैलियन"),
    ("turkish", "Turkish", "Türkçe", "tr", "turkish|तुर्की"),
    ("bengali", "Bengali", "বাংলা", "bn", "bengali|bangla|bangali|बंगाली|बांग्ला"),
    ("tamil", "Tamil", "தமிழ்", "ta", "tamil|तमिल"),
    ("telugu", "Telugu", "తెలుగు", "te", "telugu|तेलुगु"),
    ("marathi", "Marathi", "मराठी", "mr", "marathi|मराठी"),
    ("gujarati", "Gujarati", "ગુજરાતી", "gu", "gujarati|gujrati|गुजराती"),
    ("punjabi", "Punjabi", "ਪੰਜਾਬੀ", "pa", "punjabi|panjabi|पंजाबी"),
    ("kannada", "Kannada", "ಕನ್ನಡ", "kn", "kannada|कन्नड़|कन्नड"),
    ("malayalam", "Malayalam", "മലയാളം", "ml", "malayalam|मलयालम"),
    ("urdu", "Urdu", "اردو", "ur", "urdu|उर्दू"),
    ("nepali", "Nepali", "नेपाली", "ne", "nepali|नेपाली"),
    ("indonesian", "Indonesian", "Bahasa Indonesia", "id", "indonesian|bahasa"),
    ("thai", "Thai", "ไทย", "th", "thai|थाई"),
    ("vietnamese", "Vietnamese", "Tiếng Việt", "vi", "vietnamese"),
    ("dutch", "Dutch", "Nederlands", "nl", "dutch"),
]
LEVELS = {"beginner": "Beginner", "intermediate": "Intermediate", "advanced": "Advanced"}
_LANG_RX = re.compile(r"(?:^|[^a-z])(" + "|".join(x[4] for x in LANGS) + r")(?![a-z])", re.I)
_START_RX = re.compile(r"learn|learning|practice|practise|sikh|seekh|sikha|teach me|tutor|lesson|सीख|सिखा|प्रैक्टिस", re.I)
_STOP_RX = re.compile(r"(tutor|practice|practise|sikhna|learning|language|lesson|class)\s*(mode)?\s*(band|bandh|off|stop|khatam)"
                      r"|(normal|regular)\s*mode|ab\s+normal|practice\s+ho\s+gayi|chhodo\s+practice", re.I)


def find_lang(text: str):
    m = _LANG_RX.search(text.lower())
    if not m:
        return None
    w = m.group(1).lower()
    return next((x for x in LANGS if w in [a.lower() for a in x[4].split("|")]), None)


def find_level(text: str) -> str:
    s = text.lower()
    if re.search(r"advanced|expert|\bpro\b|एडवांस", s):
        return "advanced"
    if re.search(r"intermediate|medium|madhyam|thoda aata|मध्यम", s):
        return "intermediate"
    if re.search(r"beginner|basic|shuru|zero|bilkul naya|starter|बिगिनर|शुरू", s):
        return "beginner"
    return ""


def split_reply(text: str) -> tuple:
    """-> (spoken part in the target language, coaching note)"""
    head, sep, note = text.partition("|||")
    return head.strip(), note.strip()


class Tutor:
    def __init__(self, cfg: dict):
        self.cfg = cfg

    @property
    def on(self) -> bool:
        return bool((self.cfg.get("tutor") or {}).get("on"))

    @property
    def lang(self) -> tuple:
        want = (self.cfg.get("tutor") or {}).get("lang", "english")
        return next((x for x in LANGS if x[0] == want), LANGS[0])

    @property
    def code(self) -> str:
        return self.lang[3]

    @property
    def level(self) -> str:
        return (self.cfg.get("tutor") or {}).get("level", "beginner")

    def start(self, lang_id: str, level: str = "") -> None:
        self.cfg["tutor"] = {"on": True, "lang": lang_id, "level": level or self.level}

    def stop(self) -> None:
        self.cfg.setdefault("tutor", {})["on"] = False

    def set_level(self, level: str) -> None:
        self.cfg.setdefault("tutor", {"lang": self.lang[0]})["level"] = level

    def stt_languages(self) -> list:
        return [self.code, "hi", "en"] if self.on else []

    def prompt(self, me: str, user: str, gender: str = "female") -> str:
        L = self.lang
        helper = "English" if L[0] == "hindi" else "Hinglish (Hindi in Latin letters)"
        rule = {"beginner": "BEGINNER: use only very common words and very short sentences (5-9 words), simple present tense.",
                "intermediate": "INTERMEDIATE: everyday vocabulary, normal sentences, introduce a few new words.",
                "advanced": "ADVANCED: natural fluent speech with idioms; correct subtle mistakes too."}[self.level if self.level in LEVELS else "beginner"]
        roman = (f"Because {L[1]} is not written in Latin letters, add '🔤 Padho: <Roman pronunciation>' in the coaching note for beginners. "
                 if re.search(r"[^\x00-\x7f]", L[2]) and L[0] != "english" else "")
        return (f"You are {me}, a warm, patient, encouraging {gender} language tutor and conversation partner for {user}, whose mother tongue is Hindi. "
                f"{user} wants to learn {L[1]} ({L[2]}) by talking every day. Level: {rule} "
                f"FORMAT (strict): first the conversation reply written ONLY in {L[1]}, 1-3 short sentences, reacting naturally to what {user} said and "
                f"ending with ONE easy question. Then a line containing only |||. Then a short coaching note (max 3 lines) in {helper}: if there was a mistake "
                f"write 'Sahi: <corrected sentence>' and one short reason; if it was correct write 'Bahut badhiya!' and optionally 'Naya word: <word> = <meaning>'. "
                f"If {user} wrote Hindi/Hinglish or asked how to say something, give the {L[1]} phrase in the reply part and the pronunciation (Roman letters) and meaning after |||. "
                f"{roman}Never write the reply part in any language except {L[1]}. No markdown. Begin with one emotion tag in square brackets from "
                f"[happy] [sad] [angry] [surprised] [thinking] [love] [embarrassed] [sleepy] [neutral]. Example: [happy] ¡Muy bien! ¿Qué comes hoy? ||| Bahut badhiya!")

    def lesson(self, raw: str) -> str:
        s, L = raw.lower(), self.lang[1]
        if re.search(r"aaj ka word|word of the day|naye words?|new words?|vocab|shabd", s):
            return f"Teach me 5 new useful {L} words for my level today. For each: the word, its meaning, and one short example sentence. Then ask me to use one in a sentence."
        if re.search(r"\bquiz\b|test lo|test le|exam|paheli", s):
            return f"Give me a short 3-question quiz in {L} suited to my level. Ask question 1 only now and wait for my answer."
        m = re.search(r"(?:role ?play|naatak|scene)\s*(?:me|mein|:)?\s*(.{3,60})$", s)
        if m:
            return f"Let's role-play in {L}: {m.group(1)}. You play the other person. Start the scene with one short line."
        if re.search(r"story|kahani|kahaani", s):
            return f"Tell me a very short, simple story in {L} for my level (4-5 sentences), then ask me one question about it."
        return ""

    def command(self, raw: str):
        """-> None, or (spoken confirmation, lesson prompt or '')"""
        s = raw.lower().strip()
        if self.on and _STOP_RX.search(s):
            self.stop()
            return "Theek hai, tutor mode band. Ab normal baat karte hain. Dobara shuru karne ke liye bolo 'spanish sikhao'!", ""
        lv = find_level(s)
        if self.on and re.match(r"(?:level|stage)\b", s) and lv:
            self.set_level(lv)
            return f"Level {LEVELS[lv]} kar diya.", "Continue our conversation at the new level with one easy question."
        if _START_RX.search(s):
            L = find_lang(s)
            if L:
                same = (self.cfg.get("tutor") or {}).get("lang") == L[0]
                self.start(L[0], lv or (self.level if same else "beginner"))
                return (f"Badhiya! {L[1]} ka practice shuru, {LEVELS[self.level]} level par.",
                        f"Start the lesson: greet me warmly in {L[1]}, say in one short sentence who you are, and ask me one very easy question.")
            if re.search(r"tutor|language|bhasha|भाषा", s):
                return ("Kaun si bhasha seekhni hai? Bolo jaise 'english sikhao', 'spanish sikhao', 'japanese sikhao'... Mujhe 25+ bhashayein aati hain.", "")
        if self.on:
            q = self.lesson(raw)
            if q:
                return "", q
        return None
