"""Call / meeting recorder for Windows: "WhatsApp call record karo" -> saves mp3, wav or video (mp4) to Documents/Earthvasi-Recordings.

How it hears BOTH sides: system audio (WASAPI loopback = what comes out of your speakers/headset, i.e. the other person) plus your
microphone, mixed together. Video mode also films the screen. Everything is local; nothing is uploaded.
Consent: the assistant always asks "kya samne wale ki ijazat hai?" before it starts, and says "recording chalu hai" every 15 minutes."""
import datetime
import re
import shutil
import subprocess
import sys
import threading
import time
import wave
from pathlib import Path
from typing import Callable, Optional

IS_WIN = sys.platform == "win32"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
RATE = 48000
MAX_SECONDS = 4 * 3600
REMIND_EVERY = 15 * 60

START = re.compile(r"\b(?:record|recording|rec)\b|रिकॉर्ड", re.I)
STOP = re.compile(r"^\s*(?:(?:call |screen |meeting )?record(?:ing)?\s*(?:band|bandh|stop|ruko|rok|khatam|bas|save|end)(?: karo| kro| kar do| ho gaya)?"
                  r"|(?:stop|end|finish|save)\s+(?:the |my )?(?:call |screen |meeting )?record(?:ing)?|(?:band|bandh|rok|bas)\s+(?:karo\s+)?(?:call )?record(?:ing)?"
                  r"|recording (?:ho gayi|ho gaya|bas))\s*[.!]*\s*$", re.I)
LIST = re.compile(r"record(?:ings?)?\s*(?:dikhao|kholo|folder|show|open|kahan|list)|(?:show|open|dikhao)\s+(?:my |meri )?record(?:ings?)", re.I)
EXTRA = re.compile(r"^\s*(mp3|wav|video|mp4)\s*(?:bhi|me|mein|format me)?\s*(?:do|chahiye|bana do|banao|save|convert|de do)\s*[.!]*\s*$", re.I)
YES = re.compile(r"^\s*(yes|haan|han|ha|haa|ji|kar do|kardo|ok|okay|theek hai|ijazat hai|permission hai|le li|le rakhi)\s*[.!]*\s*$", re.I)
NO = re.compile(r"^\s*(no|nahi|nhi|cancel|mat|ruko|stop|ijazat nahi|permission nahi)\s*[.!]*\s*$", re.I)
NOT_RECORD = re.compile(r"\b(?:records|recorder|world record|record break\w*|recorded|criminal record)\b", re.I)


def ffmpeg_exe() -> Optional[str]:
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:  # noqa: BLE001
        return shutil.which("ffmpeg")


def out_dir() -> Path:
    d = Path.home() / "Documents" / "Earthvasi-Recordings"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _fmt_secs(s: float) -> str:
    s = int(s)
    return f"{s // 3600}h {s % 3600 // 60}m" if s >= 3600 else f"{s // 60}m {s % 60}s" if s >= 60 else f"{s}s"


def _fmt_size(p: Path) -> str:
    n = p.stat().st_size
    return f"{n / 1048576:.1f} MB" if n >= 1048576 else f"{max(1, n // 1024)} KB"


def _run(cmd: list, timeout: int = 900) -> bool:
    try:
        return subprocess.run(cmd, capture_output=True, timeout=timeout, creationflags=NO_WINDOW).returncode == 0
    except Exception:  # noqa: BLE001
        return False


class WinBackend:
    """Real capture on Windows: system-audio loopback + microphone to two WAV files, screen to mp4 through ffmpeg (gdigrab)."""

    def __init__(self):
        self._stop = threading.Event()
        self._threads = []
        self._proc = None

    @staticmethod
    def available() -> str:
        """'' if ready, else a short reason."""
        if not IS_WIN:
            return "Recording abhi sirf Windows PC par hoti hai."
        try:
            import soundcard  # noqa: F401
        except Exception:  # noqa: BLE001
            return "Recording ke liye 'soundcard' package chahiye (pip install soundcard). Installer wale version me ye pehle se hota hai."
        if not ffmpeg_exe():
            return "Recording ke liye ffmpeg chahiye (pip install imageio-ffmpeg)."
        return ""

    def _tap(self, path: Path, open_rec, channels: int) -> None:
        import numpy as np
        try:
            with wave.open(str(path), "wb") as w, open_rec() as rec:
                w.setnchannels(channels)
                w.setsampwidth(2)
                w.setframerate(RATE)
                while not self._stop.is_set():
                    d = rec.record(numframes=RATE // 10)
                    w.writeframes((np.clip(d, -1, 1) * 32767).astype("<i2").tobytes())
        except Exception:  # noqa: BLE001 - a missing mic/loopback must not kill the other stream
            pass

    def _keepalive(self) -> None:
        """WASAPI loopback only delivers data while something plays; a silent output stream keeps it flowing."""
        try:
            import numpy as np
            import sounddevice as sd
            with sd.OutputStream(samplerate=RATE, channels=2, dtype="float32") as o:
                z = np.zeros((RATE // 10, 2), dtype="float32")
                while not self._stop.is_set():
                    o.write(z)
        except Exception:  # noqa: BLE001
            pass

    def start_audio(self, sys_path: Path, mic_path: Path) -> None:
        import soundcard as sc
        self._stop.clear()
        spk = sc.default_speaker()
        loop = sc.get_microphone(id=str(spk.name), include_loopback=True)
        mic = sc.default_microphone()
        jobs = [(self._tap, (sys_path, lambda: loop.recorder(samplerate=RATE, channels=2), 2)),
                (self._tap, (mic_path, lambda: mic.recorder(samplerate=RATE, channels=1), 1)),
                (self._keepalive, ())]
        self._threads = [threading.Thread(target=f, args=a, daemon=True) for f, a in jobs]
        for t in self._threads:
            t.start()

    def stop_audio(self) -> None:
        self._stop.set()
        for t in self._threads:
            t.join(timeout=5)

    def start_video(self, path: Path) -> None:
        cmd = [ffmpeg_exe(), "-y", "-f", "gdigrab", "-framerate", "15", "-draw_mouse", "1", "-i", "desktop",
               "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28", "-pix_fmt", "yuv420p", str(path)]
        self._proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)

    def stop_video(self) -> None:
        p, self._proc = self._proc, None
        if not p:
            return
        try:
            p.stdin.write(b"q")
            p.stdin.flush()
            p.wait(timeout=20)
        except Exception:  # noqa: BLE001
            p.terminate()


class RecordCommands:
    """Voice/text commands: 'whatsapp call record karo', 'video record karo', 'record band karo', 'mp3 bhi do', 'recordings dikhao'."""

    def __init__(self, say: Callable[[str], None] = lambda m: None, backend=None, folder: Optional[Path] = None, work: Optional[Path] = None):
        self.say = say
        self.backend = backend
        self.folder = folder
        self.work = work
        self.state = None            # None | "format" | "consent" | "rec"
        self.fmt = ""                # "mp3" | "wav" | "mp4" (what the user asked for)
        self._t0 = 0.0
        self._session = None         # dict(sys, mic, video, stamp) of the last recording (kept so "mp3 bhi do" works)
        self._timer = None
        self.last_file: Optional[Path] = None

    # ---------------------------------------------------------------- helpers
    @property
    def recording(self) -> bool:
        return self.state == "rec"

    def _dir(self) -> Path:
        return self.folder or out_dir()

    def _tmp(self) -> Path:
        d = self.work or (Path.home() / ".earthvasi_rec_tmp")
        d.mkdir(parents=True, exist_ok=True)
        return d

    @staticmethod
    def _wanted_format(t: str) -> str:
        if re.search(r"video|mp4|screen|dekh", t):
            return "mp4"
        if re.search(r"\bwav\b", t):
            return "wav"
        if re.search(r"mp3|audio|awaaz|avaz|voice|sound|sirf baat", t):
            return "mp3"
        return ""

    # ---------------------------------------------------------------- entry point
    def try_execute(self, text: str) -> Optional[str]:
        t = text.strip()
        low = t.lower()
        if not low:
            return None
        if self.state in ("format", "consent"):
            if NO.match(low):
                self.state = None
                return "Theek hai, recording nahi ki."
            if self.state == "format":
                f = self._wanted_format(low)
                if f:
                    self.fmt = f
                    return self._ask_consent()
                return "Kaise save karun? Bolo: mp3 (sirf awaaz), video (screen + awaaz) ya wav."
            if YES.match(low):
                return self._begin()
            return "Pehle ijazat ka jawab do: samne wale ne recording ke liye haan kaha? (haan / nahi)"
        if self.state == "rec":
            if STOP.match(low) or (START.search(low) and re.search(r"band|stop|ruk|rok|khatam|bas|end|finish", low) and not NOT_RECORD.search(low)):
                return self.stop()
            return None
        m = EXTRA.match(low)
        if m and self._session and self._session.get("sys"):
            return self._extra(m.group(1).lower())
        if LIST.search(low):
            return self._open_folder()
        if START.search(low) and not NOT_RECORD.search(low) and not re.search(r"kharch|expense|likh|note", low) and re.search(r"karo|kro|kar do|kar lo|le lo|lo\b|start|shuru|chalu|on\b|this|the|my|call|meeting|screen|video|audio|mp3", low) \
                and not re.search(r"band|stop|rok|khatam|\bend\b", low) and len(low.split()) <= 12:
            err = WinBackend.available() if self.backend is None else ""
            if err:
                return err
            self.fmt = self._wanted_format(low)
            if not self.fmt:
                self.state = "format"
                return "Kaise save karun? Bolo: mp3 (sirf awaaz), video (screen + awaaz) ya wav."
            return self._ask_consent()
        return None

    # ---------------------------------------------------------------- flow
    def _ask_consent(self) -> str:
        self.state = "consent"
        return ("Dhyan do: call record karne se pehle samne wale ki ijazat lena zaroori hai — kai deshon me bina ijazat recording gair-kanooni hai. "
                "Kya unhone recording ke liye haan kaha? (haan / nahi)")

    def _begin(self) -> str:
        be = self.backend or WinBackend()
        stamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        w = self._tmp()
        s = {"stamp": stamp, "sys": w / f"{stamp}-system.wav", "mic": w / f"{stamp}-mic.wav", "video": w / f"{stamp}-screen.mp4" if self.fmt == "mp4" else None}
        try:
            be.start_audio(s["sys"], s["mic"])
            if s["video"]:
                be.start_video(s["video"])
        except Exception as e:  # noqa: BLE001
            self.state = None
            return f"Recording shuru nahi ho payi: {str(e)[:80]}"
        self.backend, self._session, self.state, self._t0 = be, s, "rec", time.time()
        self._arm_reminders()
        label = {"mp3": "mp3 (awaaz)", "wav": "wav (awaaz)", "mp4": "video + awaaz"}[self.fmt]
        return (f"🔴 Recording shuru ({label}). Call me dusre ki awaaz speaker/headset se aati hai, wo bhi record hogi. "
                "Khatam hone par bolo “record band karo”. Main har 15 minute me yaad dilaungi ki recording chalu hai.")

    def _arm_reminders(self) -> None:
        def tick():
            if not self.recording:
                return
            if time.time() - self._t0 > MAX_SECONDS:
                self.say(self.stop())
                return
            self.say(f"Yaad dila rahi hoon: recording chalu hai ({_fmt_secs(time.time() - self._t0)}).")
            self._arm_reminders()
        self._timer = threading.Timer(REMIND_EVERY, tick)
        self._timer.daemon = True
        self._timer.start()

    def stop(self) -> str:
        if not self.recording:
            return "Abhi koi recording chalu nahi hai."
        if self._timer:
            self._timer.cancel()
        dur = time.time() - self._t0
        s, self.state = self._session, None
        try:
            self.backend.stop_audio()
            if s["video"]:
                self.backend.stop_video()
        except Exception:  # noqa: BLE001
            pass
        mix = self._mix(s)
        if not mix:
            return "Recording band ho gayi, par awaaz save nahi ho payi (mic ya speaker nahi mila?)."
        s["mix"] = mix
        outs = []
        try:
            if self.fmt == "mp4":
                if s["video"] and s["video"].exists():
                    outs.append(self._to_mp4(s))
                outs.append(self._to_audio(s, "mp3"))
            else:
                outs.append(self._to_audio(s, self.fmt))
        except Exception as e:  # noqa: BLE001
            return f"Recording save karte time dikkat: {str(e)[:80]}"
        outs = [o for o in outs if o]
        if not outs:
            return "Recording band ho gayi par file nahi ban payi (ffmpeg check karo)."
        self.last_file = outs[0]
        names = ", ".join(f"{o.name} ({_fmt_size(o)})" for o in outs)
        return f"✅ Recording save ho gayi ({_fmt_secs(dur)}): {names}\nFolder: Documents/Earthvasi-Recordings. Doosra format chahiye to bolo “mp3 bhi do” / “wav bhi do”."

    # ---------------------------------------------------------------- files
    def _mix(self, s: dict) -> Optional[Path]:
        ff = ffmpeg_exe()
        srcs = [p for p in (s["sys"], s["mic"]) if p and p.exists() and p.stat().st_size > 1000]
        if not ff or not srcs:
            return None
        out = self._tmp() / f"{s['stamp']}-mix.wav"
        cmd = [ff, "-y"] + sum([["-i", str(p)] for p in srcs], [])
        if len(srcs) == 2:
            cmd += ["-filter_complex", "[0:a]aresample=48000,aformat=channel_layouts=stereo[a];[1:a]aresample=48000,aformat=channel_layouts=stereo[b];"
                                       "[a][b]amix=inputs=2:duration=longest:normalize=0,alimiter=limit=0.95[m]", "-map", "[m]"]
        else:
            cmd += ["-ac", "2", "-ar", "48000"]
        cmd += [str(out)]
        return out if _run(cmd) and out.exists() else None

    def _to_audio(self, s: dict, fmt: str) -> Optional[Path]:
        out = self._dir() / f"Call-{s['stamp']}.{fmt}"
        if fmt == "wav":
            shutil.copyfile(s["mix"], out)
            return out
        return out if _run([ffmpeg_exe(), "-y", "-i", str(s["mix"]), "-codec:a", "libmp3lame", "-q:a", "2", str(out)]) and out.exists() else None

    def _to_mp4(self, s: dict) -> Optional[Path]:
        out = self._dir() / f"Call-{s['stamp']}.mp4"
        return out if _run([ffmpeg_exe(), "-y", "-i", str(s["video"]), "-i", str(s["mix"]), "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-shortest", str(out)]) and out.exists() else None

    def _extra(self, fmt: str) -> str:
        s = self._session
        fmt = {"video": "mp4"}.get(fmt, fmt)
        if self.recording:
            return "Pehle recording band karo."
        if not s or not s.get("mix") or not Path(s["mix"]).exists():
            return "Pichhli recording ki file ab nahi bachi."
        if fmt == "mp4":
            if not s.get("video") or not Path(s["video"]).exists():
                return "Pichhli recording sirf awaaz thi, video nahi bani thi. Agli baar “video record karo” bolna."
            p = self._to_mp4(s)
        else:
            p = self._to_audio(s, fmt)
        if not p:
            return "Convert nahi ho paya."
        self.last_file = p
        return f"Ho gaya: {p.name} ({_fmt_size(p)}) — Documents/Earthvasi-Recordings."

    def _open_folder(self) -> str:
        d = self._dir()
        try:
            if IS_WIN:
                import os
                os.startfile(str(d))  # noqa: S606
        except Exception:  # noqa: BLE001
            pass
        n = len(list(d.glob("Call-*")))
        return f"Recordings folder: Documents/Earthvasi-Recordings ({n} files)."
