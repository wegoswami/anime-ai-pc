"""Fun for the desktop app: jokes, shayari, riddles, quiz, mini-games, daily streak + badges, coins + missions, a small shop,
things-I-remember, mood diary and comfort, weekly report. Same behaviour as the phone app (mobile/fun.js + fun2.js). Offline.
Content lives in assets/data/fun_content.json."""
import json
import random
import re
import time
from pathlib import Path
from typing import Callable, Optional

from ..paths import bundle_dir

_ASSET = bundle_dir() / "assets" / "data" / "fun_content.json"
LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]
NUM = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣"]
THEMES = {"space": ("🌌 Space", 60), "sunset": ("🌇 Sunset", 40), "garden": ("🌿 Garden", 40), "sakura": ("🌸 Sakura", 50), "ocean": ("🌊 Ocean", 50)}
ITEMS = {"plant": ("🪴", "Plant", 30), "sofa": ("🛋️", "Sofa", 50), "books": ("📚", "Books", 40), "frame": ("🖼️", "Photo frame", 60),
         "teddy": ("🧸", "Teddy", 80), "lamp": ("🕯️", "Lamp", 50), "cactus": ("🌵", "Cactus", 30), "gift": ("🎁", "Gift box", 70)}
MISSIONS = (("chats", 3, 5, "3 baatein karo"), ("games", 1, 10, "1 game khelo"), ("mood", 1, 5, "apna mood batao"))
RPS = {"rock": "🪨", "paper": "📄", "scissors": "✂️"}
RPSW = {"patthar": "rock", "rock": "rock", "kagaz": "paper", "kaagaz": "paper", "paper": "paper", "kainchi": "scissors", "scissors": "scissors"}
MOODW = "khush|happy|theek|okay|ok|badhiya|udaas|sad|gussa|angry|thaka|tired|bore|stressed|tension"
SAD = re.compile(r"\b(udaas|dukhi|akela|akeli|tension|stress|ghabra|depress|rona|ro raha|ro rahi|thak gaya|thak gayi|bore ho|gussa)\b")
STOP = re.compile(r"^(?:stop|band|quit|exit|bas|cancel)\b")
CMDS = re.compile(r"^(?:joke|shayari|paheli|riddle|quiz|games?|khel|stats|meri stats|streak|fun fact|kahani|story|truth|dare|compliment|quote|guess number|rps|rock paper scissors)\b")


def _norm(t: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s]", " ", t.lower())).strip()


def _today() -> str:
    return time.strftime("%Y-%m-%d")


class Fun:
    def __init__(self, path_getter: Callable[[], Path], add_bond: Optional[Callable[[int], None]] = None):
        self.path_getter = path_getter
        self.add_bond = add_bond or (lambda n: None)
        try:
            self.c = json.loads(_ASSET.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.c = {k: [] for k in ("JOKES", "SHAYARI", "RIDDLES", "FACTS", "WYR", "TRUTH", "DARE", "COMPL", "QUOTES", "STORIES", "TRIVIA", "BADGES", "WORDS")}
        self.pending = None
        self.ttt = None
        self.chain = None
        self.last_quip = time.time()

    # ---------------------------------------------------------------- storage
    def _load(self) -> dict:
        try:
            d = json.loads(self.path_getter().read_text(encoding="utf-8"))
        except (OSError, ValueError):
            d = {}
        d.setdefault("streak", 0); d.setdefault("best", 0); d.setdefault("last", "")
        d.setdefault("games", 0); d.setdefault("wins", 0); d.setdefault("badges", [])
        d.setdefault("coins", 0); d.setdefault("own", []); d.setdefault("theme", ""); d.setdefault("room", [])
        d.setdefault("facts", []); d.setdefault("moods", [])
        if d.get("day") != _today():
            d.update(day=_today(), chats=0, mdone=[], mgames=0, mmood=0)
        return d

    def _save(self, d: dict) -> None:
        p = self.path_getter()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")

    # ---------------------------------------------------------------- streak
    def daily(self) -> str:
        d = self._load()
        if d["last"] == _today():
            return ""
        y = time.strftime("%Y-%m-%d", time.localtime(time.time() - 86400))
        d["streak"] = d["streak"] + 1 if d["last"] == y else 1
        d["best"] = max(d["best"], d["streak"])
        d["last"] = _today()
        d["coins"] += 10
        badge = next((b for b in self.c["BADGES"] if b[0] == d["streak"] and b[0] not in d["badges"]), None)
        if badge:
            d["badges"].append(badge[0])
        self._save(d)
        self.add_bond(5 + min(d["streak"], 10))
        if badge:
            return f"🔥 {d['streak']} din ka streak! Naya badge: {badge[1]}"
        return f"🔥 {d['streak']} din ka streak! Kal bhi aana, badge milega." if d["streak"] > 1 else "Aaj ka din shuru! Roz aao, streak banao 🔥"

    def quip(self, hour: int) -> str:
        pool = []
        if 5 <= hour < 11:
            pool += ["Good morning! ☀️ Aaj ka plan kya hai?", "Subah subah chai ho jaye? ☕"]
        elif 11 <= hour < 16:
            pool += ["Khana khaya? 🍛 Paani bhi piyo!", "Thoda stretch kar lo, main dekh rahi hoon 😄"]
        elif 16 <= hour < 21:
            pool += ["Shaam ho gayi — chai time? ☕", "Aaj ka din kaisa gaya? Mujhe batao 💗"]
        else:
            pool += ["Itni raat tak jaag rahe ho? Sone ka time 😴", "Kal ke liye thoda aaram zaroori hai 🌙"]
        pool += ["Ek joke sunoge? Bolo 'joke' 😄", "Chalo ek quiz khelein? Bolo 'quiz' 🧠", "Boriyat ho rahi hai? 'games' bolo 🎮"]
        d = self._load()
        if d["facts"] and random.random() < 0.25:
            pool.append(f"Mujhe yaad hai aapne kaha tha: \"{random.choice(d['facts'])['t']}\" 💗")
        return random.choice(pool)

    # ---------------------------------------------------------------- helpers
    def _stats(self, d: dict) -> str:
        nxt = next((b for b in self.c["BADGES"] if b[0] > d["streak"]), None)
        names = {b[0]: b[1] for b in self.c["BADGES"]}
        bl = ", ".join(names[x] for x in d["badges"] if x in names) or "abhi koi nahi"
        return (f"📊 Aapki stats\n🔥 Streak: {d['streak']} din (best {d['best']})\n🎮 Games: {d['games']}, jeete: {d['wins']}\n🪙 Coins: {d['coins']}\n🏅 Badges: {bl}"
                + (f"\nAgla badge: {nxt[0] - d['streak']} din aur" if nxt else ""))

    def _played(self, d: dict, won: bool, coins: int = 0) -> None:
        d["games"] += 1
        d["mgames"] = d.get("mgames", 0) + 1
        if won:
            d["wins"] += 1
            d["coins"] += coins or 5
            self.add_bond(3)

    def _missions(self, d: dict) -> list:
        out = []
        have = {"chats": d.get("chats", 0), "games": d.get("mgames", 0), "mood": d.get("mmood", 0)}
        for k, need, rew, lab in MISSIONS:
            if k not in d["mdone"] and have[k] >= need:
                d["mdone"].append(k)
                d["coins"] += rew
                out.append(f"🎁 Mission poora: {lab} +{rew}🪙")
        if out and all(k in d["mdone"] for k, *_ in MISSIONS) and "bonus" not in d["mdone"]:
            d["mdone"].append("bonus")
            d["coins"] += 10
            out.append("🌟 Aaj ke saare mission poore! Bonus +10🪙")
        return out

    def _mission_text(self, d: dict) -> str:
        have = {"chats": d.get("chats", 0), "games": d.get("mgames", 0), "mood": d.get("mmood", 0)}
        return "🎯 Aaj ke missions:\n" + "\n".join(f"{'✅' if k in d['mdone'] else '⬜'} {lab} (+{rew}🪙) {min(have[k], need)}/{need}" for k, need, rew, lab in MISSIONS)

    @staticmethod
    def _winner(b: list):
        for a, c, d in LINES:
            if b[a] and b[a] == b[c] == b[d]:
                return b[a]
        return "draw" if all(b) else None

    @staticmethod
    def _board(b: list) -> str:
        return "\n".join("".join("❌" if b[r + c] == "X" else "⭕" if b[r + c] == "O" else NUM[r + c] for c in range(3)) for r in (0, 3, 6))

    def _bot_move(self, b: list) -> int:
        free = [i for i, v in enumerate(b) if not v]
        for m in ("O", "X"):
            for i in free:
                t = b[:]
                t[i] = m
                if self._winner(t) == m:
                    return i
        if not b[4]:
            return 4
        cor = [i for i in free if i in (0, 2, 6, 8)]
        return random.choice(cor or free)

    @staticmethod
    def _menu() -> str:
        return ("🎮 Main ye khel sakti hoon — bas bolo:\n• joke  • shayari  • paheli (riddle)\n• quiz  • rock paper scissors  • guess number\n• tic tac toe  • word chain\n• truth / dare  • would you rather\n"
                "• fun fact  • kahani  • compliment  • quote\n• meri stats  • missions  • shop  • mood report  • saans lo  • yaad rakho …")

    # ---------------------------------------------------------------- commands
    def try_execute(self, text: str) -> Optional[str]:
        raw = text.strip()
        n = _norm(raw)
        if not n:
            return None
        d = self._load()
        r = self._route(raw, n, d)
        d["chats"] = d.get("chats", 0) + 1
        extra = self._missions(d)
        self._save(d)
        if r is None:
            return None
        return r + ("\n\n" + "\n".join(extra) if extra else "")

    def _route(self, raw: str, n: str, d: dict) -> Optional[str]:
        c = self.c
        pick = random.choice
        if self.pending and time.time() - self.pending["at"] > 180:
            self.pending = None
        if self.pending and self.pending["t"] != "rps" and CMDS.match(n):
            self.pending = None
        if (self.ttt or self.chain) and CMDS.match(n):
            self.ttt = self.chain = None
        # ---- multi-turn games
        if self.ttt is not None:
            if STOP.match(n):
                self.ttt = None
                return "Tic-tac-toe band 👍"
            if re.fullmatch(r"[1-9]", n):
                i = int(n) - 1
                if self.ttt[i]:
                    return "Wo jagah bhari hai, doosri chuno.\n" + self._board(self.ttt)
                self.ttt[i] = "X"
                w = self._winner(self.ttt)
                if not w:
                    self.ttt[self._bot_move(self.ttt)] = "O"
                    w = self._winner(self.ttt)
                b = self._board(self.ttt)
                if w:
                    self.ttt = None
                    self._played(d, w == "X", 8)
                    return f"{b}\n\n" + ("🎉 Aap jeete! +8🪙" if w == "X" else "😝 Main jeet gayi!" if w == "O" else "🤝 Barabar!") + ' Phir se? bolo "tic tac toe"'
                return f"{b}\n\nAapki baari: 1-9 likho"
        if self.chain is not None:
            ch = self.chain
            if STOP.match(n):
                self.chain = None
                return f"Word chain khatam! Aapne {ch['score']} shabd jode 👏"
            if re.fullmatch(r"[a-z]{2,}", n):
                if n[0] != ch["last"]:
                    return f"Shabd '{ch['last'].upper()}' se shuru hona chahiye 🙂"
                if n in ch["used"]:
                    return "Ye shabd ho chuka hai, doosra bolo."
                ch["used"].append(n)
                ch["score"] += 1
                w = next((x for x in c["WORDS"] if x[0] == n[-1] and x not in ch["used"]), None)
                if not w:
                    self.chain = None
                    d["coins"] += ch["score"] * 2
                    return f"Mere paas '{n[-1].upper()}' se koi shabd nahi bacha — aap jeete! 🎉 Score {ch['score']}, +{ch['score'] * 2}🪙"
                ch["used"].append(w)
                ch["last"] = w[-1]
                return f"{w.upper()}! ➡️ ab '{ch['last'].upper()}' se shabd bolo"
        p = self.pending
        if p:
            if STOP.match(n):
                self.pending = None
                return "Theek hai, khel band! Phir kabhi 😊"
            if p["t"] == "guess":
                m = re.sub(r"\D+", "", n)
                if not m:
                    self.pending = None
                else:
                    g = int(m)
                    p["n"] += 1
                    if g == p["v"]:
                        self.pending = None
                        self._played(d, True)
                        return f"🎉 Sahi! {p['v']} hi tha, {p['n']} koshish me pakda!"
                    if p["n"] >= 5:
                        self.pending = None
                        self._played(d, False)
                        return f"Haar gaye 😜 Number {p['v']} tha. Phir khelein? \"guess number\""
                    return (f"Thoda aur BADA socho ⬆️ ({5 - p['n']} koshish baaki)" if g < p["v"] else f"Thoda aur CHHOTA socho ⬇️ ({5 - p['n']} koshish baaki)")
            elif p["t"] == "riddle":
                self.pending = None
                if any(w in n for w in p["a"]):
                    self._played(d, True)
                    return "🎉 Bilkul sahi! " + p["ans"]
                self._played(d, False)
                return "Nahi 😄 Jawab tha: " + p["ans"]
            elif p["t"] == "quiz":
                m = re.match(r"^([abc123])\b", n)
                ix = "abc123".index(m.group(1)) % 3 if m else next((i for i, o in enumerate(p["o"]) if o.lower() in n), -1)
                if ix < 0:
                    self.pending = None
                else:
                    right = ix == p["c"]
                    p["i"] += 1
                    p["s"] += 1 if right else 0
                    fb = "✅ Sahi!" if right else f"❌ Galat — sahi jawab: {p['o'][p['c']]}"
                    if p["i"] >= len(p["q"]):
                        self.pending = None
                        self._played(d, p["s"] >= 2)
                        return f"{fb}\n\n🏁 Quiz khatam! Score: {p['s']}/{len(p['q'])} " + ("🏆 Perfect!" if p["s"] == len(p["q"]) else "👏" if p["s"] >= 2 else "Phir koshish karo!")
                    q = p["q"][p["i"]]
                    p["c"], p["o"] = q[2], q[1]
                    return f"{fb}\n\nQ{p['i'] + 1}. {q[0]}\nA) {q[1][0]}  B) {q[1][1]}  C) {q[1][2]}"
        word = next((w for w in RPSW if re.search(rf"(^| ){w}( |$)", n)), None)
        if word and len(n.split()) <= 3 and ((self.pending or {}).get("t") == "rps" or re.search(r"rock|patthar|kagaz|kaagaz|paper|kainchi|scissors", n)):
            me, bot = RPSW[word], random.choice(list(RPS))
            beats = {"rock": "scissors", "paper": "rock", "scissors": "paper"}
            self.pending = {"t": "rps", "at": time.time()}
            if me == bot:
                return f"{RPS[me]} vs {RPS[bot]} — Barabar! 🤝 Phir se bolo."
            if beats[me] == bot:
                self._played(d, True)
                return f"{RPS[me]} vs {RPS[bot]} — Aap jeete! 🎉 Phir se?"
            self._played(d, False)
            return f"{RPS[me]} vs {RPS[bot]} — Main jeet gayi! 😝 Phir se?"
        # ---- one-shot commands
        if re.fullmatch(r"(?:ek )?(?:joke|mazaak|mazak|chutkula|funny)(?: suna(?:o)?| batao| bolo)?", n):
            return pick(c["JOKES"])
        if re.fullmatch(r"(?:ek )?(?:shayari|shayri|sher)(?: suna(?:o)?| batao)?", n):
            return pick(c["SHAYARI"])
        if re.fullmatch(r"(?:ek )?(?:paheli|riddle)(?: puchho| pucho| do| batao)?", n):
            r = pick(c["RIDDLES"])
            self.pending = {"t": "riddle", "a": r[1], "ans": r[2], "at": time.time()}
            return "🧩 " + r[0] + "\n(Jawab likho ya bolo)"
        if re.fullmatch(r"(?:fun fact|facts?|kuch interesting|interesting fact|gyan)(?: batao| sunao)?", n):
            return "🤓 " + pick(c["FACTS"])
        if n in ("would you rather", "wyr"):
            return pick(c["WYR"])
        if n == "truth":
            return pick(c["TRUTH"])
        if n == "dare":
            return pick(c["DARE"])
        if n in ("truth or dare", "truth aur dare", "truth dare"):
            return pick(c["TRUTH"] + c["DARE"])
        if re.fullmatch(r"(?:compliment|tareef|mujhe khush karo|cheer me up)(?: karo| do)?", n):
            return pick(c["COMPL"])
        if re.fullmatch(r"(?:quote|suvichar|motivation|motivate me)(?: do| batao| sunao)?", n):
            return pick(c["QUOTES"])
        if re.fullmatch(r"(?:kahani|story|ek kahani|story suna(?:o)?)(?: sunao| suna do| batao)?", n):
            return "📖 " + pick(c["STORIES"])
        if re.fullmatch(r"(?:guess(?: the)? number|number guess|number khel)", n):
            self.pending = {"t": "guess", "v": random.randint(1, 20), "n": 0, "at": time.time()}
            return "🔢 Maine 1 se 20 ke beech number socha hai. 5 koshish me pakdo! Pehla guess?"
        if re.fullmatch(r"(?:quiz|trivia|quiz khelo|quiz shuru)", n):
            q = random.sample(c["TRIVIA"], 4)
            self.pending = {"t": "quiz", "q": q, "i": 0, "s": 0, "c": q[0][2], "o": q[0][1], "at": time.time()}
            f = q[0]
            return f"🧠 Quiz shuru (4 sawal)!\n\nQ1. {f[0]}\nA) {f[1][0]}  B) {f[1][1]}  C) {f[1][2]}"
        if n in ("rock paper scissors", "rps", "patthar kagaz kainchi", "rock paper"):
            self.pending = {"t": "rps", "at": time.time()}
            return "✊ Rock, Paper, Scissors! Bolo: rock / paper / scissors"
        if n in ("tic tac toe", "ttt", "noughts and crosses"):
            self.chain = None
            self.ttt = [""] * 9
            return f"❌ aap, ⭕ main. Number likho (1-9):\n{self._board(self.ttt)}"
        if n in ("word chain", "antakshari", "shabd khel", "word game"):
            self.ttt = None
            self.chain = {"used": ["apple"], "last": "e", "score": 0}
            return "🔤 Word chain! Main bolti hoon APPLE ➡️ ab aap 'E' se koi English shabd bolo. (band karne ke liye: stop)"
        if re.fullmatch(r"(?:games?|khel|khelo|khel khelein|let s play|play|mujhse khelo|kuch khelte hain|fun)", n):
            return self._menu()
        if re.fullmatch(r"(?:meri stats|my stats|stats|streak|mera streak|badges?)", n):
            return self._stats(d)
        # ---- coins, missions, shop
        if re.fullmatch(r"(?:coins?|mere coins|wallet|balance)", n):
            return f'🪙 Aapke paas {d["coins"]} coins hain.\nAur kamane ke liye "missions" bolo, kharchne ke liye "shop".'
        if re.fullmatch(r"(?:missions?|aaj ke mission|daily missions?)", n):
            return self._mission_text(d)
        if re.fullmatch(r"(?:shop|dukaan|store|market|kharidari)", n):
            return ("🛍️ Shop (bolo: kharido <naam>)\n\n🎨 Themes:\n" + "\n".join(f"• {k} — {v[0]} — {v[1]}🪙" for k, v in THEMES.items())
                    + "\n\n🏠 Room items:\n" + "\n".join(f"• {k} — {v[0]} — {v[2]}🪙" for k, v in ITEMS.items()) + f"\n\nAapke paas: {d['coins']}🪙")
        m = re.fullmatch(r"(?:kharido|buy|khareedo|lo) ([a-z]+)", n)
        if m:
            k = m.group(1)
            if k in THEMES:
                if k in d["own"]:
                    d["theme"] = k
                    return f"{THEMES[k][0]} theme laga diya ✨"
                if d["coins"] < THEMES[k][1]:
                    return f"Abhi {THEMES[k][1] - d['coins']} coins aur chahiye 🪙 (\"missions\" se kamao)"
                d["coins"] -= THEMES[k][1]
                d["own"].append(k)
                d["theme"] = k
                return f"{THEMES[k][0]} theme mil gaya! 🎉"
            if k in ITEMS:
                if k in d["room"]:
                    return "Ye aapke ghar me pehle se hai 🙂"
                if d["coins"] < ITEMS[k][2]:
                    return f"Abhi {ITEMS[k][2] - d['coins']} coins aur chahiye 🪙"
                d["coins"] -= ITEMS[k][2]
                d["room"].append(k)
                return f"{ITEMS[k][0]} {ITEMS[k][1]} ghar me rakh diya! 🏠"
            return "Ye cheez shop me nahi hai. 'shop' bolo."
        if re.fullmatch(r"(?:mera ghar|my room|ghar dikhao)", n):
            return ("🏠 Aapka ghar: " + " ".join(ITEMS[k][0] for k in d["room"])) if d["room"] else "Ghar abhi khali hai. 'shop' se cheezein kharido 🪴"
        # ---- memory
        mm = re.match(r"^\s*(?:yaad\s+rakh(?:o|na)|remember)\s*[:,\-]?\s*(.*)$", raw, re.I)
        if mm:
            t = mm.group(1).strip()
            if len(t) < 3:
                return "Kya yaad rakhun? Bolo: yaad rakho meri exam 5 December ko"
            d["facts"] = (d["facts"] + [{"t": t, "d": _today()}])[-40:]
            return f'📝 Yaad kar liya: "{t}"'
        if n in ("mujhe kya yaad hai", "meri yaadein", "yaadein", "what do you remember", "kya yaad hai"):
            return "🧠 Mujhe ye yaad hai:\n" + "\n".join(f"{i}. {x['t']}" for i, x in enumerate(d["facts"], 1)) if d["facts"] else "Abhi kuch nahi yaad. Bolo: yaad rakho …"
        if n in ("bhool jao", "sab bhool jao", "forget everything", "yaadein mita do"):
            d["facts"] = []
            return "Sab bhula diya 🫥"
        # ---- mood
        mo = re.match(rf"^(?:mera )?mood (?:hai )?({MOODW})\b", n)
        if mo:
            w = mo.group(1)
            sc = 5 if re.fullmatch("khush|happy|badhiya", w) else 3 if re.fullmatch("theek|okay|ok", w) else 2 if w == "bore" else 1
            d["moods"] = (d["moods"] + [{"d": _today(), "s": sc, "w": w}])[-120:]
            d["mmood"] = d.get("mmood", 0) + 1
            return ("Waah, khush rehna! 😄 Isi ko banaye rakho." if sc >= 4 else "Theek hai, aur behtar bhi ho sakta hai 🙂 Chalo ek joke?" if sc == 3
                    else "Samajh sakti hoon 💗 Bolo 'saans lo' (breathing) ya 'joke' — main saath hoon.")
        if n in ("mood report", "mood diary", "mera mood graph"):
            m7 = d["moods"][-7:]
            if not m7:
                return "Abhi mood diary khali hai. Bolo: mera mood khush"
            avg = sum(x["s"] for x in m7) / len(m7)
            return "📈 Pichhle moods:\n" + "\n".join(f"{x['d'][5:]} {'█' * x['s']}{'░' * (5 - x['s'])} {x['w']}" for x in m7) + f"\nAverage: {avg:.1f}/5"
        if n in ("saans lo", "breathing", "breathe", "relax", "calm", "shaant"):
            return "🌬️ 4-4-6 breathing:\n1) 4 count tak naak se saans andar\n2) 4 count roko\n3) 6 count me muh se dheere chhodo\nIse 5 baar karo. Main yahin hoon 💗"
        if len(n.split()) <= 8 and SAD.search(n) and not re.search(r"\b(mood|kharcha|reminder)\b", n):
            return pick(["Main yahin hoon 💗 Chaho to batao kya hua? Ya 'joke' / 'saans lo' bolo.", "Thoda mushkil din lag raha hai na… koi baat nahi. Mere saath 'saans lo' try karo?", "Aap akele nahi ho. Kuch bhi bolo, main sunungi 🤗"])
        if n in ("weekly report", "is hafte ka report", "hafte ka report"):
            wk = [x for x in d["moods"] if time.time() - time.mktime(time.strptime(x["d"], "%Y-%m-%d")) < 7 * 86400]
            return (f"🗓️ Is hafte ka report\n🔥 Streak: {d['streak']} din\n🎮 Games: {d['games']} (jeete {d['wins']})\n🪙 Coins: {d['coins']}\n🏠 Ghar ke items: {len(d['room'])}\n"
                    f"😊 Mood avg: {(sum(x['s'] for x in wk) / len(wk)):.1f}/5" if wk else f"🗓️ Is hafte ka report\n🔥 Streak: {d['streak']} din\n🎮 Games: {d['games']} (jeete {d['wins']})\n🪙 Coins: {d['coins']}\n🏠 Ghar ke items: {len(d['room'])}\n😊 Mood avg: —") + "\nShabaash, aise hi lage raho! 💪"
        return None
