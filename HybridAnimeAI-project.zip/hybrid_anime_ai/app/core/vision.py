"""Screen awareness: take a screenshot ON COMMAND and let the cloud brain describe it.

Nothing is captured in the background. The picture is only sent to your chosen AI provider when you ask something
like "what's on my screen?" / "screen par kya hai?".
"""
import io
import re

SCREEN_Q = re.compile(
    r"(what(?:'s| is)(?: on| in)?\s+(?:my |the )?screen|look at (?:my |the )?screen|analy[sz]e (?:my |the )?screen|"
    r"read (?:my |the )?screen|explain (?:my |the |this )?screen|screen (?:par|pe|me|mein) (?:kya|jo)|screen (?:dekh|padh|samjha)|"
    r"is screen ko|meri screen|स्क्रीन (?:पर|में)|स्क्रीन (?:देख|पढ़|समझा)|screenshot (?:lo aur|analy|dekh|samjha))", re.I)


def capture_png(max_side: int = 1280) -> bytes:
    from PIL import ImageGrab
    try:
        img = ImageGrab.grab(all_screens=True)
    except TypeError:                       # non-Windows Pillow builds
        img = ImageGrab.grab()
    img.thumbnail((max_side, max_side))
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "PNG", optimize=True)
    return buf.getvalue()
