"""Long-term memory: remembers facts about the user and past conversations, fully offline.

Storage is one SQLite file in the user's data folder. Search is a small *vector* search: every text is turned into a
fixed-size "hashed bag-of-words" vector (words + word pairs, any language/script incl. Hindi and Hinglish) and compared
by cosine similarity. It needs no model download, is instant, and never leaves the PC.
"""
import hashlib
import json
import logging
import math
import re
import sqlite3
import threading
import time
from typing import List, Optional, Tuple

log = logging.getLogger(__name__)
DIM = 512
_WORD = re.compile(r"[\wऀ-ॿ]+", re.UNICODE)
_STOP = set("a an the is are was were am i me my you your to of and or in on at it this that for with be do does did "
            "hai hain ho tha thi ka ki ke ko se me mai main tum aap kya ye wo toh bhi aur par ek".split())


def _tokens(text: str) -> List[str]:
    w = [t for t in _WORD.findall(text.lower()) if t not in _STOP and len(t) > 1]
    return w + [f"{a}_{b}" for a, b in zip(w, w[1:])]


def embed(text: str) -> List[float]:
    v = [0.0] * DIM
    for t in _tokens(text):
        h = int(hashlib.md5(t.encode("utf-8")).hexdigest()[:8], 16)
        v[h % DIM] += 1.0 if (h >> 20) & 1 else -1.0
    n = math.sqrt(sum(x * x for x in v)) or 1.0
    return [round(x / n, 4) for x in v]


def cosine(a: List[float], b: List[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


# ---- what counts as "worth remembering" (rule based = zero latency, no API call) -------------------------------
_MONTHS = "jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|january|february|march|april|june|july|august|september|october|november|december"
FACT_PATTERNS: List[Tuple[str, "re.Pattern"]] = [
    ("name", re.compile(r"\b(?:my name is|mera naam|mera nam|i am called|call me|mujhe .{1,20} bulao)\s+([a-zऀ-ॿ]{2,20})", re.I)),
    ("birthday", re.compile(r"\b(?:my birthday is|mera birthday|meri birthday|mera janmdin|my b'?day is)\s*(?:hai|is|on)?\s*(.{3,30})", re.I)),
    ("likes", re.compile(r"\b(?:i (?:really )?(?:like|love|enjoy|prefer)|mujhe (.{2,40}?) (?:pasand(?! nahi)|achha lagta|accha lagta)|mera favourite|my favou?rite)\s*(.{0,60})", re.I)),
    ("dislikes", re.compile(r"\b(?:i (?:hate|dislike|can't stand)|mujhe (.{2,40}?) (?:pasand nahi|nahi pasand|bura lagta))\s*(.{0,60})", re.I)),
    ("work", re.compile(r"\b(?:i work (?:as|at|in)|i am a|i'm a|main .{2,30}? (?:me|mein) kaam karta|meri job)\s*(.{2,60})", re.I)),
    ("place", re.compile(r"\b(?:i live in|i am from|i'm from|main .{2,25}? (?:me|mein) rehta|main .{2,25}? se hoon)\s*(.{0,40})", re.I)),
    ("routine", re.compile(r"\b(?:every (?:day|morning|night|evening|week)|roz|hamesha|daily)\b.{3,80}", re.I)),
]
_REMEMBER = re.compile(r"^\s*(?:please\s+)?(?:remember(?: that)?|yaad rakh(?:na|o)?|note (?:this|that)|yaad rakhna ki|याद रखना)\s*[:\-,]?\s*(.{3,200})$", re.I)
_FORGET_ALL = re.compile(r"\b(?:forget everything|forget all|sab bhool ja|sab kuch bhool|सब भूल)", re.I)
_RECALL = re.compile(r"\b(?:what do you (?:remember|know) about me|kya (?:kya )?yaad hai|mere bare me kya (?:jaanti|pata)|meri yaaden|what do you remember)\b", re.I)


class Memory:
    def __init__(self, path):
        self.path = str(path)
        self._lock = threading.Lock()
        self._init()

    def _db(self):
        con = sqlite3.connect(self.path, timeout=5)
        con.row_factory = sqlite3.Row
        return con

    def _init(self) -> None:
        try:
            with self._lock, self._db() as con:
                con.execute("CREATE TABLE IF NOT EXISTS mem (id INTEGER PRIMARY KEY, kind TEXT, text TEXT, ts REAL, vec TEXT)")
                con.execute("CREATE INDEX IF NOT EXISTS mem_kind ON mem(kind)")
        except Exception:  # noqa: BLE001 - memory must never break the assistant
            log.exception("memory init failed")

    # ------------------------------------------------------------------ write
    def add(self, kind: str, text: str) -> bool:
        text = " ".join(text.split())[:400]
        if len(text) < 3:
            return False
        try:
            with self._lock, self._db() as con:
                if kind != "turn" and con.execute("SELECT 1 FROM mem WHERE kind=? AND lower(text)=lower(?)", (kind, text)).fetchone():
                    return False
                con.execute("INSERT INTO mem(kind,text,ts,vec) VALUES(?,?,?,?)", (kind, text, time.time(), json.dumps(embed(text))))
                con.execute("DELETE FROM mem WHERE kind='turn' AND id NOT IN (SELECT id FROM mem WHERE kind='turn' ORDER BY id DESC LIMIT 600)")
            return True
        except Exception:  # noqa: BLE001
            log.exception("memory add failed")
            return False

    def add_turn(self, user_text: str, reply: str) -> None:
        self.add("turn", f"User: {user_text} | Me: {reply}")

    def learn(self, user_text: str) -> List[str]:
        """Pull out durable facts from what the user said. Returns the facts stored."""
        out = []
        m = _REMEMBER.match(user_text)
        if m and self.add("note", m.group(1).strip()):
            out.append(m.group(1).strip())
        for kind, rx in FACT_PATTERNS:
            mm = rx.search(user_text)
            if mm:
                fact = f"{kind}: {mm.group(0).strip()}"
                if self.add(kind, fact):
                    out.append(fact)
        return out

    def forget_all(self) -> None:
        try:
            with self._lock, self._db() as con:
                con.execute("DELETE FROM mem")
        except Exception:  # noqa: BLE001
            log.exception("memory wipe failed")

    # ------------------------------------------------------------------ read
    def facts(self, limit: int = 12) -> List[str]:
        try:
            with self._lock, self._db() as con:
                rows = con.execute("SELECT text FROM mem WHERE kind!='turn' ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()
            return [r["text"] for r in rows]
        except Exception:  # noqa: BLE001
            return []

    def search(self, query: str, k: int = 3, min_score: float = 0.18) -> List[Tuple[float, str]]:
        q = embed(query)
        try:
            with self._lock, self._db() as con:
                rows = con.execute("SELECT text, vec, ts FROM mem ORDER BY id DESC LIMIT 800").fetchall()
        except Exception:  # noqa: BLE001
            return []
        scored = []
        now = time.time()
        for r in rows:
            try:
                s = cosine(q, json.loads(r["vec"]))
            except Exception:  # noqa: BLE001
                continue
            s += 0.04 * math.exp(-(now - r["ts"]) / 604800.0)      # slight preference for recent memories
            if s >= min_score:
                scored.append((s, r["text"]))
        scored.sort(reverse=True)
        return scored[:k]

    def context(self, query: str) -> str:
        """Text block that is added to the system prompt so the brain 'remembers'."""
        parts = []
        f = self.facts(8)
        if f:
            parts.append("Things you know about the user: " + "; ".join(f) + ".")
        rel = [t for _s, t in self.search(query, 3) if t not in f]
        if rel:
            parts.append("Possibly relevant past moments: " + " || ".join(rel[:3]) + ".")
        return " ".join(parts)

    # ------------------------------------------------------------------ chat commands
    def handle_command(self, text: str, lang: str = "en") -> Optional[str]:
        if _FORGET_ALL.search(text):
            self.forget_all()
            return {"hinglish": "Theek hai, maine sab bhula diya.", "hi": "ठीक है, मैंने सब भुला दिया।"}.get(lang, "Okay, I've forgotten everything.")
        if _RECALL.search(text):
            f = self.facts(10)
            if not f:
                return {"hinglish": "Abhi mujhe tumhare bare me kuch khaas yaad nahi. Bataoge to yaad rakhungi!",
                        "hi": "अभी मुझे आपके बारे में कुछ खास याद नहीं। बताओगे तो याद रखूँगी!"}.get(lang, "I don't remember much yet. Tell me about yourself and I will!")
            return {"hinglish": "Mujhe ye yaad hai: ", "hi": "मुझे ये याद है: "}.get(lang, "Here's what I remember: ") + "; ".join(f[:6]) + "."
        m = _REMEMBER.match(text)
        if m:
            self.add("note", m.group(1).strip())
            return {"hinglish": "Yaad rakh liya!", "hi": "याद रख लिया!"}.get(lang, "Got it, I'll remember that.")
        return None
