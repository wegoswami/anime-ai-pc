"""Reels / Shorts control for the PC: "agla reel", "pichla reel", and an auto-scroll mode ("har 10 second me reel scroll karo").
It presses Down / Up in the window you are watching (YouTube Shorts and Instagram/Facebook web reels move with the arrow keys).
Auto-scroll always stops by itself after MAX_MIN minutes, and it tells you at 30 minutes so you can take a break."""
import re
import threading
from typing import Callable, Optional

VK_UP, VK_DOWN = 0x26, 0x28
MAX_MIN = 60
BREAK_MIN = 30
DEFAULT_SEC = 12

_STOP = re.compile(r"auto ?scroll (?:band|stop|off|rok)|(?:reels?|shorts?) (?:band|stop|rok)|scroll (?:band|stop|rok)|reels? dekhna band")
_AUTO = re.compile(r"auto ?scroll|(?:reels?|shorts?) (?:auto|khud)|khud (?:se )?(?:reels?|shorts?)|har \d+ (?:sec|second|s)\b.*(?:scroll|reel|short)")
_NEXT = re.compile(r"\b(?:agla|next|naya)\b.*\b(?:reels?|shorts?)\b|\b(?:reels?|shorts?)\b.*\b(?:scroll|badlo|change|agla|next)\b")
_PREV = re.compile(r"\b(?:pichla|previous|prev|peeche)\b.*\b(?:reels?|shorts?)\b")

MSG = {
    "next": {"en": "Next reel.", "hinglish": "Agla reel.", "hi": "अगला रील।"},
    "prev": {"en": "Previous reel.", "hinglish": "Pichla reel.", "hi": "पिछला रील।"},
    "on": {"en": "Auto-scroll on: a new reel every {x} seconds. Say “auto scroll band” to stop.",
           "hinglish": "Auto-scroll chalu: har {x} second me naya reel. Rokne ke liye “auto scroll band” bolo.",
           "hi": "ऑटो-स्क्रॉल चालू: हर {x} सेकंड में नया रील। रोकने के लिए “auto scroll band” बोलो।"},
    "off": {"en": "Auto-scroll stopped.", "hinglish": "Auto-scroll band kar diya.", "hi": "ऑटो-स्क्रॉल बंद कर दिया।"},
    "none": {"en": "Auto-scroll wasn't running.", "hinglish": "Auto-scroll chal hi nahi raha tha.", "hi": "ऑटो-स्क्रॉल चल ही नहीं रहा था।"},
    "break": {"en": "That's 30 minutes of reels. Want a short break? Say “auto scroll band” whenever you like.",
              "hinglish": "30 minute ho gaye reels ko. Thoda break lein? Jab chaho “auto scroll band” bol dena.",
              "hi": "रील्स देखते 30 मिनट हो गए। थोड़ा ब्रेक लें?"},
}


def _m(key: str, lang: str, x: str = "") -> str:
    return MSG[key][lang if lang in ("hinglish", "hi") else "en"].format(x=x)


class ReelScroller:
    def __init__(self, press: Optional[Callable[[int], None]], notify: Optional[Callable[[str], None]] = None):
        self.press = press                       # press(vk) -> sends one key tap (None = not on Windows)
        self.notify = notify
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def handle(self, t: str, lang: str = "hinglish") -> Optional[str]:
        """t is the normalised command. Returns a reply or None when it is not about reels."""
        if _STOP.search(t):
            if self.running:
                self.stop()
                return _m("off", lang)
            return _m("none", lang) if re.search(r"auto", t) else None
        if _AUTO.search(t):
            m = re.search(r"(\d{1,3})\s*(?:sec|second|s)\b", t)
            sec = max(4, min(300, int(m.group(1)))) if m else DEFAULT_SEC
            self.start(sec, lang)
            return _m("on", lang, str(sec))
        if _PREV.search(t):
            self._tap(VK_UP)
            return _m("prev", lang)
        if _NEXT.search(t):
            self._tap(VK_DOWN)
            return _m("next", lang)
        return None

    def _tap(self, vk: int) -> None:
        if self.press:
            self.press(vk)

    def start(self, sec: int, lang: str = "hinglish") -> None:
        self.stop()
        self._stop = threading.Event()
        ev = self._stop

        def run():
            waited, warned = 0.0, False
            while not ev.wait(sec):
                waited += sec
                self._tap(VK_DOWN)
                if not warned and waited >= BREAK_MIN * 60:
                    warned = True
                    if self.notify:
                        self.notify(_m("break", lang))
                if waited >= MAX_MIN * 60:
                    break

        self._thread = threading.Thread(target=run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
