"""Wi-Fi bridge between the PC assistant and the phone assistant (same network only).

The user starts it with "phone jodo": the PC shows its address and a one-time pairing code. The phone enters both
("pc se jodo <ip> <code>"). After that:
  * memory facts and the soul profile are merged in both directions,
  * the phone can run commands on the PC ("pc par open notepad"), and the PC can queue commands for the phone
    ("phone par open youtube").
Every request needs the pairing code (header X-Token); the server only runs while the user has switched it on.
"""
import json
import logging
import secrets
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable, List, Optional

log = logging.getLogger(__name__)
PORT = 8765


def local_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))          # no packet is sent; just selects the LAN interface
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


class Bridge:
    def __init__(self, get_facts: Callable[[], List[str]], add_fact: Callable[[str], None],
                 get_soul: Callable[[], dict], merge_soul: Callable[[dict], None], run_cmd: Callable[[str], Optional[str]]):
        self.get_facts, self.add_fact, self.get_soul, self.merge_soul, self.run_cmd = get_facts, add_fact, get_soul, merge_soul, run_cmd
        self.token = ""
        self.server: Optional[ThreadingHTTPServer] = None
        self.outbox: List[str] = []
        self.lock = threading.Lock()

    @property
    def running(self) -> bool:
        return self.server is not None

    def start(self, port: int = PORT) -> str:
        if self.server:
            return self.token
        self.token = secrets.token_hex(3)               # 6 hex chars, new for every session
        bridge = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):  # silence default stderr logging
                pass

            def _cors(self):
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Headers", "X-Token, Content-Type")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.send_header("Access-Control-Allow-Private-Network", "true")

            def _send(self, code: int, obj: dict):
                body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
                self.send_response(code)
                self._cors()
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_OPTIONS(self):  # noqa: N802
                self.send_response(204)
                self._cors()
                self.end_headers()

            def _auth(self) -> bool:
                if secrets.compare_digest(self.headers.get("X-Token", ""), bridge.token):
                    return True
                self._send(401, {"error": "bad code"})
                return False

            def _body(self) -> dict:
                n = min(int(self.headers.get("Content-Length") or 0), 200_000)
                try:
                    return json.loads(self.rfile.read(n) or b"{}")
                except ValueError:
                    return {}

            def do_GET(self):  # noqa: N802
                if not self._auth():
                    return
                try:
                    if self.path.startswith("/ping"):
                        self._send(200, {"ok": True, "device": "pc"})
                    elif self.path.startswith("/sync"):
                        self._send(200, {"facts": bridge.get_facts(), "soul": bridge.get_soul()})
                    elif self.path.startswith("/poll"):
                        with bridge.lock:
                            out, bridge.outbox = bridge.outbox, []
                        self._send(200, {"cmds": out})
                    else:
                        self._send(404, {"error": "unknown"})
                except Exception:  # noqa: BLE001
                    log.exception("bridge GET failed")
                    self._send(500, {"error": "failed"})

            def do_POST(self):  # noqa: N802
                if not self._auth():
                    return
                try:
                    d = self._body()
                    if self.path.startswith("/sync"):
                        for f in (d.get("facts") or [])[:60]:
                            bridge.add_fact(str(f)[:300])
                        if isinstance(d.get("soul"), dict):
                            bridge.merge_soul(d["soul"])
                        self._send(200, {"ok": True})
                    elif self.path.startswith("/cmd"):
                        text = str(d.get("text", ""))[:300]
                        self._send(200, {"reply": bridge.run_cmd(text) or "Ho gaya (ya samajh nahi aaya)."})
                    else:
                        self._send(404, {"error": "unknown"})
                except Exception:  # noqa: BLE001
                    log.exception("bridge POST failed")
                    self._send(500, {"error": "failed"})

        try:
            self.server = ThreadingHTTPServer(("0.0.0.0", port), H)
        except OSError:
            self.server = None
            raise
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        return self.token

    def stop(self) -> None:
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            self.server = None

    def queue_for_phone(self, text: str) -> None:
        with self.lock:
            self.outbox = (self.outbox + [text[:300]])[-20:]
