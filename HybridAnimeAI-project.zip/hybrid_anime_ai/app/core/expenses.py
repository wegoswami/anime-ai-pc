"""Simple expense diary: "kharcha 200 chai", "aaj ka kharcha", "is mahine ka kharcha", "kharcha hatao". Stored in a small JSON file."""
import json
import re
import time
from pathlib import Path
from typing import Callable, Optional

ADD1 = re.compile(r"^\s*(?:kharcha|kharch|expense|spent|spend)\s*[:\-]?\s*(?:rs\.?|₹|inr)?\s*(\d+(?:\.\d+)?)\s*(?:rs|rupees?|rupaye|₹)?\s*(?:ka|ki|ke|on|for|pe|par)?\s*(.*)$", re.I)
ADD2 = re.compile(r"^\s*(?:rs\.?|₹)?\s*(\d+(?:\.\d+)?)\s*(?:rs|rupees?|rupaye|₹)?\s+(?:ka|ki|ke)?\s*(.*?)\s*(?:pe|par|me|mein|ke liye)?\s*(?:kharch(?:a)?|kharch kiye|kharch kiya|spent|laga|lag gaye)\s*$", re.I)
KW = re.compile(r"kharch|expense|spent", re.I)


def money(x: float) -> str:
    x = round(x, 2)
    return "₹" + (f"{x:,.0f}" if x == int(x) else f"{x:,.2f}")


def _start(kind: str) -> float:
    t = time.localtime()
    d = time.mktime((t.tm_year, t.tm_mon, 1 if kind == "month" else t.tm_mday, 0, 0, 0, 0, 0, -1))
    return d


class Expenses:
    def __init__(self, path_getter: Callable[[], Path]):
        self.path_getter = path_getter

    def _load(self) -> list:
        try:
            return json.loads(self.path_getter().read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []

    def _save(self, rows: list) -> None:
        p = self.path_getter()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")

    def _summary(self, rows: list, label: str) -> str:
        if not rows:
            return f"{label} koi kharcha darj nahi hai."
        by: dict = {}
        for r in rows:
            k = " ".join((r.get("note") or "other").lower().split()[:2]) or "other"
            by[k] = by.get(k, 0) + r["amt"]
        top = ", ".join(f"{k} {money(v)}" for k, v in sorted(by.items(), key=lambda kv: -kv[1])[:4])
        return f"{label} kul {money(sum(r['amt'] for r in rows))} kharcha hua ({len(rows)} entries). Sabse zyada: {top}."

    def try_execute(self, text: str) -> Optional[str]:
        t = text.strip()
        low = t.lower()
        if not KW.search(low) and not re.match(r"^\s*(?:rs\.?|₹)?\s*\d", t):
            return None
        rows = self._load()
        if KW.search(low) and re.search(r"undo|hatao|hata do|delete last|galat|last wala|remove last", low):
            if not rows:
                return "Hatane ke liye kuch nahi hai."
            r = rows.pop()
            self._save(rows)
            return f"Hata diya: {money(r['amt'])} {r.get('note', '')}."
        m = ADD1.match(t) or ADD2.match(t)
        if m and not re.search(r"\b(aaj|mahine|total|kitna|dikhao|list)\b", low):
            amt, note = float(m.group(1)), re.sub(r"\b(ka|ki|ke|pe|par)\s*$", "", m.group(2).strip(), flags=re.I).strip()
            if 0 < amt < 1e8:
                rows.append({"amt": amt, "note": note, "at": time.time()})
                self._save(rows)
                today = sum(r["amt"] for r in rows if r["at"] >= _start("day"))
                return f"{money(amt)} {note + ' ka ' if note else ''}likh liya. Aaj ka total: {money(today)}."
        if KW.search(low):
            if re.search(r"\baaj\b|today", low):
                return self._summary([r for r in rows if r["at"] >= _start("day")], "Aaj")
            if re.search(r"mahine|month|total|kitna|dikhao|list|hisab|hisaab|summary", low):
                return self._summary([r for r in rows if r["at"] >= _start("month")], "Is mahine")
        return None
