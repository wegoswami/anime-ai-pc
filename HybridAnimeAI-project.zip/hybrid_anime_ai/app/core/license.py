"""Pro licence + anonymous usage counts, both talking to the Earthvasi API (server/worker.js).

Everything here is inert until LICENSE_API in app/version.py is set, and every network error is swallowed:
the assistant must never stop working because the licence server is unreachable.
What is sent: random install id, app version, platform, language, feature counters. Never chats, files, keys or contacts.
"""
import logging
import threading
import time
import uuid
import webbrowser
from collections import Counter
from typing import Optional

import requests

from .. import config as config_mod
from .. import version as V

log = logging.getLogger(__name__)
GRACE_DAYS = 14                      # a licence checked OK stays valid this long without internet
_counts: Counter = Counter()
_lock = threading.Lock()


def api() -> str:
    return (V.LICENSE_API or "").rstrip("/")


def install_id(cfg: dict) -> str:
    if len(cfg.get("install_id") or "") < 12:
        cfg["install_id"] = uuid.uuid4().hex
        config_mod.save_config(cfg)
    return cfg["install_id"]


def count(name: str) -> None:
    """Counts a feature use locally; it is sent (as a number only) with the next daily ping."""
    with _lock:
        _counts[name] += 1


def is_pro(cfg: dict) -> bool:
    c = cfg.get("license_cache") or {}
    if not (c.get("valid") and cfg.get("license_key")):
        return False
    if c.get("expires") and c["expires"] / 1000 < time.time():
        return False
    return time.time() - c.get("checked", 0) < GRACE_DAYS * 86400


def allowed(cfg: dict, feature: str) -> bool:
    """False only when Pro is switched on for this release, the feature is a Pro one and this PC has no valid licence."""
    return (not V.PRO_ENFORCED) or feature not in V.PRO_FEATURES or is_pro(cfg)


def locked_message(feature: str) -> str:
    return ("Ye Pro feature hai 🔒. 'pro kharido yearly' bolo (ya monthly / lifetime) - browser me payment page khulega. "
            "Key mil jaaye to bolo: pro key EV-XXXX-XXXX-XXXX-XXXX")


def _post(path: str, body: dict, timeout: float = 8.0) -> Optional[dict]:
    if not api():
        return None
    try:
        r = requests.post(api() + path, json=body, timeout=timeout, headers={"User-Agent": V.USER_AGENT})
        return r.json()
    except Exception as exc:  # noqa: BLE001
        log.debug("api %s failed: %s", path, exc)
        return None


def verify(cfg: dict) -> dict:
    """Asks the server about the saved key and caches the answer. Returns the cache dict ({} if nothing to check)."""
    key = (cfg.get("license_key") or "").strip().upper()
    if not key or not api():
        return {}
    j = _post("/v1/license/verify", {"key": key, "id": install_id(cfg)})
    if j is None:                                    # server unreachable: keep the old answer (grace period applies)
        return cfg.get("license_cache") or {}
    cfg["license_cache"] = {"valid": bool(j.get("valid")), "plan": j.get("plan", ""), "expires": j.get("expires", 0), "reason": j.get("reason", ""), "checked": time.time()}
    config_mod.save_config(cfg)
    return cfg["license_cache"]


def activate(cfg: dict, key: str) -> str:
    key = key.strip().upper()
    if not api():
        return "Pro abhi shuru nahi hua (server set nahi hai)."
    cfg["license_key"] = key
    c = verify(cfg)
    if c.get("valid"):
        return f"Pro chalu ho gaya! ✅ Plan: {c.get('plan')}. Shukriya! 🎉"
    cfg["license_key"] = ""
    config_mod.save_config(cfg)
    why = {"unknown_key": "ye key pehchaani nahi gayi", "expired": "ye key expire ho chuki hai", "device_limit": "is key par devices ki limit poori ho gayi"}.get(c.get("reason"), "server se jawab nahi mila, internet check karke dobara try karo")
    return f"Key chali nahi: {why}."


def status(cfg: dict) -> str:
    if not api():
        return "Abhi sab features free hain. 🎁"
    if is_pro(cfg):
        c = cfg["license_cache"]
        until = "hamesha ke liye" if not c.get("expires") else "tak " + time.strftime("%d %b %Y", time.localtime(c["expires"] / 1000))
        return f"Aap Pro ho ✅ ({c.get('plan')}, {until})."
    return "Aap Free plan par ho. Pro ke liye bolo: 'pro kharido yearly' (ya monthly / lifetime)."


def _currency() -> str:
    """INR for customers in India (IST), USD elsewhere. Server ignores USD until international payments are enabled."""
    import time
    return "INR" if time.timezone == -19800 or "India" in time.tzname[0] or time.tzname[0] in ("IST",) else "USD"


def checkout(cfg: dict, plan: str) -> str:
    if not api():
        return "Pro abhi shuru nahi hua. Jaldi aayega!"
    j = _post("/v1/checkout", {"plan": plan, "id": install_id(cfg), "currency": _currency()}, timeout=12)
    if not j or not j.get("url"):
        return "Payment page nahi ban paaya, thodi der baad try karo."
    webbrowser.open(j["url"])
    return "Payment page browser me khol diya. Payment ke baad jo key dikhe use yahan bolo: pro key EV-XXXX-XXXX-XXXX-XXXX"


def ping_async(cfg: dict) -> None:
    """At most one ping per ~20 hours; refreshes the licence at the same time. Runs in a background thread."""
    if not api():
        return
    def run():
        try:
            if cfg.get("license_key"):
                verify(cfg)
            if not cfg.get("analytics", True):
                return
            if time.time() - float(cfg.get("last_ping", 0)) < 20 * 3600:
                return
            with _lock:
                ev, _counts_copy = dict(_counts), None
            lang = str(cfg.get("language") or cfg.get("lang") or "")
            j = _post("/v1/ping", {"id": install_id(cfg), "platform": "pc", "version": V.APP_VERSION, "tier": "pro" if is_pro(cfg) else "free", "lang": lang, "events": ev})
            if j and j.get("ok"):
                with _lock:
                    _counts.clear()
                cfg["last_ping"] = time.time()
                config_mod.save_config(cfg)
        except Exception:  # noqa: BLE001
            log.debug("ping failed", exc_info=True)
    threading.Thread(target=run, daemon=True).start()
