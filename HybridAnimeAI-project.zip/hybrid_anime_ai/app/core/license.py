"""Pro licence + anonymous usage counts, both talking to the Earthvasi API (server/worker.js).

Everything here is inert until LICENSE_API in app/version.py is set, and every network error is swallowed:
the assistant must never stop working because the licence server is unreachable.
What is sent: random install id, app version, platform, language, feature counters. Never chats, files, keys or contacts.
"""
import logging
import threading
import time
import uuid
import webbrowser
from collections import Counter
from typing import Optional

import requests

from .. import config as config_mod
from .. import version as V

log = logging.getLogger(__name__)
GRACE_DAYS = 14                      # a licence checked OK stays valid this long without internet
_counts: Counter = Counter()
_lock = threading.Lock()


def api() -> str:
    return (V.LICENSE_API or "").rstrip("/")


def install_id(cfg: dict) -> str:
    if len(cfg.get("install_id") or "") < 12:
        cfg["install_id"] = uuid.uuid4().hex
        config_mod.save_config(cfg)
    return cfg["install_id"]


def count(name: str) -> None:
    """Counts a feature use locally; it is sent (as a number only) with the next daily ping."""
    with _lock:
        _counts[name] += 1


def is_pro(cfg: dict) -> bool:
    if cfg.get("blocked"):
        return False
    c = cfg.get("license_cache") or {}
    if not (c.get("valid") and cfg.get("license_key")):
        return False
    if c.get("expires") and c["expires"] / 1000 < time.time():
        return False
    return time.time() - c.get("checked", 0) < GRACE_DAYS * 86400


def tier(cfg: dict) -> str:
    """Two plans only: 'free' (everyday features, offline) and 'premium' (our AI + advanced features)."""
    return "premium" if is_pro(cfg) else "free"


def managed(cfg: dict) -> bool:
    """True when online AI should go through our server (Premium). The app never holds an AI key."""
    return bool(api()) and tier(cfg) == "premium"


def cloud_ok(cfg: dict) -> bool:
    return managed(cfg)


def managed_call(cfg: dict, kind: str, body: dict, timeout: float = 40.0) -> dict:
    """Sends an AI request to OUR server, which holds the AI key, counts the daily use and forwards it. Raises RuntimeError with a user-friendly reason."""
    try:
        r = requests.post(api() + "/v1/ai", json={"key": (cfg.get("license_key") or "").strip().upper(), "id": install_id(cfg), "kind": kind, "body": body},
                          timeout=timeout, headers={"User-Agent": V.USER_AGENT})
    except requests.RequestException as exc:
        raise RuntimeError("Earthvasi AI server tak nahi pahunch paayi (net/VPN check karo)") from exc
    if r.status_code == 429:
        raise RuntimeError("Aaj ki Premium AI ki limit khatam ho gayi. Local kaam chalte rahenge, kal reset hogi.")
    if r.status_code == 403:
        threading.Thread(target=lambda: verify(cfg), daemon=True).start()
        raise RuntimeError("Aapka plan verify nahi hua (expire ya device limit). 'plans' bolo.")
    r.raise_for_status()
    return r.json()


def plans_text(cfg: dict) -> str:
    if not api():
        return "Plans abhi shuru nahi hue."
    try:
        j = requests.get(api() + "/v1/plans", timeout=8).json()
        P, q = j["plans"], j.get("quota", {})
    except Exception:  # noqa: BLE001
        return "Plans abhi nahi aa paaye, thodi der baad try karo."
    f = lambda k: ("Rs " + format(P[k]["inr"], "g")) if k in P else "-"   # noqa: E731
    return ("Free: rozmarra ke kaam, poora offline, Rs 0\n"
            f"Premium: smart AI chat, live news, tutor, screen control, natural voice, call recording. Koi setup ya key nahi. {f('premium_monthly')}/mahina ya {f('premium_yearly')}/saal "
            f"(roz: {q.get('chat')} chat, {q.get('agent')} screen step, {q.get('news')} news, {q.get('tts')} voice)\n"
            "Bolo: 'buy premium monthly' ya 'buy premium yearly'")


def allowed(cfg: dict, feature: str) -> bool:
    """False only when Pro is switched on for this release, the feature is a Pro one and this PC has no valid licence."""
    return (not V.PRO_ENFORCED) or feature not in V.PRO_FEATURES or is_pro(cfg)


def locked_message(feature: str) -> str:
    return ("Ye Premium feature hai 🔒. 'plans' bolo, phir 'buy premium monthly' ya 'buy premium yearly' - browser me payment page khulega. "
            "Key mil jaaye to bolo: pro key EV-XXXX-XXXX-XXXX-XXXX")


def _post(path: str, body: dict, timeout: float = 8.0) -> Optional[dict]:
    if not api():
        return None
    try:
        r = requests.post(api() + path, json=body, timeout=timeout, headers={"User-Agent": V.USER_AGENT})
        return r.json()
    except Exception as exc:  # noqa: BLE001
        log.debug("api %s failed: %s", path, exc)
        return None


def verify(cfg: dict) -> dict:
    """Asks the server about the saved key and caches the answer. Returns the cache dict ({} if nothing to check)."""
    key = (cfg.get("license_key") or "").strip().upper()
    if not key or not api():
        return {}
    j = _post("/v1/license/verify", {"key": key, "id": install_id(cfg)})
    if j is None:                                    # server unreachable: keep the old answer (grace period applies)
        return cfg.get("license_cache") or {}
    cfg["license_cache"] = {"valid": bool(j.get("valid")), "plan": j.get("plan", ""), "tier": j.get("tier", ""), "expires": j.get("expires", 0), "reason": j.get("reason", ""), "checked": time.time()}
    config_mod.save_config(cfg)
    return cfg["license_cache"]


def activate(cfg: dict, key: str) -> str:
    key = key.strip().upper()
    if not api():
        return "Pro abhi shuru nahi hua (server set nahi hai)."
    cfg["license_key"] = key
    c = verify(cfg)
    if c.get("valid"):
        return f"Pro chalu ho gaya! ✅ Plan: {c.get('plan')}. Shukriya! 🎉"
    cfg["license_key"] = ""
    config_mod.save_config(cfg)
    why = {"unknown_key": "ye key pehchaani nahi gayi", "expired": "ye key expire ho chuki hai", "device_limit": "is key par devices ki limit poori ho gayi"}.get(c.get("reason"), "server se jawab nahi mila, internet check karke dobara try karo")
    return f"Key chali nahi: {why}."


def status(cfg: dict) -> str:
    if not api():
        return "Abhi sab features free hain. 🎁"
    if is_pro(cfg):
        c = cfg["license_cache"]
        until = "hamesha ke liye" if not c.get("expires") else "tak " + time.strftime("%d %b %Y", time.localtime(c["expires"] / 1000))
        return f"Aap Premium par ho ✅ ({c.get('plan')}, {until})."
    return "Aap Free plan par ho. Pro ke liye bolo: 'pro kharido yearly' (ya monthly / lifetime)."


def _currency() -> str:
    """INR for customers in India (IST), USD elsewhere. Server ignores USD until international payments are enabled."""
    import time
    return "INR" if time.timezone == -19800 or "India" in time.tzname[0] or time.tzname[0] in ("IST",) else "USD"


def checkout(cfg: dict, plan: str) -> str:
    if not api():
        return "Pro abhi shuru nahi hua. Jaldi aayega!"
    j = _post("/v1/checkout", {"plan": plan, "id": install_id(cfg), "currency": _currency()}, timeout=12)
    if not j or not j.get("url"):
        return "Payment page nahi ban paaya, thodi der baad try karo."
    webbrowser.open(j["url"])
    return "Payment page browser me khol diya. Payment ke baad jo key dikhe use yahan bolo: pro key EV-XXXX-XXXX-XXXX-XXXX"


# ---------------------------------------------------------------- support: queries to the owner, replies, announcements, remote settings
def _vnew(a: str, b: str) -> bool:
    def t(x):
        return [int(p) if p.isdigit() else 0 for p in str(x).split(".")[:3]] + [0, 0, 0]
    return t(a)[:3] > t(b)[:3]


def send_ticket(cfg: dict, kind: str, body: str) -> str:
    if not api():
        return "Feedback abhi chalu nahi hua."
    try:
        r = requests.post(api() + "/v1/ticket", json={"id": install_id(cfg), "kind": kind, "body": body, "version": V.APP_VERSION, "platform": "pc"}, timeout=10)
    except requests.RequestException:
        return "Bhej nahi paayi, net check karo."
    if r.status_code == 429:
        return "Aaj bahut bhej diye, kal phir bhejna."
    if r.status_code != 200:
        return "Abhi bhej nahi paa rahi, thodi der baad try karo."
    return f"✅ Team ko bhej diya (#{r.json().get('ticket')}). Jawab aate hi yahin bata dungi. 'meri requests' bolke kabhi bhi dekho."


def pull(cfg: dict) -> Optional[dict]:
    j = _post("/v1/sync", {"id": install_id(cfg), "tier": tier(cfg), "version": V.APP_VERSION}, timeout=10)
    return j if j and j.get("ok") else None


def tickets_text(cfg: dict) -> str:
    j = pull(cfg)
    if not j:
        return "Requests nahi la paayi."
    if not j["tickets"]:
        return "Abhi koi request nahi. 'feedback: ...' bolke bhejo."
    st = {"open": "⏳ open", "progress": "🔧 in progress", "done": "✅ done", "rejected": "❌ abhi plan me nahi"}
    return "\n".join(f"#{t['id']} {st.get(t['status'], t['status'])} - {str(t['body'])[:60]}" + (f"\n   ↪ {t['reply']}" if t.get("reply") else "") for t in j["tickets"])


def sync(cfg: dict, say) -> None:
    """Blocked flag, announcements (once each), replies to your tickets, maintenance / update notices. `say(text)` shows them."""
    j = pull(cfg)
    if not j:
        return
    S = cfg.setdefault("support_state", {"seen": [], "tk": {}, "warn": ""})
    cfg["blocked"] = bool(j.get("blocked"))
    if j.get("gift") and not is_pro(cfg):
        say("🎁 " + activate(cfg, j["gift"]))        # a plan the owner gave this install
    for a in j.get("announcements", []):
        if a["id"] not in S["seen"]:
            S["seen"].append(a["id"])
            say("📣 " + a["body"])
    S["seen"] = S["seen"][-50:]
    for t in j.get("tickets", []):
        sig, key = f"{t['status']}|{t.get('reply') or ''}", str(t["id"])
        if key in S["tk"] and S["tk"][key] != sig and (t.get("reply") or t["status"] != "open"):
            say(f"🎫 #{t['id']} ({str(t['body'])[:30]}...): {t['status']}" + (f" - {t['reply']}" if t.get("reply") else ""))
        S["tk"][key] = sig
    c = j.get("config") or {}
    if c.get("maintenance") and S["warn"] != "m:" + c["maintenance"]:
        S["warn"] = "m:" + c["maintenance"]
        say("🛠 " + c["maintenance"])
    elif c.get("min_version") and _vnew(c["min_version"], V.APP_VERSION) and S["warn"] != "v:" + c["min_version"]:
        S["warn"] = "v:" + c["min_version"]
        say(f"Naya version ({c['min_version']}) aa gaya hai - app update kar lo.")
    config_mod.save_config(cfg)


def sync_async(cfg: dict, say) -> None:
    if api():
        threading.Thread(target=lambda: sync(cfg, say), daemon=True).start()


def ping_async(cfg: dict) -> None:
    """At most one ping per ~20 hours; refreshes the licence at the same time. Runs in a background thread."""
    if not api():
        return
    def run():
        try:
            if cfg.get("license_key"):
                verify(cfg)
            if not cfg.get("analytics", True):
                return
            if time.time() - float(cfg.get("last_ping", 0)) < 20 * 3600:
                return
            with _lock:
                ev, _counts_copy = dict(_counts), None
            lang = str(cfg.get("language") or cfg.get("lang") or "")
            j = _post("/v1/ping", {"id": install_id(cfg), "platform": "pc", "version": V.APP_VERSION, "tier": tier(cfg), "lang": lang, "events": ev})
            if j and j.get("ok"):
                with _lock:
                    _counts.clear()
                cfg["last_ping"] = time.time()
                config_mod.save_config(cfg)
        except Exception:  # noqa: BLE001
            log.debug("ping failed", exc_info=True)
    threading.Thread(target=run, daemon=True).start()
