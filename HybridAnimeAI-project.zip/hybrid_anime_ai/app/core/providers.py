"""Cloud brains: Gemini, OpenAI and Claude behind one tiny interface (plain REST, no heavy SDKs).

Every call has a short timeout. A provider that fails is "cooled down" for a minute so the next questions skip straight
to the next brain (or the offline model) instead of making the user wait again.
"""
import base64
import logging
import time
from typing import Dict, List, Optional, Tuple

import requests

log = logging.getLogger(__name__)
TIMEOUT = 25
COOLDOWN = 60.0
_down_until: Dict[str, float] = {}

NAMES = {"gemini": "Gemini", "openai": "OpenAI", "claude": "Claude"}
KEY_FIELD = {"gemini": "gemini_api_key", "openai": "openai_api_key", "claude": "anthropic_api_key"}


def available(cfg: dict) -> List[str]:
    """Providers that have a key, in the user's preferred order."""
    order = [p for p in (cfg.get("provider_order") or ["gemini", "openai", "claude"]) if p in KEY_FIELD]
    for p in KEY_FIELD:
        if p not in order:
            order.append(p)
    return [p for p in order if (cfg.get(KEY_FIELD[p]) or "").strip()]


def usable(cfg: dict) -> List[str]:
    now = time.time()
    return [p for p in available(cfg) if _down_until.get(p, 0) <= now]


def mark_down(p: str) -> None:
    _down_until[p] = time.time() + COOLDOWN


def reset() -> None:
    _down_until.clear()


def _check(r: requests.Response, name: str) -> dict:
    if r.status_code in (401, 403):
        raise RuntimeError(f"{name}: the API key was rejected")
    if r.status_code == 429:
        raise RuntimeError(f"{name}: rate limit / quota reached")
    r.raise_for_status()
    return r.json()


def ask(provider: str, cfg: dict, system: str, history: List[Tuple[str, str]], text: str,
        image: Optional[bytes] = None, max_tokens: int = 260) -> str:
    key = (cfg.get(KEY_FIELD[provider]) or "").strip()
    if provider == "gemini":
        model = cfg.get("gemini_model") or "gemini-2.5-flash"
        contents = [{"role": "user" if r == "user" else "model", "parts": [{"text": t}]} for r, t in history]
        parts = [{"text": text}]
        if image:
            parts.insert(0, {"inline_data": {"mime_type": "image/png", "data": base64.b64encode(image).decode()}})
        contents.append({"role": "user", "parts": parts})
        r = requests.post(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                          headers={"x-goog-api-key": key, "Content-Type": "application/json"},
                          json={"systemInstruction": {"parts": [{"text": system}]}, "contents": contents,
                                "generationConfig": {"temperature": 0.8, "maxOutputTokens": max_tokens}}, timeout=TIMEOUT)
        j = _check(r, "Gemini")
        out = "".join(p.get("text", "") for p in (j.get("candidates") or [{}])[0].get("content", {}).get("parts", []))
    elif provider == "openai":
        model = cfg.get("openai_model") or "gpt-4o-mini"
        msgs = [{"role": "system", "content": system}] + [{"role": r, "content": t} for r, t in history]
        if image:
            msgs.append({"role": "user", "content": [{"type": "text", "text": text}, {"type": "image_url", "image_url": {
                "url": "data:image/png;base64," + base64.b64encode(image).decode()}}]})
        else:
            msgs.append({"role": "user", "content": text})
        r = requests.post("https://api.openai.com/v1/chat/completions", headers={"Authorization": f"Bearer {key}"},
                          json={"model": model, "messages": msgs, "max_tokens": max_tokens, "temperature": 0.8}, timeout=TIMEOUT)
        out = _check(r, "OpenAI")["choices"][0]["message"]["content"]
    elif provider == "claude":
        model = cfg.get("claude_model") or "claude-haiku-5-5"
        msgs = [{"role": r, "content": t} for r, t in history]
        if image:
            msgs.append({"role": "user", "content": [{"type": "image", "source": {"type": "base64", "media_type": "image/png",
                                                                                   "data": base64.b64encode(image).decode()}},
                                                     {"type": "text", "text": text}]})
        else:
            msgs.append({"role": "user", "content": text})
        r = requests.post("https://api.anthropic.com/v1/messages",
                          headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                          json={"model": model, "system": system, "messages": msgs, "max_tokens": max_tokens}, timeout=TIMEOUT)
        out = "".join(b.get("text", "") for b in _check(r, "Claude").get("content", []))
    else:
        raise ValueError(provider)
    out = (out or "").strip()
    if not out:
        raise RuntimeError(f"{NAMES[provider]}: empty answer")
    return out
