"""Online AI = Premium only. The app never holds an AI key (so none can be stolen from a PC or phone): every online question goes to the
Earthvasi server, which checks the Premium licence and the daily fair-use limit and talks to the AI service with a key that stays on the server.

Free users get the everyday features and the local (offline) model. A failing provider is "cooled down" for a minute so the next question
skips straight to the offline model instead of making the user wait again.
"""
import base64
import logging
import time
from typing import Dict, List, Optional, Tuple

log = logging.getLogger(__name__)
COOLDOWN = 60.0
_down_until: Dict[str, float] = {}
NAMES = {"gemini": "EarthVasi"}


def available(cfg: dict) -> List[str]:
    from . import license as lic
    return ["gemini"] if lic.managed(cfg) else []


def usable(cfg: dict) -> List[str]:
    now = time.time()
    return [p for p in available(cfg) if _down_until.get(p, 0) <= now]


def mark_down(p: str) -> None:
    _down_until[p] = time.time() + COOLDOWN


def reset() -> None:
    _down_until.clear()


def ask(provider: str, cfg: dict, system: str, history: List[Tuple[str, str]], text: str,
        image: Optional[bytes] = None, max_tokens: int = 600) -> str:
    from . import license as lic
    if provider != "gemini" or not lic.managed(cfg):
        raise RuntimeError("Smart AI Premium me hai. 'plans' bolo.")
    contents = [{"role": "user" if r == "user" else "model", "parts": [{"text": t}]} for r, t in history]
    parts = [{"text": text}]
    if image:
        parts.insert(0, {"inline_data": {"mime_type": "image/png", "data": base64.b64encode(image).decode()}})
    contents.append({"role": "user", "parts": parts})
    j = lic.managed_call(cfg, "agent" if image else "chat", {"systemInstruction": {"parts": [{"text": system}]}, "contents": contents,
                                                             "generationConfig": {"temperature": 0.8, "maxOutputTokens": max_tokens}})
    out = "".join(p.get("text", "") for p in (j.get("candidates") or [{}])[0].get("content", {}).get("parts", [])).strip()
    if not out:
        raise RuntimeError("AI se khaali jawab aaya")
    return out
