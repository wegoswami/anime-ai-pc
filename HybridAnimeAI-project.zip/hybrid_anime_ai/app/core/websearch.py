"""Live web search via DuckDuckGo's HTML endpoint (no API key). Used only when the user asks for fresh information."""
import html
import logging
import re
from typing import List, Tuple
from urllib.parse import parse_qs, unquote, urlparse

import requests

log = logging.getLogger(__name__)
WEB_Q = re.compile(r"\b(?:search (?:the )?(?:web|internet|online) for|web search|google (?:karke|par) (?:batao|dhundo)|internet (?:par|se) (?:dhundo|batao|search)|latest news|aaj ki (?:khabar|news)|news (?:about|on))\b", re.I)


def _clean(s: str) -> str:
    return html.unescape(re.sub(r"<[^>]+>", "", s)).strip()


def search(query: str, n: int = 5, timeout: float = 6.0) -> List[Tuple[str, str, str]]:
    """Returns [(title, snippet, url)]; empty list on any failure (caller falls back gracefully)."""
    try:
        r = requests.post("https://html.duckduckgo.com/html/", data={"q": query}, timeout=timeout,
                          headers={"User-Agent": "Mozilla/5.0 (EarthvasiAI)"})
        r.raise_for_status()
    except Exception:  # noqa: BLE001
        log.info("web search failed")
        return []
    out = []
    for m in re.finditer(r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>.*?class="result__snippet"[^>]*>(.*?)</a>', r.text, re.S):
        url = m.group(1)
        q = parse_qs(urlparse(url).query).get("uddg")
        out.append((_clean(m.group(2)), _clean(m.group(3)), unquote(q[0]) if q else url))
        if len(out) >= n:
            break
    return out


def context_for(query: str) -> str:
    q = WEB_Q.sub("", query).strip(" ?.") or query
    res = search(q)
    if not res:
        return ""
    return "Live web results (cite naturally, do not read URLs aloud):\n" + "\n".join(f"- {t}: {s}" for t, s, _u in res)
