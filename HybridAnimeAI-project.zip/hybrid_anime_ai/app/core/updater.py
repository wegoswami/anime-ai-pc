"""Over-the-air updater (app side): check manifest -> stream download -> verify -> stage -> hand off.

version.json format (host it over HTTPS):
{
  "version": "1.0.1",
  "url": "https://your-domain.com/hybrid-anime-ai/HybridAnimeAI-1.0.1.zip",
  "sha256": "<hex sha256 of the zip>",
  "size": 123456789,
  "notes": "What's new"
}
The zip contains the contents of dist/HybridAnimeAI/ (HybridAnimeAI.exe, _internal/, updater.exe ...).
"""
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

import requests

from .. import build_info
from ..paths import data_dir, install_dir, is_frozen, updater_helper_path, updates_dir
from ..version import APP_ID, APP_VERSION, UPDATE_MANIFEST_URL, USER_AGENT

log = logging.getLogger(__name__)


class UpdateError(Exception):
    pass


@dataclass
class UpdateInfo:
    version: str
    url: str
    sha256: str
    size: int = 0
    notes: str = ""


def parse_version(v: str) -> tuple:
    nums = [int(x) for x in re.findall(r"\d+", v)]
    return tuple(nums + [0] * (4 - len(nums)))


def updates_enabled() -> bool:
    return is_frozen() or os.environ.get("HAA_FORCE_UPDATE") == "1"


def manifest_url(override: str = "") -> str:
    """Where to look for updates: explicit config > the GitHub repo this build came from > legacy placeholder."""
    if override.strip():
        return override.strip()
    if build_info.GITHUB_REPO:
        return f"https://github.com/{build_info.GITHUB_REPO}/releases/latest/download/version.json"
    return UPDATE_MANIFEST_URL


def fetch_manifest(override: str = "") -> dict:
    r = requests.get(manifest_url(override), timeout=8, headers={"User-Agent": USER_AGENT,
                                                              "Cache-Control": "no-cache"})
    r.raise_for_status()
    return r.json()


def check_for_update(override: str = "") -> Optional[UpdateInfo]:
    """Return UpdateInfo if the server has a newer version, else None. Raises on bad data."""
    m = fetch_manifest(override)
    version, url, sha = str(m.get("version", "")), str(m.get("url", "")), str(m.get("sha256", ""))
    if not version or not url or not re.fullmatch(r"[0-9a-fA-F]{64}", sha):
        raise UpdateError("Update manifest is incomplete (version, url, sha256 are required).")
    if not url.lower().startswith("https://"):
        raise UpdateError("Update package must be served over HTTPS.")
    if parse_version(version) <= parse_version(APP_VERSION):
        return None
    return UpdateInfo(version, url, sha.lower(), int(m.get("size") or 0), str(m.get("notes", "")))


def download_update(info: UpdateInfo, progress: Callable[[int, int], None]) -> Path:
    """Stream the package in chunks, hashing as we go. Deletes the file on hash mismatch."""
    final = updates_dir() / f"update-{info.version}.zip"
    part = final.with_suffix(".zip.part")
    digest = hashlib.sha256()
    with requests.get(info.url, stream=True, timeout=(8, 30),
                      headers={"User-Agent": USER_AGENT}) as r:
        r.raise_for_status()
        total = int(r.headers.get("Content-Length") or info.size or 0)
        done = 0
        with open(part, "wb") as f:
            for chunk in r.iter_content(chunk_size=256 * 1024):
                if not chunk:
                    continue
                f.write(chunk)
                digest.update(chunk)
                done += len(chunk)
                progress(done, total)
    if digest.hexdigest().lower() != info.sha256:
        part.unlink(missing_ok=True)
        raise UpdateError("Downloaded update failed its integrity check.")
    os.replace(part, final)
    return final


def expected_exe_name() -> str:
    return Path(sys.executable).name if is_frozen() else f"{APP_ID}.exe"


def stage_update(zip_path: Path, info: UpdateInfo) -> Path:
    """Unpack into a staging folder (with zip-slip protection) and return the folder to copy from."""
    staging = updates_dir() / f"staging-{info.version}"
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(parents=True)
    root = staging.resolve()
    with zipfile.ZipFile(zip_path) as z:
        for member in z.infolist():
            dest = (staging / member.filename).resolve()
            if dest != root and root not in dest.parents:
                raise UpdateError("Update package contains an unsafe path.")
        z.extractall(staging)
    zip_path.unlink(missing_ok=True)

    content = staging
    entries = list(staging.iterdir())
    if len(entries) == 1 and entries[0].is_dir():
        content = entries[0]
    if is_frozen() and not (content / expected_exe_name()).exists():
        raise UpdateError(f"Update package does not contain {expected_exe_name()}.")
    return content


def launch_helper(content_dir: Path) -> None:
    """Start the detached helper from a temp copy (so it may overwrite updater.exe too)."""
    helper = updater_helper_path()
    if not helper.exists():
        raise UpdateError("updater.exe is missing from the installation.")
    tmp = Path(tempfile.mkdtemp(prefix="haa-upd-"))
    run_helper = tmp / helper.name
    shutil.copy2(helper, run_helper)
    cmd = [str(run_helper)] if is_frozen() else [sys.executable, str(run_helper)]
    cmd += ["--pid", str(os.getpid()),
            "--source", str(content_dir),
            "--target", str(install_dir()),
            "--exe", expected_exe_name(),
            "--log", str(data_dir() / "updater.log"),
            "--cleanup", str(content_dir if content_dir.parent == updates_dir() else content_dir.parent)]
    flags = 0
    if sys.platform == "win32":
        flags = (getattr(subprocess, "DETACHED_PROCESS", 0)
                 | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                 | getattr(subprocess, "CREATE_NO_WINDOW", 0))
    subprocess.Popen(cmd, creationflags=flags, close_fds=True, cwd=str(tmp),
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    log.info("Updater helper launched: %s", cmd)


# ----------------------------------------------------------------------------- pending / offline updates
def _pending_file() -> Path:
    return updates_dir() / "pending.json"


def save_pending(content: Path, version: str) -> None:
    _pending_file().write_text(json.dumps({"dir": str(content), "version": version}), encoding="utf-8")


def load_pending() -> Optional[tuple]:
    """(content_dir, version) of an update that was downloaded earlier but not installed yet."""
    try:
        d = json.loads(_pending_file().read_text(encoding="utf-8"))
        content = Path(d["dir"])
        if content.is_dir() and parse_version(d["version"]) > parse_version(APP_VERSION):
            return content, str(d["version"])
    except (OSError, ValueError, KeyError):
        pass
    _pending_file().unlink(missing_ok=True)
    return None


def clear_pending() -> None:
    _pending_file().unlink(missing_ok=True)


def inbox_dir() -> Path:
    d = updates_dir() / "inbox"
    d.mkdir(parents=True, exist_ok=True)
    return d


def version_from_name(name: str) -> str:
    m = re.search(r"(\d+\.\d+(?:\.\d+){0,2})", name)
    return m.group(1) if m else ""


def stage_local_zip(zip_path: Path, copy: bool = True) -> tuple:
    """Offline update from a zip the user already has (USB stick, LAN share, inbox folder).

    Returns (content_dir, version). Raises UpdateError when the package is unusable or not newer.
    """
    zip_path = Path(zip_path)
    if not zipfile.is_zipfile(zip_path):
        raise UpdateError("That file is not a valid update package (.zip).")
    version = version_from_name(zip_path.name) or "0.0.0"
    if version != "0.0.0" and parse_version(version) <= parse_version(APP_VERSION):
        raise UpdateError(f"Version {version} is not newer than the installed v{APP_VERSION}.")
    work = updates_dir() / f"local-{int(time.time())}.zip"
    shutil.copy2(zip_path, work) if copy else shutil.move(str(zip_path), work)
    info = UpdateInfo(version if version != "0.0.0" else "local", "", "")
    return stage_update(work, info), info.version


def find_inbox_update() -> Optional[Path]:
    """Newest valid-looking zip dropped into the inbox folder, if it is newer than what's installed."""
    best = None
    for f in inbox_dir().glob("*.zip"):
        v = version_from_name(f.name)
        if v and parse_version(v) > parse_version(APP_VERSION):
            if best is None or parse_version(v) > parse_version(version_from_name(best.name)):
                best = f
    return best
