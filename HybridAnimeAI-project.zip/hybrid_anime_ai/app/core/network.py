"""Low-level connectivity probe used by the hybrid online/offline switcher.

Many networks block raw DNS (port 53) but allow normal HTTPS, so the probe tries several targets, including
port 443 on well-known hosts, in parallel. Any single success means "online".
"""
import socket
import threading

_PROBES = (("www.google.com", 443), ("generativelanguage.googleapis.com", 443), ("1.1.1.1", 443), ("8.8.8.8", 53), ("1.1.1.1", 53))


def is_online(timeout: float = 2.5) -> bool:
    ok = threading.Event()
    left = [len(_PROBES)]
    lock = threading.Lock()
    done = threading.Event()

    def probe(host: str, port: int) -> None:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                ok.set()
                done.set()
        except OSError:
            pass
        finally:
            with lock:
                left[0] -= 1
                if left[0] == 0:
                    done.set()

    for h, p in _PROBES:
        threading.Thread(target=probe, args=(h, p), daemon=True).start()
    done.wait(timeout + 1.0)
    return ok.is_set()
