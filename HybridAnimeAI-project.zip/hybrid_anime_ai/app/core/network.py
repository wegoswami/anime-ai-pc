"""Low-level connectivity probe used by the hybrid online/offline switcher."""
import socket

_PROBES = (("8.8.8.8", 53), ("1.1.1.1", 53))


def is_online(timeout: float = 2.0) -> bool:
    """Open a raw TCP socket to a public DNS server. No HTTP, no payload."""
    for host, port in _PROBES:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except OSError:
            continue
    return False
