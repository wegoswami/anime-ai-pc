"""Health check: tests every feature for real and says exactly what to fix (written as a report the user can send)."""
import os
import sys
from typing import Callable, List, Tuple

Result = Tuple[object, str, str, str]       # ok(True/False/None), name, detail, fix


def run(cfg: dict, version: str, hotkey_active: bool, plugins_info: str, bridge_port_free: Callable[[], bool]) -> List[Result]:
    out: List[Result] = []
    add = lambda ok, name, detail="", fix="": out.append((ok, name, detail, fix))
    from . import hardware, ollama_manager, providers
    from .network import is_online

    net = is_online(4.0)
    add(net, "Internet", "ok" if net else "nahi mil raha", "Wi-Fi/LAN check karo, VPN band karke dekho.")
    keys = providers.available(cfg)
    if not keys:
        add(None, "Premium AI", "Free plan (offline)", "Smart online AI ke liye 'plans' bolo.")
    for p in keys:
        if not net:
            add(None, "Premium AI", "internet ke bina test nahi ho sakta")
            continue
        try:
            providers.ask(p, cfg, "Reply with OK", [], "OK?", None, 8)
            add(True, f"{p} key", "chal rahi hai")
        except Exception as exc:  # noqa: BLE001
            s = str(exc)
            why = "key galat/reject" if any(x in s for x in ("400", "401", "403")) else "limit khatam (429)" if "429" in s else "server/network error"
            add(False, f"{p} key", why, "Settings → AI me key ya limit check karo.")
    try:
        model = hardware.effective_model(cfg)
        up = ollama_manager.find_ollama() is not None
        add(up, "Offline AI (Ollama)", "installed" if up else "installed nahi", "Settings → AI → 'Offline dimaag setup' dabao (ek baar).")
        if up:
            add(ollama_manager.model_present(model), f"Offline model {model}", "taiyaar" if ollama_manager.model_present(model) else "download nahi hua", "Settings → AI → Offline setup chalao.")
    except Exception as exc:  # noqa: BLE001
        add(False, "Offline AI", str(exc)[:80], "Settings → AI → Offline setup.")
    try:
        import sounddevice as sd
        has_in = any(d.get("max_input_channels", 0) > 0 for d in sd.query_devices())
        add(has_in, "Microphone", "mila" if has_in else "koi mic nahi mila", "Windows Settings → Privacy → Microphone me app ko allow karo.")
    except Exception:  # noqa: BLE001
        add(False, "Microphone", "audio library nahi chali", "App dobara install karo.")
    try:
        import faster_whisper  # noqa: F401
        add(True, "Offline speech-to-text", "ok")
    except Exception:  # noqa: BLE001
        add(False, "Offline speech-to-text", "nahi mila", "Settings → Voice me online STT use karo ya app dobara install karo.")
    if sys.platform == "win32":
        try:
            from . import recorder
            why = recorder.WinBackend.available()
            add(not why, "Call recording", "ok" if not why else why, "App dobara install karo (soundcard + ffmpeg chahiye).")
        except Exception as exc:  # noqa: BLE001
            add(False, "Call recording", str(exc)[:80], "App dobara install karo.")
        try:
            import pyttsx3
            e = pyttsx3.init()
            n = len(e.getProperty("voices") or [])
            add(n > 0, "Awaaz (TTS)", f"{n} voices", "Windows Settings → Speech me ek voice install karo.")
        except Exception:  # noqa: BLE001
            add(False, "Awaaz (TTS)", "engine start nahi hua", "Windows Settings → Time & Language → Speech.")
        try:
            from PIL import ImageGrab
            ImageGrab.grab().size
            add(True, "Screen capture", "ok")
        except Exception:  # noqa: BLE001
            add(False, "Screen capture", "nahi hua", "Kisi security software ne block kiya ho sakta hai.")
    if cfg.get("hotkey"):
        add(hotkey_active or sys.platform != "win32", f"Hotkey ({cfg.get('hotkey')})", "active" if hotkey_active else "band/busy", "Settings me doosri key chuno (kisi aur app ne ye le li ho sakti hai).")
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    add(os.access(docs, os.W_OK), "Documents folder likhna", "ok" if os.access(docs, os.W_OK) else "permission nahi", "Folder ki permission check karo (OneDrive/antivirus).")
    add(True, "Plugins", plugins_info)
    add(bridge_port_free(), "Phone link port 8765", "free" if bridge_port_free() else "busy", "Dusra program port 8765 use kar raha hai.")
    if net:
        try:
            import requests
            r = requests.get("https://api.github.com", timeout=5)
            add(r.status_code < 500, "Update server (GitHub)", "ok", "")
        except Exception:  # noqa: BLE001
            add(False, "Update server (GitHub)", "nahi pahunch pa raha", "Internet/Firewall check karo.")
    add(None, "Version", version)
    return out


def format_report(results: List[Result]) -> str:
    lines = []
    for ok, name, detail, fix in results:
        icon = "OK  " if ok is True else "FAIL" if ok is False else "--  "
        lines.append(f"[{icon}] {name}: {detail}" + (f"\n        -> {fix}" if ok is False and fix else ""))
    bad = sum(1 for r in results if r[0] is False)
    return ("EarthVasi - Health report\n" + "=" * 40 + "\n" + "\n".join(lines) + f"\n\n{bad} cheezein theek karni hain." if bad else
            "EarthVasi - Health report\n" + "=" * 40 + "\n" + "\n".join(lines) + "\n\nSab theek hai.")


def log_tail(path, lines: int = 25) -> str:
    """Last warnings/errors from app.log, appended to the health report so problems can be diagnosed from one paste."""
    try:
        rows = [r.rstrip() for r in open(path, encoding="utf-8", errors="replace").read().splitlines()]
        bad = [r for r in rows if " WARNING " in r or " ERROR " in r or "Traceback" in r or r.startswith("  File") or r[:1].isalpha() and "Error" in r[:60]][-lines:]
        return "\n\nRecent errors from app.log:\n" + ("\n".join(bad) if bad else "none")
    except OSError:
        return "\n\nRecent errors from app.log: (no log yet)"
