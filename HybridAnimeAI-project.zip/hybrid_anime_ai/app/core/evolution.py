"""Self-evolving brain: a private "soul profile", tone mirroring, and safe auto-skill creation.

* user_soul_profile.json (in the user's data folder, never uploaded) stores name, language/tone, likes, dislikes,
  routines and projects. Every REFLECT_EVERY interactions a background reflection updates it (rule based, and an
  optional one-line style summary from the LLM) and `style_prompt()` feeds it back into the system prompt, so the
  assistant slowly mirrors how the user talks.
* Auto-skills: when the same command keeps repeating, or the user says "skill banao: <what>", the LLM drafts a small
  plugin. The draft is VALIDATED (AST allow-list, no file/network/exec access, must run), then shown to the user and
  only saved into the plugins folder after they say "yes". Nothing the AI writes ever runs without that confirmation.
"""
import ast
import json
import logging
import re
import threading
import time
from collections import Counter
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)
REFLECT_EVERY = 10
REPEAT_AT = 3

DEFAULT_PROFILE = {"name": "", "language": "auto", "tone": "", "likes": [], "dislikes": [], "routines": [],
                   "projects": [], "style": {"avg_words": 0, "emoji": False, "hinglish": 0.0, "formal": 0.0},
                   "style_note": "", "interactions": 0, "updated": 0}

_HINGLISH = set("hai hain kya nahi nhi kr kro karo mujhe mera meri tum aap bhai yaar acha accha theek thik kaise kaha "
                "kab bolo batao dikhao khol chalu band abhi ek aur bhi toh".split())
_EMOJI = re.compile("[\U0001F300-\U0001FAFF\u2600-\u27BF]")
_PROJECT = re.compile(r"\b(?:i am working on|i'm working on|mai(?:n)? .{2,30}? pe kaam kar(?:ta|ti)? (?:hoon|hu)|mera project)\s*(.{3,80})", re.I)


class Soul:
    def __init__(self, path):
        self.path = Path(path)
        self.lock = threading.Lock()
        self.data = json.loads(json.dumps(DEFAULT_PROFILE))
        self.recent: List[str] = []
        try:
            if self.path.exists():
                loaded = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    self.data.update(loaded)
        except Exception:  # noqa: BLE001 - corrupt file: start fresh, never crash
            log.warning("soul profile unreadable, starting fresh")

    def save(self) -> None:
        try:
            with self.lock:
                self.data["updated"] = int(time.time())
                tmp = self.path.with_suffix(".tmp")
                tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
                tmp.replace(self.path)
        except Exception:  # noqa: BLE001
            log.exception("could not save soul profile")

    def _push(self, key: str, value: str, cap: int = 12) -> None:
        value = value.strip(" .,!?")[:60]
        if value and value.lower() not in [x.lower() for x in self.data[key]]:
            self.data[key] = (self.data[key] + [value])[-cap:]

    def observe(self, text: str) -> bool:
        """Call for every user message. Returns True when a reflection is due."""
        from .memory import FACT_PATTERNS
        self.recent = (self.recent + [text])[-30:]
        self.data["interactions"] = int(self.data.get("interactions", 0)) + 1
        for kind, pat in FACT_PATTERNS:
            m = pat.search(text)
            if not m:
                continue
            val = next((g for g in m.groups() if g), m.group(0))
            if kind == "name":
                self.data["name"] = val.strip().title()
            elif kind in ("likes", "dislikes", "routine"):
                self._push({"routine": "routines"}.get(kind, kind), val)
        pm = _PROJECT.search(text)
        if pm:
            self._push("projects", pm.group(1))
        return self.data["interactions"] % REFLECT_EVERY == 0

    def reflect(self, summarize: Optional[Callable[[str], str]] = None) -> None:
        """Update the style numbers from recent messages; optionally ask the LLM for a one-line style note."""
        msgs = self.recent[-20:]
        if not msgs:
            return
        words = [w for m in msgs for w in re.findall(r"[\w']+", m.lower())]
        n = max(1, len(msgs))
        hing = sum(1 for w in words if w in _HINGLISH) / max(1, len(words))
        self.data["style"] = {
            "avg_words": round(len(words) / n, 1), "emoji": any(_EMOJI.search(m) for m in msgs),
            "hinglish": round(hing, 2),
            "formal": round(sum(1 for m in msgs if re.search(r"\b(please|kindly|could you|kripya)\b", m, re.I)) / n, 2)}
        if hing > 0.12:
            self.data["language"] = "hinglish"
        elif sum(1 for m in msgs if re.search("[\u0900-\u097F]", m)) > n / 2:
            self.data["language"] = "hi"
        if summarize:
            try:
                note = summarize("Describe in ONE short sentence how this user talks (tone, length, language mix) "
                                 "so an assistant can mirror it. Messages:\n" + "\n".join(msgs[-12:]))
                if note:
                    self.data["style_note"] = note.strip()[:200]
            except Exception:  # noqa: BLE001 - offline / provider down: keep the rule-based profile
                log.info("style summary skipped")
        self.save()

    def style_prompt(self) -> str:
        d, s = self.data, self.data.get("style", {})
        bits = []
        if d.get("name"):
            bits.append(f"The user's name is {d['name']}.")
        if d.get("likes"):
            bits.append("They like: " + ", ".join(d["likes"][-5:]) + ".")
        if d.get("dislikes"):
            bits.append("They dislike: " + ", ".join(d["dislikes"][-4:]) + ".")
        if d.get("projects"):
            bits.append("Ongoing projects: " + "; ".join(d["projects"][-3:]) + ".")
        if d.get("routines"):
            bits.append("Routines: " + "; ".join(d["routines"][-3:]) + ".")
        if s.get("avg_words"):
            bits.append("They write about %d words per message, so keep replies %s." % (
                s["avg_words"], "very short" if s["avg_words"] < 6 else "short" if s["avg_words"] < 15 else "a bit fuller"))
        if s.get("emoji"):
            bits.append("They use emojis, so a light playful tone suits them.")
        if d.get("style_note"):
            bits.append("Mirror their style: " + d["style_note"])
        return (" ".join(bits) + " ") if bits else ""

    def forget(self) -> None:
        self.data = json.loads(json.dumps(DEFAULT_PROFILE))
        self.save()


# ---------------------------------------------------------------------------------------------- auto-skills
ALLOWED_IMPORTS = {"random", "json", "datetime", "math", "re", "string", "textwrap", "statistics", "calendar", "time",
                   "urllib.parse", "html", "base64", "hashlib", "collections", "itertools", "functools"}
BANNED_NAMES = {"eval", "exec", "compile", "open", "__import__", "globals", "locals", "vars", "input", "breakpoint",
                "getattr", "setattr", "delattr", "memoryview", "exit", "quit"}


def validate_skill(code: str) -> Tuple[bool, str]:
    """Static safety check for AI-written plugin code. Returns (ok, reason)."""
    if len(code) > 8000:
        return False, "too long"
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        return False, f"syntax error: {exc.msg}"
    has_run = False
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name not in ALLOWED_IMPORTS:
                    return False, f"import '{a.name}' not allowed"
        elif isinstance(node, ast.ImportFrom):
            if (node.module or "") not in ALLOWED_IMPORTS or node.level:
                return False, f"import from '{node.module}' not allowed"
        elif isinstance(node, ast.Name) and node.id in BANNED_NAMES:
            return False, f"'{node.id}' not allowed"
        elif isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            return False, "dunder attribute access not allowed"
        elif isinstance(node, ast.FunctionDef) and node.name == "run":
            has_run = True
    if not has_run:
        return False, "needs a run(text, ctx) function"
    for need in ("NAME", "TRIGGERS"):
        if not any(isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == need for t in n.targets)
                   for n in tree.body):
            return False, f"needs {need}"
    return True, "ok"


class _FakeCtx:
    lang = "en"
    cfg: dict = {}

    def say(self, *_a): pass
    def open_url(self, *_a): pass
    def remember(self, *_a): pass
    def search_memory(self, *_a): return []
    def run_command(self, *_a): return None


def dry_run(code: str, sample: str) -> Tuple[bool, str]:
    """Execute the draft once with a fake context and a short timeout (in a thread; the AST check already blocked
    file/network/exec access)."""
    out: Dict[str, object] = {}

    def work():
        try:
            ns: dict = {}
            ns = {"__builtins__": __builtins__}
            exec(compile(code, "<auto_skill>", "exec"), ns)  # noqa: S102 - validated
            out["r"] = ns["run"](sample, _FakeCtx())
        except Exception as exc:  # noqa: BLE001
            out["e"] = f"{type(exc).__name__}: {exc}"

    t = threading.Thread(target=work, daemon=True)
    t.start()
    t.join(3.0)
    if t.is_alive():
        return False, "took too long"
    if "e" in out:
        return False, str(out["e"])
    return True, str(out.get("r"))


SKILL_PROMPT = (
    "Write ONE small Python plugin file. Rules: define NAME = '...', TRIGGERS = [regex strings], and "
    "def run(text, ctx): returning a short reply string. Allowed imports only: random, json, datetime, math, re, "
    "string, textwrap, statistics, calendar, time, collections, itertools. No file access, no network, no eval/exec/"
    "open, no dunder attributes. ctx offers ctx.say(t), ctx.open_url(u), ctx.run_command('open notepad'). "
    "Output ONLY the code, no explanation, no markdown fences.\nTask: ")


class AutoSkills:
    """Counts repeated commands, drafts skills, validates them, and installs after confirmation."""

    def __init__(self, plugins_folder, llm: Callable[[str], str], on_installed: Callable[[], None]):
        self.folder = Path(plugins_folder)
        self.llm = llm
        self.on_installed = on_installed
        self.counts: Counter = Counter()
        self.offered: set = set()
        self.staged: Optional[Tuple[str, str, str]] = None        # (filename, code, description)

    @staticmethod
    def _norm(text: str) -> str:
        return re.sub(r"\s+", " ", re.sub(r"\d+", "#", text.lower())).strip()

    def watch(self, text: str, handled_by_system: bool) -> Optional[str]:
        """Call for every command. Returns an offer message the 3rd time a command repeats."""
        if not handled_by_system or len(text) < 6:
            return None
        k = self._norm(text)
        self.counts[k] += 1
        if self.counts[k] >= REPEAT_AT and k not in self.offered:
            self.offered.add(k)
            return (f"Tum ye kaafi baar bol chuke ho (“{text[:50]}”). Kya main iske liye ek chhoti skill bana doon? "
                    f"Bolo: skill banao {text[:60]}")
        return None

    def draft(self, description: str) -> str:
        try:
            raw = self.llm(SKILL_PROMPT + description)
        except Exception:  # noqa: BLE001
            return "Abhi skill nahi bana paayi (AI available nahi hai). Thodi der baad try karo."
        code = re.sub(r"^```(?:python)?\s*|\s*```$", "", (raw or "").strip(), flags=re.M).strip()
        ok, why = validate_skill(code)
        if ok:
            ns: dict = {}
            try:
                ns = {"__builtins__": __builtins__}
                exec(compile(code, "<chk>", "exec"), ns)  # noqa: S102 - validated above
                sample = (ns.get("TRIGGERS") or ["test"])[0]
                ok, why = dry_run(code, re.sub(r"\\[bwds]|[\^\$\\?]", "", str(sample)) or "test")
            except Exception as exc:  # noqa: BLE001
                ok, why = False, str(exc)
        if not ok:
            return f"Skill safe/valid nahi thi ({why}), isliye install nahi ki."
        slug = re.sub(r"[^a-z0-9]+", "_", description.lower())[:24].strip("_") or "skill"
        self.staged = (f"auto_{slug}.py", code, description)
        return (f"Skill taiyaar hai: “{description[:60]}”. Safe check pass ho gaya. Install karun? “yes” ya “no” bolo. "
                f"(Ye sirf is PC par rahegi.)")

    def handle_command(self, text: str) -> Optional[str]:
        t = text.strip().lower()
        m = re.match(r"^(?:skill banao|make a skill|create a skill|new skill)\s*[:\-]?\s*(.{4,200})$", text.strip(), re.I)
        if m:
            return self.draft(m.group(1).strip())
        if self.staged and re.match(r"^(yes|haan|han|ha|ok|install|y)\b", t):
            fn, code, _d = self.staged
            self.staged = None
            try:
                self.folder.mkdir(parents=True, exist_ok=True)
                (self.folder / fn).write_text(code, encoding="utf-8")
                self.on_installed()
                return "Nayi skill install ho gayi! ✅ Ab use bolkar try karo."
            except OSError:
                return "Skill save nahi ho paayi."
        if self.staged and re.match(r"^(no|nahi|nhi|cancel|n)\b", t):
            self.staged = None
            return "Theek hai, skill nahi banayi."
        return None
