"""Global hotkey (default Alt+Space) on Windows via RegisterHotKey. Silent no-op elsewhere or if the key is taken."""
import logging
import sys

log = logging.getLogger(__name__)
MODS = {"alt": 0x1, "ctrl": 0x2, "shift": 0x4, "win": 0x8}
VK = {"space": 0x20, "enter": 0x0D, "tab": 0x09}


def parse(spec: str):
    parts = [p.strip().lower() for p in (spec or "").replace("+", " ").split() if p.strip()]
    if not parts:
        return None
    mods, key = 0, None
    for p in parts:
        if p in MODS:
            mods |= MODS[p]
        elif p in VK:
            key = VK[p]
        elif len(p) == 1 and p.isalnum():
            key = ord(p.upper())
        elif p.startswith("f") and p[1:].isdigit() and 1 <= int(p[1:]) <= 12:
            key = 0x70 + int(p[1:]) - 1
    return (mods | 0x4000, key) if key else None       # 0x4000 = no auto-repeat


def install(app, spec: str, callback) -> bool:        # sets install.active when registered
    """Returns True when the hotkey is active. Never raises."""
    if not sys.platform.startswith("win"):
        return False
    try:
        import ctypes
        from ctypes import wintypes
        from PyQt6.QtCore import QAbstractNativeEventFilter

        parsed = parse(spec)
        if not parsed:
            return False
        mods, vk = parsed
        if not ctypes.windll.user32.RegisterHotKey(None, 0xEA27, mods, vk):
            log.info("hotkey %s is used by another app", spec)
            return False

        class _Filter(QAbstractNativeEventFilter):
            def nativeEventFilter(self, event_type, message):  # noqa: N802
                try:
                    if event_type == b"windows_generic_MSG":
                        msg = wintypes.MSG.from_address(int(message))
                        if msg.message == 0x0312 and msg.wParam == 0xEA27:
                            callback()
                except Exception:  # noqa: BLE001
                    log.exception("hotkey handler failed")
                return False, 0

        flt = _Filter()
        app.installNativeEventFilter(flt)
        app._earth_hotkey_filter = flt                      # keep a reference alive
        install.active = True
        return True
    except Exception:  # noqa: BLE001
        log.exception("hotkey unavailable")
        return False
