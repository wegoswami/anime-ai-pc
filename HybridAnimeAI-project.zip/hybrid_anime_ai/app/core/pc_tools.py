"""Advanced PC control that works offline: files and folders, system info, volume level, brightness, screenshots,
clipboard, and document creation (Word/PDF/CSV/text). Everything file-related stays inside the user's home folder.
Destructive actions (delete) go to the Recycle Bin and always ask first.
"""
import datetime
import logging
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from typing import List, Optional

from .automation import IS_WIN, NO_WINDOW, has, _normalize, press_key

log = logging.getLogger(__name__)
FOLDERS = {"desktop": "Desktop", "downloads": "Downloads", "download": "Downloads", "documents": "Documents",
           "document": "Documents", "docs": "Documents", "pictures": "Pictures", "photos": "Pictures",
           "music": "Music", "videos": "Videos", "home": ""}
_FOLDER_WORDS = "|".join(sorted(FOLDERS, key=len, reverse=True))
_SKIP_DIRS = {"node_modules", ".git", "appdata", "__pycache__", "$recycle.bin"}


def home() -> Path:
    return Path(os.path.expanduser("~"))


def resolve_folder(word: str) -> Path:
    return home() / FOLDERS.get(word.lower().strip(), "")


def inside_home(p: Path) -> bool:
    try:
        p.resolve().relative_to(home().resolve())
        return True
    except ValueError:
        return False


def safe_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", name).strip(" .")
    return name[:80]


# ------------------------------------------------------------------------------------------- documents
def _xml(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def make_docx(path: Path, title: str, body: str) -> None:
    big = '<w:rPr><w:b/><w:sz w:val="36"/></w:rPr>'
    paras = [(big, title)] + [("", ln) for ln in body.splitlines() if ln.strip()]
    xml = "".join('<w:p><w:r>%s<w:t xml:space="preserve">%s</w:t></w:r></w:p>' % (fmt, _xml(txt)) for fmt, txt in paras)
    doc = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/'
           f'wordprocessingml/2006/main"><w:body>{xml}</w:body></w:document>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
        z.writestr("word/document.xml", doc)


def make_pdf(path: Path, title: str, body: str) -> None:
    """Plain-text PDF (Helvetica, Latin text). Non-Latin text is refused so we never write a broken PDF."""
    lines: List[str] = [title, ""]
    for ln in body.splitlines():
        while len(ln) > 90:
            cut = ln.rfind(" ", 0, 90) or 90
            lines.append(ln[:cut])
            ln = ln[cut:].lstrip()
        lines.append(ln)
    text = "\n".join(lines)
    if any(ord(c) > 255 for c in text):
        raise ValueError("non-latin")
    esc = lambda s: s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    per_page, pages = 48, []
    for i in range(0, len(lines), per_page):
        chunk = lines[i:i + per_page]
        stream = "BT /F1 11 Tf 50 790 Td 15 TL\n" + "\n".join(f"({esc(c)}) Tj T*" for c in chunk) + "\nET"
        pages.append(stream)
    objs = ["<< /Type /Catalog /Pages 2 0 R >>", None, "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"]
    kids = []
    for s in pages:
        objs.append(f"<< /Length {len(s.encode('latin-1'))} >>\nstream\n{s}\nendstream")
        cid = len(objs)
        objs.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents {cid} 0 R /Resources << /Font << /F1 3 0 R >> >> >>")
        kids.append(f"{len(objs)} 0 R")
    objs[1] = f"<< /Type /Pages /Kids [{' '.join(kids)}] /Count {len(kids)} >>"
    out, offs = bytearray(b"%PDF-1.4\n"), []
    for i, o in enumerate(objs, 1):
        offs.append(len(out))
        out += f"{i} 0 obj\n{o}\nendobj\n".encode("latin-1")
    x = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode() + b"".join(f"{o:010d} 00000 n \n".encode() for o in offs)
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{x}\n%%EOF\n".encode()
    path.write_bytes(bytes(out))


def make_csv(path: Path, title: str, body: str) -> None:
    rows = [ln for ln in body.splitlines() if ln.strip()]
    import csv
    with open(path, "w", newline="", encoding="utf-8-sig") as f:          # utf-8-sig: Excel shows Hindi correctly
        w = csv.writer(f)
        for r in rows:
            w.writerow([c.strip() for c in (r.split("|") if "|" in r else r.split(","))])


def create_document(kind: str, title: str, body: str, folder: Optional[Path] = None) -> Path:
    """kind: docx | pdf | csv | txt. Returns the file path. Raises ValueError for unsupported content."""
    folder = folder or (home() / "Documents" / "Earthvasi")
    folder.mkdir(parents=True, exist_ok=True)
    base = safe_name(title) or "document"
    p, n = folder / f"{base}.{kind}", 1
    while p.exists():
        n += 1
        p = folder / f"{base} ({n}).{kind}"
    {"docx": make_docx, "pdf": make_pdf, "csv": make_csv}.get(kind, lambda pp, t, b: pp.write_text(f"{t}\n\n{b}", encoding="utf-8"))(p, title, body)
    return p


def doc_request(text: str):
    """'word file banao: topic' -> (kind, topic) or None."""
    m = re.match(r"^\s*(?:please\s+)?(?:(?:create|make|write|generate|banao|bana do|likho)\s+(?:a |an |ek )?)?"
                 r"(word|docx|pdf|excel|csv|text|txt|notes?)\s*(?:file|document|doc)?\s*(?:banao|bana do|bnao|banado|create|make|likho)?"
                 r"\s*(?:on|about|for|ka|ki|ke liye|par|per|:|-)?\s*(.{4,300})$", text.strip(), re.I)
    if not m or not re.search(r"banao|bana do|bnao|banado|create|make|write|generate|likho", text, re.I):
        return None
    kind = {"word": "docx", "docx": "docx", "pdf": "pdf", "excel": "csv", "csv": "csv"}.get(m.group(1).lower(), "txt")
    return kind, m.group(2).strip(" :-")


# ------------------------------------------------------------------------------------------- the tool box
class PCTools:
    def __init__(self):
        self._pending = None           # ("delete", Path, expires)
        self.last_file: Optional[Path] = None

    def try_execute(self, text: str, lang: str = "en") -> Optional[str]:
        t = _normalize(text)
        if not t:
            return None
        now = time.time()
        if self._pending and now > self._pending[2]:
            self._pending = None
        if self._pending:
            if has(t, ["yes", "haan", "han", "ha", "kar do", "kardo", "confirm", "ok"]):
                return self._do_delete()
            if has(t, ["no", "nahi", "nhi", "cancel", "mat"]):
                self._pending = None
                return "Theek hai, kuch delete nahi kiya."
        for fn in (self._sysinfo, self._volume_level, self._brightness, self._screenshot, self._clipboard, self._files):
            r = fn(text, t)
            if r:
                return r
        return None

    # ---- system info
    def _sysinfo(self, raw: str, t: str) -> Optional[str]:
        if not re.search(r"system info|pc (?:ki )?(?:halat|status|info|health)|cpu (?:usage|info)|ram (?:kitni|kitna|usage|info|free|status)|memory kitni|disk space|storage kitna|\bip address\b|\bmy ip\b", t):
            return None
        parts = []
        try:
            total, used, free = shutil.disk_usage(home().anchor or "/")
            parts.append(f"Disk: {free // 2**30} GB free of {total // 2**30} GB")
        except OSError:
            pass
        try:
            if IS_WIN:
                import ctypes

                class MS(ctypes.Structure):
                    _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong), ("tot", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong),
                                ("a", ctypes.c_ulonglong), ("b", ctypes.c_ulonglong), ("c", ctypes.c_ulonglong), ("d", ctypes.c_ulonglong), ("e", ctypes.c_ulonglong)]
                ms = MS()
                ms.l = ctypes.sizeof(MS)
                ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms))
                parts.append(f"RAM: {ms.av / 2**30:.1f} GB free of {ms.tot / 2**30:.1f} GB ({ms.load}% used)")
            else:
                mi = dict(l.split(":", 1) for l in Path("/proc/meminfo").read_text().splitlines() if ":" in l)
                parts.append(f"RAM: {int(mi['MemAvailable'].split()[0]) / 2**20:.1f} GB free of {int(mi['MemTotal'].split()[0]) / 2**20:.1f} GB")
        except Exception:  # noqa: BLE001
            pass
        parts.append(f"CPU cores: {os.cpu_count()}")
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("10.255.255.255", 1))
                parts.append("IP: " + s.getsockname()[0])
        except OSError:
            pass
        return ". ".join(parts) + "."

    # ---- volume level / brightness
    def _volume_level(self, raw: str, t: str) -> Optional[str]:
        m = re.search(r"(?:volume|awaaz|awaz|आवाज़|आवाज)\D{0,14}(\d{1,3})\s*(?:%|percent|prati|par|pe|kar|kr|set)?", t) or \
            re.search(r"(\d{1,3})\s*(?:%|percent)\s*(?:volume|awaaz)", t)
        if not m or not re.search(r"volume|awaaz|awaz|आवाज़|आवाज", t):
            return None
        level = max(0, min(100, int(m.group(1))))
        if not IS_WIN:
            return "Ye sirf Windows par hota hai."
        press_key(0xAE, 50)                                  # each key press = 2%
        press_key(0xAF, level // 2)
        return f"Volume {level}% kar diya."

    def _brightness(self, raw: str, t: str) -> Optional[str]:
        m = re.search(r"(?:brightness|roshni|ujala|चमक)\D{0,14}(\d{1,3})", t)
        if not m:
            return None
        level = max(5, min(100, int(m.group(1))))
        if not IS_WIN:
            return "Ye sirf Windows laptop par hota hai."
        cmd = f"(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,{level})"
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, timeout=10, creationflags=NO_WINDOW)
            return f"Brightness {level}% kar di." if r.returncode == 0 else "Is screen par brightness badalna support nahi hai (desktop monitor?)."
        except Exception:  # noqa: BLE001
            return "Brightness nahi badal paayi."

    def _screenshot(self, raw: str, t: str) -> Optional[str]:
        if not re.search(r"screenshot (?:lo|le|save|kar)|take (?:a )?screenshot|screenshot save|screen capture", t):
            return None
        try:
            from PIL import ImageGrab
            folder = home() / "Pictures" / "Earthvasi"
            folder.mkdir(parents=True, exist_ok=True)
            p = folder / datetime.datetime.now().strftime("screenshot-%Y%m%d-%H%M%S.png")
            ImageGrab.grab().save(p)
            self.last_file = p
            return f"Screenshot save kar diya: Pictures/Earthvasi/{p.name}"
        except Exception:  # noqa: BLE001
            return "Screenshot nahi le paayi."

    def _clipboard(self, raw: str, t: str) -> Optional[str]:
        if not IS_WIN:
            return None
        if re.search(r"clipboard (?:padho|read|me kya|dikhao)|what(?:'s| is) (?:in )?(?:my )?clipboard", t):
            try:
                r = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-Clipboard -Raw"], capture_output=True, timeout=8, creationflags=NO_WINDOW)
                txt = r.stdout.decode("utf-8", "ignore").strip()
                return ("Clipboard me: " + txt[:300]) if txt else "Clipboard khali hai."
            except Exception:  # noqa: BLE001
                return "Clipboard nahi padh paayi."
        m = re.match(r"^\s*(?:copy|clipboard me copy kro|clipboard me rakh)\s+(?:this\s+)?[:\-]?\s*(.{2,300})$", raw, re.I)
        if m:
            try:
                subprocess.run(["clip"], input=m.group(1).encode("utf-16-le"), timeout=5, creationflags=NO_WINDOW)
                return "Clipboard me copy kar diya."
            except Exception:  # noqa: BLE001
                return "Copy nahi ho paaya."
        return None

    # ---- files and folders
    def _files(self, raw: str, t: str) -> Optional[str]:
        m = re.match(rf"^\s*(?:create|make|new|banao|bana do|nayi)\s+(?:a |an |ek |nayi |new )?folder\s+(.+?)(?:\s+(?:in|on|me|mein|par)\s+(?:my\s+)?({_FOLDER_WORDS}))?\s*$", raw, re.I) or \
            re.match(rf"^\s*folder\s+(.+?)\s+(?:banao|bana do|bnao)(?:\s+(?:in|on|me|mein|par)\s+({_FOLDER_WORDS}))?\s*$", raw, re.I)
        if m:
            base = resolve_folder(m.group(2) or "desktop")
            p = base / safe_name(m.group(1))
            if not safe_name(m.group(1)) or not inside_home(p):
                return "Folder ka naam samajh nahi aaya."
            try:
                p.mkdir(parents=True, exist_ok=True)
                return f"Folder bana diya: {p.name} ({base.name or 'Home'} me)."
            except OSError:
                return "Folder nahi ban paaya."
        m = re.match(rf"^\s*(?:create|make|new|banao|bana do)\s+(?:a |an |ek )?(?:text |txt |note )?file\s+(?:called |named )?([\w .\-]{{1,60}}?)(?:\s+(?:in|on|me|mein|par)\s+({_FOLDER_WORDS}))?(?:\s+(?:with|jisme|likho)\s+(.+))?\s*$", raw, re.I)
        if m:
            name = safe_name(m.group(1))
            name = name if "." in name else name + ".txt"
            p = resolve_folder(m.group(2) or "desktop") / name
            if not name or not inside_home(p):
                return "File ka naam samajh nahi aaya."
            try:
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(m.group(3) or "", encoding="utf-8")
                self.last_file = p
                return f"File bana di: {p.name}."
            except OSError:
                return "File nahi ban paayi."
        m = re.match(rf"^\s*(?:list|show|dikhao|dikha)\s+(?:my\s+)?(?:files?\s+(?:in|on|of)\s+)?({_FOLDER_WORDS})(?:\s+(?:files?|me kya hai))?\s*$", raw, re.I) or \
            re.match(rf"^\s*({_FOLDER_WORDS})\s+(?:me|mein)\s+kya\s+(?:hai|h)\s*$", raw, re.I)
        if m:
            d = resolve_folder(m.group(1))
            try:
                items = sorted(d.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True)[:8]
            except OSError:
                return "Wo folder nahi khul paaya."
            return (f"{d.name or 'Home'} me latest: " + ", ".join(i.name for i in items)) if items else "Folder khali hai."
        m = re.match(rf"^\s*(?:open|kholo|khol)\s+(?:my\s+)?({_FOLDER_WORDS})\s*(?:folder)?\s*$", raw, re.I)
        if m and IS_WIN:
            os.startfile(str(resolve_folder(m.group(1))))      # noqa: S606
            return f"{m.group(1).title()} folder khol diya."
        m = re.match(r"^\s*(?:find|search|dhundo|dhoondo|khojo)\s+(?:file|my file)\s+(.{2,60})$", raw, re.I)
        if m:
            return self._find(m.group(1).strip())
        m = re.match(rf"^\s*(?:delete|remove|hatao|mita do|mitao)\s+(?:file |folder )?(.{{2,60}}?)(?:\s+(?:from|in|se|me)\s+({_FOLDER_WORDS}))?\s*$", raw, re.I)
        if m and not re.match(r"(?:task|reminder|note|memory|plugin|profile|alarm|sab|everything|all|history)s?(?:\s|\d|$)", m.group(1).strip(), re.I):
            p = resolve_folder(m.group(2) or "desktop") / safe_name(m.group(1))
            if not inside_home(p) or not p.exists():
                return "Wo file ya folder mujhe mila nahi."
            self._pending = ("delete", p, time.time() + 20)
            return f"“{p.name}” ko Recycle Bin me bhej dun? 'haan' bolo (20 second me)."
        m = re.match(rf"^\s*(copy|move)\s+(.{{2,60}}?)\s+(?:to|ko)\s+({_FOLDER_WORDS})\s*$", raw, re.I)
        if m:
            src = self._locate(m.group(2))
            if not src:
                return "Wo file mujhe mili nahi."
            dst = resolve_folder(m.group(3)) / src.name
            try:
                (shutil.copy2 if m.group(1).lower() == "copy" else shutil.move)(str(src), str(dst)) if src.is_file() else \
                    (shutil.copytree if m.group(1).lower() == "copy" else shutil.move)(str(src), str(dst))
                return f"{src.name} {m.group(3)} me {'copy' if m.group(1).lower() == 'copy' else 'move'} ho gayi."
            except OSError:
                return "Ye nahi ho paaya."
        return None

    def _locate(self, name: str) -> Optional[Path]:
        name = safe_name(name).lower()
        for fd in ("Desktop", "Downloads", "Documents"):
            for p in (home() / fd).glob("*"):
                if p.name.lower() == name or p.stem.lower() == name:
                    return p
        return None

    def _find(self, query: str) -> str:
        q, hits, scanned = query.lower(), [], 0
        for root, dirs, files in os.walk(home()):
            dirs[:] = [d for d in dirs if d.lower() not in _SKIP_DIRS and not d.startswith(".")]
            if root[len(str(home())):].count(os.sep) > 4:
                dirs[:] = []
            for f in files:
                scanned += 1
                if q in f.lower():
                    hits.append(os.path.join(root, f))
            if len(hits) >= 5 or scanned > 40000:
                break
        if not hits:
            return "Is naam ki koi file nahi mili."
        self.last_file = Path(hits[0])
        return "Mili: " + "; ".join(str(Path(h).relative_to(home())) for h in hits[:4])

    def _do_delete(self) -> str:
        _k, p, _e = self._pending
        self._pending = None
        if not IS_WIN:
            return "Recycle Bin sirf Windows par hai, isliye delete nahi kiya."
        try:
            import ctypes
            from ctypes import wintypes

            class OP(ctypes.Structure):
                _fields_ = [("hwnd", wintypes.HWND), ("func", wintypes.UINT), ("src", wintypes.LPCWSTR), ("dst", wintypes.LPCWSTR),
                            ("flags", ctypes.c_ushort), ("abort", wintypes.BOOL), ("map", ctypes.c_void_p), ("title", wintypes.LPCWSTR)]
            op = OP(None, 3, str(p) + "\0", None, 0x40 | 0x10 | 0x4, False, None, None)   # FO_DELETE, ALLOWUNDO|NOCONFIRMATION|SILENT
            ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
            return f"“{p.name}” Recycle Bin me bhej diya."
        except Exception:  # noqa: BLE001
            return "Delete nahi ho paaya."


# ------------------------------------------------------------------------------------------- multi-step
_VERBS = r"(?:open|kholo|khol|search|dhundo|play|chalao|bajao|volume|mute|screenshot|create|make|banao|bana|list|show|dikhao|find|copy|move|set|lock|weather|time|note|remind|launch|start|close|band)"
_SEQ = re.compile(r"\s*(?:,\s*)?\b(?:and then|aur phir|phir|fir|uske baad|uske bad|then|after that|next)\b\s*,?\s*|\s*,\s*(?=" + _VERBS + r"\b)|\s+(?:aur|and)\s+(?=" + _VERBS + r"\b)", re.I)
BLOCKED_IN_PLAN = re.compile(r"shutdown|shut down|restart|reboot|power off|delete|remove|hatao|mita|format|forget", re.I)


def split_steps(text: str) -> List[str]:
    parts = [p.strip(" ,.") for p in _SEQ.split(text) if p and p.strip(" ,.")]
    return parts if len(parts) >= 2 else []


PLAN_PROMPT = ("You control a Windows PC through a fixed set of text commands. Turn the user's goal into 2 to 8 steps. "
               "Each step must be ONE short command in this style: 'open chrome', 'open youtube', 'search <query>', 'play <song> on youtube', "
               "'volume 40', 'mute', 'screenshot lo', 'create folder <name> on desktop', 'create file <name>.txt with <text>', "
               "'list downloads', 'open downloads', 'find file <name>', 'weather', 'what is the time'. "
               "Never include shutdown, restart or delete. Output ONLY a JSON array of strings.\nGoal: ")


def parse_plan(raw: str) -> List[str]:
    import json
    m = re.search(r"\[.*\]", raw or "", re.S)
    if not m:
        return []
    try:
        arr = json.loads(m.group(0))
    except ValueError:
        return []
    return [s.strip() for s in arr if isinstance(s, str) and s.strip() and not BLOCKED_IN_PLAN.search(s)][:8]
