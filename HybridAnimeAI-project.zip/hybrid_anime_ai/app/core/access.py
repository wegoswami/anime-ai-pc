"""Access Center (PC): checks what Windows still blocks (microphone privacy, screen capture, admin rights), tells the person
exactly what to switch on and opens the right Settings page. Nothing here changes a setting by itself - Windows needs the person's own click."""
import ctypes
import logging
import os
import subprocess
import sys

log = logging.getLogger(__name__)
IS_WIN = sys.platform.startswith("win")

PAGES = {"mic": "ms-settings:privacy-microphone", "notif": "ms-settings:notifications", "camera": "ms-settings:privacy-webcam"}
HOW = {
    "mic": "Microphone: Settings me 'Let desktop apps access your microphone' ON karo.",
    "screen": "Screen control: koi permission nahi chahiye, par app ko 'Run as administrator' se kholo agar kisi admin app (jaise Task Manager) par kaam karna ho.",
    "admin": "Administrator: app par right-click → Run as administrator (sirf tab jab system-level kaam ho).",
    "notif": "Notifications: Settings me app ke notifications ON karo.",
}


def _reg(path: str, name: str):
    if not IS_WIN:
        return None
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path) as k:
            return winreg.QueryValueEx(k, name)[0]
    except Exception:  # noqa: BLE001
        return None


def is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin()) if IS_WIN else os.geteuid() == 0
    except Exception:  # noqa: BLE001
        return False


def check() -> dict:
    """{name: True/False/None}. None = could not tell (so we never nag about it)."""
    out = {"mic": None, "screen": None, "admin": is_admin()}
    if IS_WIN:
        base = r"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone"
        v, vd = _reg(base, "Value"), _reg(base + r"\NonPackaged", "Value")
        out["mic"] = None if v is None and vd is None else not (v == "Deny" or vd == "Deny")
    try:
        import mss  # noqa: F401
        out["screen"] = True
    except Exception:  # noqa: BLE001
        try:
            from PIL import ImageGrab
            ImageGrab.grab(bbox=(0, 0, 2, 2))
            out["screen"] = True
        except Exception:  # noqa: BLE001
            out["screen"] = False if IS_WIN else None
    return out


def report() -> str:
    c = check()
    names = {"mic": "Microphone", "screen": "Screen dekhna/control", "admin": "Administrator"}
    lines = []
    for k in ("mic", "screen", "admin"):
        v = c.get(k)
        lines.append(f"{'✅' if v else ('❔' if v is None else '❌')} {names[k]}" + ("" if v or k == "admin" else "  →  " + HOW[k]))
    return "\n".join(lines)


def open_page(which: str) -> bool:
    if IS_WIN and which in PAGES:
        try:
            os.startfile(PAGES[which])  # type: ignore[attr-defined]
            return True
        except Exception:  # noqa: BLE001
            try:
                subprocess.Popen(["cmd", "/c", "start", "", PAGES[which]])
                return True
            except Exception:  # noqa: BLE001
                log.debug("open settings failed", exc_info=True)
    return False


def setup() -> str:
    """Opens the first thing that is blocked and says what to tap; call again after allowing it."""
    c = check()
    if c.get("mic") is False:
        open_page("mic")
        return "🎤 Mic band hai. Settings khol di: 'Let desktop apps access your microphone' ko ON karo, phir bolo 'permission check'."
    if c.get("screen") is False:
        return "🖥 Screen capture nahi chal raha: app dobara install/update karo ya antivirus me Earthvasi ko allow karo."
    note = "" if c.get("admin") else "\nℹ Kuch system-level kaam ke liye app ko 'Run as administrator' se kholna padega (jab zaroorat ho tab bataungi)."
    return "✅ PC par koi permission block nahi hai. Main screen, apps, mic sab chala sakti hoon." + note
