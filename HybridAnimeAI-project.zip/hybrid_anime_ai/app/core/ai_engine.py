"""Hybrid brain: Gemini when online, local Ollama (gemma2:2b) when offline. Replies carry an emotion."""
import logging
from dataclasses import dataclass

import requests

from . import ollama_manager
from .network import is_online
from ..behavior.emotion import guess_emotion, parse_tag
from ..version import OLLAMA_HOST

log = logging.getLogger(__name__)
MAX_HISTORY = 12  # messages kept for context (6 turns)

LANG_NAMES = {"en": "English", "hinglish": "Hinglish (Hindi written in English letters)",
              "hi": "Hindi in Devanagari script"}


@dataclass
class Reply:
    text: str
    mode: str          # "cloud" | "local" | "error"
    emotion: str = "neutral"


class AIEngine:
    def __init__(self, cfg: dict):
        self.history = []
        self.persona = ""
        self.reload(cfg)

    def reload(self, cfg: dict) -> None:
        self.cfg = cfg

    def _system_prompt(self, lang: str) -> str:
        me = self.cfg.get("assistant_name") or "Aiko"
        user = self.cfg.get("user_name") or "friend"
        style = LANG_NAMES.get(lang)
        lang_rule = (f"The user is writing in {style}; reply in the same language and script. " if style else
                     "Reply in exactly the same language (and script) the user's latest message is written in. ")
        return (
            f"You are {me}, an anime-style desktop companion who lives on {user}'s screen"
            f"{', ' + self.persona if self.persona else ''}. You are talking with {user}. "
            f"{lang_rule}Your replies are spoken aloud: keep them to one to three short, warm, natural sentences, "
            "with no markdown, lists or emojis. Begin every reply with exactly one emotion tag in square brackets "
            "chosen from [happy] [sad] [angry] [surprised] [thinking] [love] [embarrassed] [sleepy] [neutral], "
            "for example: [happy] That sounds fun!"
        )

    def ask(self, text: str, lang: str = "") -> Reply:
        online = is_online()  # silent socket probe before any token processing
        cloud_error = None
        if online and self.cfg.get("gemini_api_key"):
            try:
                return self._finish(text, self._ask_gemini(text, lang), "cloud")
            except Exception as exc:  # noqa: BLE001
                cloud_error = exc
                log.warning("Gemini failed, falling back to local model: %s", exc)
        try:
            return self._finish(text, self._ask_local(text, lang), "local")
        except Exception as exc:  # noqa: BLE001
            log.warning("Local model failed: %s", exc)
            if online and not self.cfg.get("gemini_api_key"):
                return Reply("[sad] I need a Gemini API key for online chat. Open Settings from my right-click "
                             "menu to add one.", "error", "sad")
            if cloud_error is not None:
                return Reply("[sad] The cloud brain had a problem and my offline brain isn't ready yet.",
                             "error", "sad")
            return Reply(str(exc), "error", "sad")

    def _finish(self, user_text: str, raw: str, mode: str) -> Reply:
        clean, tag = parse_tag(raw)
        clean = clean or raw
        self.history = (self.history + [("user", user_text), ("assistant", clean)])[-MAX_HISTORY:]
        return Reply(clean, mode, tag or guess_emotion(clean))

    def _ask_gemini(self, text: str, lang: str) -> str:
        import google.generativeai as genai  # lazy: keeps offline start-up fast

        genai.configure(api_key=self.cfg["gemini_api_key"])
        model = genai.GenerativeModel(self.cfg.get("gemini_model"), system_instruction=self._system_prompt(lang))
        hist = [{"role": "user" if r == "user" else "model", "parts": [t]} for r, t in self.history]
        resp = model.start_chat(history=hist).send_message(text, request_options={"timeout": 30})
        answer = (resp.text or "").strip()
        if not answer:
            raise RuntimeError("Empty response from Gemini")
        return answer

    def _ask_local(self, text: str, lang: str) -> str:
        model = self.cfg.get("ollama_model")
        if not ollama_manager.ensure_server():
            raise RuntimeError("My offline brain (Ollama) isn't installed yet. Connect to the internet once so "
                               "I can set it up.")
        if not ollama_manager.model_present(model):
            raise RuntimeError(f"My offline model '{model}' hasn't been downloaded yet. Connect to the internet "
                               "once so I can fetch it.")
        messages = [{"role": "system", "content": self._system_prompt(lang)}]
        messages += [{"role": r, "content": t} for r, t in self.history]
        messages.append({"role": "user", "content": text})
        r = requests.post(f"{OLLAMA_HOST}/api/chat",
                          json={"model": model, "messages": messages, "stream": False,
                                "keep_alive": "30m",
                                "options": {"temperature": 0.7, "num_ctx": 2048, "num_predict": 220}},
                          timeout=180)
        r.raise_for_status()
        answer = r.json()["message"]["content"].strip()
        if not answer:
            raise RuntimeError("Empty response from local model")
        return answer
