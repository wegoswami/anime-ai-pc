"""Hybrid brain: Gemini when online, local Ollama (gemma2:2b) when offline. Replies carry an emotion."""
import logging
import time
from dataclasses import dataclass

import requests

from . import hardware, ollama_manager, providers
from .network import is_online
from ..behavior.emotion import guess_emotion, parse_tag
from ..version import OLLAMA_HOST

log = logging.getLogger(__name__)
MAX_HISTORY = 16  # messages kept for context (6 turns)

LANG_NAMES = {"en": "English", "hinglish": "Hinglish (Hindi written in English letters)",
              "hi": "Hindi in Devanagari script"}


@dataclass
class Reply:
    text: str
    mode: str          # "cloud" | "local" | "error"
    emotion: str = "neutral"


class AIEngine:
    def __init__(self, cfg: dict):
        self.history = []
        self.persona = ""
        self.memory = None          # app.core.memory.Memory, attached by the controller
        self.tools_hint = ""        # extra prompt text about plugins/routines
        self.soul = None            # app.core.evolution.Soul (tone mirroring), attached by the controller
        self.last_provider = ""
        self.reload(cfg)

    def reload(self, cfg: dict) -> None:
        self.cfg = cfg

    def _system_prompt(self, lang: str, query: str = "") -> str:
        me = self.cfg.get("assistant_name") or "Aiko"
        user = self.cfg.get("user_name") or "friend"
        style = LANG_NAMES.get(lang)
        lang_rule = (f"The user is writing in {style}; reply in the same language and script. " if style else
                     "Reply in exactly the same language (and script) the user's latest message is written in. ")
        return (
            f"You are {me}, an anime-style desktop companion who lives on {user}'s screen"
            f"{', ' + self.persona if self.persona else ''}. You are talking with {user}. "
            f"{lang_rule}Your replies are spoken aloud: keep them to one to three short, warm, natural sentences, "
            "with no markdown, lists or emojis. Begin every reply with exactly one emotion tag in square brackets "
            "chosen from [happy] [sad] [angry] [surprised] [thinking] [love] [embarrassed] [sleepy] [neutral], "
            "for example: [happy] That sounds fun! "
            "You are warm, caring and a little playful, like a best friend: notice the user's mood and answer with matching "
            "empathy (gentle when they're sad, excited when they're happy). Use what you remember about them naturally, "
            "never robotically. "
            f"Today is {time.strftime('%A, %d %B %Y, %I:%M %p')}. "
            + (self.memory.context(query) if (self.memory and query) else "")
            + (self.soul.style_prompt() if self.soul else "")
            + self.tools_hint
        )

    def ask(self, text: str, lang: str = "", image: bytes = None) -> Reply:
        # With a key saved we always TRY the cloud: a failed probe must never block it (blocked DNS port, VPN, proxy...).
        online = bool(providers.available(self.cfg)) or is_online()
        errors = []
        if online:
            sysmsg = self._system_prompt(lang, text)
            for prov in providers.usable(self.cfg):       # preferred order; a failing one is skipped for a minute
                try:
                    raw = providers.ask(prov, self.cfg, sysmsg, self.history, text, image=image)
                    self.last_provider = prov
                    return self._finish(text, raw, "cloud")
                except Exception as exc:  # noqa: BLE001 - one broken provider must never stop the assistant
                    providers.mark_down(prov)
                    errors.append(str(exc))
                    log.warning("%s failed, trying the next brain: %s", prov, exc)
        if image is not None:
            return Reply("[sad] I need the internet and an AI key to look at your screen.", "error", "sad")
        try:
            self.last_provider = "local"
            return self._finish(text, self._ask_local(text, lang), "local")
        except Exception as exc:  # noqa: BLE001
            log.warning("Local model failed: %s", exc)
            if online and not providers.available(self.cfg):
                return Reply("[sad] I need an API key for online chat (Gemini, OpenAI or Claude). Open Settings from my "
                             "right-click menu to add one.", "error", "sad")
            if errors:
                return Reply("[sad] My cloud brain had a problem (" + errors[-1][:90] + ") and my offline brain isn't ready yet.",
                             "error", "sad")
            return Reply(str(exc), "error", "sad")

    def long_form(self, prompt: str, max_tokens: int = 900) -> str:
        """Longer one-shot text (documents, plans). Cloud first, then the local model. Raises if nothing works."""
        if providers.available(self.cfg) or is_online():
            for prov in providers.usable(self.cfg):
                try:
                    return providers.ask(prov, self.cfg, "You are a precise, helpful writer.", [], prompt, None, max_tokens)
                except Exception as exc:  # noqa: BLE001
                    providers.mark_down(prov)
                    log.warning("%s failed for long text: %s", prov, exc)
        model = hardware.effective_model(self.cfg)
        if not (ollama_manager.ensure_server() and ollama_manager.model_present(model)):
            raise RuntimeError("no brain available")
        r = requests.post(f"{OLLAMA_HOST}/api/chat", json={"model": model, "stream": False, "keep_alive": "30m",
                          "messages": [{"role": "user", "content": prompt}],
                          "options": {"temperature": 0.5, "num_ctx": 4096, "num_predict": max_tokens}}, timeout=300)
        r.raise_for_status()
        return r.json()["message"]["content"].strip()

    def _finish(self, user_text: str, raw: str, mode: str) -> Reply:
        clean, tag = parse_tag(raw)
        clean = clean or raw
        self.history = (self.history + [("user", user_text), ("assistant", clean)])[-MAX_HISTORY:]
        return Reply(clean, mode, tag or guess_emotion(clean))

    def _ask_local(self, text: str, lang: str) -> str:
        model = hardware.effective_model(self.cfg)
        if not ollama_manager.ensure_server():
            raise RuntimeError("My offline brain (Ollama) isn't installed yet. Connect to the internet once so "
                               "I can set it up.")
        if not ollama_manager.model_present(model):
            raise RuntimeError(f"My offline model '{model}' hasn't been downloaded yet. Connect to the internet "
                               "once so I can fetch it.")
        messages = [{"role": "system", "content": self._system_prompt(lang, text)}]
        messages += [{"role": r, "content": t} for r, t in self.history]
        messages.append({"role": "user", "content": text})
        r = requests.post(f"{OLLAMA_HOST}/api/chat",
                          json={"model": model, "messages": messages, "stream": False,
                                "keep_alive": "30m",
                                "options": {"temperature": 0.7, "num_ctx": 4096, "num_predict": 320, "repeat_penalty": 1.1}},
                          timeout=180)
        r.raise_for_status()
        answer = r.json()["message"]["content"].strip()
        if not answer:
            raise RuntimeError("Empty response from local model")
        return answer
