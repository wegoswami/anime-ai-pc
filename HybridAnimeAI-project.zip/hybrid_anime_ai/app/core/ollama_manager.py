"""Install / start / provision a local Ollama so offline mode works without manual steps."""
import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Callable, Optional, Tuple

import requests

from ..version import OLLAMA_HOST, OLLAMA_INSTALLER_URL, USER_AGENT

log = logging.getLogger(__name__)
IS_WIN = sys.platform == "win32"
Progress = Callable[[str, int], None]


def find_ollama() -> Optional[str]:
    found = shutil.which("ollama")
    if found:
        return found
    if IS_WIN:
        for env, sub in (("LOCALAPPDATA", r"Programs\Ollama\ollama.exe"),
                         ("PROGRAMFILES", r"Ollama\ollama.exe")):
            base = os.environ.get(env)
            if base:
                p = os.path.join(base, sub)
                if os.path.exists(p):
                    return p
    return None


def server_up(timeout: float = 1.5) -> bool:
    try:
        return requests.get(f"{OLLAMA_HOST}/api/tags", timeout=timeout).status_code == 200
    except requests.RequestException:
        return False


def ensure_server(wait: float = 20.0) -> bool:
    if server_up():
        return True
    exe = find_ollama()
    if not exe:
        return False
    flags = 0
    if IS_WIN:
        flags = (getattr(subprocess, "CREATE_NO_WINDOW", 0)
                 | getattr(subprocess, "DETACHED_PROCESS", 0))
    try:
        subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         stdin=subprocess.DEVNULL, creationflags=flags, close_fds=True)
    except OSError as exc:
        log.warning("Could not start ollama: %s", exc)
        return False
    deadline = time.time() + wait
    while time.time() < deadline:
        if server_up():
            return True
        time.sleep(0.5)
    return False


def model_present(model: str) -> bool:
    try:
        r = requests.get(f"{OLLAMA_HOST}/api/tags", timeout=5)
        r.raise_for_status()
        names = {m.get("name", "") for m in r.json().get("models", [])}
    except (requests.RequestException, ValueError):
        return False
    return model in names or f"{model}:latest" in names


def warm(model: str) -> None:
    """Load the model into RAM and keep it there for 30 min (empty prompt = no generation)."""
    if server_up() and model_present(model):
        requests.post(f"{OLLAMA_HOST}/api/generate", json={"model": model, "keep_alive": "30m"}, timeout=120)


def pull_model(model: str, progress: Progress) -> None:
    payload = {"model": model, "name": model, "stream": True}
    with requests.post(f"{OLLAMA_HOST}/api/pull", json=payload, stream=True,
                       timeout=(10, 600)) as r:
        r.raise_for_status()
        for line in r.iter_lines():
            if not line:
                continue
            d = json.loads(line)
            if "error" in d:
                raise RuntimeError(d["error"])
            total, done = d.get("total"), d.get("completed")
            if total and done is not None:
                progress("Downloading offline brain", int(done * 100 / total))
            else:
                progress(str(d.get("status", "Preparing")).capitalize(), 0)


def install_ollama(progress: Progress) -> None:
    """Download the official Windows installer in chunks and run it silently (per-user)."""
    if not IS_WIN:
        raise RuntimeError("Automatic Ollama install is Windows-only. Install it from ollama.com.")
    target = os.path.join(tempfile.mkdtemp(prefix="haa-ollama-"), "OllamaSetup.exe")
    with requests.get(OLLAMA_INSTALLER_URL, stream=True, timeout=(10, 60),
                      headers={"User-Agent": USER_AGENT}) as r:
        r.raise_for_status()
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        with open(target, "wb") as f:
            for chunk in r.iter_content(chunk_size=512 * 1024):
                if chunk:
                    f.write(chunk)
                    done += len(chunk)
                    progress("Downloading local AI engine", int(done * 100 / total) if total else 0)
    progress("Installing local AI engine", 100)
    subprocess.run([target, "/VERYSILENT", "/NORESTART", "/SP-"], timeout=900,
                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    shutil.rmtree(os.path.dirname(target), ignore_errors=True)


def provision(model: str, progress: Progress) -> Tuple[bool, str]:
    """Make sure Ollama + the model exist. Needs internet the first time only."""
    try:
        if not find_ollama():
            install_ollama(progress)
        if not find_ollama():
            return False, "Offline engine could not be installed."
        if not ensure_server():
            return False, "Offline engine installed but did not start."
        if not model_present(model):
            pull_model(model, progress)
        return True, "Offline brain is ready."
    except Exception as exc:  # noqa: BLE001 - report any failure to the UI
        log.exception("Offline provisioning failed")
        return False, f"Offline setup failed: {exc}"
