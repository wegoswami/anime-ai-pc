"""PC cleaner / booster / virus scan - voice driven, with a preview and a 'yes' before anything is deleted.

Safety rules:
  * only fixed, well-known junk folders are ever touched (user temp, browser *cache* folders, thumbnail cache);
    never documents, downloads, passwords, cookies or browser profiles;
  * only files older than a day are removed, and files that are in use are simply skipped;
  * the Recycle Bin is only emptied on the second 'yes'; apps are only closed by name after a 'yes'.
"""
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

WIN = sys.platform == "win32"
MIN_AGE = 24 * 3600
PROTECTED = {"system", "idle", "registry", "smss.exe", "csrss.exe", "wininit.exe", "services.exe", "lsass.exe", "winlogon.exe",
             "explorer.exe", "svchost.exe", "dwm.exe", "fontdrvhost.exe", "memory compression", "hybridanimeai.exe", "python.exe",
             "pythonw.exe", "msmpeng.exe", "taskmgr.exe", "audiodg.exe", "ctfmon.exe", "sihost.exe", "searchhost.exe"}


def human(n: float) -> str:
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return f"{n:.0f} {u}" if u == "B" else f"{n:.1f} {u}"
        n /= 1024
    return f"{n:.1f} GB"


def junk_roots() -> Dict[str, Path]:
    """name -> folder. Only these are ever cleaned."""
    roots: Dict[str, Path] = {}
    tmp = os.environ.get("TEMP") or os.environ.get("TMP")
    if tmp:
        roots["Temp files"] = Path(tmp)
    local = os.environ.get("LOCALAPPDATA")
    if local:
        lp = Path(local)
        roots["Thumbnail cache"] = lp / "Microsoft" / "Windows" / "Explorer"
        for label, sub in (("Chrome cache", "Google/Chrome/User Data/Default/Cache"), ("Chrome code cache", "Google/Chrome/User Data/Default/Code Cache"),
                           ("Edge cache", "Microsoft/Edge/User Data/Default/Cache"), ("Edge code cache", "Microsoft/Edge/User Data/Default/Code Cache")):
            roots[label] = lp / sub
    return roots


def _walk(root: Path, only_old: bool, thumbs_only: bool = False):
    now = time.time()
    if not root.is_dir():
        return
    for p in root.rglob("*"):
        try:
            if not p.is_file() or p.is_symlink():
                continue
            if thumbs_only and not re.match(r"(thumbcache|iconcache).*\.db$", p.name, re.I):
                continue
            if only_old and now - p.stat().st_mtime < MIN_AGE:
                continue
            yield p
        except OSError:
            continue


def scan(roots: Optional[Dict[str, Path]] = None) -> List[Tuple[str, int, int]]:
    """[(name, files, bytes)] of what could be removed."""
    out = []
    for name, root in (roots or junk_roots()).items():
        n = b = 0
        for p in _walk(root, True, name == "Thumbnail cache"):
            try:
                b += p.stat().st_size
                n += 1
            except OSError:
                pass
        if n:
            out.append((name, n, b))
    return out


def clean(roots: Optional[Dict[str, Path]] = None) -> Tuple[int, int]:
    """Deletes the old junk files. Returns (files removed, bytes freed). Locked files are skipped."""
    files = freed = 0
    for name, root in (roots or junk_roots()).items():
        for p in list(_walk(root, True, name == "Thumbnail cache")):
            try:
                size = p.stat().st_size
                p.unlink()
                files += 1
                freed += size
            except OSError:
                continue
    return files, freed


def recycle_bin_size() -> int:
    if not WIN:
        return 0
    try:
        import ctypes
        from ctypes import wintypes

        class Info(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("size", ctypes.c_longlong), ("items", ctypes.c_longlong)]
        i = Info(ctypes.sizeof(Info), 0, 0)
        ctypes.windll.shell32.SHQueryRecycleBinW(None, ctypes.byref(i))
        return int(i.size)
    except Exception:  # noqa: BLE001
        return 0


def empty_recycle_bin() -> bool:
    if not WIN:
        return False
    try:
        import ctypes
        return ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, 0x7) == 0       # no confirmation / progress / sound
    except Exception:  # noqa: BLE001
        return False


def flush_dns() -> bool:
    if not WIN:
        return False
    try:
        return subprocess.run(["ipconfig", "/flushdns"], capture_output=True, timeout=15, creationflags=0x08000000).returncode == 0
    except Exception:  # noqa: BLE001
        return False


def memory() -> Tuple[int, int]:
    """(free bytes, total bytes) of RAM."""
    if WIN:
        try:
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong), ("tp", ctypes.c_ulonglong), ("ap", ctypes.c_ulonglong),
                            ("tpf", ctypes.c_ulonglong), ("apf", ctypes.c_ulonglong), ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong), ("ae", ctypes.c_ulonglong)]
            m = MS()
            m.l = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return int(m.ap), int(m.tp)
        except Exception:  # noqa: BLE001
            return 0, 0
    try:
        d = {k: int(v.split()[0]) * 1024 for k, v in (ln.split(":", 1) for ln in open("/proc/meminfo"))}
        return d.get("MemAvailable", 0), d.get("MemTotal", 0)
    except Exception:  # noqa: BLE001
        return 0, 0


def heavy_apps(top: int = 5) -> List[Tuple[str, int]]:
    """[(process name, MB)] biggest memory users (Windows tasklist)."""
    if not WIN:
        return []
    try:
        out = subprocess.run(["tasklist", "/FO", "CSV", "/NH"], capture_output=True, text=True, timeout=15, creationflags=0x08000000).stdout
    except Exception:  # noqa: BLE001
        return []
    agg: Dict[str, int] = {}
    for ln in out.splitlines():
        parts = [x.strip('"') for x in ln.split('","')]
        if len(parts) >= 5:
            mem = int(re.sub(r"\D", "", parts[4]) or 0) // 1024          # K -> MB
            name = parts[0].strip('"')
            agg[name] = agg.get(name, 0) + mem
    rows = [(n, m) for n, m in agg.items() if n.lower() not in PROTECTED]
    return sorted(rows, key=lambda r: -r[1])[:top]


def startup_apps() -> List[str]:
    if not WIN:
        return []
    names: List[str] = []
    try:
        import winreg
        for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
            try:
                with winreg.OpenKey(hive, r"Software\Microsoft\Windows\CurrentVersion\Run") as k:
                    i = 0
                    while True:
                        names.append(winreg.EnumValue(k, i)[0])
                        i += 1
            except OSError:
                continue
    except Exception:  # noqa: BLE001
        pass
    return names


def close_app(name: str) -> bool:
    n = name.strip().lower()
    n = n if n.endswith(".exe") else n + ".exe"
    if not WIN or n in PROTECTED:
        return False
    try:
        return subprocess.run(["taskkill", "/IM", n], capture_output=True, timeout=15, creationflags=0x08000000).returncode == 0   # polite close, no /F
    except Exception:  # noqa: BLE001
        return False


def defender_scan(full: bool = False) -> bool:
    """Starts a Windows Defender scan in the background (Defender is the real antivirus; we just drive it)."""
    if not WIN:
        return False
    kind = "FullScan" if full else "QuickScan"
    try:
        subprocess.Popen(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command",
                          f"Update-MpSignature -ErrorAction SilentlyContinue; Start-MpScan -ScanType {kind}"], creationflags=0x08000000)
        return True
    except Exception:  # noqa: BLE001
        return False


def defender_threats() -> str:
    if not WIN:
        return ""
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", "(Get-MpThreatDetection | Measure-Object).Count"], capture_output=True, text=True, timeout=30, creationflags=0x08000000).stdout.strip()
        return out
    except Exception:  # noqa: BLE001
        return ""


class Cleaner:
    """Chat commands. try_execute(text) -> reply or None."""
    SCAN = re.compile(r"\b(virus|malware|antivirus|security)\b.*\b(scan|check|dhundo|jaanch)\b|\b(scan|check)\b.*\b(virus|malware)\b|virus (scan|check)", re.I)
    FULL = re.compile(r"\b(full|poora|pura|deep)\b", re.I)
    CLEAN = re.compile(r"^\s*(?:pc |computer |laptop )?(?:clean(?:er)?|saaf|safai|junk|boost|optimi[sz]e|tune ?up)\b.*|.*\b(clean|boost|speed up|speed badhao|fast kar|tez kar|cache (?:hata|clear|delete)|junk (?:hata|saaf)|pc (?:slow|hang))\b.*", re.I)
    CLOSE = re.compile(r"^\s*(?:close|band karo|kill)\s+([A-Za-z0-9 ._-]{2,30})\s*$", re.I)
    YES = re.compile(r"^\s*(yes|haan|han|ha|kar do|kardo|ok|okay|theek hai|proceed|confirm)\s*[.!]*\s*$", re.I)
    NO = re.compile(r"^\s*(no|nahi|nhi|cancel|mat|ruko|stop)\s*[.!]*\s*$", re.I)

    def __init__(self, say: Callable[[str], None] = lambda m: None, roots: Optional[Dict[str, Path]] = None):
        self.say, self.roots = say, roots
        self.pending: Optional[Tuple[str, float, object]] = None

    def _report(self) -> str:
        items = scan(self.roots)
        total = sum(b for _, _, b in items)
        rb = recycle_bin_size() if self.roots is None else 0
        free, tot = memory()
        parts = [f"{n}: {human(b)}" for n, _, b in items]
        text = ("Kachra mila: " + ", ".join(parts) + f" (kul {human(total)})." if items else "Temp/cache me abhi kuch kachra nahi mila.")
        if rb:
            text += f" Recycle Bin me {human(rb)}."
        if tot:
            text += f" RAM free: {human(free)} / {human(tot)}."
        heavy = heavy_apps(3)
        if heavy:
            text += " Sabse zyada RAM: " + ", ".join(f"{n} ({m} MB)" for n, m in heavy) + "."
        su = startup_apps()
        if su:
            text += f" Startup me {len(su)} apps hain (Task Manager → Startup se band kar sakte ho)."
        return text

    def try_execute(self, text: str) -> Optional[str]:
        t = text.strip()
        now = time.time()
        if self.pending and now > self.pending[1]:
            self.pending = None
        if self.pending:
            kind, _, data = self.pending
            if self.YES.match(t):
                self.pending = None
                if kind == "clean":
                    files, freed = clean(self.roots)
                    flushed = flush_dns() if self.roots is None else False
                    rb = recycle_bin_size() if self.roots is None else 0
                    msg = f"Ho gaya! {files} files hataayi, {human(freed)} jagah khaali." + (" DNS cache bhi saaf." if flushed else "")
                    if rb:
                        self.pending = ("bin", now + 60, rb)
                        msg += f" Recycle Bin me {human(rb)} hai - khaali kar du? (haan/nahi)"
                    return msg
                if kind == "bin":
                    return "Recycle Bin khaali kar diya. ✅" if empty_recycle_bin() else "Recycle Bin khaali nahi ho paaya."
                if kind == "close":
                    return f"{data} band kar diya." if close_app(str(data)) else f"{data} band nahi ho paaya (ya wo zaroori system app hai)."
            if self.NO.match(t):
                self.pending = None
                return "Theek hai, kuch nahi hataya."
        m = self.CLOSE.match(t)
        if m and m.group(1).lower().strip() not in ("app", "this", "ye", "isko"):
            name = m.group(1).strip()
            if name.lower().removesuffix(".exe") + ".exe" in PROTECTED:
                return f"{name} zaroori system program hai, main ise band nahi karungi."
            self.pending = ("close", now + 45, name)
            return f"{name} ko band kar du? Save na kiya kaam ud sakta hai. (haan/nahi)"
        if self.SCAN.search(t):
            if not WIN:
                return "Virus scan sirf Windows par hota hai (Windows Defender ke zariye)."
            ok = defender_scan(bool(self.FULL.search(t)))
            return ("Windows Defender ka " + ("full" if self.FULL.search(t) else "quick") + " scan chalu kar diya, signatures bhi update ho rahe hain. "
                    "Background me chalega; Windows Security me result dikhega.") if ok else "Defender scan shuru nahi ho paaya. Windows Security app kholkar khud scan chalao."
        if self.CLEAN.match(t) and not re.search(r"\b(file|folder|screen|desktop|downloads?)\b", t, re.I):
            self.pending = ("clean", now + 60, None)
            return self._report() + " Sirf purani temp/cache files hataungi (documents, downloads, passwords nahi chhuungi). Safai kar du? (haan/nahi)"
        return None
