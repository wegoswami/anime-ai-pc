"""Looks at this PC (RAM / CPU / GPU) and picks the best offline model that will run smoothly."""
import logging
import os
import platform
import re
import subprocess
import sys
from dataclasses import dataclass
from typing import Optional

log = logging.getLogger(__name__)


@dataclass
class Hardware:
    ram_gb: float
    cpu_cores: int
    gpu_name: str = ""
    gpu_vram_gb: float = 0.0

    def summary(self) -> str:
        g = f", GPU {self.gpu_name}" + (f" ({self.gpu_vram_gb:.0f} GB)" if self.gpu_vram_gb else "") if self.gpu_name else ", no dedicated GPU"
        return f"{self.ram_gb:.0f} GB RAM, {self.cpu_cores} CPU cores{g}"


def _ram_gb() -> float:
    try:
        if sys.platform == "win32":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("l", ctypes.c_ulong), ("p", ctypes.c_ulong), ("tp", ctypes.c_ulonglong), ("ap", ctypes.c_ulonglong),
                            ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong), ("tx", ctypes.c_ulonglong), ("ax", ctypes.c_ulonglong),
                            ("ae", ctypes.c_ulonglong)]
            m = MS()
            m.l = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.tp / 2 ** 30
        with open("/proc/meminfo") as f:
            return int(re.search(r"MemTotal:\s+(\d+)", f.read()).group(1)) / 2 ** 20
    except Exception:  # noqa: BLE001
        return 8.0


def _gpu() -> tuple:
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
                             capture_output=True, text=True, timeout=4).stdout.strip().splitlines()
        if out:
            name, mem = [x.strip() for x in out[0].split(",")]
            return name, float(mem) / 1024
    except Exception:  # noqa: BLE001
        pass
    if sys.platform == "win32":
        try:
            out = subprocess.run(["powershell", "-NoProfile", "-Command",
                                  "(Get-CimInstance Win32_VideoController | Select-Object -First 1 -ExpandProperty Name)"],
                                 capture_output=True, text=True, timeout=6).stdout.strip()
            if out:
                return out, 0.0
        except Exception:  # noqa: BLE001
            pass
    return "", 0.0


def detect() -> Hardware:
    gpu, vram = _gpu()
    return Hardware(_ram_gb(), os.cpu_count() or 2, gpu, vram)


# (min RAM GB, model, approx download)  -- first match from the top wins
TIERS = [(24, "llama3.1:8b", "4.7 GB"), (12, "llama3.2:3b", "2.0 GB"), (6, "gemma2:2b", "1.6 GB"), (0, "qwen2.5:0.5b", "0.4 GB")]


def recommend_model(hw: Optional[Hardware] = None) -> tuple:
    hw = hw or detect()
    ram = hw.ram_gb
    if hw.gpu_vram_gb >= 8:
        ram = max(ram, 24)                       # a decent NVIDIA card can run the bigger model quickly
    for need, model, size in TIERS:
        if ram >= need:
            return model, size
    return TIERS[-1][1], TIERS[-1][2]


_cache: dict = {}


def cached() -> Hardware:
    if "hw" not in _cache:
        try:
            _cache["hw"] = detect()
        except Exception:  # noqa: BLE001
            _cache["hw"] = Hardware(8.0, 2)
    return _cache["hw"]


def effective_model(cfg: dict) -> str:
    """The offline model to use: auto-picked for this PC, or the one the user typed in Settings."""
    if cfg.get("auto_model", True):
        return recommend_model(cached())[0]
    return cfg.get("ollama_model") or "gemma2:2b"
