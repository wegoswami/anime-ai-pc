"""What the assistant is doing, shown as a gesture + prop + label so you can SEE it working (no Qt here, easy to test).

guess(text)            -> activity kind for a command ("search", "news", "write" ...) or None for plain chat
ACTS[kind]             -> icon, body gesture, emotion and rotating labels
gesture_xform(g, t)    -> (dx, dy, rotate_deg, scale_x, scale_y) body movement for gesture g at time t (seconds)
"""
import math
import re

ACTS = {
    "think":     ("💭", "think",  "thinking",  ["Soch rahi hoon…", "Jawab bana rahi hoon…", "Bas ek second…"]),
    "search":    ("🔍", "search", "thinking",  ["Dhundh rahi hoon…", "Web par dekh rahi hoon…", "Sahi jawab chun rahi hoon…"]),
    "news":      ("📰", "read",   "thinking",  ["Taaza khabrein la rahi hoon…", "Headlines padh rahi hoon…", "Sab kuch short kar rahi hoon…"]),
    "weather":   ("⛅", "float",  "happy",     ["Mausam dekh rahi hoon…"]),
    "screen":    ("👆", "tap",    "thinking",  ["Screen dekh rahi hoon…", "Tap karne ja rahi hoon…", "Kaam kar rahi hoon…"]),
    "write":     ("✍️", "type",   "thinking",  ["Likh rahi hoon…", "Draft bana rahi hoon…"]),
    "read":      ("📖", "read",   "thinking",  ["Padh rahi hoon…", "Samajh rahi hoon…"]),
    "listen":    ("🎧", "listen", "listening", ["Sun rahi hoon…"]),
    "call":      ("📞", "ring",   "happy",     ["Call laga rahi hoon…"]),
    "record":    ("⏺️", "pulse",  "listening", ["Recording chal rahi hai…"]),
    "remind":    ("⏰", "ring",   "happy",     ["Reminder laga rahi hoon…"]),
    "reels":     ("📱", "read",   "happy",     ["Reel badal rahi hoon…"]),
    "music":     ("🎵", "dance",  "happy",     ["Gaana lagati hoon…"]),
    "calc":      ("🧮", "type",   "thinking",  ["Hisaab laga rahi hoon…"]),
    "translate": ("🌐", "spin",   "thinking",  ["Translate kar rahi hoon…"]),
    "tutor":     ("🎓", "think",  "happy",     ["Sabak taiyar kar rahi hoon…"]),
    "open":      ("🚀", "dance",  "happy",     ["Khol rahi hoon…"]),
    "note":      ("📝", "type",   "happy",     ["Note kar rahi hoon…"]),
    "clean":     ("🧹", "dance",  "happy",     ["Safai kar rahi hoon…"]),
    "done":      ("✅", "hop",    "happy",     ["Ho gaya!"]),
}

_RX = [
    ("remind", r"\b(yaad|remind|reminder|alarm|timer)\b"), ("record", r"\brecord(ing)?\b"), ("call", r"\b(call|dial|phone)\b"),
    ("news", r"\b(news|khabar|khabrein|headline)\b"), ("weather", r"\b(mausam|weather|barish|temperature)\b"),
    ("reels", r"\b(reels?|shorts?|auto ?scroll)\b"), ("music", r"\b(gaana|gana|song|music|play)\b"), ("translate", r"\b(translate|anuvad|meaning|matlab)\b"),
    ("tutor", r"\b(sikhao|tutor|lesson|word of the day|aaj ka word)\b"),
    ("write", r"\b(likho|likh|draft|compose|message|sms|whatsapp|email|mail)\b"), ("note", r"\b(note|task|todo|to-do)\b"),
    ("calc", r"\d\s*[+\-*/x×÷]\s*\d|\b(calculate|hisaab|kitna hota)\b"), ("read", r"\b(padho|padh|summary|summarize|read)\b"),
    ("screen", r"\b(screen|tap|click|scroll|swipe|type karo|dabao)\b"), ("clean", r"\b(clean|cleaner|safai|junk|temp files)\b"),
    ("search", r"\b(search|dhundo|dhoondo|google|find|youtube)\b"), ("open", r"\b(kholo|open|chalu karo|launch|start)\b"),
]
_COMPILED = [(k, re.compile(p)) for k, p in _RX]


def guess(text: str):
    n = (text or "").lower()
    for kind, rx in _COMPILED:
        if rx.search(n):
            return kind
    return None


def label(kind: str, elapsed: float, i: int = 0) -> str:
    labs = ACTS.get(kind, ACTS["think"])[3]
    if kind in ("done", "listen", "record"):
        return labs[0]
    if elapsed > 14:
        return "Network thoda slow hai… ruko 🙏"
    if elapsed > 6:
        return "Thoda time lag raha hai… bas ho hi gaya"
    return labs[i % len(labs)]


def gesture_xform(g: str, t: float):
    """Body movement for the avatar (dx, dy in canvas units, rotation in degrees, scale x, scale y)."""
    s = math.sin
    if g == "think":
        return 0.0, -3 * max(0.0, s(t * 2.6)), 3.0 * s(t * 2.6), 1, 1
    if g == "search":
        return 6 * s(t * 3.9), 0, 4.0 * s(t * 3.9), 1, 1
    if g == "read":
        return 0, 0, 2.0 + 1.5 * s(t * 3.1), 1.0 + 0.01 * s(t * 3.1), 1.0 - 0.01 * s(t * 3.1)
    if g == "tap":
        return 0, 5 * max(0.0, s(t * 9)), 0, 1.01, 0.98
    if g == "type":
        return 0, -2 * max(0.0, s(t * 21)), 0, 1, 1
    if g == "listen":
        return 0, -2 * max(0.0, s(t * 2.9)), 5.0 + 1.5 * s(t * 2.9), 1, 1
    if g == "ring":
        return 0, 0, 2.5 * s(t * 14), 1, 1
    if g == "dance":
        return 0, -12 * abs(s(t * 7.8)), 4.0 * s(t * 7.8), 1, 1
    if g == "spin":
        return 0, -3 * max(0.0, s(t * 4.4)), 3.0 * s(t * 4.4), 1, 1
    if g == "pulse":
        return 0, 0, 0, 1.0 + 0.04 * (0.5 + 0.5 * s(t * 6.3)), 1.0 + 0.04 * (0.5 + 0.5 * s(t * 6.3))
    if g == "float":
        return 0, -7 * (0.5 + 0.5 * s(t * 2.8)), 0, 1, 1
    if g == "hop":
        k = min(1.0, t / 0.55)
        return 0, -22 * s(k * math.pi), 0, 1.0 + 0.04 * s(k * math.pi), 1.0 - 0.02 * s(k * math.pi)
    return 0, 0, 0, 1, 1
