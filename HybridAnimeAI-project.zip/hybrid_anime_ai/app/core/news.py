"""Daily news headlines for the desktop app (free: public Google News RSS, no key, titles only)."""
import html
import logging
import re
import xml.etree.ElementTree as ET
from typing import List
from urllib.parse import quote

import requests

from ..version import USER_AGENT

log = logging.getLogger(__name__)
TRIGGER = re.compile(r"^\s*(?:(?:aaj\s+ki|aaj\s+ka|latest|taaza|today'?s|daily)\s+)?(?:news|khabar|khabrein|samachar|headlines)"
                     r"(?:\s+(?:about|on|of|ki|ka|ke baare me|for)\s+(?P<topic>.+?))?\s*(?:batao|sunao|dikhao|do|bolo)?\s*[?.!]*\s*$", re.I)
FEEDS = {"hi": ("hi", "IN", "IN:hi"), "en": ("en-IN", "IN", "IN:en"), "hinglish": ("en-IN", "IN", "IN:en")}


def parse_titles(xml_text: str, n: int = 5) -> List[str]:
    out = []
    for it in ET.fromstring(xml_text).iter("item"):
        t = html.unescape((it.findtext("title") or "").strip())
        if t:
            out.append(t)
        if len(out) >= n:
            break
    return out


def fetch(topic: str = "", lang: str = "en", n: int = 5, timeout: float = 7.0) -> List[str]:
    hl, gl, ceid = FEEDS.get(lang, FEEDS["en"])
    base = "https://news.google.com/rss"
    url = (f"{base}/search?q={quote(topic)}&hl={hl}&gl={gl}&ceid={ceid}" if topic else f"{base}?hl={hl}&gl={gl}&ceid={ceid}")
    r = requests.get(url, timeout=timeout, headers={"User-Agent": USER_AGENT})
    r.raise_for_status()
    return parse_titles(r.text, n)


def try_execute(text: str, lang: str = "en") -> str:
    """Return a reply if `text` asks for news, else ''."""
    m = TRIGGER.match(text or "")
    if not m:
        return ""
    topic = (m.group("topic") or "").strip()
    try:
        items = fetch(topic, lang)
    except Exception as exc:  # noqa: BLE001
        log.info("news failed: %s", exc)
        return "Khabar nahi la paayi. Internet check karo aur phir se bolo."
    if not items:
        return "Abhi koi khabar nahi mili."
    head = f"{topic.title()} ki taaza khabrein:" if topic else "Aaj ki taaza khabrein:"
    return head + "\n" + "\n".join(f"{i}. {t}" for i, t in enumerate(items, 1))
