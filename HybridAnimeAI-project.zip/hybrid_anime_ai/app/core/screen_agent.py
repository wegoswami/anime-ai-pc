"""PC screen control: looks at the screen, decides ONE action, performs it, repeats until the goal is done.

Works inside any app or website (browser, Word, Excel, WhatsApp Desktop, games' menus...). Needs a vision-capable
cloud brain (Gemini / OpenAI / Claude). Safety rails: max steps, a stop word at any time, and the model is told to
stop and hand over for passwords, payments, captchas and anything destructive.
"""
import json
import logging
import re
import threading
import time
from typing import Callable, Dict, List, Optional

log = logging.getLogger(__name__)
MAX_STEPS = 30
TRIGGER = re.compile(r"^\s*(?:screen (?:control|agent)|computer use|pc control|pc par|is screen par|screen par|is app me|isme|iske andar|mere pc par|control my pc)\s*[:\-]?\s*(.{4,300})$", re.I)
STOP = re.compile(r"^\s*(?:stop|ruko|ruk jao|rok do|cancel|band karo|bas)\s*(?:agent|screen|control)?\s*$", re.I)
RISKY = re.compile(r"password|passcode|\botp\b|card number|cvv|pin code|bank|payment|pay now|purchase|buy now|checkout|delete account|format|shutdown|install", re.I)

SYSTEM = (
    "You control a Windows PC by looking at screenshots. Reply with ONE JSON object only, no prose.\n"
    'Actions: {"action":"click","x":0-1000,"y":0-1000} | {"action":"double_click",...} | {"action":"right_click",...} | '
    '{"action":"type","text":"..."} | {"action":"key","keys":"ctrl+l"} | {"action":"scroll","amount":-5..5} | '
    '{"action":"drag","x":0-1000,"y":0-1000,"x2":0-1000,"y2":0-1000} | {"action":"open_url","url":"https://..."} | {"action":"open_app","name":"chrome|notepad|excel|..."} | '
    '{"action":"say","say":"read this out loud to the user"} | {"action":"wait"} | {"action":"done","say":"short summary for the user"} | {"action":"ask","say":"what you need from the user"}.\n'
    "x and y are positions on the screenshot scaled to 0-1000 (0,0 = top-left). Click a text box before typing in it. "
    "Prefer keyboard shortcuts when sure (ctrl+l for the browser address bar, win key to open Start, enter to submit, ctrl+f to find text on a page, ctrl+a / ctrl+c / ctrl+v to select, copy, paste). "
    "Use open_url for web searches (https://www.google.com/search?q=...), open_app to start a program, drag to move or select things, scroll to read long pages, and say to read text aloud. "
    "If the screen asks for a password, OTP, captcha, payment, or the goal would delete/buy/install something, use the 'ask' action "
    "instead of continuing. When the goal is complete, use 'done'. Never invent success: if the screen does not show it, keep going or 'ask'.")


def parse_action(raw: str) -> Optional[Dict]:
    m = re.search(r"\{.*\}", raw or "", re.S)
    if not m:
        return None
    try:
        a = json.loads(m.group(0))
    except ValueError:
        return None
    if not isinstance(a, dict) or a.get("action") not in ("click", "double_click", "right_click", "type", "key", "scroll", "wait", "done", "ask", "drag", "open_url", "open_app", "say"):
        return None
    for k in ("x", "y", "x2", "y2"):
        if k in a:
            try:
                a[k] = max(0, min(1000, int(a[k])))
            except (TypeError, ValueError):
                return None
    if a["action"] in ("click", "double_click", "right_click") and ("x" not in a or "y" not in a):
        return None
    if a["action"] == "drag" and not all(k in a for k in ("x", "y", "x2", "y2")):
        return None
    if a["action"] == "open_url":
        a["url"] = str(a.get("url", "")).strip()[:500]
        if not re.match(r"^https?://[^\s]+$", a["url"], re.I):
            return None
    if a["action"] == "open_app":
        a["name"] = str(a.get("name", "")).strip()[:40]
        if not re.match(r"^[A-Za-z0-9][A-Za-z0-9 ._-]*$", a["name"]):
            return None
    if a["action"] == "say":
        a["say"] = str(a.get("say", ""))[:400]
    if a["action"] == "type":
        a["text"] = str(a.get("text", ""))[:400]
    if a["action"] == "key":
        a["keys"] = str(a.get("keys", ""))[:40]
    return a


# ------------------------------------------------------------------ input (Windows)
VK = {"ctrl": 0x11, "control": 0x11, "alt": 0x12, "shift": 0x10, "win": 0x5B, "enter": 0x0D, "tab": 0x09, "esc": 0x1B, "escape": 0x1B,
      "space": 0x20, "backspace": 0x08, "delete": 0x2E, "home": 0x24, "end": 0x23, "pageup": 0x21, "pagedown": 0x22,
      "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28}
for _i in range(1, 13):
    VK[f"f{_i}"] = 0x6F + _i


def keys_to_vks(spec: str) -> List[int]:
    out = []
    for part in re.split(r"[+\s]+", spec.lower().strip()):
        if part in VK:
            out.append(VK[part])
        elif len(part) == 1 and part.isalnum():
            out.append(ord(part.upper()))
        else:
            return []
    return out


class WinInput:
    def __init__(self):
        import ctypes
        self.u = ctypes.windll.user32
        self.w = self.u.GetSystemMetrics(0)
        self.h = self.u.GetSystemMetrics(1)

    def move(self, nx: int, ny: int) -> None:
        self.u.SetCursorPos(int(nx / 1000 * (self.w - 1)), int(ny / 1000 * (self.h - 1)))

    def click(self, nx, ny, kind="click") -> None:
        self.move(nx, ny)
        time.sleep(0.08)
        down, up = (0x8, 0x10) if kind == "right_click" else (0x2, 0x4)
        for _ in range(2 if kind == "double_click" else 1):
            self.u.mouse_event(down, 0, 0, 0, 0)
            self.u.mouse_event(up, 0, 0, 0, 0)
            time.sleep(0.06)

    def type_text(self, text: str) -> None:
        import ctypes
        from ctypes import wintypes

        class KI(ctypes.Structure):
            _fields_ = [("vk", wintypes.WORD), ("scan", wintypes.WORD), ("flags", wintypes.DWORD), ("time", wintypes.DWORD), ("extra", ctypes.c_void_p)]

        class IN(ctypes.Structure):
            class U(ctypes.Union):
                _fields_ = [("ki", KI), ("pad", ctypes.c_byte * 32)]
            _anonymous_ = ("u",)
            _fields_ = [("type", wintypes.DWORD), ("u", U)]

        for ch in text:
            for flags in (0x4, 0x4 | 0x2):                       # KEYEVENTF_UNICODE down / up
                i = IN(1, IN.U(ki=KI(0, ord(ch), flags, 0, None)))
                self.u.SendInput(1, ctypes.byref(i), ctypes.sizeof(IN))
            time.sleep(0.01)

    def key(self, spec: str) -> bool:
        vks = keys_to_vks(spec)
        if not vks:
            return False
        for v in vks:
            self.u.keybd_event(v, 0, 0, 0)
        for v in reversed(vks):
            self.u.keybd_event(v, 0, 2, 0)
        return True

    def drag(self, x1, y1, x2, y2) -> None:
        self.move(x1, y1)
        time.sleep(0.1)
        self.u.mouse_event(0x2, 0, 0, 0, 0)
        for i in range(1, 11):
            self.move(x1 + (x2 - x1) * i / 10, y1 + (y2 - y1) * i / 10)
            time.sleep(0.03)
        self.u.mouse_event(0x4, 0, 0, 0, 0)

    def open_url(self, url: str) -> None:
        import webbrowser
        webbrowser.open(url)

    def open_app(self, name: str) -> None:
        import subprocess
        subprocess.Popen(f'start "" "{name}"', shell=True)               # name is restricted to letters, digits, space . _ -

    def scroll(self, amount: int) -> None:
        self.u.mouse_event(0x800, 0, 0, int(-amount * 120) & 0xFFFFFFFF, 0)


class ScreenAgent:
    def __init__(self, capture: Callable[[], bytes], vision: Callable[[str, str, bytes], str], inp, say: Callable[[str], None]):
        self.capture, self.vision, self.inp, self.say = capture, vision, inp, say
        self.running = False
        self.stop_flag = False

    def stop(self) -> None:
        self.stop_flag = True

    def run(self, goal: str) -> str:
        """Blocking; call from a worker thread. Returns the final message for the user."""
        if self.running:
            return "Main pehle se ek kaam kar rahi hoon. 'ruko' bolo."
        if RISKY.search(goal):
            return "Ye kaam paise, password ya delete/install se juda lag raha hai, isliye main ise khud nahi karungi. Aap khud kar lijiye ya aasaan karke bolo."
        self.running, self.stop_flag = True, False
        history: List[str] = []
        try:
            for step in range(1, MAX_STEPS + 1):
                if self.stop_flag:
                    return "Ruk gayi. 🛑"
                try:
                    raw = self.vision(SYSTEM, f"GOAL: {goal}\nSteps so far: {'; '.join(history[-12:]) or 'none'}\nStep {step}/{MAX_STEPS}. What is the next single action?", self.capture())
                except Exception as exc:  # noqa: BLE001
                    log.warning("vision failed: %s", exc)
                    return "Screen samajhne wala AI abhi chal nahi raha (internet ya key check karo)."
                a = parse_action(raw)
                if not a:
                    history.append("(unclear reply)")
                    if len([h for h in history if h == "(unclear reply)"]) >= 3:
                        return "Mujhe screen par agla kadam samajh nahi aaya, isliye ruk gayi."
                    continue
                kind = a["action"]
                if kind == "done":
                    return a.get("say") or "Ho gaya! ✅"
                if kind == "ask":
                    return a.get("say") or "Mujhe aapki madad chahiye."
                if kind == "type" and RISKY.search(" ".join(history[-2:])):
                    return "Yahan password/payment jaisa kuch lag raha hai, isliye main ruk gayi. Aap khud daal do."
                try:
                    if kind in ("click", "double_click", "right_click"):
                        self.inp.click(a["x"], a["y"], kind)
                        history.append(f"{kind} ({a['x']},{a['y']})")
                    elif kind == "type":
                        self.inp.type_text(a["text"])
                        history.append(f"typed '{a['text'][:30]}'")
                    elif kind == "key":
                        if not self.inp.key(a["keys"]):
                            history.append(f"bad key {a['keys']}")
                            continue
                        history.append(f"key {a['keys']}")
                    elif kind == "drag":
                        self.inp.drag(a["x"], a["y"], a["x2"], a["y2"])
                        history.append(f"drag ({a['x']},{a['y']})->({a['x2']},{a['y2']})")
                    elif kind == "open_url":
                        self.inp.open_url(a["url"])
                        history.append(f"opened {a['url'][:50]}")
                        time.sleep(2.0)
                    elif kind == "open_app":
                        self.inp.open_app(a["name"])
                        history.append(f"opened app {a['name']}")
                        time.sleep(2.0)
                    elif kind == "say":
                        self.say(a["say"])
                        history.append("said something")
                    elif kind == "scroll":
                        self.inp.scroll(int(a.get("amount", 3)))
                        history.append("scrolled")
                    else:
                        history.append("waited")
                except Exception:  # noqa: BLE001
                    log.exception("input failed")
                    return "Mouse/keyboard control nahi ho paaya (kisi admin app par ho sakta hai)."
                if len(history) >= 3 and len(set(history[-3:])) == 1:
                    history.append("(same action 3 times, no progress - try something different or finish with ask/done)")
                time.sleep(1.1)
            return "Itne steps me kaam poora nahi hua. Thoda aasaan karke ya chhote hisson me bolo."
        finally:
            self.running = False
