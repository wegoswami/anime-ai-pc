"""Parse 'remind me in 10 minutes to drink water' / '10 minute baad paani peene ka yaad dilana'."""
import re
from typing import Optional

_NUM = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "ten": 10, "fifteen": 15,
        "twenty": 20, "thirty": 30, "half an": 0.5, "half": 0.5, "ek": 1, "do": 2, "teen": 3, "paanch": 5,
        "das": 10, "adha": 0.5, "आधा": 0.5, "एक": 1, "दो": 2, "पाँच": 5, "दस": 10}
_UNIT = r"(sec(?:ond)?s?|min(?:ute)?s?|hours?|hrs?|ghant(?:e|a)|ghanta|सेकंड|मिनट|घंटे|घंटा)"
_DUR = re.compile(r"(\d+(?:\.\d+)?|half an|half|an|a|one|two|three|four|five|ten|fifteen|twenty|thirty|ek|do|teen|"
                  r"paanch|das|adha|आधा|एक|दो|पाँच|दस)\s*" + _UNIT, re.I)
_TRIGGER = re.compile(r"remind|yaad dila|yaad dilana|याद दिला|alarm|timer", re.I)
_FILLERS = re.compile(r"\b(remind me|remind|yaad dilana|yaad dilao|yaad dila do|yaad dila|please|in|after|baad|"
                      r"ke baad|mein|me|to|that|about|mujhe|ki|ko|set a timer for|timer|alarm)\b|याद दिलाना|याद दिला|"
                      r"बाद|मुझे", re.I)


def parse(text: str) -> Optional[tuple]:
    """Return (seconds, what) or None."""
    t = text.strip()
    if not _TRIGGER.search(t):
        return None
    m = _DUR.search(t)
    if not m:
        return None
    raw = m.group(1).lower()
    n = float(raw) if raw.replace(".", "", 1).isdigit() else _NUM.get(raw, 1)
    unit = m.group(2).lower()
    if unit.startswith(("sec", "सेकंड")):
        secs = n
    elif unit.startswith(("min", "मिनट")):
        secs = n * 60
    else:
        secs = n * 3600
    rest = (t[:m.start()] + " " + t[m.end():])
    what = re.sub(r"\s+", " ", _FILLERS.sub(" ", rest)).strip(" .,!?")
    return max(1.0, secs), what
