"""Parse 'remind me in 10 minutes to drink water' / '10 minute baad paani peene ka yaad dilana' and clock times
('remind me at 6 pm to call mom', 'kal subah 7 baje alarm', 'wake me up at 6')."""
import re
from datetime import datetime, timedelta
from typing import Optional

_NUM = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "ten": 10, "fifteen": 15,
        "twenty": 20, "thirty": 30, "half an": 0.5, "half": 0.5, "ek": 1, "do": 2, "teen": 3, "paanch": 5,
        "das": 10, "adha": 0.5, "आधा": 0.5, "एक": 1, "दो": 2, "पाँच": 5, "दस": 10}
_UNIT = r"(sec(?:ond)?s?|min(?:ute)?s?|hours?|hrs?|ghant(?:e|a)|ghanta|सेकंड|मिनट|घंटे|घंटा)"
_DUR = re.compile(r"(\d+(?:\.\d+)?|half an|half|an|a|one|two|three|four|five|ten|fifteen|twenty|thirty|ek|do|teen|"
                  r"paanch|das|adha|आधा|एक|दो|पाँच|दस)\s*" + _UNIT, re.I)
_TRIGGER = re.compile(r"remind|yaad dila|yaad dilana|याद दिला|alarm|timer|wake me|wake up|jagana|jaga do|जगाना|अलार्म", re.I)
_FILLERS = re.compile(r"\b(remind me|remind|yaad dilana|yaad dilao|yaad dila do|yaad dila|please|set|in|after|baad|"
                      r"ke baad|mein|me|to|that|about|mujhe|ki|ko|set a timer for|timer|alarm)\b|याद दिलाना|याद दिला|"
                      r"बाद|मुझे|\b(an|a|for|up|the|my|wake|tomorrow|kal|today|aaj|subah|morning|shaam|evening|raat|night|dopahar|afternoon|at)\b|सुबह|शाम|रात|कल|आज", re.I)
_CLOCK = [re.compile(r"(?<!\d)(\d{1,2})(?::(\d{2}))?\s*(am|pm|baje|bje|बजे)", re.I), re.compile(r"(?<!\d)(\d{1,2}):(\d{2})()(?!\d)"),
          re.compile(r"\b(?:at|by|around|for)\s+(\d{1,2})(?::(\d{2}))?()(?!\d)", re.I)]


def _has(t: str, *words: str) -> bool:
    return any(re.search(r"(?<![a-z])" + w + r"(?![a-z])", t) if w.isascii() else w in t for w in words)


def parse_clock(text: str, now: Optional[datetime] = None) -> Optional[tuple]:
    """'remind me at 6 pm to call mom' -> (seconds until then, 'call mom'); None if no clock time."""
    t = text.lower()
    m = next((x for x in (c.search(t) for c in _CLOCK) if x), None)
    if not m:
        return None
    h, mi, mark = int(m.group(1)), int(m.group(2) or 0), (m.group(3) or "").lower()
    if h > 23 or mi > 59:
        return None
    morning = _has(t, "subah", "savere", "morning", "wake", "jagana", "सुबह", "सवेरे")
    noon, eve, night = _has(t, "dopahar", "afternoon", "दोपहर"), _has(t, "shaam", "evening", "शाम"), _has(t, "raat", "night", "रात")
    fixed = True
    if mark == "pm" or eve or noon:
        h += 12 if h < 12 else 0
    elif mark == "am" or morning:
        h = 0 if h == 12 else h
    elif night:
        h = 0 if h == 12 else (h + 12 if h >= 6 else h)
    else:
        fixed = h > 12                                         # plain "7 baje": whichever comes next
    now = now or datetime.now()
    at = now.replace(hour=h, minute=mi, second=0, microsecond=0)
    if _has(t, "tomorrow", "kal", "कल"):
        at += timedelta(days=1)
    elif at <= now:
        at = at + timedelta(hours=12) if (not fixed and h < 12 and at + timedelta(hours=12) > now) else at + timedelta(days=1)
    rest = t[:m.start()] + " " + t[m.end():]
    what = re.sub(r"\s+", " ", _FILLERS.sub(" ", rest)).strip(" .,!?")
    return max(1.0, (at - now).total_seconds()), what


def parse(text: str) -> Optional[tuple]:
    """Return (seconds, what) or None."""
    t = text.strip()
    if not _TRIGGER.search(t):
        return None
    m = _DUR.search(t)
    if not m:
        return parse_clock(t)
    raw = m.group(1).lower()
    n = float(raw) if raw.replace(".", "", 1).isdigit() else _NUM.get(raw, 1)
    unit = m.group(2).lower()
    if unit.startswith(("sec", "सेकंड")):
        secs = n
    elif unit.startswith(("min", "मिनट")):
        secs = n * 60
    else:
        secs = n * 3600
    rest = (t[:m.start()] + " " + t[m.end():])
    what = re.sub(r"\s+", " ", _FILLERS.sub(" ", rest)).strip(" .,!?")
    return max(1.0, secs), what
