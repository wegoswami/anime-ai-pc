"""Routines: one phrase runs a whole sequence ("Start Work Mode" -> open apps, set focus, greet...).

Stored in routines.json in the user's data folder, so they are easy to edit or share. Steps:
  {"say": "text"}  {"open": "chrome"}  {"url": "https://..."}  {"search": "lofi music"}  {"wait": 2}
  {"focus": 60} (stay quiet for N minutes)  {"lock": true}  {"screen": "what am I working on?"}  {"command": "any normal command"}
"""
import json
import logging
import re
import threading
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional

log = logging.getLogger(__name__)

DEFAULT = {
    "work mode": {"triggers": ["work mode", "kaam shuru", "start work", "काम शुरू", "वर्क मोड"], "steps": [
        {"say": "Work mode on! Let's get things done."}, {"open": "chrome"}, {"wait": 2},
        {"url": "https://calendar.google.com"}, {"focus": 60}, {"say": "I'll stay quiet for an hour. You've got this!"}]},
    "study mode": {"triggers": ["study mode", "padhai shuru", "padhai mode", "स्टडी मोड"], "steps": [
        {"say": "Study mode! Phone down, focus up."}, {"open": "chrome"}, {"focus": 45}]},
    "break time": {"triggers": ["break time", "break mode", "chai break", "ब्रेक टाइम"], "steps": [
        {"say": "Break time! Stretch, drink some water, rest your eyes."}, {"focus": 0}]},
    "good night": {"triggers": ["good night mode", "sone ja raha", "so jata hu", "good night routine"], "steps": [
        {"say": "Good night! Sleep well. I'll lock the screen."}, {"wait": 3}, {"lock": True}]},
}


class Routines:
    def __init__(self, path: Path, runner: Dict[str, Callable]):
        self.path = Path(path)
        self.runner = runner            # step handlers: say/command/url/focus/lock/screen/open/search
        self.data: Dict[str, dict] = {}
        self.running = False
        self.load()

    def load(self) -> None:
        try:
            self.data = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            self.data = json.loads(json.dumps(DEFAULT))
            try:
                self.path.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")
            except OSError:
                pass

    def match(self, text: str) -> Optional[str]:
        t = " ".join(re.sub(r"[^\wऀ-ॿ ]", " ", text.lower()).split())
        if len(t.split()) > 9:
            return None
        for name, r in self.data.items():
            if t == name or any(trig.lower() in t for trig in r.get("triggers", [])):
                return name
        return None

    def names(self) -> List[str]:
        return list(self.data)

    def run(self, name: str) -> str:
        r = self.data.get(name)
        if not r or self.running:
            return ""
        self.running = True

        def go():
            try:
                for st in r.get("steps", []):
                    for key, val in st.items():
                        fn = self.runner.get(key)
                        try:
                            if key == "wait":
                                time.sleep(min(float(val), 30))
                            elif fn:
                                fn(val)
                        except Exception:  # noqa: BLE001 - one bad step must not stop the routine
                            log.exception("routine step %s failed", key)
            finally:
                self.running = False

        threading.Thread(target=go, daemon=True).start()
        return name

    def handle_command(self, text: str, lang: str = "en") -> Optional[str]:
        if re.match(r"(?i)^\s*(?:my routines|routines dikhao|list routines|show routines|meri routines)\s*$", text):
            return "Routines: " + ", ".join(self.names()) + ". Just say the name to start one."
        name = self.match(text)
        if name:
            self.run(name)
            return ""        # the routine speaks for itself
        return None
