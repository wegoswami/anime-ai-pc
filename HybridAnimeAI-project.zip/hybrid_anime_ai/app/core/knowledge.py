"""Offline knowledge base (local RAG): index folders of notes/PDF/Word/text and answer from them with no internet.

Chunks + hashed vectors live in one SQLite file. Re-indexing only touches files that changed.
"""
import json
import logging
import re
import sqlite3
import threading
import zipfile
from pathlib import Path
from typing import Callable, List, Optional, Tuple

from .memory import cosine, embed

log = logging.getLogger(__name__)
TEXT_EXT = {".txt", ".md", ".csv", ".json", ".py", ".log", ".html", ".htm", ".rtf"}
MAX_FILE = 8 * 1024 * 1024
CHUNK = 700
_INDEX = re.compile(r"^(?:index|add|scan)\s+(?:folder|directory)\s+(.+)$|^(?:folder|folder ko)\s+(.+?)\s+(?:index|yaad)\s*(?:karo|kro)?$", re.I)
_ASK = re.compile(r"^(?:from my (?:docs|files|notes|knowledge)|(?:meri )?(?:docs|files|notes) (?:me|mein|se)|knowledge (?:me|se))\s*[:,\-]?\s*(.{3,200})$", re.I)


def _read(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in TEXT_EXT:
        raw = path.read_bytes()
        txt = raw.decode("utf-8", errors="ignore")
        return re.sub(r"<[^>]+>", " ", txt) if ext in (".html", ".htm") else txt
    if ext == ".docx":
        with zipfile.ZipFile(path) as z:
            xml = z.read("word/document.xml").decode("utf-8", errors="ignore")
        return re.sub(r"<[^>]+>", " ", xml.replace("</w:p>", "\n"))
    if ext == ".pdf":
        try:
            from pypdf import PdfReader  # optional dependency
        except ImportError:
            return ""
        return "\n".join((pg.extract_text() or "") for pg in PdfReader(str(path)).pages[:200])
    return ""


def _chunks(text: str) -> List[str]:
    text = re.sub(r"[ \t]+", " ", text)
    paras = [p.strip() for p in re.split(r"\n{2,}|(?<=[.!?।])\s+(?=[A-Zऀ-ॿ])", text) if p.strip()]
    out, cur = [], ""
    for p in paras:
        if len(cur) + len(p) > CHUNK and cur:
            out.append(cur)
            cur = ""
        cur += (" " if cur else "") + p
    if cur:
        out.append(cur)
    return [c[:1500] for c in out]


class Knowledge:
    def __init__(self, path):
        self.path = str(path)
        self.lock = threading.Lock()
        with self._db() as db:
            db.execute("CREATE TABLE IF NOT EXISTS chunks(id INTEGER PRIMARY KEY, file TEXT, mtime REAL, text TEXT, vec TEXT)")
            db.execute("CREATE INDEX IF NOT EXISTS ix_file ON chunks(file)")

    def _db(self):
        return sqlite3.connect(self.path, timeout=10)

    def index_folder(self, folder: str, progress: Optional[Callable[[str], None]] = None) -> Tuple[int, int]:
        """Returns (files_indexed, chunks_added). Safe to call repeatedly."""
        root = Path(folder).expanduser()
        if not root.is_dir():
            raise FileNotFoundError(folder)
        files = chunks = 0
        with self.lock, self._db() as db:
            for f in root.rglob("*"):
                try:
                    if not f.is_file() or f.suffix.lower() not in TEXT_EXT | {".pdf", ".docx"} or f.stat().st_size > MAX_FILE:
                        continue
                    mt = f.stat().st_mtime
                    row = db.execute("SELECT mtime FROM chunks WHERE file=? LIMIT 1", (str(f),)).fetchone()
                    if row and abs(row[0] - mt) < 1:
                        continue
                    db.execute("DELETE FROM chunks WHERE file=?", (str(f),))
                    for c in _chunks(_read(f)):
                        db.execute("INSERT INTO chunks(file,mtime,text,vec) VALUES(?,?,?,?)", (str(f), mt, c, json.dumps(embed(c))))
                        chunks += 1
                    files += 1
                    if progress and files % 10 == 0:
                        progress(f"{files} files…")
                except Exception:  # noqa: BLE001 - one unreadable file never stops the scan
                    log.info("skipped %s", f)
        return files, chunks

    def search(self, query: str, k: int = 4) -> List[Tuple[float, str, str]]:
        qv = embed(query)
        with self._db() as db:
            rows = db.execute("SELECT file,text,vec FROM chunks").fetchall()
        scored = [(cosine(qv, json.loads(v)), f, t) for f, t, v in rows]
        return sorted([s for s in scored if s[0] > 0.12], reverse=True)[:k]

    def count(self) -> int:
        with self._db() as db:
            return db.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]

    def clear(self) -> None:
        with self.lock, self._db() as db:
            db.execute("DELETE FROM chunks")

    def context_for(self, query: str) -> str:
        hits = self.search(query)
        if not hits:
            return ""
        return "From the user's own files:\n" + "\n".join(f"- ({Path(f).name}) {t[:400]}" for _s, f, t in hits)

    # ---- chat commands
    @staticmethod
    def parse_index(text: str) -> Optional[str]:
        m = _INDEX.match(text.strip())
        return (m.group(1) or m.group(2)).strip().strip('"') if m else None

    @staticmethod
    def parse_ask(text: str) -> Optional[str]:
        m = _ASK.match(text.strip())
        return m.group(1).strip() if m else None
