"""Adapt: the assistant reshapes itself around the user. Everything is stored in one small JSON file on this PC.

  Prefs  - how it talks (length, tone, language, what it calls you, its own name), changed just by saying so
  Teach  - routines/shortcuts the user teaches in plain words ("jab main good morning bolu to news batao phir weather")
  Auto   - things that run by themselves every day at a set time ("roz subah 7 baje news batao")
  Habits - notices what you repeat at the same time of day and OFFERS to automate it (asks first, never silent)
  Draft  - writes a message in your style; you press send yourself

`Adapt.handle(text, ll)` returns None when the text is not an Adapt command, else an `Outcome` with the reply and
optional steps for the controller to run one after another.
"""
import json
import logging
import re
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Callable, List, NamedTuple, Optional
from urllib.parse import quote

from . import reminders

log = logging.getLogger(__name__)


class Outcome(NamedTuple):
    reply: str
    steps: tuple = ()          # commands to run one after another (a taught routine)
    draft: tuple = ()          # (kind, who, points) -> the controller asks the AI to write it
    open_url: str = ""         # something to open (a prepared message)


def _norm(t: str) -> str:
    return " ".join(re.sub(r"[^\wऀ-ॿ:+\-*/.% ]", " ", t.lower()).split())


def _clean(n: str) -> str:
    return re.sub(r"[\s.!?]+$", "", n)


def _M(ll: str, en: str, hing: str, hi: str = "") -> str:
    return {"en": en, "hi": hi or hing}.get(ll, hing)


_STEP_SPLIT = re.compile(r"\s*(?:,|;|\bphir\b|\bfir\b|\bthen\b|\band then\b|\baur phir\b|\buske baad\b)\s*", re.I)
_SENSITIVE = re.compile(r"\b(?:call|sms|whatsapp|message|record|pay|send|bhejo|delete|hatao|lock|screenshot|password|otp|key)\b")


class Adapt:
    def __init__(self, path: Path, cfg: dict, save_cfg: Optional[Callable[[], None]] = None):
        self.path = Path(path)
        self.cfg = cfg
        self.save_cfg = save_cfg or (lambda: None)
        self._lock = threading.RLock()
        d = {}
        try:
            d = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001 - first run or a damaged file: start fresh
            pass
        self.prefs = {"len": "", "tone": "", "lang": ""}
        self.prefs.update(d.get("prefs", {}))
        self.teach: List[dict] = d.get("teach", [])
        self.auto: List[dict] = d.get("auto", [])
        self.habit_data: dict = d.get("habits", {})
        self.habit_no: List[str] = d.get("habits_no", [])
        self.habit_ask = float(d.get("habit_ask", 0))
        self.pending: Optional[dict] = None
        self.draft_last: Optional[dict] = None
        self.running = False                       # a taught routine is executing

    # ------------------------------------------------------------------ storage
    def save(self) -> None:
        with self._lock:
            data = {"prefs": self.prefs, "teach": self.teach, "auto": self.auto, "habits": self.habit_data,
                    "habits_no": self.habit_no, "habit_ask": self.habit_ask}
            try:
                tmp = self.path.with_suffix(".tmp")
                tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
                tmp.replace(self.path)
            except OSError:
                log.exception("could not save adapt data")

    # ------------------------------------------------------------------ prompt for the AI
    def prompt(self) -> str:
        p, b = self.prefs, []
        if p["len"] == "short":
            b.append("Keep every reply to ONE short sentence unless asked for more.")
        if p["len"] == "long":
            b.append("Give detailed, step-by-step answers (up to about 8 sentences) when useful.")
        if p["tone"] == "formal":
            b.append("Speak politely and formally (respectful 'aap').")
        if p["tone"] == "casual":
            b.append("Talk like a close friend, relaxed and informal.")
        if p["tone"] == "funny":
            b.append("Add light humour and playful jokes.")
        if p["tone"] == "serious":
            b.append("Be calm and serious, no jokes.")
        if p["lang"]:
            b.append({"hi": "Always reply in Hindi (Devanagari).", "en": "Always reply in English.",
                      "hinglish": "Always reply in Hinglish (Hindi in Latin letters)."}[p["lang"]])
        return ("The user chose these style rules, they override the defaults above: " + " ".join(b) + " ") if b else ""

    # ------------------------------------------------------------------ entry point
    def handle(self, text: str, ll: str = "hinglish") -> Optional[Outcome]:
        n = _clean(_norm(text))
        if not n:
            return None
        for fn in (self._habit_reply, self._prefs, self._teach, self._auto, self._draft):
            out = fn(text, n, ll)
            if out is not None:
                return out
        return None

    # ------------------------------------------------------------------ Prefs
    def _set(self, key: str, val: str, msg: str) -> Outcome:
        self.prefs[key] = val
        self.save()
        return Outcome(msg)

    def _prefs(self, raw: str, n: str, ll: str) -> Optional[Outcome]:
        M = lambda *a: _M(ll, *a)  # noqa: E731
        if re.fullmatch(r"(?:ab se |aaj se |please )?(?:chhota|chota|chhote|short|brief) (?:jawab|answers?|replies|reply|baat)(?: do| dena| diya karo)?|"
                        r"keep (?:it|replies|answers) short|be brief|short me bolo|short mein bolo|kam bolo|kam shabdon me", n):
            return self._set("len", "short", M("Okay, short answers from now on.", "Theek hai, ab se chhote jawab dungi.", "ठीक है, अब से छोटे जवाब दूँगी।"))
        if re.fullmatch(r"(?:ab se )?(?:lamba|lambe|detail|detailed|vistar se) (?:jawab|answers?|replies|reply)(?: do| dena| diya karo)?|"
                        r"detail me jawab do|always give detailed answers", n):
            return self._set("len", "long", M("Okay, I'll explain in detail.", "Theek hai, ab detail me samjhaungi.", "ठीक है, अब विस्तार से समझाऊँगी।"))
        if re.fullmatch(r"(?:formal|professional|respectful) (?:ho jao|ban jao|raho|mode)|aap se baat karo|aap kehkar baat karo|adab se baat karo", n):
            return self._set("tone", "formal", M("Understood, I'll stay polite and formal.", "Theek hai, ab aap kehkar, adab se baat karungi.", "ठीक है, अब आप कहकर बात करूँगी।"))
        if re.fullmatch(r"(?:(?:friendly|casual|dost jaisi|dost ki tarah) ?(?:ho jao|ban jao|baat karo|mode)?)|tum se baat karo", n):
            return self._set("tone", "casual", M("Cool, back to friend mode!", "Theek hai, ab dost ki tarah baat karungi!", "ठीक है, अब दोस्त की तरह!"))
        if re.fullmatch(r"(?:funny|mazakiya|mazaakiya|masti wali) (?:ho jao|ban jao|raho|mode)|mazak karo|joke wali baat karo", n):
            return self._set("tone", "funny", M("Funny mode on!", "Funny mode on! Ab masti chalegi!", "फनी मोड ऑन!"))
        if re.fullmatch(r"serious (?:ho jao|ban jao|raho|mode)|mazak band(?: karo)?", n):
            return self._set("tone", "serious", M("Okay, serious mode.", "Theek hai, ab serious rahungi.", "ठीक है, अब गंभीर।"))
        if re.fullmatch(r"style reset|apni style reset karo|normal ho jao|pehle jaisi ho jao|reset style", n):
            self.prefs.update({"len": "", "tone": "", "lang": ""})
            self.cfg["language_pref"] = "auto"
            self.save()
            self.save_cfg()
            return Outcome(M("Back to my normal style.", "Pehle jaisi ho gayi.", "पहले जैसी हो गई।"))
        if re.fullmatch(r"gestures? (?:band|off)|ishare band|animations? band", n):
            self.cfg["gestures"] = False
            self.save_cfg()
            return Outcome(M("Gestures off.", "Ishare band kar diye."))
        if re.fullmatch(r"gestures? (?:on|chalu)|ishare chalu|animations? chalu", n):
            self.cfg["gestures"] = True
            self.save_cfg()
            return Outcome(M("Gestures on!", "Ishare chalu!"))
        if re.fullmatch(r"meri style|my style|style dikhao|show style|meri settings dikhao", n):
            p = self.prefs
            ln = {"short": "chhote", "long": "lambe"}.get(p["len"], "normal")
            tn = {"formal": "formal", "casual": "dost jaisa", "funny": "funny", "serious": "serious"}.get(p["tone"], "normal")
            me, you = self.cfg.get("assistant_name") or "Aiko", self.cfg.get("user_name") or "dost"
            return Outcome(M(f"Replies: {ln}. Tone: {tn}. Language: {p['lang'] or 'auto'}. I call you: {you}. My name: {me}.",
                             f"Jawab: {ln}. Tone: {tn}. Bhasha: {p['lang'] or 'auto'}. Main aapko bulati hoon: {you}. Mera naam: {me}. Badalne ke liye bas bol do."))
        for pat, code, en, hing in (
                (r"(?:hindi|हिंदी) (?:me|mein|में) (?:baat|bolo|jawab)|speak hindi", "hi", "Okay, Hindi from now on.", "Theek hai, ab Hindi me."),
                (r"english (?:me|mein) (?:baat|bolo|jawab)|speak english", "en", "Okay, English from now on.", "Theek hai, ab English me."),
                (r"hinglish (?:me|mein) (?:baat|bolo|jawab)", "hinglish", "Okay, Hinglish it is.", "Theek hai, ab Hinglish me."),
                (r"meri bhasha auto|language auto|jis bhasha me bolu usi me", "", "I'll follow your language.", "Jis bhasha me bologe usi me jawab dungi.")):
            if re.match(pat, n):
                self.cfg["language_pref"] = code or "auto"
                self.save_cfg()
                return self._set("lang", code, M(en, hing))
        m = (re.match(r"^\s*(?:mujhe|mereko|meko)\s+(.{2,20}?)\s+(?:bulao|bolna|bolo|kaho|kehna|bula)\s*[.!]*$", raw, re.I)
             or re.match(r"^\s*call me\s+(.{2,20}?)\s*[.!]*$", raw, re.I))
        if m and not re.search(r"\bko\b", m.group(1), re.I):
            self.cfg["user_name"] = m.group(1).strip()
            self.save_cfg()
            return Outcome(M(f"Okay, I'll call you {self.cfg['user_name']}.", f"Theek hai, ab se aapko {self.cfg['user_name']} bulaungi.",
                             f"ठीक है, अब से आपको {self.cfg['user_name']} बुलाऊँगी।"))
        m = (re.match(r"^\s*(?:tumhara|tera|aapka)\s+(?:naam|name)\s+(.{2,20}?)\s+(?:rakh do|rakho|rakhte hain|hai ab se|ho gaya)\s*[.!]*$", raw, re.I)
             or re.match(r"^\s*(?:your name is now|call yourself)\s+(.{2,20}?)\s*[.!]*$", raw, re.I))
        if m:
            self.cfg["assistant_name"] = m.group(1).strip()
            self.save_cfg()
            return Outcome(M(f"I'm {self.cfg['assistant_name']} now!", f"Ab mera naam {self.cfg['assistant_name']} hai!", f"अब मेरा नाम {self.cfg['assistant_name']} है!"))
        return None

    # ------------------------------------------------------------------ Teach
    @staticmethod
    def _steps(body: str) -> List[str]:
        body = re.sub(r"^(?:do|karo|kar do|tum|you)\s+", "", body.strip(), flags=re.I)
        return [s.strip() for s in _STEP_SPLIT.split(body) if s.strip()][:8]

    def _find_routine(self, n: str) -> Optional[dict]:
        core = re.sub(r"\b(?:run|start|chalao|chalu karo|shuru karo|shuru|karo|kro|routine|mode|please|plz|ab|execute)\b", " ", n)
        core = " ".join(core.split())
        for r in self.teach:
            t = r["trig"]
            if core == t or n == t or (len(t.split()) >= 2 and t in n and len(n.split()) <= 9):
                return r
        return None

    def _teach(self, raw: str, n: str, ll: str) -> Optional[Outcome]:
        M = lambda *a: _M(ll, *a)  # noqa: E731
        if re.fullmatch(r"meri routines?|my routines?|routines? dikhao|show routines?|meri commands?|meri shortcuts?", n):
            mine = [f"“{r['name']}” → {' → '.join(r['steps'])}" for r in self.teach]
            tail = (" Yours: " + "; ".join(mine)) if mine else " You haven't taught me any yet. Try: “jab main good morning bolu to news batao phir weather”."
            tail_h = (" Aapke sikhaye: " + "; ".join(mine)) if mine else " Aapne abhi koi nahi sikhaya. Try karo: “jab main good morning bolu to news batao phir weather”."
            return Outcome(M(tail.strip(), tail_h.strip()))
        m = (re.match(r"^\s*(?:routine|shortcut|command)\s+(?:hatao|hata do|delete|remove|mita do)\s+(.{2,30}?)\s*$", raw, re.I)
             or re.match(r"^\s*(?:delete|remove)\s+(?:the\s+)?(?:routine|shortcut)\s+(.{2,30}?)\s*$", raw, re.I))
        if m:
            k = _norm(m.group(1))
            before = len(self.teach)
            self.teach = [r for r in self.teach if _norm(r["name"]) != k and r["trig"] != k]
            self.save()
            return Outcome(M(f"Removed “{m.group(1)}”.", f"“{m.group(1)}” hata diya.") if len(self.teach) < before
                           else M("I don't have a routine with that name.", "Is naam ki routine nahi mili."))
        name = body = ""
        m = (re.match(r"^\s*(?:new |nayi |nai )?routine\s+(?:banao|bana|bnao|bana do|add karo|create)\s+(.{2,30}?)\s*[:=\-]\s*(.{3,400})$", raw, re.I)
             or re.match(r"^\s*(?:create|make|add|new)\s+(?:a\s+)?(?:routine|shortcut)\s+(?:called\s+|named\s+)?(.{2,30}?)\s*[:=\-]\s*(.{3,400})$", raw, re.I)
             or re.match(r"^\s*(?:jab|when(?:ever)?|if)\s+(?:main|mai|mein|i)\s+[\"“'‘]?(.{2,40}?)[\"”'’]?\s+(?:bolu|bolun|bolunga|bolta hu|bolta hoon|kahu|kahun|say|type|likhu)\s*,?\s*(?:to|then|toh)?\s*(.{3,400})$", raw, re.I))
        if m:
            name, body = m.group(1), m.group(2)
        if name:
            st = self._steps(body)
            if not st:
                return Outcome(M("Tell me the steps after a colon, like: routine banao subah: news batao, weather batao.",
                                 "Steps colon ke baad bolo, jaise: routine banao subah: news batao, weather batao."))
            if any(re.search(r"routine\s+(?:banao|bana|create)|^jab\s+main", s, re.I) for s in st):
                return Outcome(M("A routine can't create another routine.", "Routine ke andar routine nahi bana sakte."))
            trig = _norm(name)
            self.teach = [r for r in self.teach if r["trig"] != trig]
            self.teach.append({"name": name.strip()[:30], "trig": trig, "steps": st})
            self.save()
            return Outcome(M(f"Learned! When you say “{trig}”, I'll do {len(st)} step(s): {' → '.join(st)}.",
                             f"Seekh liya! Jab aap “{trig}” bologe, main {len(st)} kaam karungi: {' → '.join(st)}.",
                             f"सीख लिया! जब आप “{trig}” बोलोगे, मैं {len(st)} काम करूँगी।"))
        if self.teach and not self.running and len(n.split()) <= 9:        # steps of a running routine never re-trigger routines
            r = self._find_routine(n)
            if r:
                return Outcome(M(f"Running “{r['name']}”…", f"“{r['name']}” chala rahi hoon…"), steps=tuple(r["steps"]))
        return None

    # ------------------------------------------------------------------ Auto (daily jobs)
    @staticmethod
    def _hm(a: dict) -> tuple:
        h, m = a["at"].split(":")
        return int(h), int(m)

    def add_auto(self, at: str, kind: str, text: str) -> dict:
        a = {"id": f"{int(time.time() * 1000)}{len(self.auto)}{int(time.time_ns() % 997)}", "at": at, "kind": kind, "text": text, "last": ""}
        self.auto.append(a)
        self.save()
        return a

    def due(self, now: Optional[datetime] = None) -> List[dict]:
        """Daily jobs whose time has come (within 3 hours after it, once per day). Marks them as done for today."""
        now = now or datetime.now()
        day, out = now.strftime("%Y-%m-%d"), []
        for a in self.auto:
            if a.get("last") == day:
                continue
            h, m = self._hm(a)
            d = (now - now.replace(hour=h, minute=m, second=0, microsecond=0)).total_seconds()
            if 0 <= d <= 3 * 3600:
                a["last"] = day
                out.append(dict(a))
        if out:
            self.save()
        return out

    def _auto(self, raw: str, n: str, ll: str) -> Optional[Outcome]:
        M = lambda *a: _M(ll, *a)  # noqa: E731
        if re.fullmatch(r"mere roz ke kaam|roz ke kaam|my daily tasks|daily tasks|auto list|meri auto list|mere daily kaam", n):
            if not self.auto:
                return Outcome(M("No daily jobs yet. Try: “roz subah 7 baje news batao”.", "Abhi koi roz ka kaam nahi. Try karo: “roz subah 7 baje news batao”."))
            return Outcome("; ".join(f"{i + 1}. {a['at']} {'🔔' if a['kind'] == 'say' else '▶'} {a['text']}" for i, a in enumerate(self.auto)))
        m = re.fullmatch(r"(?:roz ka kaam|daily task|roz ke kaam|auto) (?:hatao|delete|remove|cancel) ?(\d+|sab|saare|all)", n)
        if m:
            if m.group(1) in ("sab", "saare", "all"):
                self.auto = []
            elif 0 < int(m.group(1)) <= len(self.auto):
                self.auto.pop(int(m.group(1)) - 1)
            self.save()
            return Outcome(M("Done, removed.", "Ho gaya, hata diya."))
        m = re.match(r"^\s*(?:roz|rozana|daily|every ?day|everyday|har din|hr din)\s+(.{3,200})$", raw, re.I)
        if m and re.search(r"\d", m.group(1)):
            rest = m.group(1)
            pc = reminders.parse_clock(rest)
            if pc is None:
                return None
            t = datetime.fromtimestamp(time.time() + pc[0])
            at = f"{t.hour:02d}:{t.minute:02d}"
            text = re.sub(r"(?:subah|savere|morning|dopahar|afternoon|shaam|evening|raat|night)\s+", " ", rest, flags=re.I)
            text = re.sub(r"(?:at\s+)?\d{1,2}(?::\d{2})?\s*(?:am|pm|baje|bje|बजे)?", " ", text, count=1, flags=re.I)
            text = " ".join(re.sub(r"\b(?:ko|par|pe)\b", " ", text, flags=re.I).split())
            if len(text) < 2:
                return Outcome(M("What should I do at that time?", "Us waqt kya karna hai?"))
            is_rem = bool(re.match(r"(?i)^(?:remind|reminder|yaad)", text))
            if is_rem:
                text = re.sub(r"(?i)^(?:remind me to|remind me|reminder|yaad dilao|yaad dilana|yaad dila do|yaad)\s*", "", text).strip() or text
            self.add_auto(at, "say" if is_rem else "cmd", text)
            return Outcome(M(f"Done! Every day at {at} I'll {'remind you: ' if is_rem else 'do: '}{text}. (Keep the app running.)",
                             f"Ho gaya! Roz {at} baje main {'yaad dilaungi: ' if is_rem else 'ye karungi: '}{text}. (App chalu rakhna.)"))
        return None

    # ------------------------------------------------------------------ Habits
    def note(self, text: str) -> None:
        if self.cfg.get("memory_enabled", True) is False or self.cfg.get("habits") is False or self.running:
            return
        n = _clean(_norm(text))
        if len(n) < 4 or len(n.split()) > 6 or re.fullmatch(r"haan|ha|han|yes|ok|okay|nahi|nhi|no|thik hai|theek hai|ruko|stop", n) or _SENSITIVE.search(n):
            return
        now = datetime.now()
        day = now.strftime("%Y-%m-%d")
        e = self.habit_data.setdefault(n, {"s": []})
        if not any(x[0] == day for x in e["s"]):
            e["s"].append([day, now.hour * 60 + now.minute])
        e["s"] = e["s"][-6:]
        if len(self.habit_data) > 80:
            self.habit_data = {k: v for k, v in self.habit_data.items() if len(v["s"]) >= 2}
        self.save()

    def find_habit(self, today: Optional[datetime] = None) -> Optional[dict]:
        today = today or datetime.now()
        for cmd, e in self.habit_data.items():
            if cmd in self.habit_no or any(_norm(a["text"]) == cmd for a in self.auto) or len(e["s"]) < 3:
                continue
            last = e["s"][-4:]
            mins = sorted(x[1] for x in last)
            med = mins[len(mins) // 2]
            if all(abs(x - med) <= 50 for x in mins):
                age = (today - datetime.strptime(last[-1][0], "%Y-%m-%d")).days
                if age <= 4:
                    return {"cmd": cmd, "mins": round(med / 5) * 5}
        return None

    def suggest(self, ll: str = "hinglish") -> Optional[str]:
        """Returns the question to ask (and remembers it as pending), at most once a day."""
        if self.cfg.get("habits") is False or self.cfg.get("memory_enabled", True) is False or self.pending or time.time() - self.habit_ask < 86400:
            return None
        f = self.find_habit()
        if not f:
            return None
        at = f"{(f['mins'] // 60) % 24:02d}:{f['mins'] % 60:02d}"
        self.pending = {"cmd": f["cmd"], "at": at, "t": time.time()}
        self.habit_ask = time.time()
        self.save()
        return _M(ll, f"I noticed you often say “{f['cmd']}” around {at}. Want me to do it automatically every day? Say yes or no.",
                  f"Maine dekha aap roz ~{at} baje “{f['cmd']}” bolte ho. Roz apne aap kar du? “haan” ya “nahi” bolo.")

    def _habit_reply(self, raw: str, n: str, ll: str) -> Optional[Outcome]:
        M = lambda *a: _M(ll, *a)  # noqa: E731
        if re.fullmatch(r"habits? (?:band|off|stop)|aadat(?:en)? band", n):
            self.cfg["habits"] = False
            self.habit_data = {}
            self.save_cfg()
            self.save()
            return Outcome(M("I won't track habits anymore and I deleted what I had.", "Ab aadatein track nahi karungi, jo tha wo bhi mita diya."))
        if re.fullmatch(r"habits? (?:on|chalu)|aadat(?:en)? chalu", n):
            self.cfg["habits"] = True
            self.save_cfg()
            return Outcome(M("Habit suggestions are on.", "Aadat suggestions chalu."))
        p = self.pending
        if not p:
            return None
        if time.time() - p["t"] > 600:
            self.pending = None
            return None
        if re.fullmatch(r"haan|ha|han|yes|ok|okay|kar do|kardo|theek hai|thik hai|sure|हाँ|हां", n):
            self.add_auto(p["at"], "cmd", p["cmd"])
            self.pending = None
            return Outcome(M(f"Done! Every day at {p['at']}: {p['cmd']}.", f"Ho gaya! Roz {p['at']} baje: {p['cmd']}."))
        if re.fullmatch(r"nahi|nhi|no|mat karo|rehne do|nope|नहीं", n):
            self.habit_no.append(p["cmd"])
            self.pending = None
            self.save()
            return Outcome(M("Okay, I won't ask about that again.", "Theek hai, ye dobara nahi puchungi."))
        return None

    # ------------------------------------------------------------------ Draft
    def _draft(self, raw: str, n: str, ll: str) -> Optional[Outcome]:
        M = lambda *a: _M(ll, *a)  # noqa: E731
        d = self.draft_last
        if d and time.time() - d["t"] < 600 and re.fullmatch(r"bhejo|bhej do|send|send it|send karo|ye bhej do", n):
            body, url = d["text"], ""
            if d["kind"] == "email":
                s = re.match(r"(?is)\s*subject:\s*(.+?)\n+", body)
                if s:
                    body = body[s.end():]
                url = "mailto:?" + (f"subject={quote(s.group(1))}&" if s else "") + "body=" + quote(body)
            else:
                url = "https://wa.me/?text=" + quote(body)           # sms has no PC app: WhatsApp Web is the closest
            self.draft_last = None
            return Outcome(M("Opening it with your text ready. Pick the contact and press send yourself.",
                             "Text ke saath khol rahi hoon. Contact chuno aur send khud dabao."), open_url=url)
        m = re.match(r"^\s*(?:draft|write|compose|likho|likh do)\s+(?:a\s+|an\s+)?(whatsapp|sms|email|mail|message|msg)\s*(?:to|for|ko)?\s*([^:\-]{0,30}?)\s*[:\-]\s*(.{4,400})$", raw, re.I)
        if m:
            kind, who, pts = m.group(1), m.group(2), m.group(3)
        else:
            m = re.match(r"^\s*([^:\-]{2,30}?)\s+ko\s+(whatsapp|sms|email|mail|message|msg)\s+(?:likho|likh do|draft karo)\s*[:\-]?\s*(.{4,400})$", raw, re.I)
            if not m:
                return None
            who, kind, pts = m.group(1), m.group(2), m.group(3)
        kind = "email" if "mail" in kind.lower() else "sms" if "sms" in kind.lower() else "whatsapp"
        return Outcome(M("Writing the draft…", "Draft likh rahi hoon…"), draft=(kind, who.strip(), pts.strip()))

    def draft_prompt(self, kind: str, who: str, pts: str, soul_prompt: str = "") -> str:
        return (f"Write a short {kind} message{' to ' + who if who else ''} for the user based on these points: {pts}\n"
                f"Write it in the same language and style the user uses. {soul_prompt}{self.prompt()}"
                "Output ONLY the message text, no quotes or explanation, under 80 words."
                + (" Start with a line 'Subject: ...'." if kind == "email" else ""))

    def set_draft(self, kind: str, text: str) -> str:
        self.draft_last = {"kind": kind, "text": text.strip(), "t": time.time()}
        return f"Here's the draft:\n{text.strip()}\n\nSay “bhejo” to open it for sending."
