"""Avatars made from a user's own picture (PNG/JPG/... or animated GIF).

The picture gets puppet animation (breathing, walking bob, tilt, squash & stretch, flipping) plus the same
emotion effects (hearts, sweat drops, zzz ...) as the built-in characters.
"""
import math
from pathlib import Path

from PyQt6.QtCore import QRectF
from PyQt6.QtGui import QMovie, QPainter, QPixmap

from .effects import draw_effects
from .state import CANVAS_H, CANVAS_W, CENTER_X, GROUND_Y

BOX_W, BOX_H = 230.0, 270.0


class ImageAvatar:
    def __init__(self, spec: dict):
        path = str(Path(spec["dir"]) / spec.get("file", "avatar.png"))
        self.movie = None
        self.pix = None
        if spec.get("type") == "gif":
            self.movie = QMovie(path)
            self.movie.setCacheMode(QMovie.CacheMode.CacheAll)
            self.movie.start()
        else:
            self.pix = QPixmap(path)
        self.pack = {}                                   # photo pack: one picture per mood / talking
        for k, fn in (spec.get("states") or {}).items():
            pm = QPixmap(str(Path(spec["dir"]) / fn))
            if not pm.isNull():
                self.pack[k] = pm
        if self.pack and (self.pix is None or self.pix.isNull()):
            self.pix = self.pack.get("neutral") or next(iter(self.pack.values()))

    def _pixmap(self, st=None) -> QPixmap:
        if self.movie:
            return self.movie.currentPixmap()
        if self.pack and st is not None:
            if st.speaking and "talk" in self.pack and int(st.t * 7) % 2 == 0:
                return self.pack["talk"]
            pose = getattr(st, "pose", "")
            if "blink" in self.pack and st.blink > 0.5 and not st.speaking and st.emotion == "neutral" and not pose.startswith("sleep"):
                return self.pack["blink"]
            key = "sleepy" if pose in ("sleep", "sleep_edge") else st.emotion
            return self.pack.get(key) or self.pack.get("neutral") or self.pix
        return self.pix

    def paint(self, p: QPainter, w: float, h: float, st) -> None:
        pm = self._pixmap(st)
        if pm is None or pm.isNull():
            return
        s = min(w / CANVAS_W, h / CANVAS_H)
        p.save()
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        p.translate((w - CANVAS_W * s) / 2.0, h - CANVAS_H * s)
        p.scale(s, s)

        iw, ih = float(pm.width()), float(pm.height())
        k = min(BOX_W / iw, BOX_H / ih)
        dw, dh = iw * k, ih * k
        t, pose = st.t, st.pose

        breathe = 1.0 + 0.018 * math.sin(t * 2.2)
        sx, sy, dy, rot, dx = 1.0, breathe, 0.0, 0.0, 0.0
        if pose == "walk":
            sy = 1.0 + 0.03 * abs(math.sin(st.walk_phase))
            dy = -abs(math.sin(st.walk_phase)) * 9
            rot = math.sin(st.walk_phase) * 4.5
        elif pose in ("sit_edge", "sit_ground"):
            sy, dy = 0.9 * breathe, 0.0
        elif pose in ("sleep", "sleep_edge"):
            sy, rot = 0.88 * breathe, 9.0
        elif pose == "wave":
            rot = math.sin(t * 9) * 6
        elif pose == "held":
            rot = math.sin(t * 6) * 10
        elif pose in ("fall", "jump"):
            sx, sy = 0.92, 1.08
        if st.speaking:
            sy *= 1.0 + 0.025 * abs(math.sin(t * 13))
        if st.emotion == "happy":
            dy -= abs(math.sin(t * 5)) * 4
        elif st.emotion == "angry":
            dx += math.sin(t * 40) * 1.4
        elif st.emotion == "sad":
            sy *= 0.97
        if pose in ("sit_edge", "sleep_edge"):
            base_y = GROUND_Y + 8.0          # seat on the surface, legs (if any) hang below
        else:
            base_y = GROUND_Y
        dh_eff = dh * sy
        p.translate(CENTER_X + dx, base_y + dy)
        p.rotate(rot)
        p.scale(float(st.facing) * sx, 1.0)
        p.drawPixmap(QRectF(-dw / 2, -dh_eff, dw, dh_eff), pm, QRectF(0.0, 0.0, iw, ih))
        p.restore()

        # effects float above the picture
        p.save()
        p.translate((w - CANVAS_W * s) / 2.0, h - CANVAS_H * s)
        p.scale(s, s)
        top = base_y - dh_eff
        draw_effects(p, st, CENTER_X, top + dh * 0.22, min(70.0, dw * 0.32))
        p.restore()
