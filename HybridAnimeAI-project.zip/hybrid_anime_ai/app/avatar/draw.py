"""Small drawing helpers shared by the avatar renderers (only the strict PyQt6 overloads)."""
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QBrush, QColor, QPainterPath, QPen


def rgb(hexstr: str):
    h = hexstr.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def col(hexstr: str, alpha: float = 1.0) -> QColor:
    r, g, b = rgb(hexstr)
    return QColor(r, g, b, max(0, min(255, int(round(alpha * 255)))))


def shade(hexstr: str, f: float) -> str:
    """f < 1 darkens, f > 1 lightens (towards white). Returns '#rrggbb'."""
    r, g, b = rgb(hexstr)
    if f <= 1:
        r, g, b = (int(c * f) for c in (r, g, b))
    else:
        k = f - 1
        r, g, b = (int(c + (255 - c) * k) for c in (r, g, b))
    return "#%02x%02x%02x" % (max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b)))


def mix(a: str, b: str, t: float) -> str:
    ra, ga, ba = rgb(a)
    rb, gb, bb = rgb(b)
    return "#%02x%02x%02x" % (int(ra + (rb - ra) * t), int(ga + (gb - ga) * t), int(ba + (bb - ba) * t))


def pen(color, width: float) -> QPen:
    p = QPen(color, width)
    p.setCapStyle(Qt.PenCapStyle.RoundCap)
    p.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    return p


def fill(p, color) -> None:
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QBrush(color))


def heart_path(cx: float, cy: float, s: float) -> QPainterPath:
    h = QPainterPath()
    h.moveTo(cx, cy + s * 0.95)
    h.cubicTo(cx - s * 1.7, cy - s * 0.1, cx - s * 0.8, cy - s * 1.25, cx, cy - s * 0.45)
    h.cubicTo(cx + s * 0.8, cy - s * 1.25, cx + s * 1.7, cy - s * 0.1, cx, cy + s * 0.95)
    h.closeSubpath()
    return h


def sparkle_path(cx: float, cy: float, s: float) -> QPainterPath:
    q = QPainterPath()
    q.moveTo(cx, cy - s)
    q.quadTo(cx, cy, cx + s, cy)
    q.quadTo(cx, cy, cx, cy + s)
    q.quadTo(cx, cy, cx - s, cy)
    q.quadTo(cx, cy, cx, cy - s)
    q.closeSubpath()
    return q
