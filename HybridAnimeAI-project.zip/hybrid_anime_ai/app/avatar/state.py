"""State shared by every avatar type. Pure data - no Qt import."""
from dataclasses import dataclass

# Canvas every avatar draws into (logical units). The pet window scales it uniformly.
CANVAS_W, CANVAS_H = 300.0, 410.0
CENTER_X = 150.0
GROUND_Y = 335.0          # y (in canvas units) where the feet / seat rest on a surface

EMOTIONS = ("neutral", "happy", "love", "sad", "angry", "surprised", "thinking",
            "embarrassed", "sleepy", "confused", "listening")
POSES = ("stand", "walk", "sit_edge", "sit_ground", "sleep", "sleep_edge", "wave", "held", "fall", "jump")


@dataclass
class AvatarState:
    emotion: str = "neutral"
    pose: str = "stand"
    facing: int = 1            # 1 = looks right, -1 = looks left
    t: float = 0.0             # running clock (seconds)
    walk_phase: float = 0.0    # radians, advances while walking
    effect_t: float = 0.0      # seconds since the current emotion started
    mouth: float = 0.0         # 0..1 lip-sync openness
    blink: float = 0.0         # 0 open .. 1 closed
    look: tuple = (0.0, 0.0)   # -1..1 gaze direction (towards the cursor)
    speaking: bool = False
    listening: bool = False
