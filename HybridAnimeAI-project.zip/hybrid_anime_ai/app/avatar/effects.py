"""Floating emotion effects (hearts, sweat drops, zzz ...) drawn around the head. Shared by all avatars."""
import math

from PyQt6.QtCore import QPointF
from PyQt6.QtGui import QPainterPath

from .draw import col, fill, heart_path, pen, sparkle_path

EFFECT_FOR = {"love": "hearts", "happy": "sparkles", "angry": "vein", "surprised": "exclaim",
              "thinking": "dots", "embarrassed": "sweat", "sleepy": "zzz", "confused": "question",
              "listening": "waves", "sad": "rain"}


def effect_name(st) -> str:
    if st.pose.startswith("sleep"):
        return "zzz"
    return EFFECT_FOR.get(st.emotion, "")


def draw_effects(p, st, hx: float, hy: float, r: float) -> None:
    """(hx, hy) = head centre in canvas units, r = head radius."""
    name = effect_name(st)
    if not name:
        return
    fn = _FX.get(name)
    if fn:
        p.save()
        fn(p, st, hx, hy, r)
        p.restore()


def _hearts(p, st, hx, hy, r):
    for i in range(3):
        ph = (st.t * 0.6 + i / 3.0) % 1.0
        x = hx + (i - 1) * r * 0.75 + math.sin(st.t * 2 + i * 2) * 8
        y = hy - r * 0.9 - ph * 46
        p.setOpacity(max(0.0, 1.0 - ph) * 0.95)
        fill(p, col("#ff5c8a"))
        p.drawPath(heart_path(x, y, 7 + (1 - ph) * 4))
    p.setOpacity(1.0)


def _sparkles(p, st, hx, hy, r):
    spots = ((-1.0, -0.55), (1.05, -0.35), (0.75, -0.95))
    for i, (ox, oy) in enumerate(spots):
        s = 5 + 4 * (0.5 + 0.5 * math.sin(st.t * 5 + i * 2))
        p.setOpacity(0.55 + 0.45 * math.sin(st.t * 5 + i * 2 + 1) ** 2)
        fill(p, col("#ffd84a"))
        p.drawPath(sparkle_path(hx + ox * r, hy + oy * r, s))
    p.setOpacity(1.0)


def _sweat(p, st, hx, hy, r):
    x, y = hx + r * 0.95, hy - r * 0.35 + math.sin(st.t * 3) * 2
    d = QPainterPath()
    d.moveTo(x, y - 12)
    d.cubicTo(x + 9, y, x + 8, y + 10, x, y + 10)
    d.cubicTo(x - 8, y + 10, x - 9, y, x, y - 12)
    d.closeSubpath()
    fill(p, col("#7cc8ff"))
    p.setOpacity(0.95)
    p.drawPath(d)
    fill(p, col("#ffffff", 0.9))
    p.drawEllipse(QPointF(x - 2.5, y + 2), 2.2, 3.2)


def _vein(p, st, hx, hy, r):
    x, y = hx + r * 0.72, hy - r * 0.78
    k = 1.0 + 0.12 * math.sin(st.t * 14)
    p.setPen(pen(col("#e8323c"), 3.2))
    for sx, sy in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
        a = QPainterPath()
        a.moveTo(x + sx * 3 * k, y + sy * 3 * k)
        a.quadTo(x + sx * 10 * k, y + sy * 3 * k, x + sx * 11 * k, y + sy * 11 * k)
        p.drawPath(a)


def _exclaim(p, st, hx, hy, r):
    s = 1.0 + 0.12 * math.sin(st.t * 12)
    x, y = hx + r * 0.9, hy - r * 0.95
    fill(p, col("#ff9a1f"))
    bar = QPainterPath()
    bar.addRoundedRect(x - 4 * s, y - 20 * s, 8 * s, 22 * s, 4 * s, 4 * s)
    p.drawPath(bar)
    p.drawEllipse(QPointF(x, y + 9 * s), 4.6 * s, 4.6 * s)


def _question(p, st, hx, hy, r):
    x, y = hx + r * 0.9, hy - r * 0.9 + math.sin(st.t * 4) * 2
    p.setPen(pen(col("#7b6cff"), 4.6))
    q = QPainterPath()
    q.moveTo(x - 8, y - 12)
    q.cubicTo(x - 8, y - 26, x + 12, y - 26, x + 10, y - 12)
    q.cubicTo(x + 9, y - 4, x, y - 4, x, y + 5)
    p.drawPath(q)
    fill(p, col("#7b6cff"))
    p.drawEllipse(QPointF(x, y + 14), 3.4, 3.4)


def _dots(p, st, hx, hy, r):
    fill(p, col("#9a8cff"))
    for i in range(3):
        k = 0.5 + 0.5 * math.sin(st.t * 4 - i * 0.9)
        p.setOpacity(0.35 + 0.65 * k)
        p.drawEllipse(QPointF(hx + r * 0.62 + i * 15, hy - r * 0.98 - i * 7), 3.8 + 2.6 * k, 3.8 + 2.6 * k)
    p.setOpacity(1.0)


def _zzz(p, st, hx, hy, r):
    for i in range(3):
        ph = (st.t * 0.35 + i / 3.0) % 1.0
        s = 7 + i * 3
        x = hx + r * 0.7 + ph * 26
        y = hy - r * 0.6 - ph * 44
        p.setOpacity(max(0.0, 1.0 - ph) * 0.95)
        p.setPen(pen(col("#6d78ff"), 3.0))
        z = QPainterPath()
        z.moveTo(x - s, y - s)
        z.lineTo(x + s, y - s)
        z.lineTo(x - s, y + s)
        z.lineTo(x + s, y + s)
        p.drawPath(z)
    p.setOpacity(1.0)


def _waves(p, st, hx, hy, r):
    for side in (-1, 1):
        for i in range(3):
            k = (st.t * 1.6 + i * 0.33) % 1.0
            rad = r * (1.12 + k * 0.4)
            p.setOpacity(max(0.0, 1.0 - k) * 0.8)
            p.setPen(pen(col("#59b7ff"), 3.0))
            a = QPainterPath()
            a.moveTo(hx + side * rad, hy - 18)
            a.quadTo(hx + side * (rad + 12), hy, hx + side * rad, hy + 18)
            p.drawPath(a)
    p.setOpacity(1.0)


def _rain(p, st, hx, hy, r):
    # small gloomy cloud + drops above the head
    p.setOpacity(0.9)
    fill(p, col("#8d96b8"))
    for dx, dy, rr in ((-16, 0, 11), (0, -6, 14), (17, 0, 11)):
        p.drawEllipse(QPointF(hx + dx, hy - r * 1.12 + dy), rr, rr * 0.8)
    p.setPen(pen(col("#5aa6ff"), 2.6))
    for i in range(3):
        ph = (st.t * 1.4 + i / 3.0) % 1.0
        x = hx - 14 + i * 14
        y = hy - r * 1.0 + ph * 24
        d = QPainterPath()
        d.moveTo(x, y)
        d.lineTo(x - 2, y + 6)
        p.setOpacity(1.0 - ph)
        p.drawPath(d)
    p.setOpacity(1.0)


_FX = {"hearts": _hearts, "sparkles": _sparkles, "sweat": _sweat, "vein": _vein, "exclaim": _exclaim,
       "question": _question, "dots": _dots, "zzz": _zzz, "waves": _waves, "rain": _rain}
