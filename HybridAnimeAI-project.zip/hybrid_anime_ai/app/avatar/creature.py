"""Original cute creature companions (cat, bunny, bear, panda, fox, puppy, penguin, hamster), drawn live.

Same interface and state machinery as VectorAvatar (emotions, blinking, lip-sync, eyes follow the cursor, walking,
waving, sitting, sleeping), so they react to everything exactly like the human characters. All designs are original
generic animals; no existing character, brand or franchise is imitated.
"""
import math

from PyQt6.QtCore import QPointF
from PyQt6.QtGui import QBrush, QLinearGradient, QPainterPath, QRadialGradient

from .draw import col, fill, mix, pen, shade
from .effects import draw_effects
from .state import CANVAS_H, CANVAS_W, CENTER_X, GROUND_Y
from .vector import FACE, TILT

SPECIES = {   # body, belly/muzzle, inner ear, nose, ear shape, tail, extras
    "cat":     dict(body="#f2b27a", belly="#fff1e0", inner="#ff9fb0", nose="#e8708a", ears="point", tail="long", marks="stripes", whisk=True),
    "bunny":   dict(body="#f4efe9", belly="#ffffff", inner="#ffb3c6", nose="#f08aa0", ears="long", tail="puff", marks="", whisk=False),
    "bear":    dict(body="#b9824f", belly="#e8c9a0", inner="#8f5d34", nose="#3b2a22", ears="round", tail="stub", marks="", whisk=False),
    "panda":   dict(body="#fbfbfb", belly="#ffffff", inner="#2b2b33", nose="#2b2b33", ears="round_dark", tail="stub", marks="panda", whisk=False),
    "fox":     dict(body="#ee7b30", belly="#fff4e6", inner="#3b2a22", nose="#2b2020", ears="point", tail="bushy", marks="fox", whisk=False),
    "puppy":   dict(body="#d9a566", belly="#fff0d9", inner="#b3763d", nose="#2b2020", ears="floppy", tail="wag", marks="patch", whisk=False),
    "penguin": dict(body="#2f3b52", belly="#ffffff", inner="#f5a623", nose="#f5a623", ears="none", tail="stub", marks="penguin", whisk=False),
    "hamster": dict(body="#e9c08a", belly="#fff6e8", inner="#ffb3a0", nose="#e8708a", ears="round", tail="stub", marks="hamster", whisk=True),
}


def _ell(p, x, y, rx, ry):
    p.drawEllipse(QPointF(x, y), rx, ry)


class CreatureAvatar:
    def __init__(self, spec: dict):
        self.spec = spec
        base = SPECIES.get(spec.get("species", "cat"), SPECIES["cat"])
        self.s = dict(base)
        for k in ("body", "belly", "inner", "nose"):
            if spec.get(k):
                self.s[k] = spec[k]
        self.accent = spec.get("accent", "#ff7ab0")
        self.eye_col = spec.get("eyes", "#2a2233")
        self.line = shade(self.s["body"], 0.55)
        self.acc = spec.get("accessory", "")

    # ------------------------------------------------------------------ entry
    def paint(self, p, w: float, h: float, st) -> None:
        s = min(w / CANVAS_W, h / CANVAS_H)
        p.save()
        p.translate((w - CANVAS_W * s) / 2.0, h - CANVAS_H * s)
        p.scale(s, s)
        p.translate(CENTER_X, 0.0)
        p.scale(float(st.facing), 1.0)
        p.translate(-CENTER_X, 0.0)
        self._draw(p, st)
        p.restore()

    def _draw(self, p, st) -> None:
        pose, t = st.pose, st.t
        edge = pose in ("sit_edge", "sleep_edge")
        gsit = pose in ("sit_ground", "sleep")
        dy = bob = 0.0
        leg, arm, dangle = [0.0, 0.0], [0.0, 0.0], False
        if pose == "walk":
            ph = st.walk_phase
            bob = -abs(math.sin(ph)) * 6
            sw = math.sin(ph) * 14
            leg, arm = [sw, -sw], [sw * 0.8, -sw * 0.8]
        elif pose in ("stand", "wave", "jump"):
            bob = math.sin(t * 2.1) * 1.8
        if edge:
            dy, dangle = 73.0, True
            sw = math.sin(t * 1.7) * 7
            leg, bob = [sw, -sw], math.sin(t * 1.4) * 1.2
        elif gsit:
            dy, bob = 38.0, math.sin(t * 1.4) * 1.2
        raise_arm = 0.0
        if pose == "wave":
            raise_arm = 1.0 + math.sin(t * 10) * 0.25
        elif pose == "held":
            dangle = True
            sw = math.sin(t * 6) * 10
            leg, arm, bob = [sw, -sw], [-sw, sw], 0
            raise_arm = 0.9
        elif pose in ("fall", "jump"):
            raise_arm, bob = 0.9, 0
        if st.emotion == "angry" and pose in ("stand", "sit_ground", "sit_edge"):
            raise_arm = 0.0
        sleeping = pose.startswith("sleep")
        tilt = 13 if sleeping else TILT.get(st.emotion, 0)
        face = FACE.get(st.emotion, FACE["neutral"])
        if sleeping:
            face = dict(face, mouth="flat")

        if pose in ("stand", "walk", "sit_ground", "sleep", "wave"):
            self._shadow(p, 74 if pose != "walk" else 66)
        p.save()
        p.translate(0.0, dy + bob)
        self._tail(p, t, pose)
        self._ears_and_head(p, st, face, tilt, back=True)
        self._feet(p, leg, gsit, dangle)
        self._body(p)
        self._arms(p, arm, raise_arm, st)
        self._ears_and_head(p, st, face, tilt, back=False)
        p.restore()

    # ------------------------------------------------------------------ parts
    def _shadow(self, p, rx):
        g = QRadialGradient(CENTER_X, GROUND_Y + 2, rx)
        g.setColorAt(0, col("#000000", 0.28))
        g.setColorAt(1, col("#000000", 0.0))
        p.setPen(pen(col("#000000", 0.0), 0.0))
        p.setBrush(QBrush(g))
        _ell(p, CENTER_X, GROUND_Y + 2, rx, 10)

    def _fur(self, p, x, y, rx, ry, c, outline=True):
        g = QRadialGradient(x - rx * 0.3, y - ry * 0.4, max(rx, ry) * 1.35)
        g.setColorAt(0, col(shade(c, 1.18)))
        g.setColorAt(0.65, col(c))
        g.setColorAt(1, col(shade(c, 0.84)))
        p.setPen(pen(col(self.line), 2.2) if outline else pen(col(c, 0.0), 0.0))
        p.setBrush(QBrush(g))
        _ell(p, x, y, rx, ry)

    def _tail(self, p, t, pose):
        k, c = self.s["tail"], self.s["body"]
        wag = math.sin(t * (9 if k == "wag" else 2.4)) * (14 if k == "wag" else 6)
        p.save()
        p.translate(196.0, 296.0)
        p.rotate(wag)
        if k == "long":
            path = QPainterPath()
            path.moveTo(0, 0)
            path.cubicTo(40, -10, 62, -50, 40, -84)
            path.cubicTo(30, -66, 22, -34, -2, -18)
            path.closeSubpath()
            p.setPen(pen(col(self.line), 2.2))
            p.setBrush(QBrush(col(c)))
            p.drawPath(path)
        elif k == "bushy":
            path = QPainterPath()
            path.moveTo(0, 0)
            path.cubicTo(50, 4, 78, -40, 56, -80)
            path.cubicTo(30, -70, 16, -40, -2, -20)
            path.closeSubpath()
            p.setPen(pen(col(self.line), 2.2))
            p.setBrush(QBrush(col(c)))
            p.drawPath(path)
            fill(p, col("#fff4e6"))
            _ell(p, 54, -72, 13, 15)
        elif k == "wag":
            p.setPen(pen(col(self.line), 2.2))
            p.setBrush(QBrush(col(shade(c, 0.92))))
            _ell(p, 22, -20, 10, 26)
        elif k == "puff":
            self._fur(p, 12, -4, 16, 16, "#ffffff")
        else:
            self._fur(p, 8, -4, 10, 10, c)
        p.restore()

    def _feet(self, p, leg, gsit, dangle):
        for i, sx in enumerate((-1, 1)):
            x = 150 + sx * 30.0
            y = 322.0 + (0 if dangle else 0)
            if gsit:
                self._fur(p, 150 + sx * 44.0, 316.0, 20, 12, self.s["body"])
            elif dangle:
                self._fur(p, x, 306.0 + leg[i] * 0.7, 17, 13, self.s["body"])
            else:
                self._fur(p, x + leg[i] * 0.6, y - max(0.0, -leg[i]) * 0.5, 19, 13, self.s["body"])
                fill(p, col(shade(self.s["body"], 0.8), 0.9))
                for dx in (-6, 0, 6):
                    _ell(p, x + leg[i] * 0.6 + dx, y + 4, 2.4, 3)

    def _body(self, p):
        s = self.s
        self._fur(p, 150, 262, 54, 58, s["body"])
        # belly
        g = QRadialGradient(150, 270, 40)
        g.setColorAt(0, col(shade(s["belly"], 1.05)))
        g.setColorAt(1, col(s["belly"]))
        p.setPen(pen(col(self.line, 0.0), 0.0))
        p.setBrush(QBrush(g))
        _ell(p, 150, 274, 33, 42)
        m = s["marks"]
        if m == "stripes":
            p.setPen(pen(col(shade(s["body"], 0.7), 0.8), 4))
            for y in (238, 252):
                q = QPainterPath()
                q.moveTo(100, y)
                q.quadTo(112, y + 4, 118, y + 14)
                p.drawPath(q)
                q = QPainterPath()
                q.moveTo(200, y)
                q.quadTo(188, y + 4, 182, y + 14)
                p.drawPath(q)
        if self.acc == "scarf" or m == "penguin":
            fill(p, col(self.accent))
            sc = QPainterPath()
            sc.addRoundedRect(106, 206, 88, 18, 9, 9)
            p.drawPath(sc)

    def _arms(self, p, arm, raised, st):
        for i, sx in enumerate((-1, 1)):
            p.save()
            p.translate(150 + sx * 52.0, 240.0)
            ang = sx * (18 + arm[i] * 0.6)
            if raised and (sx == 1 or st.pose in ("held", "fall", "jump")):
                ang = sx * -(60 + raised * 55) if sx == 1 else -sx * -(40 + raised * 30)
            p.rotate(ang)
            self._fur(p, 0, 22, 12, 24, self.s["body"])
            p.restore()

    def _ears_and_head(self, p, st, face, tilt, back):
        s = self.s
        p.save()
        p.translate(CENTER_X, 196.0)
        p.rotate(float(tilt))
        p.translate(-CENTER_X, -196.0)
        if back:
            self._ears(p)
        else:
            self._head(p)
            self._face(p, st, face)
            self._extras(p, st)
            draw_effects(p, st, CENTER_X, 120.0, 70.0)
        p.restore()

    def _ears(self, p):
        s, c = self.s, self.s["body"]
        k = s["ears"]
        if k == "none":
            return
        for sx in (-1, 1):
            p.save()
            p.translate(150 + sx * 52.0, 92.0)
            if k == "point":
                path = QPainterPath()
                path.moveTo(-24 * sx, 22)
                path.lineTo(-8 * sx, -34)
                path.lineTo(26 * sx, 14)
                path.closeSubpath()
                p.setPen(pen(col(self.line), 2.2))
                p.setBrush(QBrush(col(c)))
                p.drawPath(path)
                fill(p, col(s["inner"]))
                inner = QPainterPath()
                inner.moveTo(-14 * sx, 16)
                inner.lineTo(-6 * sx, -16)
                inner.lineTo(14 * sx, 12)
                inner.closeSubpath()
                p.drawPath(inner)
            elif k == "long":
                p.rotate(sx * 8)
                self._fur(p, 0, -34, 15, 44, c)
                fill(p, col(s["inner"]))
                _ell(p, 0, -30, 8, 32)
            elif k == "floppy":
                p.rotate(sx * 14)
                self._fur(p, sx * 14, 6, 18, 38, s["inner"])
            else:
                self._fur(p, sx * 8, -8, 24, 24, "#2b2b33" if k == "round_dark" else c)
                fill(p, col(s["inner"]))
                _ell(p, sx * 8, -6, 12, 12)
            p.restore()

    def _head(self, p):
        s = self.s
        self._fur(p, 150, 150, 80, 72, s["body"])
        m = s["marks"]
        p.setPen(pen(col(self.line, 0.0), 0.0))
        if m == "panda":
            for sx in (-1, 1):
                p.setBrush(QBrush(col("#2b2b33")))
                _ell(p, 150 + sx * 34, 146, 22, 27)
        elif m == "fox":
            p.setBrush(QBrush(col(s["belly"])))
            for sx in (-1, 1):
                q = QPainterPath()
                q.moveTo(150 + sx * 80, 160)
                q.quadTo(150 + sx * 40, 190, 150, 200)
                q.quadTo(150 + sx * 44, 168, 150 + sx * 78, 140)
                q.closeSubpath()
                p.drawPath(q)
        elif m == "patch":
            p.setBrush(QBrush(col(s["inner"])))
            _ell(p, 188, 132, 22, 26)
        elif m == "penguin":
            p.setBrush(QBrush(col(s["belly"])))
            _ell(p, 150, 164, 56, 50)
        elif m == "hamster":
            p.setBrush(QBrush(col(s["belly"])))
            _ell(p, 150, 168, 48, 36)

    def _face(self, p, st, f):
        s = self.s
        # muzzle
        p.setPen(pen(col(self.line, 0.0), 0.0))
        p.setBrush(QBrush(col(s["belly"])))
        if s["marks"] not in ("penguin", "hamster"):
            _ell(p, 150, 178, 30, 21)
        # blush
        fill(p, col("#ff6f8f", min(0.8, f["blush"] + 0.2)))
        for sx in (-1, 1):
            _ell(p, 150 + sx * 56.0, 176, 14, 8)
        for sx in (-1, 1):
            self._eye(p, 150 + sx * 34.0, 146.0, sx, st, f)
        # nose
        fill(p, col(s["nose"]))
        nz = QPainterPath()
        nz.moveTo(142, 166)
        nz.quadTo(150, 162, 158, 166)
        nz.quadTo(156, 176, 150, 177)
        nz.quadTo(144, 176, 142, 166)
        nz.closeSubpath()
        p.drawPath(nz)
        if s["marks"] == "penguin":
            bk = QPainterPath()
            bk.moveTo(136, 168)
            bk.quadTo(150, 158, 164, 168)
            bk.quadTo(150, 186, 136, 168)
            bk.closeSubpath()
            p.drawPath(bk)
        self._mouth(p, st, f)
        if s["whisk"]:
            p.setPen(pen(col(shade(s["body"], 0.5), 0.75), 1.6))
            for sx in (-1, 1):
                for k, dy in enumerate((-4, 4)):
                    w = QPainterPath()
                    w.moveTo(150 + sx * 30, 178 + dy)
                    w.quadTo(150 + sx * 52, 176 + dy * 2, 150 + sx * 72, 180 + dy * 4)
                    p.drawPath(w)
        if st.emotion == "sad":
            fill(p, col("#8fd0ff", 0.9))
            x, y = 118.0, 170.0 + (st.t * 20 % 14)
            tear = QPainterPath()
            tear.moveTo(x, y - 8)
            tear.cubicTo(x + 6, y, x + 5, y + 7, x, y + 7)
            tear.cubicTo(x - 5, y + 7, x - 6, y, x, y - 8)
            tear.closeSubpath()
            p.drawPath(tear)
        # brows
        tilt, lift = f["brow"]
        p.setPen(pen(col(shade(s["body"], 0.45), 0.9), 3.0))
        for sx in (-1, 1):
            cx, cy = 150 + sx * 34.0, 118.0 + lift * 0.6
            b = QPainterPath()
            b.moveTo(cx - 11, cy + tilt * 0.4 * sx)
            b.lineTo(cx + 11, cy - tilt * 0.4 * sx)
            p.drawPath(b)

    def _eye(self, p, cx, cy, side, st, f):
        ink = self.eye_col
        kind = f["eye"]
        op = f["open"] * (1.0 - st.blink)
        if st.pose.startswith("sleep"):
            op, kind = 0.0, "open"
        if kind == "arc" or (kind == "open" and op < 0.12):
            p.setPen(pen(col(ink), 3.6))
            a = QPainterPath()
            a.moveTo(cx - 12, cy + 2)
            a.quadTo(cx, cy - (12 if kind == "arc" else -2), cx + 12, cy + 2)
            p.drawPath(a)
            return
        if kind == "heart":
            from .draw import heart_path
            fill(p, col("#ff4f7e"))
            p.drawPath(heart_path(cx, cy, 11))
            return
        ry = 19.0 * max(0.25, op)
        rx = 15.0
        px = cx + st.look[0] * 4.0
        py = cy + st.look[1] * 4.0 + (2 if f["slant"] else 0)
        fill(p, col("#ffffff"))
        _ell(p, cx, cy, rx + 2, ry + 2)
        g = QRadialGradient(px, py - ry * 0.2, rx + 2)
        g.setColorAt(0, col(shade(ink, 1.5)))
        g.setColorAt(0.7, col(ink))
        g.setColorAt(1, col(shade(ink, 0.5)))
        p.setBrush(QBrush(g))
        _ell(p, px, py, rx * f["pupil"] + 1, ry * min(1.05, f["pupil"] + 0.1))
        fill(p, col("#ffffff", 0.95))
        _ell(p, px - 5, py - ry * 0.35, 5.2, 5.2)
        _ell(p, px + 5, py + ry * 0.3, 2.4, 2.4)
        if f["slant"]:                                   # angry lid
            fill(p, col(shade(self.s["body"], 0.95)))
            lid = QPainterPath()
            lid.moveTo(cx - 18, cy - ry - 4)
            lid.lineTo(cx + 18, cy - ry - 4)
            lid.lineTo(cx + 18 * (-side), cy - ry * 0.15)
            lid.closeSubpath()
            p.drawPath(lid)

    def _mouth(self, p, st, f):
        m = f["mouth"]
        cx, cy = 150.0, 183.0
        lip = max(0.0, min(1.0, st.mouth)) if (st.speaking or st.mouth > 0.04) else 0.0
        ink = "#4a2a2a"
        if lip > 0.05 or m in ("o", "yawn", "grin"):
            size = lip if lip > 0.05 else {"o": 0.7, "yawn": 1.0, "grin": 0.55}[m]
            w, h = 11 + 5 * size, 3 + 13 * size
            fill(p, col(ink))
            _ell(p, cx, cy + h * 0.5, w, h)
            fill(p, col("#ff8a9a"))
            _ell(p, cx, cy + h * 0.9, w * 0.55, h * 0.4)
            return
        p.setPen(pen(col(ink), 2.6))
        q = QPainterPath()
        if m == "frown":
            q.moveTo(cx - 12, cy + 7)
            q.quadTo(cx, cy - 1, cx + 12, cy + 7)
        elif m == "flat":
            q.moveTo(cx - 9, cy + 3)
            q.lineTo(cx + 9, cy + 3)
        elif m == "wavy":
            q.moveTo(cx - 12, cy + 4)
            q.quadTo(cx - 6, cy - 2, cx, cy + 4)
            q.quadTo(cx + 6, cy + 10, cx + 12, cy + 4)
        else:                                            # smile: the classic "w" muzzle smile
            q.moveTo(cx - 14, cy)
            q.quadTo(cx - 7, cy + 10, cx, cy + 2)
            q.quadTo(cx + 7, cy + 10, cx + 14, cy)
        p.drawPath(q)

    def _extras(self, p, st):
        if self.acc == "bow":
            fill(p, col(self.accent))
            for sx in (-1, 1):
                b = QPainterPath()
                b.moveTo(116 + 8 * (sx + 1) * 0, 84)
                b.moveTo(150 + sx * 52, 84)
                b.quadTo(150 + sx * 80, 64, 150 + sx * 78, 96)
                b.quadTo(150 + sx * 70, 94, 150 + sx * 52, 84)
                b.closeSubpath()
                p.drawPath(b)
            _ell(p, 202, 84, 6, 6)
        elif self.acc == "headphones":
            p.setPen(pen(col(self.accent), 6))
            a = QPainterPath()
            a.moveTo(74, 140)
            a.cubicTo(70, 50, 230, 50, 226, 140)
            p.drawPath(a)
            fill(p, col(self.accent))
            for sx in (-1, 1):
                _ell(p, 150 + sx * 76, 144, 11, 17)
        elif self.acc == "flower":
            fill(p, col(self.accent))
            for k in range(5):
                a = k * 2 * math.pi / 5
                _ell(p, 196 + math.cos(a) * 7, 90 + math.sin(a) * 7, 5, 5)
            fill(p, col("#ffd54a"))
            _ell(p, 196, 90, 4, 4)
