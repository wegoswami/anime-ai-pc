"""Create the right avatar object for a character spec."""
from .vector import VectorAvatar


def create_avatar(spec: dict):
    kind = spec.get("type", "vector")
    if kind in ("image", "gif"):
        from .image import ImageAvatar   # imported lazily: needs QPixmap / QMovie
        return ImageAvatar(spec)
    return VectorAvatar(spec)
