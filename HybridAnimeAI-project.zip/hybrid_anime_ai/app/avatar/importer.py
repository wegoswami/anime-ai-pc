"""Turn any user image (PNG, JPG, WEBP, BMP, GIF, TIFF, ICO ...) into a pet character. Pillow only (no Qt)."""
import json
import re
import time
from collections import deque
from pathlib import Path
from typing import Optional

from PIL import Image, ImageFilter, ImageSequence

from ..paths import user_characters_dir

MAX_SIDE = 640
SUPPORTED = "*.png *.jpg *.jpeg *.webp *.bmp *.gif *.tif *.tiff *.ico *.jfif *.ppm"


def _slug(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_") or "custom"
    return f"{s}_{int(time.time()) % 100000}"


def remove_background(img: Image.Image, tolerance: int = 38) -> Image.Image:
    """Make the flat background transparent by flood-filling inwards from every image border.

    Works for photos/artwork on a plain (white, black, green-screen ...) background. Images that already
    have transparency are returned unchanged.
    """
    img = img.convert("RGBA")
    alpha = img.getchannel("A")
    if alpha.getextrema()[0] < 250:      # already transparent somewhere
        return img
    w, h = img.size
    px = img.load()
    seen = bytearray(w * h)
    bg = deque()

    def seed(x, y):
        if not seen[y * w + x]:
            seen[y * w + x] = 1
            bg.append((x, y))

    # The background must be genuinely flat: most of the border has to be one colour, otherwise (sky, rooms,
    # gradients ...) cutting it out would eat the character, so we leave the picture alone.
    border = [px[x, y][:3] for x in range(w) for y in (0, h - 1)] + [px[x, y][:3] for y in range(h) for x in (0, w - 1)]
    ref = tuple(sorted(c[i] for c in border)[len(border) // 2] for i in range(3))

    def close(c, r):
        return abs(c[0] - r[0]) + abs(c[1] - r[1]) + abs(c[2] - r[2]) <= tolerance * 2

    if sum(close(c, ref) for c in border) < 0.85 * len(border):
        return img
    corners = [ref]

    def is_bg(c):
        return any(close(c, r) for r in corners)

    for x in range(w):
        for y in (0, h - 1):
            if is_bg(px[x, y][:3]):
                seed(x, y)
    for y in range(h):
        for x in (0, w - 1):
            if is_bg(px[x, y][:3]):
                seed(x, y)
    mask = bytearray(w * h)
    while bg:
        x, y = bg.popleft()
        mask[y * w + x] = 1
        for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if 0 <= nx < w and 0 <= ny < h and not seen[ny * w + nx] and is_bg(px[nx, ny][:3]):
                seen[ny * w + nx] = 1
                bg.append((nx, ny))
    if sum(mask) < w * h * 0.03 or sum(mask) > w * h * 0.85:   # nothing / everything found -> keep the picture
        return img
    m = Image.frombytes("L", (w, h), bytes(255 if v else 0 for v in mask))
    m = m.filter(ImageFilter.MaxFilter(3)).filter(ImageFilter.GaussianBlur(0.8))
    new_alpha = Image.eval(m, lambda v: 255 - v)
    out = img.copy()
    out.putalpha(new_alpha)
    return out


def soft_card(img: Image.Image, radius_frac: float = 0.12, feather: float = 2.0) -> Image.Image:
    """For pictures whose busy background can't be cut out: round the corners with a soft edge (sticker look)."""
    from PIL import ImageDraw
    img = img.convert("RGBA")
    w, h = img.size
    scale = 4
    m = Image.new("L", (w * scale, h * scale), 0)
    r = int(min(w, h) * radius_frac * scale)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w * scale - 1, h * scale - 1), radius=r, fill=255)
    m = m.resize((w, h), Image.Resampling.LANCZOS).filter(ImageFilter.GaussianBlur(feather))
    a = Image.composite(m, Image.new("L", (w, h), 0), img.getchannel("A"))
    img.putalpha(Image.eval(a, lambda v: v))
    return img


def _mostly_opaque(img: Image.Image) -> bool:
    hist = img.getchannel("A").histogram()
    return sum(hist[250:]) >= 0.92 * (img.width * img.height)


def _prepare(img: Image.Image, remove_bg: bool) -> Image.Image:
    img = img.convert("RGBA")
    if remove_bg:
        img = remove_background(img)
        if _mostly_opaque(img):          # busy background (sky, room ...): keep the scene as a soft card
            img = soft_card(img)
    box = img.getchannel("A").point(lambda a: 255 if a > 20 else 0).getbbox()
    if box:
        img = img.crop(box)
    if max(img.size) > MAX_SIDE:
        img.thumbnail((MAX_SIDE, MAX_SIDE), Image.Resampling.LANCZOS)
    return img


def import_image(path: str, name: str, gender: str = "girl", remove_bg: bool = True,
                 personality: str = "", dest_root: Optional[Path] = None) -> dict:
    """Create assets for a new custom character and return its character.json dict."""
    src = Path(path)
    root = dest_root or user_characters_dir()
    cid = _slug(name or src.stem)
    folder = root / cid
    folder.mkdir(parents=True, exist_ok=True)
    with Image.open(src) as im:
        animated = getattr(im, "is_animated", False) and im.format == "GIF"
        if animated:
            frames, durations = [], []
            for fr in ImageSequence.Iterator(im):
                f = fr.convert("RGBA")
                if max(f.size) > 400:
                    f.thumbnail((400, 400), Image.Resampling.LANCZOS)
                frames.append(f)
                durations.append(fr.info.get("duration", 80))
            frames[0].save(folder / "avatar.gif", save_all=True, append_images=frames[1:], duration=durations,
                           loop=0, disposal=2)
            kind, fname = "gif", "avatar.gif"
        else:
            im.load()
            _prepare(im, remove_bg).save(folder / "avatar.png")
            kind, fname = "image", "avatar.png"
    spec = {"id": cid, "name": name or src.stem, "type": kind, "file": fname, "gender": gender,
            "voice_gender": "female" if gender == "girl" else "male",
            "personality": personality or "friendly and expressive"}
    (folder / "character.json").write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")
    return spec
