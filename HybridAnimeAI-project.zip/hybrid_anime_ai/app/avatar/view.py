"""Widget that animates and paints an avatar (blink, lip-sync, clock). Mouse events fall through to the parent."""
import math
import random

from PyQt6.QtCore import QElapsedTimer, Qt, QTimer
from PyQt6.QtGui import QImage, QPainter
from PyQt6.QtWidgets import QWidget

from .factory import create_avatar
from .state import CANVAS_H, CANVAS_W, AvatarState


class AvatarView(QWidget):
    def __init__(self, spec: dict, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.state = AvatarState()
        self.avatar = create_avatar(spec)
        self._clock = QElapsedTimer()
        self._clock.start()
        self._last = 0.0
        self._next_blink = random.uniform(1.5, 4.0)
        self._blink_t = -1.0
        self._emotion_since = 0.0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(33)

    def set_avatar(self, spec: dict) -> None:
        self.avatar = create_avatar(spec)
        self.update()

    def set_emotion(self, name: str) -> None:
        if name != self.state.emotion:
            self.state.emotion = name
            self.state.effect_t = 0.0

    def _tick(self) -> None:
        now = self._clock.elapsed() / 1000.0
        dt = min(0.1, now - self._last)
        self._last = now
        st = self.state
        st.t = now
        st.effect_t += dt
        # blink
        if self._blink_t < 0 and now >= self._next_blink:
            self._blink_t = 0.0
        if self._blink_t >= 0:
            self._blink_t += dt
            x = self._blink_t / 0.16
            st.blink = 1.0 - abs(2 * x - 1) if x < 1 else 0.0
            if x >= 1:
                self._blink_t = -1.0
                self._next_blink = now + random.uniform(2.0, 5.5)
        # lip sync: pseudo-random syllable envelope while speaking
        if st.speaking:
            st.mouth = max(0.0, min(1.0, 0.5 + 0.38 * math.sin(now * 17) + 0.25 * math.sin(now * 7.3 + 1.1)))
        else:
            st.mouth = max(0.0, st.mouth - dt * 6)
        self.update()

    def paintEvent(self, _event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.avatar.paint(p, float(self.width()), float(self.height()), self.state)
        p.end()

    def render_preview(self, width: int, height: int) -> QImage:
        img = QImage(width, height, QImage.Format.Format_ARGB32_Premultiplied)
        img.fill(0)
        p = QPainter(img)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.avatar.paint(p, float(width), float(height), self.state)
        p.end()
        return img


def preview_image(spec: dict, width: int = 120, height: int = 164) -> QImage:
    """Static render of a character (used for the picker in the settings dialog)."""
    img = QImage(width, height, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    st = AvatarState(emotion="happy" if spec.get("type", "vector") == "vector" else "neutral", t=1.0)
    create_avatar(spec).paint(p, float(width), float(height), st)
    p.end()
    return img


ASPECT = CANVAS_W / CANVAS_H
