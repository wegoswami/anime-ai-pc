"""Cel-shaded chibi anime character drawn live with QPainter from a small JSON spec.

No image files are needed: eyes follow the cursor, blink, lip-sync, show emotions, walk, wave, sit on
window edges and sleep. Everything is drawn in a 300x400 canvas (see state.py).
"""
import copy
import math

from PyQt6.QtCore import QPointF, Qt
from PyQt6.QtGui import QBrush, QLinearGradient, QPainterPath, QRadialGradient

from .draw import col, fill, mix, pen, shade
from .effects import draw_effects
from .state import CANVAS_H, CANVAS_W, CENTER_X, GROUND_Y

DEFAULT_SPEC = {
    "gender": "girl",
    "hair": {"style": "long", "bangs": "split", "color": "#5a4636"},
    "eyes": "#4d8dff",
    "skin": "#ffe3d2",
    "outfit": {"type": "sailor", "color": "#2b3a7a", "accent": "#ffffff", "bow": "#e0405a",
               "pants": "#2b3a7a", "legs": "socks", "sock": "#ffffff", "shoes": "#4a3434"},
    "accessories": [],
    "accent": "#ff7ab0",
    "ahoge": False,
    "blush": True,
}

# eye kind, openness, brow (tilt, lift), mouth, blush alpha, lid slant, pupil scale
FACE = {
    "neutral":     dict(eye="open", open=1.00, brow=(0, 0), mouth="smile", blush=0.0, slant=0, pupil=1.0),
    "happy":       dict(eye="arc", open=1.00, brow=(-2, -3), mouth="grin", blush=0.35, slant=0, pupil=1.0),
    "love":        dict(eye="heart", open=1.00, brow=(-2, -3), mouth="smile", blush=0.55, slant=0, pupil=1.0),
    "sad":         dict(eye="open", open=0.92, brow=(-6, 1), mouth="frown", blush=0.0, slant=0, pupil=1.15),
    "angry":       dict(eye="open", open=0.78, brow=(7, 2), mouth="frown", blush=0.0, slant=7, pupil=0.8),
    "surprised":   dict(eye="open", open=1.18, brow=(0, -8), mouth="o", blush=0.0, slant=0, pupil=0.7),
    "thinking":    dict(eye="open", open=0.95, brow=(-2, -3), mouth="flat", blush=0.0, slant=0, pupil=1.0),
    "embarrassed": dict(eye="open", open=0.8, brow=(-4, 0), mouth="wavy", blush=0.75, slant=0, pupil=0.9),
    "sleepy":      dict(eye="open", open=0.38, brow=(0, 2), mouth="yawn", blush=0.0, slant=0, pupil=1.0),
    "confused":    dict(eye="open", open=1.0, brow=(-4, -2), mouth="wavy", blush=0.0, slant=0, pupil=0.9),
    "listening":   dict(eye="open", open=1.05, brow=(-1, -3), mouth="smile", blush=0.1, slant=0, pupil=1.1),
}

TILT = {"listening": 6, "thinking": -5, "sad": 3, "embarrassed": -4, "confused": 5, "sleepy": 7}


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


class VectorAvatar:
    def __init__(self, spec: dict):
        self.sp = _merge(DEFAULT_SPEC, spec)
        h = self.sp["hair"]["color"]
        self.hair = h
        self.hair_dark = shade(h, 0.72)
        self.hair_light = shade(h, 1.28)
        self.ink = shade(h, 0.32)
        self.line = shade(h, 0.5)

    # ------------------------------------------------------------------ entry
    def paint(self, p, w: float, h: float, st) -> None:
        s = min(w / CANVAS_W, h / CANVAS_H)
        p.save()
        p.translate((w - CANVAS_W * s) / 2.0, h - CANVAS_H * s)
        p.scale(s, s)
        p.translate(CENTER_X, 0.0)
        p.scale(float(st.facing), 1.0)
        p.translate(-CENTER_X, 0.0)
        self._draw(p, st)
        p.restore()

    # -------------------------------------------------------------- composition
    def _draw(self, p, st) -> None:
        pose = st.pose
        edge = pose in ("sit_edge", "sleep_edge")
        gsit = pose in ("sit_ground", "sleep")
        t = st.t
        dy, bob = 0.0, 0.0
        leg = [0.0, 0.0]
        arm = [8.0, 8.0]
        dangle = False
        if pose == "walk":
            ph = st.walk_phase
            bob = -abs(math.sin(ph)) * 6
            sw = math.sin(ph) * 30
            leg = [sw, -sw]
            arm = [8 + sw * 0.9, 8 - sw * 0.9]
        elif pose in ("stand", "wave", "jump"):
            bob = math.sin(t * 2.1) * 1.8
        if edge:
            dy, dangle = 73.0, True
            sw = math.sin(t * 1.7) * 9
            leg = [sw, -sw]
            bob = math.sin(t * 1.4) * 1.2
        elif gsit:
            dy = 38.0
            leg = [34.0, 34.0]
            bob = math.sin(t * 1.4) * 1.2
        if pose == "wave":
            arm[1] = 116 + math.sin(t * 10) * 15
        elif pose == "held":
            dangle = True
            sw = math.sin(t * 6) * 14
            leg = [sw, -sw]
            arm = [122 + sw, 122 - sw]
            bob = 0
        elif pose in ("fall", "jump"):
            arm = [128, 128]
            leg = [14, 14]
            bob = 0
        if st.emotion == "angry" and pose in ("stand", "sit_ground", "sit_edge"):
            arm = [20, 20]
        sleeping = pose.startswith("sleep")
        tilt = TILT.get(st.emotion, 0) * (1 if st.facing >= 0 else 1)
        if sleeping:
            tilt = 13
        face = FACE.get(st.emotion, FACE["neutral"])
        if sleeping:
            face = dict(face, mouth="flat")

        if pose in ("stand", "walk", "sit_ground", "sleep", "wave"):
            self._shadow(p, 78 if pose != "walk" else 70)

        p.save()
        p.translate(0.0, dy + bob)
        p.save()
        p.translate(CENTER_X, 196.0)
        p.rotate(float(tilt))
        p.translate(-CENTER_X, -196.0)
        self._hair_back(p)
        p.restore()
        if not gsit:
            self._legs(p, leg, gsit, dangle)
        self._torso(p)
        if gsit:
            self._legs(p, leg, gsit, dangle)
        self._arms(p, arm)
        p.save()
        p.translate(CENTER_X, 196.0)
        p.rotate(float(tilt))
        p.translate(-CENTER_X, -196.0)
        self._neck_and_head(p)
        self._face(p, st, face)
        self._hair_front(p)
        self._brows(p, st, face)
        self._accessories(p, st)
        draw_effects(p, st, CENTER_X, 128.0, 70.0)
        p.restore()
        p.restore()

    # ------------------------------------------------------------------ parts
    def _shadow(self, p, rx):
        g = QRadialGradient(CENTER_X, GROUND_Y + 2, rx)
        g.setColorAt(0.0, col("#000000", 0.30))
        g.setColorAt(1.0, col("#000000", 0.0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(g))
        p.drawEllipse(QPointF(CENTER_X, GROUND_Y + 2), rx, 11.0)

    def _outline(self, p, color=None, w=2.2):
        p.setPen(pen(col(color or self.line), w))

    def _limb(self, p, x, y, ang, length, width, color, sleeve_len=None, skin=None, hand=0.0, shoe=None):
        """Rounded limb hanging from pivot (x, y), rotated by ang degrees (positive = towards viewer-left)."""
        p.save()
        p.translate(x, y)
        p.rotate(float(ang))
        if skin:
            fill(p, col(skin))
            sk = QPainterPath()
            sk.addRoundedRect(-width * 0.36, length * 0.5, width * 0.72, length * 0.5, 4.0, 4.0)
            p.drawPath(sk)
        self._outline(p, shade(color, 0.55), 1.8)
        p.setBrush(QBrush(col(color)))
        body = QPainterPath()
        body.addRoundedRect(-width / 2, 0.0, width, sleeve_len or length, width / 2.4, width / 2.4)
        p.drawPath(body)
        if hand:
            fill(p, col(self.sp["skin"]))
            p.drawEllipse(QPointF(0.0, length + 1), hand, hand)
        if shoe:
            self._outline(p, shade(shoe, 0.5), 1.8)
            p.setBrush(QBrush(col(shoe)))
            p.drawEllipse(QPointF(0.0, length + 3), width * 0.78, 7.5)
        p.restore()

    def _legs(self, p, leg, gsit, dangle):
        length = 46 if dangle else 56
        o = self.sp["outfit"]
        skin = self.sp["skin"]
        style = o.get("legs", "socks")
        for i, x in enumerate((CENTER_X - 18, CENTER_X + 18)):
            ang = leg[i] if i == 0 else leg[i]
            if gsit:
                ang = 34 if i == 0 else -34
                self._limb(p, x, 262.0, ang, 26, 19, o["pants"] if style == "pants" else skin,
                           shoe=o["shoes"])
                continue
            if style == "pants":
                self._limb(p, x, 262.0, ang, length, 20, o["pants"], shoe=o["shoes"])
            elif style == "socks":
                self._limb(p, x, 262.0, ang, length, 17, o.get("sock", "#ffffff"), sleeve_len=length,
                           skin=skin, shoe=o["shoes"])
                # skin thigh visible between skirt and sock
                p.save()
                p.translate(x, 262.0)
                p.rotate(float(ang))
                fill(p, col(skin))
                th = QPainterPath()
                th.addRoundedRect(-7.5, 0.0, 15.0, 24.0, 4.0, 4.0)
                p.drawPath(th)
                p.restore()
            else:
                self._limb(p, x, 262.0, ang, length, 17, skin, shoe=o["shoes"])

    def _torso(self, p):
        o, t = self.sp["outfit"], self.sp["outfit"]["type"]
        c, acc = o["color"], o["accent"]
        girl = self.sp["gender"] == "girl"
        self._outline(p, shade(c, 0.5), 2.2)
        grad = QLinearGradient(0, 184, 0, 266)
        grad.setColorAt(0, col(shade(c, 1.12)))
        grad.setColorAt(1, col(shade(c, 0.86)))
        p.setBrush(QBrush(grad))
        body = QPainterPath()
        if t == "coat":
            body.moveTo(118, 190)
            body.cubicTo(118, 184, 134, 182, 150, 182)
            body.cubicTo(166, 182, 182, 184, 182, 190)
            body.lineTo(194, 296)
            body.quadTo(150, 312, 106, 296)
            body.closeSubpath()
        else:
            body.moveTo(120, 192)
            body.cubicTo(120, 185, 135, 183, 150, 183)
            body.cubicTo(165, 183, 180, 185, 180, 192)
            body.lineTo(184, 262)
            body.cubicTo(170, 268, 130, 268, 116, 262)
            body.closeSubpath()
        p.drawPath(body)

        if girl and t in ("sailor", "blazer", "hoodie", "jacket"):
            self._skirt(p, o)
        if t == "dress":
            self._dress_skirt(p, o)

        if t == "sailor":
            fill(p, col(acc))
            col_path = QPainterPath()
            col_path.moveTo(114, 195)
            col_path.lineTo(150, 240)
            col_path.lineTo(186, 195)
            col_path.lineTo(176, 187)
            col_path.lineTo(150, 214)
            col_path.lineTo(124, 187)
            col_path.closeSubpath()
            self._outline(p, shade(c, 0.6), 1.6)
            p.setBrush(QBrush(col(acc)))
            p.drawPath(col_path)
            p.setPen(pen(col(c), 2.0))
            for k in (0.0, 0.22):
                s = QPainterPath()
                s.moveTo(121 + k * 30, 196 + k * 28)
                s.lineTo(131 + k * 28, 190 + k * 26)
                p.drawPath(s)
            self._bow(p, 150, 216, o.get("bow", "#e0405a"), 0.9)
        elif t == "hoodie":
            self._outline(p, shade(c, 0.55), 1.8)
            p.setBrush(QBrush(col(shade(c, 0.82))))
            hood = QPainterPath()
            hood.moveTo(112, 192)
            hood.quadTo(150, 230, 188, 192)
            hood.quadTo(150, 206, 112, 192)
            hood.closeSubpath()
            p.drawPath(hood)
            p.setPen(pen(col(acc), 2.4))
            for x in (141, 159):
                s = QPainterPath()
                s.moveTo(x, 210)
                s.lineTo(x, 234)
                p.drawPath(s)
            self._outline(p, shade(c, 0.55), 1.6)
            p.setBrush(QBrush(col(shade(c, 0.9))))
            pk = QPainterPath()
            pk.moveTo(124, 238)
            pk.lineTo(176, 238)
            pk.lineTo(181, 258)
            pk.lineTo(119, 258)
            pk.closeSubpath()
            p.drawPath(pk)
        elif t == "jacket":
            fill(p, col(acc))
            panel = QPainterPath()
            panel.moveTo(136, 186)
            panel.lineTo(164, 186)
            panel.lineTo(160, 264)
            panel.lineTo(140, 264)
            panel.closeSubpath()
            self._outline(p, shade(acc, 0.7), 1.4)
            p.setBrush(QBrush(col(acc)))
            p.drawPath(panel)
            p.setPen(pen(col(shade(c, 0.5)), 1.8))
            z = QPainterPath()
            z.moveTo(136, 188)
            z.lineTo(140, 264)
            z.moveTo(164, 188)
            z.lineTo(160, 264)
            p.drawPath(z)
            self._outline(p, shade(c, 0.5), 1.6)
            p.setBrush(QBrush(col(shade(c, 1.1))))
            for sx in (-1, 1):
                cl = QPainterPath()
                cl.moveTo(150 + sx * 32, 190)
                cl.lineTo(150 + sx * 10, 186)
                cl.lineTo(150 + sx * 18, 212)
                cl.closeSubpath()
                p.drawPath(cl)
        elif t == "blazer":
            fill(p, col("#ffffff"))
            v = QPainterPath()
            v.moveTo(134, 186)
            v.lineTo(150, 230)
            v.lineTo(166, 186)
            v.closeSubpath()
            p.drawPath(v)
            p.setBrush(QBrush(col(acc)))
            self._outline(p, shade(acc, 0.6), 1.4)
            tie = QPainterPath()
            tie.moveTo(150, 212)
            tie.lineTo(144, 240)
            tie.lineTo(150, 250)
            tie.lineTo(156, 240)
            tie.closeSubpath()
            p.drawPath(tie)
            p.setPen(pen(col(shade(c, 0.5)), 2.0))
            lap = QPainterPath()
            lap.moveTo(128, 188)
            lap.lineTo(147, 232)
            lap.moveTo(172, 188)
            lap.lineTo(153, 232)
            p.drawPath(lap)
        elif t == "uniform":
            fill(p, col(acc))
            for y in (214, 232, 250):
                p.drawEllipse(QPointF(150.0, float(y)), 3.0, 3.0)
            self._outline(p, shade(acc, 0.6), 1.4)
            p.setBrush(QBrush(col(shade(c, 1.05))))
            cl = QPainterPath()
            cl.addRoundedRect(134, 182, 32, 12, 4, 4)
            p.drawPath(cl)
        elif t == "coat":
            p.setPen(pen(col(shade(c, 0.5)), 2.0))
            s = QPainterPath()
            s.moveTo(150, 196)
            s.lineTo(150, 304)
            p.drawPath(s)
            fill(p, col(acc))
            for y in (214, 238, 262):
                p.drawEllipse(QPointF(143.0, float(y)), 3.0, 3.0)
            self._outline(p, shade(c, 0.5), 1.6)
            p.setBrush(QBrush(col(shade(c, 1.15))))
            for sx in (-1, 1):
                cl = QPainterPath()
                cl.moveTo(150 + sx * 34, 184)
                cl.lineTo(150 + sx * 12, 174)
                cl.lineTo(150 + sx * 14, 206)
                cl.lineTo(150 + sx * 36, 206)
                cl.closeSubpath()
                p.drawPath(cl)
            p.setBrush(QBrush(col(acc)))
            belt = QPainterPath()
            belt.addRoundedRect(118, 258, 64, 8, 3, 3)
            p.drawPath(belt)
        elif t == "dress":
            p.setBrush(QBrush(col(acc)))
            self._outline(p, shade(acc, 0.7), 1.4)
            belt = QPainterPath()
            belt.addRoundedRect(116, 244, 68, 10, 4, 4)
            p.drawPath(belt)
            self._bow(p, 150, 205, acc, 0.75)
        if "scarf" in self.sp["accessories"]:
            self._outline(p, shade(self.sp["accent"], 0.6), 1.8)
            p.setBrush(QBrush(col(self.sp["accent"])))
            sc = QPainterPath()
            sc.addRoundedRect(112, 184, 76, 16, 8, 8)
            p.drawPath(sc)
            tail = QPainterPath()
            tail.addRoundedRect(158, 192, 16, 44, 6, 6)
            p.drawPath(tail)

    def _skirt(self, p, o):
        c = o["pants"]
        self._outline(p, shade(c, 0.5), 2.0)
        g = QLinearGradient(0, 250, 0, 304)
        g.setColorAt(0, col(shade(c, 1.1)))
        g.setColorAt(1, col(shade(c, 0.82)))
        p.setBrush(QBrush(g))
        sk = QPainterPath()
        sk.moveTo(114, 250)
        sk.lineTo(186, 250)
        sk.lineTo(202, 296)
        sk.quadTo(150, 310, 98, 296)
        sk.closeSubpath()
        p.drawPath(sk)
        p.setPen(pen(col(shade(c, 0.6), 0.7), 1.4))
        for x0, x1 in ((124, 118), (137, 133), (150, 150), (163, 167), (176, 182)):
            s = QPainterPath()
            s.moveTo(x0, 254)
            s.lineTo(x1, 302)
            p.drawPath(s)

    def _dress_skirt(self, p, o):
        c = o["color"]
        acc = o["accent"]
        self._outline(p, shade(c, 0.5), 2.0)
        g = QLinearGradient(0, 246, 0, 314)
        g.setColorAt(0, col(shade(c, 1.1)))
        g.setColorAt(1, col(shade(c, 0.8)))
        p.setBrush(QBrush(g))
        sk = QPainterPath()
        sk.moveTo(116, 248)
        sk.lineTo(184, 248)
        sk.lineTo(214, 306)
        sk.quadTo(150, 322, 86, 306)
        sk.closeSubpath()
        p.drawPath(sk)
        p.setBrush(QBrush(col(acc)))
        self._outline(p, shade(acc, 0.7), 1.2)
        hem = QPainterPath()
        hem.moveTo(90, 300)
        hem.quadTo(150, 316, 210, 300)
        hem.lineTo(214, 306)
        hem.quadTo(150, 322, 86, 306)
        hem.closeSubpath()
        p.drawPath(hem)

    def _bow(self, p, cx, cy, color, k=1.0):
        self._outline(p, shade(color, 0.55), 1.6)
        p.setBrush(QBrush(col(color)))
        for sx in (-1, 1):
            w = QPainterPath()
            w.moveTo(cx, cy)
            w.cubicTo(cx + sx * 12 * k, cy - 16 * k, cx + sx * 32 * k, cy - 10 * k, cx + sx * 28 * k, cy + 5 * k)
            w.cubicTo(cx + sx * 26 * k, cy + 15 * k, cx + sx * 10 * k, cy + 12 * k, cx, cy)
            w.closeSubpath()
            p.drawPath(w)
        p.setBrush(QBrush(col(shade(color, 0.85))))
        p.drawEllipse(QPointF(float(cx), float(cy)), 5.5 * k, 5.5 * k)

    def _arms(self, p, arm):
        o = self.sp["outfit"]
        sleeve = o.get("sleeve", o["color"] if o["type"] != "dress" else o["accent"])
        skin = self.sp["skin"]
        for i, (x, ang) in enumerate(((121.0, arm[0]), (179.0, -arm[1] if False else arm[1]))):
            a = ang if i == 0 else -ang
            self._limb(p, x, 197.0, a, 50, 15, sleeve, sleeve_len=30, skin=skin, hand=7.2)

    def _neck_and_head(self, p):
        skin = self.sp["skin"]
        fill(p, col(shade(skin, 0.92)))
        nk = QPainterPath()
        nk.addRoundedRect(138, 178, 24, 28, 6, 6)
        p.drawPath(nk)
        # ears
        self._outline(p, shade(skin, 0.7), 1.6)
        p.setBrush(QBrush(col(skin)))
        for sx in (-1, 1):
            p.drawEllipse(QPointF(150 + sx * 71.0, 142.0), 8.0, 11.0)
        g = QLinearGradient(0, 62, 0, 200)
        g.setColorAt(0, col(shade(skin, 1.03)))
        g.setColorAt(0.75, col(skin))
        g.setColorAt(1, col(shade(skin, 0.9)))
        p.setPen(pen(col(shade(skin, 0.62)), 2.2))
        p.setBrush(QBrush(g))
        face = QPainterPath()
        face.moveTo(150, 64)
        face.cubicTo(198, 64, 224, 98, 221, 136)
        face.cubicTo(218, 172, 190, 199, 150, 201)
        face.cubicTo(110, 199, 82, 172, 79, 136)
        face.cubicTo(76, 98, 102, 64, 150, 64)
        face.closeSubpath()
        p.drawPath(face)

    # ----------------------------------------------------------------- face
    def _face(self, p, st, f):
        girl = self.sp["gender"] == "girl"
        # forehead shadow cast by the bangs
        fill(p, col(shade(self.sp["skin"], 0.78), 0.55))
        p.drawPath(self._bangs_path(translate=(0, 7)))
        # blush
        b = f["blush"] + (0.16 if (self.sp["blush"] and girl) else 0.05)
        fill(p, col("#ff6f8f", min(0.8, b)))
        for sx in (-1, 1):
            p.drawEllipse(QPointF(150 + sx * 50.0, 172.0), 15.0, 7.5)
        # eyes
        for side in (-1, 1):
            self._eye(p, 150 + side * 36.0, 146.0, side, st, f)
        # nose
        p.setPen(pen(col(shade(self.sp["skin"], 0.66)), 1.7))
        n = QPainterPath()
        n.moveTo(149, 163)
        n.quadTo(152, 166, 150, 167)
        p.drawPath(n)
        self._mouth(p, st, f)
        if st.emotion == "sad":
            fill(p, col("#8fd0ff", 0.9))
            tear = QPainterPath()
            x, y = 118.0, 168.0 + (st.t * 20 % 14)
            tear.moveTo(x, y - 8)
            tear.cubicTo(x + 6, y, x + 5, y + 7, x, y + 7)
            tear.cubicTo(x - 5, y + 7, x - 6, y, x, y - 8)
            tear.closeSubpath()
            p.drawPath(tear)

    def _eye(self, p, cx, cy, side, st, f):
        girl = self.sp["gender"] == "girl"
        w = 37.0
        h0 = 47.0 if girl else 41.0
        ink = self.ink
        kind = f["eye"]
        op = f["open"] * (1.0 - st.blink)
        if st.pose.startswith("sleep"):
            op, kind = 0.0, "open"
        if kind == "arc" and op > 0.3 or (kind == "arc" and st.blink < 0.5):
            p.setPen(pen(col(ink), 4.6))
            a = QPainterPath()
            a.moveTo(cx - w / 2, cy + 7)
            a.quadTo(cx, cy - 15, cx + w / 2, cy + 7)
            p.drawPath(a)
            return
        if kind == "heart" and st.blink < 0.5:
            fill(p, col("#ff4f84"))
            from .draw import heart_path
            p.drawPath(heart_path(cx, cy - 1, 11.5))
            fill(p, col("#ffffff", 0.9))
            p.drawEllipse(QPointF(cx - 4.0, cy - 6.0), 3.0, 3.0)
            return
        if op < 0.16:
            p.setPen(pen(col(ink), 4.2))
            a = QPainterPath()
            a.moveTo(cx - w / 2, cy + 2)
            a.quadTo(cx, cy + 10, cx + w / 2, cy + 2)
            p.drawPath(a)
            if girl:
                p.setPen(pen(col(ink), 3.0))
                fl = QPainterPath()
                fl.moveTo(cx + side * w / 2, cy + 2)
                fl.lineTo(cx + side * (w / 2 + 6), cy - 2)
                p.drawPath(fl)
            return
        h = h0 * op
        look_x, look_y = st.look
        # sclera
        p.setPen(pen(col(shade(ink, 1.6), 0.5), 1.2))
        p.setBrush(QBrush(col("#fbfcff")))
        p.drawEllipse(QPointF(cx, cy), w / 2, h / 2)
        # iris
        ix = cx + max(-5.0, min(5.0, look_x * 5.0))
        iy = cy + h * 0.04 + max(-4.0, min(4.0, look_y * 4.0))
        rx, ry = w * 0.43, h * 0.49
        g = QLinearGradient(0, iy - ry, 0, iy + ry)
        eye = self.sp["eyes"]
        g.setColorAt(0.0, col(shade(eye, 0.5)))
        g.setColorAt(0.55, col(eye))
        g.setColorAt(1.0, col(shade(eye, 1.45)))
        p.setPen(pen(col(shade(eye, 0.4)), 1.2))
        p.setBrush(QBrush(g))
        p.drawEllipse(QPointF(ix, iy), rx, ry)
        fill(p, col(shade(eye, 0.18)))
        ps = f["pupil"]
        p.drawEllipse(QPointF(ix, iy + ry * 0.04), rx * 0.42 * ps, ry * 0.46 * ps)
        fill(p, col("#ffffff"))
        p.drawEllipse(QPointF(ix - rx * 0.36, iy - ry * 0.4), max(2.6, w * 0.15), max(2.6, w * 0.15))
        fill(p, col("#ffffff", 0.85))
        p.drawEllipse(QPointF(ix + rx * 0.42, iy + ry * 0.45), max(1.4, w * 0.07), max(1.4, w * 0.07))
        # upper lid (thick line art)
        slant = f["slant"]
        inner = -side
        top = cy - h / 2 - 3
        p.setPen(pen(col(ink), 4.8 if girl else 4.2))
        lid = QPainterPath()
        lid.moveTo(cx + inner * (w / 2 + 1), cy + h * 0.1 + slant)
        lid.cubicTo(cx + inner * w * 0.35, top, cx - inner * w * 0.35, top, cx - inner * (w / 2 + 1), cy + h * 0.1)
        p.drawPath(lid)
        if girl:
            p.setPen(pen(col(ink), 3.2))
            fl = QPainterPath()
            fl.moveTo(cx + side * (w / 2 + 1), cy + h * 0.1)
            fl.lineTo(cx + side * (w / 2 + 7), cy - h * 0.06)
            p.drawPath(fl)
        p.setPen(pen(col(ink, 0.35), 1.6))
        lo = QPainterPath()
        lo.moveTo(cx - w * 0.38, cy + h / 2 - 0.5)
        lo.quadTo(cx, cy + h / 2 + 3, cx + w * 0.38, cy + h / 2 - 0.5)
        p.drawPath(lo)

    def _brows(self, p, st, f):
        if st.emotion in ("neutral", "sleepy") and not st.pose.startswith("sleep"):
            return
        if st.pose.startswith("sleep"):
            return
        tilt, lift = f["brow"]
        p.setPen(pen(col(self.hair_dark), 3.6 if self.sp["gender"] == "boy" else 3.0))
        for side in (-1, 1):
            cx = 150 + side * 37.0
            inner_x, outer_x = cx - side * 15, cx + side * 15
            base = 117.0 + lift
            b = QPainterPath()
            b.moveTo(inner_x, base + tilt)
            b.quadTo(cx, base - 3 + tilt * 0.3, outer_x, base - tilt * 0.35)
            p.drawPath(b)

    def _mouth(self, p, st, f):
        cx, y = CENTER_X, 178.0
        ink = self.ink
        m = st.mouth
        dark = col("#8a2f45")
        if st.speaking or m > 0.08:
            wd, hg = 15 + 4 * m, 3 + 15 * m
            p.setPen(pen(col(ink), 2.0))
            p.setBrush(QBrush(dark))
            p.drawEllipse(QPointF(cx, y + hg * 0.35), wd / 2, hg / 2)
            fill(p, col("#ff8fa3"))
            p.drawEllipse(QPointF(cx, y + hg * 0.6), wd * 0.3, max(1.0, hg * 0.2))
            return
        kind = f["mouth"]
        p.setPen(pen(col(ink), 2.8))
        p.setBrush(Qt.BrushStyle.NoBrush)
        path = QPainterPath()
        if kind == "smile":
            path.moveTo(cx - 9, y)
            path.quadTo(cx, y + 8, cx + 9, y)
            p.drawPath(path)
        elif kind == "frown":
            path.moveTo(cx - 9, y + 5)
            path.quadTo(cx, y - 4, cx + 9, y + 5)
            p.drawPath(path)
        elif kind == "flat":
            path.moveTo(cx - 7, y + 2)
            path.lineTo(cx + 8, y + 1)
            p.drawPath(path)
        elif kind == "wavy":
            path.moveTo(cx - 12, y + 2)
            path.quadTo(cx - 6, y - 4, cx, y + 2)
            path.quadTo(cx + 6, y + 8, cx + 12, y + 2)
            p.drawPath(path)
        elif kind == "grin":
            p.setPen(pen(col(ink), 2.0))
            p.setBrush(QBrush(dark))
            path.moveTo(cx - 13, y - 2)
            path.quadTo(cx, y + 2, cx + 13, y - 2)
            path.quadTo(cx + 10, y + 15, cx, y + 15)
            path.quadTo(cx - 10, y + 15, cx - 13, y - 2)
            path.closeSubpath()
            p.drawPath(path)
            fill(p, col("#ff8fa3"))
            p.drawEllipse(QPointF(cx, y + 11.0), 6.0, 3.6)
        elif kind == "o":
            p.setPen(pen(col(ink), 2.0))
            p.setBrush(QBrush(dark))
            p.drawEllipse(QPointF(cx, y + 5.0), 6.0, 8.0)
        elif kind == "yawn":
            p.setPen(pen(col(ink), 2.0))
            p.setBrush(QBrush(dark))
            p.drawEllipse(QPointF(cx, y + 5.0), 8.0 + math.sin(st.t * 1.3) * 1.5, 9.0 + math.sin(st.t * 1.3) * 2)

    # ----------------------------------------------------------------- hair
    def _hair_brush(self):
        g = QLinearGradient(0, 36, 0, 250)
        g.setColorAt(0.0, col(self.hair_light))
        g.setColorAt(0.35, col(self.hair))
        g.setColorAt(1.0, col(self.hair_dark))
        return QBrush(g)

    def _hair_back(self, p):
        hair = self.sp["hair"]
        style = hair["style"]
        p.setPen(pen(col(self.line), 2.2))
        p.setBrush(self._hair_brush())
        path = QPainterPath()
        if style in ("spiky", "messy", "swept"):
            path = self._boy_silhouette(style)
        else:
            path.addEllipse(70, 40, 160, 158)
            p.drawPath(path)
            path = QPainterPath()
            if style == "long":
                path.moveTo(70, 120)
                path.cubicTo(54, 170, 52, 238, 72, 280)
                path.quadTo(110, 294, 150, 290)
                path.quadTo(190, 294, 228, 280)
                path.cubicTo(248, 238, 246, 170, 230, 120)
                path.closeSubpath()
            elif style == "twintails":
                for sx in (-1, 1):
                    path.moveTo(150 + sx * 70, 108)
                    path.cubicTo(150 + sx * 112, 112, 150 + sx * 134, 170, 150 + sx * 124, 232)
                    path.cubicTo(150 + sx * 120, 266, 150 + sx * 96, 272, 150 + sx * 90, 244)
                    path.cubicTo(150 + sx * 86, 200, 150 + sx * 76, 164, 150 + sx * 62, 140)
                    path.closeSubpath()
            elif style == "bob":
                path.moveTo(70, 118)
                path.cubicTo(58, 152, 60, 198, 84, 214)
                path.cubicTo(110, 226, 190, 226, 216, 214)
                path.cubicTo(240, 198, 242, 152, 230, 118)
                path.closeSubpath()
            elif style == "ponytail":
                path.moveTo(190, 66)
                path.cubicTo(252, 52, 284, 120, 266, 196)
                path.cubicTo(260, 236, 238, 256, 226, 240)
                path.cubicTo(238, 204, 236, 148, 206, 112)
                path.closeSubpath()
            elif style == "wavy":
                path.moveTo(68, 120)
                path.cubicTo(44, 170, 60, 210, 46, 250)
                path.quadTo(60, 292, 84, 276)
                path.quadTo(104, 296, 126, 284)
                path.quadTo(150, 300, 174, 284)
                path.quadTo(196, 296, 216, 276)
                path.quadTo(240, 292, 254, 250)
                path.cubicTo(240, 210, 256, 170, 232, 120)
                path.closeSubpath()
        p.drawPath(path)

    def _boy_silhouette(self, style) -> QPainterPath:
        pts = {
            "spiky": [(72, 132), (60, 96), (82, 104), (78, 62), (106, 84), (110, 40), (132, 70), (150, 30),
                      (168, 70), (190, 40), (194, 84), (222, 62), (218, 104), (240, 96), (228, 132)],
            "messy": [(72, 134), (64, 104), (80, 100), (84, 70), (104, 80), (116, 48), (136, 68), (156, 40),
                      (172, 66), (196, 50), (198, 80), (222, 74), (220, 104), (236, 108), (228, 134)],
            "swept": [(72, 134), (64, 98), (86, 74), (116, 52), (150, 42), (186, 44), (214, 62), (234, 96),
                      (228, 134)],
        }[style]
        path = QPainterPath()
        path.moveTo(*pts[0])
        for x, y in pts[1:]:
            path.lineTo(x, y)
        path.cubicTo(232, 176, 196, 192, 150, 192)
        path.cubicTo(104, 192, 68, 176, 72, 134)
        path.closeSubpath()
        return path

    def _bangs_path(self, translate=(0, 0)) -> QPainterPath:
        hair = self.sp["hair"]
        bangs = hair["bangs"]
        style = hair["style"]
        dx, dy = translate
        fringe = {
            "split": [(220, 134), (212, 118), (202, 134), (190, 106), (178, 128), (164, 98), (150, 112),
                      (136, 98), (122, 128), (110, 106), (98, 134), (88, 118), (80, 134)],
            "straight": [(222, 134), (222, 122), (190, 120), (150, 118), (110, 120), (78, 122), (78, 134)],
            "swept": [(222, 134), (214, 112), (196, 106), (170, 100), (140, 104), (116, 120), (100, 132),
                      (88, 124), (78, 134)],
            "spiky": [(222, 134), (214, 112), (202, 130), (192, 100), (178, 126), (166, 96), (152, 124),
                      (138, 92), (126, 122), (112, 98), (100, 126), (88, 106), (78, 134)],
            "curtain": [(222, 134), (214, 126), (196, 108), (176, 92), (150, 84), (124, 92), (104, 108),
                        (86, 126), (78, 134)],
        }[bangs]
        path = QPainterPath()
        path.moveTo(76 + dx, 134 + dy)
        path.cubicTo(64 + dx, 84 + dy, 104 + dx, 40 + dy, 150 + dx, 38 + dy)
        path.cubicTo(196 + dx, 40 + dy, 236 + dx, 84 + dy, 224 + dx, 134 + dy)
        for x, y in fringe:
            path.lineTo(x + dx, y + dy)
        path.closeSubpath()
        return path

    def _hair_front(self, p):
        hair = self.sp["hair"]
        style = hair["style"]
        p.setPen(pen(col(self.line), 2.2))
        p.setBrush(self._hair_brush())
        if style in ("long", "twintails", "bob", "ponytail", "wavy"):
            ln = 196 if style in ("bob",) else 214
            for sx in (-1, 1):
                lock = QPainterPath()
                lock.moveTo(150 + sx * 74, 112)
                lock.cubicTo(150 + sx * 80, 146, 150 + sx * 78, 188, 150 + sx * 68, ln)
                lock.cubicTo(150 + sx * 60, 186, 150 + sx * 56, 150, 150 + sx * 60, 120)
                lock.closeSubpath()
                p.drawPath(lock)
        p.drawPath(self._bangs_path())
        # glossy highlight band
        p.setPen(pen(col(self.hair_light, 0.55), 5.0))
        hl = QPainterPath()
        hl.moveTo(100, 82)
        hl.quadTo(150, 50, 200, 82)
        p.drawPath(hl)
        if self.sp["ahoge"]:
            p.setPen(pen(col(self.line), 8.0))
            a = QPainterPath()
            a.moveTo(150, 44)
            a.cubicTo(140, 16, 172, 8, 160, 28)
            p.drawPath(a)
            p.setPen(pen(col(self.hair), 4.6))
            p.drawPath(a)

    # ------------------------------------------------------------ accessories
    def _accessories(self, p, st):
        acc = self.sp["accessories"]
        ac = self.sp["accent"]
        ink = self.ink
        style = self.sp["hair"]["style"]
        if "cat_ears" in acc:
            for sx in (-1, 1):
                self._outline(p, self.line, 2.2)
                p.setBrush(QBrush(col(self.hair)))
                e = QPainterPath()
                e.moveTo(150 + sx * 66, 80)
                e.lineTo(150 + sx * 70, 22)
                e.lineTo(150 + sx * 22, 52)
                e.closeSubpath()
                p.drawPath(e)
                fill(p, col("#ff9db8"))
                i = QPainterPath()
                i.moveTo(150 + sx * 59, 66)
                i.lineTo(150 + sx * 62, 36)
                i.lineTo(150 + sx * 38, 54)
                i.closeSubpath()
                p.drawPath(i)
        if "ribbon" in acc:
            if style == "twintails":
                self._bow(p, 80, 116, ac, 0.8)
                self._bow(p, 220, 116, ac, 0.8)
            else:
                self._bow(p, 106, 62, ac, 0.9)
        if "hairpin" in acc:
            p.setPen(pen(col(ac), 4.4))
            for a, b in (((196, 88), (212, 102)), ((212, 88), (196, 102))):
                s = QPainterPath()
                s.moveTo(*a)
                s.lineTo(*b)
                p.drawPath(s)
        if "headband" in acc:
            p.setPen(pen(col(shade(ac, 0.6)), 9.0))
            hb = QPainterPath()
            hb.moveTo(78, 112)
            hb.cubicTo(88, 56, 212, 56, 222, 112)
            p.drawPath(hb)
            p.setPen(pen(col(ac), 6.0))
            p.drawPath(hb)
        if "headphones" in acc:
            p.setPen(pen(col(shade(ac, 0.55)), 10.0))
            hb = QPainterPath()
            hb.moveTo(76, 134)
            hb.cubicTo(66, 22, 234, 22, 224, 134)
            p.drawPath(hb)
            p.setPen(pen(col(ac), 6.0))
            p.drawPath(hb)
            for sx in (-1, 1):
                self._outline(p, shade(ac, 0.5), 2.0)
                p.setBrush(QBrush(col(ac)))
                c = QPainterPath()
                c.addRoundedRect(150 + sx * 74 - 12, 122, 24, 38, 10, 10)
                p.drawPath(c)
                fill(p, col(shade(ac, 0.7)))
                p.drawEllipse(QPointF(150 + sx * 74.0, 141.0), 6.0, 11.0)
        if "glasses" in acc:
            p.setPen(pen(col(ink), 3.0))
            p.setBrush(QBrush(col("#ffffff", 0.14)))
            for sx in (-1, 1):
                p.drawEllipse(QPointF(150 + sx * 36.0, 146.0), 25.0, 23.0)
            br = QPainterPath()
            br.moveTo(137, 144)
            br.quadTo(150, 137, 163, 144)
            p.drawPath(br)
            p.setPen(pen(col("#ffffff", 0.7), 2.4))
            for sx in (-1, 1):
                gl = QPainterPath()
                gl.moveTo(150 + sx * 36 - 12, 136)
                gl.lineTo(150 + sx * 36 - 6, 130)
                p.drawPath(gl)
        if "mask_tag" in acc:
            pass

