"""Central constants. Bump APP_VERSION for every release (tools/make_release.py reads it)."""

APP_NAME = "Earthvasi Personal AI"
APP_ID = "HybridAnimeAI"
APP_VERSION = "3.7.0"

# >>> CHANGE THIS to the HTTPS URL where you host version.json <<<
UPDATE_MANIFEST_URL = "https://your-domain.com/hybrid-anime-ai/version.json"

DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"
DEFAULT_OLLAMA_MODEL = "gemma2:2b"
OLLAMA_HOST = "http://127.0.0.1:11434"
OLLAMA_INSTALLER_URL = "https://ollama.com/download/OllamaSetup.exe"

USER_AGENT = f"{APP_ID}/{APP_VERSION}"

# >>> After deploying the Earthvasi API (see /server), put its URL here. Empty = no stats, no licences, no network calls. <<<
LICENSE_API = ""
# Flip to True when you launch Pro. While False every feature stays free for everyone.
PRO_ENFORCED = False
PRO_FEATURES = ("agent", "natural_voice")
