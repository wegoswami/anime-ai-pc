"""Central constants. Bump APP_VERSION for every release (tools/make_release.py reads it)."""

APP_NAME = "Hybrid Anime AI Assistant"
APP_ID = "HybridAnimeAI"
APP_VERSION = "2.0.0"

# >>> CHANGE THIS to the HTTPS URL where you host version.json <<<
UPDATE_MANIFEST_URL = "https://your-domain.com/hybrid-anime-ai/version.json"

DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"
DEFAULT_OLLAMA_MODEL = "gemma2:2b"
OLLAMA_HOST = "http://127.0.0.1:11434"
OLLAMA_INSTALLER_URL = "https://ollama.com/download/OllamaSetup.exe"

USER_AGENT = f"{APP_ID}/{APP_VERSION}"
