"""Natural, human-sounding voices (Microsoft neural voices through the optional `edge-tts` package).

Needs internet. Anything that goes wrong (no package, offline, timeout, no audio device) returns False so the
caller falls back to the offline system voice - speech never fails because of this module.
"""
import asyncio
import logging
import os
import sys
import tempfile

log = logging.getLogger(__name__)

VOICES = {
    "hi": {"female": "hi-IN-SwaraNeural", "male": "hi-IN-MadhurNeural"},
    "en": {"female": "en-IN-NeerjaNeural", "male": "en-IN-PrabhatNeural"},
    "es": {"female": "es-ES-ElviraNeural", "male": "es-ES-AlvaroNeural"},
    "fr": {"female": "fr-FR-DeniseNeural", "male": "fr-FR-HenriNeural"},
    "de": {"female": "de-DE-KatjaNeural", "male": "de-DE-ConradNeural"},
    "ja": {"female": "ja-JP-NanamiNeural", "male": "ja-JP-KeitaNeural"},
    "ar": {"female": "ar-SA-ZariyahNeural", "male": "ar-SA-HamedNeural"},
}


def voice_name(lang: str, gender: str) -> str:
    g = "male" if gender == "male" else "female"
    return VOICES.get((lang or "en")[:2], VOICES["en"])[g]


def available() -> bool:
    try:
        import edge_tts  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def _rate_str(rate: int) -> str:
    pct = int(round((int(rate) - 175) / 175 * 100))
    return f"{max(-40, min(60, pct)):+d}%"


def synth_to_file(text: str, voice: str, rate: int, path: str, timeout: float = 12.0) -> None:
    import edge_tts

    async def run():
        await asyncio.wait_for(edge_tts.Communicate(text, voice, rate=_rate_str(rate)).save(path), timeout)

    asyncio.run(run())


def _play_mci(path: str) -> bool:
    if sys.platform != "win32":
        return False
    import ctypes
    mci = ctypes.windll.winmm.mciSendStringW
    alias = "hnat"
    buf = ctypes.create_unicode_buffer(64)
    mci(f"close {alias}", None, 0, None)
    if mci(f'open "{path}" type mpegvideo alias {alias}', None, 0, None):
        return False
    try:
        mci(f"status {alias} length", buf, 64, None)
        ms = int(buf.value or 0)
        if mci(f"play {alias}", None, 0, None):
            return False
        import time
        time.sleep(ms / 1000 + 0.3 if ms else 3)
        return True
    finally:
        mci(f"close {alias}", None, 0, None)


def speak(text: str, lang: str, gender: str, cfg: dict) -> bool:
    """Blocking. True when spoken with the natural voice."""
    if not available():
        return False
    fd, path = tempfile.mkstemp(suffix=".mp3")
    os.close(fd)
    try:
        synth_to_file(text, voice_name(lang, gender), int(cfg.get("voice_rate", 175)), path)
        if os.path.getsize(path) < 200:
            return False
        return _play_mci(path)
    except Exception as exc:  # noqa: BLE001
        log.info("natural voice unavailable (%s) - using the system voice", exc)
        return False
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
