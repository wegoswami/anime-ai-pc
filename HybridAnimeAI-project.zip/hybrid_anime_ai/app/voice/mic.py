"""Microphone capture with voice-activity detection (sounddevice + numpy).

sounddevice ships its own PortAudio DLL, so unlike PyAudio it installs and freezes cleanly on Windows.
"""
import logging
import os
import queue
import sys
import threading
import time
from collections import deque
from typing import Callable, Iterator, Optional

import numpy as np

log = logging.getLogger(__name__)
SR = 16000
FRAME_S = 0.03

PRIVACY_HELP = ("I can't open the microphone. In Windows go to Settings > Privacy & security > Microphone "
                "and turn ON 'Microphone access' and 'Let desktop apps access your microphone'. "
                "Also close apps that use the mic exclusively.")
NO_MIC_HELP = "No microphone was found. Plug one in (or enable it in Windows Sound settings) and try again."


class MicError(Exception):
    """A problem that can be shown to the user as is."""


class NoSpeech(MicError):
    pass


def open_privacy_settings() -> None:
    if sys.platform == "win32":
        try:
            os.startfile("ms-settings:privacy-microphone")  # noqa: S606 - fixed trusted URI
        except OSError:
            pass


def _sd():
    try:
        import sounddevice as sd
        return sd
    except ImportError as exc:
        raise MicError("The 'sounddevice' audio package is not installed.") from exc
    except OSError as exc:
        raise MicError("The audio engine (PortAudio) could not be loaded.") from exc


def _friendly(exc: Exception) -> str:
    text = str(exc).lower()
    if "no default input" in text or "invalid number of channels" in text or "no input" in text \
            or "invalid device" in text:
        return NO_MIC_HELP
    return PRIVACY_HELP


def list_input_devices() -> list:
    """[(index, name)] of input devices, de-duplicated by name (Windows lists every host API)."""
    try:
        sd = _sd()
        seen, out = set(), []
        for i, d in enumerate(sd.query_devices()):
            if d.get("max_input_channels", 0) > 0 and d["name"] not in seen:
                seen.add(d["name"])
                out.append((i, d["name"]))
        return out
    except Exception:  # noqa: BLE001
        return []


def diagnose(device=None) -> tuple:
    """Open the mic for a moment. Returns (ok, human readable message)."""
    try:
        sd = _sd()
        with sd.InputStream(samplerate=SR, channels=1, dtype="float32", device=device):
            time.sleep(0.2)
        return True, "Microphone works."
    except MicError as exc:
        return False, str(exc)
    except Exception as exc:  # noqa: BLE001
        return False, _friendly(exc)


def to_16k(x: np.ndarray, sr: int) -> np.ndarray:
    if sr == SR or len(x) == 0:
        return x.astype(np.float32)
    n = max(1, int(len(x) * SR / sr))
    return np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype(np.float32)


class Segmenter:
    """Energy based VAD with an adaptive noise floor. feed() returns a finished phrase or None."""

    def __init__(self, sr=SR, start_factor=3.2, min_rms=0.012, end_silence=0.85, preroll=0.35,
                 max_s=25.0, min_speech=0.25):
        self.sr, self.start_factor, self.min_rms = sr, start_factor, min_rms
        self.end_silence, self.max_s, self.min_speech = end_silence, max_s, min_speech
        self.pre = deque(maxlen=max(1, int(preroll / FRAME_S)))
        self.reset()

    def reset(self) -> None:
        self.state = "idle"
        self.floor = None
        self.buf, self.total, self.silence, self.speech, self.hits = [], 0.0, 0.0, 0.0, 0
        self.pre.clear()

    @property
    def in_speech(self) -> bool:
        return self.state == "speech"

    def feed(self, frame: np.ndarray) -> Optional[np.ndarray]:
        dur = len(frame) / self.sr
        rms = float(np.sqrt(np.mean(np.square(frame))) + 1e-9)
        if self.floor is None:
            self.floor = min(rms, 0.02)
        thr = max(self.min_rms, self.floor * self.start_factor)
        if self.state == "idle":
            self.pre.append(frame)
            if rms > thr:
                self.hits += 1
            else:
                self.hits = 0
                self.floor = 0.96 * self.floor + 0.04 * min(rms, 0.05)
            if self.hits >= 2:
                self.state = "speech"
                self.buf = list(self.pre)
                self.total = len(self.buf) * dur
                self.speech, self.silence = 0.0, 0.0
            return None
        self.buf.append(frame)
        self.total += dur
        if rms > thr * 0.6:
            self.silence = 0.0
            self.speech += dur
        else:
            self.silence += dur
        if self.silence >= self.end_silence or self.total >= self.max_s:
            audio = np.concatenate(self.buf) if self.buf else None
            enough = self.speech >= self.min_speech
            floor = self.floor
            self.reset()
            self.floor = floor
            return audio if enough else None
        return None


def capture(device=None, stop: Optional[threading.Event] = None,
            level_cb: Optional[Callable[[float], None]] = None,
            paused: Optional[Callable[[], bool]] = None,
            first_timeout: Optional[float] = None) -> Iterator[np.ndarray]:
    """Yield 16 kHz mono float32 phrases until stop is set. Raises NoSpeech if first_timeout elapses."""
    sd = _sd()
    stop = stop or threading.Event()
    q: "queue.Queue[np.ndarray]" = queue.Queue(maxsize=400)
    sr = SR

    def cb(indata, _frames, _time, _status):
        try:
            q.put_nowait(indata[:, 0].copy())
        except queue.Full:
            pass

    def open_stream(rate):
        s = sd.InputStream(samplerate=rate, channels=1, dtype="float32", device=device,
                           blocksize=int(rate * FRAME_S), callback=cb)
        s.start()
        return s

    try:
        try:
            stream = open_stream(SR)
        except Exception as first:  # noqa: BLE001 - some devices only run at their native rate
            try:
                sr = int(sd.query_devices(device, "input")["default_samplerate"])
                stream = open_stream(sr)
            except Exception:  # noqa: BLE001
                raise MicError(_friendly(first)) from first
    except MicError:
        raise
    seg = Segmenter(sr=sr)
    started = time.time()
    try:
        while not stop.is_set():
            try:
                frame = q.get(timeout=0.25)
            except queue.Empty:
                frame = None
            if frame is None:
                if first_timeout and not seg.in_speech and time.time() - started > first_timeout:
                    raise NoSpeech("I didn't hear anything.")
                continue
            if paused and paused():
                seg.reset()
                started = time.time()
                continue
            if level_cb:
                level_cb(float(np.sqrt(np.mean(np.square(frame)))))
            phrase = seg.feed(frame)
            if phrase is not None:
                yield to_16k(phrase, sr)
                started = time.time()
            elif first_timeout and not seg.in_speech and time.time() - started > first_timeout:
                raise NoSpeech("I didn't hear anything.")
    finally:
        try:
            stream.stop()
            stream.close()
        except Exception:  # noqa: BLE001
            pass


def record_phrase(device=None, level_cb=None, timeout: float = 8.0,
                  stop: Optional[threading.Event] = None) -> np.ndarray:
    """Listen once: wait up to `timeout` seconds for speech, return the phrase."""
    gen = capture(device, stop, level_cb, None, timeout)
    try:
        return next(gen)
    except StopIteration as exc:
        raise NoSpeech("I didn't hear anything.") from exc
    finally:
        gen.close()
