"""Tiny language helpers (no dependencies): script detection, Hinglish detection, line language."""
import re

_RANGES = [
    (0x0900, 0x097F, "hi"), (0x0980, 0x09FF, "bn"), (0x0A00, 0x0A7F, "pa"), (0x0A80, 0x0AFF, "gu"),
    (0x0B80, 0x0BFF, "ta"), (0x0C00, 0x0C7F, "te"), (0x0C80, 0x0CFF, "kn"), (0x0D00, 0x0D7F, "ml"),
    (0x0600, 0x06FF, "ar"), (0x0400, 0x04FF, "ru"), (0x3040, 0x30FF, "ja"), (0x4E00, 0x9FFF, "zh"),
    (0xAC00, 0xD7AF, "ko"),
]

# Hindi words written in English letters. Ambiguous English words (to, me, ho, ka ...) are left out.
_HINGLISH = {
    "hai", "hain", "kya", "nahi", "nahin", "karo", "kar", "karna", "kaise", "kaisa", "kaisi", "mujhe",
    "mera", "meri", "mere", "tum", "tumhe", "tumhara", "aap", "aapka", "bhai", "yaar", "batao", "bata",
    "kholo", "khol", "chalao", "chala", "kyun", "kyu", "abhi", "bahut", "bohot", "haan", "raha", "rahi",
    "rahe", "tha", "thi", "hoon", "accha", "acha", "theek", "thik", "mein", "aur", "lekin", "kuch", "sab",
    "samajh", "baat", "karo", "band", "dikhao", "suno", "bolo", "chahiye", "wala", "wali", "hua", "gaya",
    "kaam", "ghar", "dost", "pyaar", "namaste", "shukriya", "dhanyavaad",
}


def script_code(text: str) -> str:
    """ISO code of the dominant non-Latin script in text, or 'latin'."""
    counts = {}
    for ch in text:
        o = ord(ch)
        for lo, hi, code in _RANGES:
            if lo <= o <= hi:
                counts[code] = counts.get(code, 0) + 1
                break
    if not counts:
        return "latin"
    return max(counts, key=counts.get)


def is_hinglish(text: str) -> bool:
    words = re.findall(r"[a-z']+", text.lower())
    return any(w in _HINGLISH for w in words)


def detect_lang(text: str, whisper_lang: str = "") -> str:
    """Return 'hinglish', 'en' or an ISO code like 'hi', 'ja', 'ar' ..."""
    sc = script_code(text)
    if sc != "latin":
        return sc
    if is_hinglish(text):
        return "hinglish"
    if whisper_lang and whisper_lang not in ("hi", "ur"):
        return whisper_lang
    return "en"


def line_lang(code: str) -> str:
    """Which canned-line set to use: 'en', 'hinglish' or 'hi' (Devanagari)."""
    if code in ("hinglish", "hi"):
        return code
    return "en"


def tts_lang(text: str, user_code: str = "") -> str:
    """Two-letter language the speech engine should use for this reply text."""
    sc = script_code(text)
    if sc != "latin":
        return sc
    return "en" if user_code in ("", "hinglish") else user_code
