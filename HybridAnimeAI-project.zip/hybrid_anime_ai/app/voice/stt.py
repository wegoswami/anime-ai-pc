"""Speech to text: offline Whisper (faster-whisper) with automatic language detection.

If the Whisper model is not downloaded yet and the PC is online, Gemini transcribes instead.
"""
import io
import logging
import os
import threading
import time
import wave
from typing import Callable, Optional

import numpy as np

from ..paths import models_dir
from .lang import detect_lang

log = logging.getLogger(__name__)
Progress = Callable[[str, int], None]

# approximate download sizes (bytes) of the CTranslate2 int8 models, used for the progress bar
MODEL_BYTES = {"tiny": 75e6, "base": 145e6, "small": 484e6, "medium": 1.53e9}
MODEL_CHOICES = [("tiny", "Tiny - fastest, rough (75 MB)"), ("base", "Base - fast (145 MB)"),
                 ("small", "Small - recommended, understands Hindi well (480 MB)"),
                 ("medium", "Medium - most accurate, slow on weak PCs (1.5 GB)")]
_JUNK = {"you", "thank you", "thanks", "thanks for watching", "bye", "okay", "ok", "hmm", "uh", "um",
         "subtitles by the amara.org community", "thank you for watching", "so", "yeah", "the"}


class Transcriber:
    def __init__(self):
        self._model = None
        self._size = None
        self._lock = threading.Lock()

    @staticmethod
    def model_path(size: str):
        return models_dir() / f"whisper-{size}"

    def is_ready(self, size: str) -> bool:
        p = self.model_path(size)
        return (p / "model.bin").exists() and (p / "config.json").exists()

    def ensure_model(self, size: str, progress: Progress) -> None:
        if self.is_ready(size):
            return
        from faster_whisper.utils import download_model   # lazy import (heavy)
        target = self.model_path(size)
        target.mkdir(parents=True, exist_ok=True)
        expected = MODEL_BYTES.get(size, 500e6)
        stop = threading.Event()

        def poll():
            while not stop.is_set():
                got = sum(f.stat().st_size for f in target.rglob("*") if f.is_file())
                progress("Downloading voice model", min(99, int(got * 100 / expected)))
                stop.wait(0.8)

        t = threading.Thread(target=poll, daemon=True)
        t.start()
        try:
            download_model(size, output_dir=str(target))
        finally:
            stop.set()
        progress("Voice model ready", 100)

    def _load(self, size: str):
        with self._lock:
            if self._model is not None and self._size == size:
                return self._model
            from faster_whisper import WhisperModel
            threads = max(2, (os.cpu_count() or 4) // 2)
            self._model = WhisperModel(str(self.model_path(size)), device="cpu", compute_type="int8",
                                       cpu_threads=threads)
            self._size = size
            return self._model

    def transcribe(self, audio: np.ndarray, size: str = "small", allowed: Optional[list] = None) -> tuple:
        """Return (text, detected_language_code). Language is detected automatically per phrase."""
        model = self._load(size)
        kw = dict(beam_size=1, vad_filter=False, condition_on_previous_text=False, temperature=0.0,
                  no_speech_threshold=0.6)
        segments, info = model.transcribe(audio, language=None, **kw)
        lang = info.language
        if allowed and lang not in allowed:
            probs = dict(getattr(info, "all_language_probs", None) or [])
            best = max((a for a in allowed if a in probs), key=lambda a: probs[a], default=allowed[0])
            segments, info = model.transcribe(audio, language=best, **kw)
            lang = best
        parts = []
        for seg in segments:
            if getattr(seg, "no_speech_prob", 0) > 0.7 and getattr(seg, "avg_logprob", 0) < -0.8:
                continue
            parts.append(seg.text.strip())
        text = " ".join(p for p in parts if p).strip()
        if len(audio) < 16000 * 2 and text.lower().strip(" .!?,") in _JUNK:
            return "", lang
        return text, lang


def _wav_bytes(audio: np.ndarray) -> bytes:
    pcm = (np.clip(audio, -1, 1) * 32767).astype("<i2").tobytes()
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(16000)
        w.writeframes(pcm)
    return buf.getvalue()


def cloud_transcribe(cfg: dict, audio: np.ndarray) -> tuple:
    """Gemini transcription (auto language). Only used when Whisper isn't available yet."""
    import google.generativeai as genai
    genai.configure(api_key=cfg["gemini_api_key"])
    model = genai.GenerativeModel(cfg.get("gemini_model"))
    resp = model.generate_content([
        {"mime_type": "audio/wav", "data": _wav_bytes(audio)},
        "Transcribe this speech exactly as spoken, in its original language and script. "
        "Output only the transcript. If there is no intelligible speech output nothing.",
    ], request_options={"timeout": 30})
    text = (resp.text or "").strip()
    return text, detect_lang(text)
