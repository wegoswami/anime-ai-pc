"""Offline text-to-speech (pyttsx3 / Windows SAPI5) that picks a voice matching the reply's language."""
import logging
import re
from typing import Optional

from .lang import tts_lang
from . import neural

log = logging.getLogger(__name__)

_FEMALE = ("zira", "hazel", "susan", "heera", "kalpana", "aria", "jenny", "sara", "eva", "helena", "hanhan",
           "haruka", "huihui", "yaoyao", "heami", "irina", "katja", "elsa", "paulina", "julie", "microsoft zira")
_MALE = ("david", "mark", "ravi", "hemant", "george", "james", "richard", "guy", "ichiro", "kangkang",
         "pavel", "stefan", "pablo", "claude", "sean")


def clean_for_speech(text: str) -> str:
    text = re.sub(r"[*_`#>~]", "", text)
    text = re.sub(r"https?://\S+", "link", text)
    return text.strip()


def _locale_of(voice_id: str, name: str) -> str:
    m = re.search(r"_([A-Za-z]{2})-([A-Za-z]{2,4})_", voice_id) or re.search(r"\b([a-z]{2})-([A-Z]{2})\b", name)
    return f"{m.group(1).lower()}-{m.group(2).upper()}" if m else ""


def gender_of(name: str) -> str:
    n = name.lower()
    if any(k in n for k in _FEMALE):
        return "female"
    if any(k in n for k in _MALE):
        return "male"
    return ""


def list_voices() -> list:
    """[(voice_id, display_name, locale)] for the installed SAPI voices."""
    try:
        import pyttsx3
        engine = pyttsx3.init()
        out = [(v.id, v.name, _locale_of(v.id, v.name)) for v in engine.getProperty("voices")]
        engine.stop()
        return out
    except Exception:  # noqa: BLE001
        log.exception("Could not list voices")
        return []


def pick_voice(voices: list, lang: str, gender: str = "", configured: str = "") -> Optional[str]:
    """Best installed voice for a language: the user's own choice if it speaks that language, else the
    first voice of that language matching the character's gender, else None (engine default)."""
    if not voices:
        return configured or None
    in_lang = [v for v in voices if v[2].startswith(lang)]
    if configured and any(v[0] == configured for v in in_lang):
        return configured
    if in_lang:
        for v in in_lang:
            if gender and gender_of(v[1]) == gender:
                return v[0]
        return in_lang[0][0]
    if lang == "en":
        return configured or None
    return configured or None     # no voice for that language installed -> keep the default voice


def speak(text: str, cfg: dict, user_lang: str = "", gender: str = "") -> None:
    """Blocking speech - call from a worker thread. A fresh engine per call avoids the pyttsx3 'run loop
    already started' problem."""
    text = clean_for_speech(text)
    if not text:
        return
    override = cfg.get("voice_gender", "auto")
    if override in ("female", "male"):
        gender = override
    if cfg.get("voice_engine", "natural") == "natural" and neural.speak(text, tts_lang(text, user_lang), gender or "female", cfg):
        return
    com = None
    try:
        import comtypes
        comtypes.CoInitialize()
        com = comtypes
    except Exception:  # noqa: BLE001 - not on Windows
        pass
    try:
        import pyttsx3
        engine = pyttsx3.init()
        voices = [(v.id, v.name, _locale_of(v.id, v.name)) for v in engine.getProperty("voices")]
        vid = pick_voice(voices, tts_lang(text, user_lang), gender, cfg.get("voice_id", "") if override == "auto" else "")
        if vid:
            try:
                engine.setProperty("voice", vid)
            except Exception:  # noqa: BLE001
                log.warning("Voice %s unavailable, using default", vid)
        engine.setProperty("rate", int(cfg.get("voice_rate", 175)))
        engine.setProperty("volume", max(0.0, min(1.0, float(cfg.get("voice_volume", 1.0)))))
        engine.say(text)
        engine.runAndWait()
        engine.stop()
    finally:
        if com is not None:
            try:
                com.CoUninitialize()
            except Exception:  # noqa: BLE001
                pass
