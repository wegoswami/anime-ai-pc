"""Overwritten by the GitHub workflow at build time with the repository that publishes releases."""
GITHUB_REPO = ""      # e.g. "your-name/your-repo"  (the workflow fills this in automatically)
