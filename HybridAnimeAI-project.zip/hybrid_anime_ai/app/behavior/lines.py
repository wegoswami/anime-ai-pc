"""Canned things the pet says by itself, in English, Hinglish (Hindi in English letters) and Hindi.

Placeholders: {name} = your name, {app} = the app you work in, {me} = assistant name, {what} = reminder text.
"""

LINES = {
    "en": {
        "greet_morning": ["Good morning, {name}! Ready for a great day?", "Morning, {name}! I'm all set when you are."],
        "greet_afternoon": ["Good afternoon, {name}! How's your day going?", "Hey {name}, hope lunch was good!"],
        "greet_evening": ["Good evening, {name}! Nice to see you.", "Evening, {name}! Let's finish strong."],
        "greet_night": ["Hi {name}! Burning the midnight oil?", "Hello {name}. Don't stay up too late, okay?"],
        "break_reminder": ["{name}, you've been at it for a long time. Stretch and drink some water!",
                           "Time for a little break, {name}. Look away from the screen for twenty seconds!"],
        "perched": ["I'll sit up here while you work in {app}.", "Found a cozy spot above {app}. Carry on, {name}!"],
        "app_code": ["Coding time! You've got this, {name}.", "Bugs beware. {name} is on the keyboard!"],
        "app_browser": ["Found anything interesting online?", "Browsing again? Don't forget to take breaks!"],
        "app_office": ["Looks like serious work. I'll stay quiet and cheer for you!", "Go {name}, go! Productivity mode!"],
        "app_media": ["Ooh, nice. Enjoy it, {name}!", "Entertainment break? You deserve it."],
        "app_chat": ["Chatting with friends? Say hi from me!", "Busy chatting, huh?"],
        "cursor_near": ["Hm? Did you need me, {name}?", "I see your cursor! Hello!", "Are you working right here?"],
        "cursor_fast": ["Whoa, slow down!", "Eek! That was fast!"],
        "woke_up": ["Oh, you're back! I dozed off.", "Welcome back, {name}!"],
        "idle_nudge": ["{name}, are you still there?", "It's quiet... I'll take a little nap soon."],
        "late_night": ["It's really late, {name}. Sleep is important!", "Past midnight... go rest soon, okay?"],
        "random": ["I'm here if you want to chat, {name}!", "Did you know? Smiling makes you feel better.",
                   "Tip: say 'what was I doing' and I'll tell you what you worked on.",
                   "You can drag me anywhere. I like exploring your screen!", "Want me to open something? Just ask."],
        "dragged": ["Waaah! Put me down!", "Eek! Where are we going?"],
        "landed_hard": ["Ouch... I'm okay!", "That was a big drop, hehe."],
        "poked": ["Hehe, that tickles!", "Yes, {name}?", "Hi hi!"],
        "reminder": ["Reminder, {name}: {what}", "Hey {name}! Time to {what}."],
    },
    "hinglish": {
        "greet_morning": ["Good morning {name}! Aaj ka din mast jaayega!", "Suprabhat {name}! Main ready hoon."],
        "greet_afternoon": ["Namaste {name}! Din kaisa chal raha hai?", "Hey {name}, lunch ho gaya kya?"],
        "greet_evening": ["Good evening {name}! Aapko dekh ke accha laga.", "Shaam mubarak {name}! Chalo kaam khatam karte hain."],
        "greet_night": ["Hi {name}! Raat ko bhi kaam? Dhyan rakhna.", "Hello {name}, zyada der mat jaagna, theek hai?"],
        "break_reminder": ["{name}, bahut der se kaam kar rahe ho. Thoda stretch karo aur paani piyo!",
                           "Chhota sa break lo {name}! Screen se nazar hata ke 20 second dekho."],
        "perched": ["Aap {app} mein kaam karo, main yahin upar baithi hoon.", "Yahan {app} ke upar mast jagah mili. Chalo {name}, kaam karo!"],
        "app_code": ["Coding time! {name}, aap kar loge.", "Bug ko bolo bhaag jaao, {name} aa gaye!"],
        "app_browser": ["Kuch interesting mila online?", "Phir se browsing? Break lena mat bhoolna!"],
        "app_office": ["Serious kaam lag raha hai. Main chup rehti hoon aur cheer karti hoon!", "Chalo {name}, productivity mode on!"],
        "app_media": ["Wah, maza karo {name}!", "Entertainment break? Aapka haq banta hai."],
        "app_chat": ["Dosto se baat? Meri taraf se hi bolna!", "Chatting chal rahi hai, hai na?"],
        "cursor_near": ["Hmm? Kuch chahiye {name}?", "Maine aapka cursor dekh liya! Hello!", "Yahin kaam kar rahe ho kya?"],
        "cursor_fast": ["Arre arre, dheere!", "Oho! Kitni tez!"],
        "woke_up": ["Oh, aap aa gaye! Meri aankh lag gayi thi.", "Welcome back {name}!"],
        "idle_nudge": ["{name}, aap wahan ho?", "Bahut shaanti hai... main thodi der sone wali hoon."],
        "late_night": ["Bahut raat ho gayi {name}. Neend bhi zaroori hai!", "Aadhi raat ho gayi... ab so jao, theek hai?"],
        "random": ["Main yahin hoon, baat karni ho to bolo {name}!", "Pata hai? Muskurane se mood accha hota hai.",
                   "Tip: bolo 'main kya kar raha tha' to main bata dungi.", "Mujhe kahin bhi drag kar do, mujhe ghoomna pasand hai!",
                   "Kuch kholna ho to bas bol do."],
        "dragged": ["Aaaa! Mujhe neeche utaro!", "Arre! Kahan le ja rahe ho?"],
        "landed_hard": ["Aww... main theek hoon!", "Itni oonchai se gira diya, hehe."],
        "poked": ["Hehe, gudgudi hui!", "Ji {name}?", "Hi hi!"],
        "reminder": ["Yaad dilana tha {name}: {what}", "Hey {name}! {what} ka time ho gaya."],
    },
    "hi": {
        "greet_morning": ["सुप्रभात {name}! आज का दिन शानदार रहेगा!"],
        "greet_afternoon": ["नमस्ते {name}! दिन कैसा चल रहा है?"],
        "greet_evening": ["शुभ संध्या {name}! आपको देखकर अच्छा लगा।"],
        "greet_night": ["नमस्ते {name}! देर रात तक काम? अपना ध्यान रखना।"],
        "break_reminder": ["{name}, बहुत देर से काम कर रहे हो। थोड़ा आराम करो और पानी पियो!"],
        "perched": ["आप {app} में काम करो, मैं यहीं ऊपर बैठी हूँ।"],
        "app_code": ["कोडिंग का समय! {name}, आप कर लोगे।"],
        "app_browser": ["कुछ मज़ेदार मिला?"],
        "app_office": ["गंभीर काम लग रहा है। मैं चुप रहकर आपका हौसला बढ़ाऊँगी!"],
        "app_media": ["वाह, मज़े करो {name}!"],
        "app_chat": ["दोस्तों से बात? मेरी तरफ़ से हेलो बोलना!"],
        "cursor_near": ["हम्म? कुछ चाहिए {name}?", "मैंने आपका कर्सर देख लिया!"],
        "cursor_fast": ["अरे अरे, धीरे!"],
        "woke_up": ["अरे, आप आ गए! मेरी आँख लग गई थी।"],
        "idle_nudge": ["{name}, आप वहाँ हो?"],
        "late_night": ["बहुत रात हो गई {name}। नींद भी ज़रूरी है!"],
        "random": ["मैं यहीं हूँ, बात करनी हो तो बोलो {name}!", "मुस्कुराने से मूड अच्छा होता है।"],
        "dragged": ["आआआ! मुझे नीचे उतारो!"],
        "landed_hard": ["आउच... मैं ठीक हूँ!"],
        "poked": ["हेहे, गुदगुदी हुई!", "जी {name}?"],
        "reminder": ["याद दिलाना था {name}: {what}"],
    },
}

APP_CATEGORY = {
    "app_code": {"code.exe", "devenv.exe", "pycharm64.exe", "idea64.exe", "sublime_text.exe", "notepad++.exe",
                 "windowsterminal.exe", "cmd.exe", "powershell.exe"},
    "app_browser": {"chrome.exe", "msedge.exe", "firefox.exe", "brave.exe", "opera.exe"},
    "app_office": {"winword.exe", "excel.exe", "powerpnt.exe", "onenote.exe", "outlook.exe", "acrobat.exe",
                   "notepad.exe"},
    "app_media": {"spotify.exe", "vlc.exe", "obs64.exe", "steam.exe"},
    "app_chat": {"whatsapp.exe", "telegram.exe", "discord.exe", "teams.exe", "ms-teams.exe", "slack.exe", "zoom.exe"},
}


def category_for(process: str) -> str:
    p = (process or "").lower()
    for cat, procs in APP_CATEGORY.items():
        if p in procs:
            return cat
    return ""
