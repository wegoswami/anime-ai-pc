"""Decides WHEN and WHAT the pet says on its own (greetings, break reminders, app comments, reactions)."""
import random
import time
from typing import Optional

from .lines import LINES, category_for

# seconds between random remarks for each chattiness level (None = never)
INTERVAL = {"off": None, "low": 1500.0, "normal": 720.0, "high": 300.0}
PROB = {"off": 0.0, "low": 0.45, "normal": 0.8, "high": 1.0}
EMOTION_FOR = {"greet_morning": "happy", "greet_afternoon": "happy", "greet_evening": "happy",
               "greet_night": "sleepy", "break_reminder": "thinking", "perched": "happy", "cursor_near": "happy",
               "cursor_fast": "surprised", "woke_up": "happy", "idle_nudge": "confused", "late_night": "sleepy",
               "random": "happy", "dragged": "surprised", "landed_hard": "embarrassed", "poked": "embarrassed",
               "reminder": "happy"}


class Chatter:
    def __init__(self, get_cfg, tracker, rng: Optional[random.Random] = None):
        self.cfg = get_cfg           # callable returning the live config dict
        self.tracker = tracker
        self.rng = rng or random.Random()
        self.user_lang = "en"        # language the user spoke/typed last ('en' / 'hinglish' / 'hi' / ...)
        self.cool = {}               # key -> time when allowed again
        self.last_spoke = time.time()
        self.last_fg = ""
        self.fg_since = 0.0
        self.last_break = time.time()
        self.greeted = False

    # ------------------------------------------------------------------ helpers
    def lang(self) -> str:
        pref = self.cfg().get("language_pref", "auto")
        if pref in ("en", "hinglish", "hi"):
            return pref
        return self.user_lang if self.user_lang in ("hinglish", "hi") else "en"

    quiet_until = 0.0        # focus mode: stay silent until this epoch time

    def level(self) -> str:
        return self.cfg().get("proactive_level", "normal")

    def _ready(self, key: str, now: float, cooldown: float) -> bool:
        if now < self.cool.get(key, 0.0):
            return False
        self.cool[key] = now + cooldown
        return True

    def say(self, kind: str, now: float, **fmt):
        pool = LINES[self.lang()].get(kind) or LINES["en"].get(kind)
        if not pool:
            return None
        cfg = self.cfg()
        text = self.rng.choice(pool).format(name=cfg.get("user_name") or "friend", me=cfg.get("assistant_name", ""),
                                            app=fmt.get("app", "this"), what=fmt.get("what", ""))
        self.last_spoke = now
        return text, EMOTION_FOR.get(kind, "happy")

    # ----------------------------------------------------------------- events
    def greeting(self, now: float, hour: int):
        kind = ("greet_morning" if 5 <= hour < 12 else "greet_afternoon" if 12 <= hour < 17
                else "greet_evening" if 17 <= hour < 21 else "greet_night")
        self.greeted = True
        return self.say(kind, now)

    def on_intent(self, kind: str, arg: str, now: float):
        lvl = self.level()
        if lvl == "off" or now < self.quiet_until:
            return None
        if self.rng.random() > PROB[lvl] and kind not in ("woke_up", "poked"):
            return None
        table = {"perched": ("perched", 600), "cursor_near": ("cursor_near", 120), "cursor_fast": ("cursor_fast", 60),
                 "woke_up": ("woke_up", 60), "landed_hard": ("landed_hard", 40), "poked": ("poked", 4),
                 "dragging": ("dragged", 40)}
        if kind not in table:
            return None
        line_kind, cd = table[kind]
        key = f"{kind}:{arg}" if kind == "perched" else kind
        if not self._ready(key, now, cd):
            return None
        return self.say(line_kind, now, app=arg or "this")

    # -------------------------------------------------------------- periodic
    def tick(self, now: float, hour: int, fg_proc: str, busy: bool, fullscreen: bool, idle_s: float):
        """Called about once per second. Returns (text, emotion) or None."""
        lvl = self.level()
        if lvl == "off" or busy or fullscreen or now < self.quiet_until:
            return None
        # app comment after 90 s inside the same app category
        if fg_proc != self.last_fg:
            self.last_fg, self.fg_since = fg_proc, now
        cat = category_for(fg_proc)
        if cat and now - self.fg_since > 90 and now - self.last_spoke > 120 and self._ready(f"app:{cat}", now, 1800):
            if self.rng.random() < PROB[lvl]:
                return self.say(cat, now)
        # long work session -> break reminder
        if self.tracker is not None and self.tracker.active_minutes(now) > 50 and now - self.last_break > 3000:
            self.last_break = now
            return self.say("break_reminder", now)
        if 0 <= hour < 4 and self._ready("late", now, 3600) and idle_s < 60:
            return self.say("late_night", now)
        if 120 <= idle_s < 200 and self._ready("idle", now, 900):
            return self.say("idle_nudge", now)
        iv = INTERVAL[lvl]
        if iv and now - self.last_spoke > iv * self.rng.uniform(0.8, 1.4) and idle_s < 120:
            return self.say("random", now)
        return None
