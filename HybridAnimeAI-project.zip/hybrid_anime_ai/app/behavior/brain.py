"""The pet's autonomous behaviour (pure Python, no Qt, fully unit-tested).

It owns the pet's feet position and decides: fall with gravity, wander, sit, wave, sleep when you are away,
jump onto the window you are working in, follow your cursor with its eyes and react to it.
All coordinates are Qt logical pixels, y grows downwards, (x, y) = the point where the feet touch a surface.
"""
import math
import random
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from .emotion import EmotionState

GRAVITY = 2200.0
WALK_SPEED = 85.0
SLEEP_AFTER = 180.0          # seconds without keyboard/mouse input


@dataclass
class Surface:
    id: str
    left: float
    right: float
    y: float                 # standing line (the top edge of a window / the ground)
    label: str = ""          # friendly app name


@dataclass
class Env:
    now: float
    dt: float
    screen: Tuple[float, float, float, float]       # available area (l, t, r, b), logical
    surfaces: List[Surface] = field(default_factory=list)   # window tops (ground is added by the brain)
    cursor: Tuple[float, float] = (0.0, 0.0)
    cursor_still_s: float = 0.0
    cursor_speed: float = 0.0                       # px / second
    cursor_surface_id: Optional[str] = None         # window under the cursor ("ground-work" = maximised one)
    user_idle_s: float = 0.0
    speaking: bool = False
    listening: bool = False
    head_offset: float = 150.0                      # feet -> head distance (px) for gaze


@dataclass
class Frame:
    x: float
    y: float
    pose: str
    facing: int
    emotion: str
    look: Tuple[float, float]
    walk_phase: float
    surface_id: str
    intents: List[Tuple[str, str]] = field(default_factory=list)


class PetBrain:
    def __init__(self, x: float, y: float, rng: Optional[random.Random] = None,
                 walk: bool = True, perch: bool = True):
        self.rng = rng or random.Random()
        self.walk_enabled, self.perch_enabled = walk, perch
        self.x, self.y, self.vy = x, y, 0.0
        self.mode = "fall"
        self.pinned = False            # True: stays exactly where the user drops it (no falling, no wandering)
        self.surface_id = "ground"
        self.facing = 1
        self.walk_phase = 0.0
        self.target_x: Optional[float] = None
        self.until = 0.0
        self.next_decision = 0.0
        self.next_go = 0.0
        self.emotion = EmotionState()
        self.look = [0.0, 0.0]
        self.near_since: Optional[float] = None
        self.last_react = -99.0
        self.last_fast = -99.0
        self.jump = None
        self._screen = (0.0, 0.0, 1920.0, 1080.0)

    # ------------------------------------------------------- user interaction
    def grab(self, x: float, y: float, now: float) -> None:
        self.mode, self.x, self.y, self.vy = "held", x, y, 0.0
        self.emotion.set("surprised", 99, now)

    def drag(self, x: float, y: float) -> None:
        self.x, self.y = x, y

    def release(self, now: float) -> None:
        if self.mode == "held":
            self.vy, self.surface_id = 0.0, ""
            self.mode = "pinned" if self.pinned else "fall"
            self.emotion.set("happy" if self.pinned else "surprised", 1.2, now)

    def set_pinned(self, on: bool) -> None:
        self.pinned = bool(on)
        if self.pinned and self.mode not in ("held",):
            self.mode, self.vy, self.target_x = "pinned", 0.0, None
        elif not self.pinned and self.mode == "pinned":
            self.mode = "fall"                                  # un-pinning lets it drop to the nearest surface

    def poke(self, now: float) -> List[Tuple[str, str]]:
        self.emotion.set(self.rng.choice(["happy", "surprised", "embarrassed", "love"]), 3.0, now)
        return [("poked", "")]

    def set_emotion(self, name: str, seconds: float, now: float) -> None:
        self.emotion.set(name, seconds, now)

    # -------------------------------------------------------------------- tick
    def tick(self, env: Env) -> Frame:
        now, dt = env.now, min(env.dt, 0.1)
        self._screen = env.screen
        sl, st, sr, sb = env.screen
        ground = Surface("ground", sl, sr, sb, "")
        surfaces = sorted(env.surfaces + [ground], key=lambda s: s.y)
        intents: List[Tuple[str, str]] = []
        pose = "stand"

        self._update_look(env, dt)

        if self.mode == "held":
            pose = "held"
            if now - self.last_react > 30:
                self.last_react = now
                intents.append(("dragging", ""))
        elif self.mode == "pinned":
            pose = "stand"
            self._react_to_cursor(env, intents)
        elif self.mode == "fall":
            pose = "fall"
            self._fall(dt, surfaces, env, intents)
        elif self.mode == "jump":
            pose = "jump"
            self._do_jump(dt, env, intents)
        else:
            pose = self._ground_logic(env, surfaces, intents)

        sleepy = self.mode == "sleep"
        emo = self.emotion.get(now)
        if emo == "neutral":
            if sleepy:
                emo = "sleepy"
            elif env.listening:
                emo = "listening"
        return Frame(self.x, self.y, pose, self.facing, emo, (self.look[0] * self.facing, self.look[1]),
                     self.walk_phase, self.surface_id, intents)

    # ----------------------------------------------------------------- physics
    def _fall(self, dt, surfaces, env, intents) -> None:
        sl, _st, sr, _sb = env.screen
        prev = self.y
        self.vy += GRAVITY * dt
        self.y += self.vy * dt
        self.x = max(sl + 20, min(sr - 20, self.x))
        for s in surfaces:
            if s.left - 4 <= self.x <= s.right + 4 and prev <= s.y + 1 and self.y >= s.y:
                hard = self.vy > 1500
                self.y, self.vy = s.y, 0.0
                self._land(s, env.now)
                if hard:
                    self.emotion.set("embarrassed", 2.5, env.now)
                    intents.append(("landed_hard", ""))
                return

    def _land(self, s: Surface, now: float) -> None:
        self.mode, self.surface_id, self.target_x = "idle", s.id, None
        self.next_decision = now + self.rng.uniform(1.0, 2.5)
        self.until = 0.0

    def _do_jump(self, dt, env, intents) -> None:
        j = self.jump
        j["t"] += dt
        u = min(1.0, j["t"] / j["dur"])
        self.x = j["x0"] + (j["x1"] - j["x0"]) * u
        self.y = j["y0"] + (j["y1"] - j["y0"]) * u - 4 * j["h"] * u * (1 - u)
        self.facing = 1 if j["x1"] >= j["x0"] else -1
        if u >= 1.0:
            self.x, self.y = j["x1"], j["y1"]
            target = next((s for s in env.surfaces if s.id == j["sid"]), None)
            self.jump = None
            if target is None and j["sid"] != "ground":
                self.mode, self.vy, self.surface_id = "fall", 0.0, ""
                return
            self.mode, self.surface_id = "idle", j["sid"]
            self.next_decision = env.now + self.rng.uniform(2.0, 4.0)
            if j["sid"] != "ground":
                intents.append(("perched", target.label if target else ""))
                self.emotion.set("happy", 2.5, env.now)

    def _start_jump(self, x1: float, s: Surface, now: float) -> None:
        dist = math.hypot(x1 - self.x, s.y - self.y)
        self.jump = {"x0": self.x, "y0": self.y, "x1": x1, "y1": s.y, "sid": s.id, "t": 0.0,
                     "dur": max(0.5, min(1.0, dist / 700.0)), "h": 70 + dist * 0.12}
        self.mode = "jump"

    # --------------------------------------------------------------- behaviour
    def _current_surface(self, env, surfaces) -> Optional[Surface]:
        for s in surfaces:
            if s.id == self.surface_id:
                return s
        return None

    def _ground_logic(self, env, surfaces, intents) -> str:
        now, dt = env.now, min(env.dt, 0.1)
        surf = self._current_surface(env, surfaces)
        if surf is None:                      # window closed / minimised under our feet -> fall
            self.mode, self.vy, self.surface_id = "fall", 0.0, ""
            return "fall"
        self.y = surf.y                       # ride along when the window moves
        lo, hi = surf.left + 24, surf.right - 24
        if hi < lo:
            lo = hi = (surf.left + surf.right) / 2
        self.x = max(lo, min(hi, self.x))
        on_window = surf.id != "ground"
        seat = "sit_edge" if on_window else "sit_ground"

        # ---- sleep / wake
        if self.mode == "sleep":
            if env.user_idle_s < 3.0:
                self.mode = "idle"
                self.emotion.set("surprised", 1.2, now)
                intents.append(("woke_up", ""))
                self.next_decision = now + 2.0
            else:
                return "sleep_edge" if on_window else "sleep"
        elif env.user_idle_s > SLEEP_AFTER and not env.speaking:
            self.mode = "sleep"
            intents.append(("fell_asleep", ""))
            return "sleep_edge" if on_window else "sleep"

        self._react_to_cursor(env, intents)

        if env.speaking or env.listening:
            if self.mode == "walk":
                self.mode = "idle"
            return seat if self.mode == "sit" else "stand"

        # ---- go where the user is working
        if self.perch_enabled and self.mode in ("idle", "walk", "sit") and now >= self.next_go:
            tgt = self._work_target(env, surfaces, surf)
            if tgt is not None:
                s, x1 = tgt
                self.next_go = now + 30.0
                self._start_jump(x1, s, now)
                return "jump"

        if self.mode == "walk":
            return self._walk(dt, lo, hi, now)
        if self.mode == "sit":
            if now >= self.until:
                self.mode = "idle"
            return seat
        if self.mode == "wave":
            if now >= self.until:
                self.mode = "idle"
            return "wave"

        if now >= self.next_decision:
            self._decide(now, lo, hi)
        return "stand"

    def _work_target(self, env, surfaces, cur) -> Optional[tuple]:
        sid = env.cursor_surface_id
        if not sid or env.cursor_still_s < 6.0 or sid == cur.id:
            return None
        cx = env.cursor[0]
        if sid == "ground-work":              # user works in a maximised window: wait on the ground nearby
            if cur.id == "ground":
                return None
            g = next(s for s in surfaces if s.id == "ground")
            return g, max(g.left + 24, min(g.right - 24, cx))
        s = next((s for s in env.surfaces if s.id == sid), None)
        if s is None:
            return None
        return s, max(s.left + 30, min(s.right - 30, cx))

    def _walk(self, dt, lo, hi, now) -> str:
        if self.target_x is None:
            self.mode = "idle"
            return "stand"
        d = self.target_x - self.x
        step = WALK_SPEED * dt
        if abs(d) <= step:
            self.x = self.target_x
            self.target_x, self.mode = None, "idle"
            self.next_decision = now + self.rng.uniform(3.0, 7.0)
            return "stand"
        direction = 1 if d > 0 else -1
        self.facing = direction
        self.x = max(lo, min(hi, self.x + direction * step))
        self.walk_phase += step / 16.0
        return "walk"

    def _decide(self, now, lo, hi) -> None:
        r = self.rng.random()
        self.next_decision = now + self.rng.uniform(3.0, 6.5)
        if r < 0.45 and self.walk_enabled and hi - lo > 80:
            span = hi - lo
            tx = self.x + self.rng.choice([-1, 1]) * self.rng.uniform(min(60, span / 3), min(380, span))
            self.target_x = max(lo, min(hi, tx))
            self.mode = "walk"
        elif r < 0.62:
            self.mode, self.until = "sit", now + self.rng.uniform(7, 16)
        elif r < 0.70:
            self.mode, self.until = "wave", now + 2.4
            self.emotion.set("happy", 2.6, now)
        elif r < 0.80:
            self.facing = -self.facing

    # ------------------------------------------------------------ cursor logic
    def _react_to_cursor(self, env, intents) -> None:
        now = env.now
        cx, cy = env.cursor
        dist = math.hypot(cx - self.x, cy - (self.y - env.head_offset * 0.6))
        if dist < 150:
            self.near_since = self.near_since or now
        else:
            self.near_since = None
        if self.mode == "sleep":
            return
        if self.near_since and now - self.near_since > 1.2 and now - self.last_react > 12:
            self.last_react = now
            self.emotion.set("happy", 3.0, now)
            intents.append(("cursor_near", ""))
        elif dist < 260 and env.cursor_speed > 1800 and now - self.last_fast > 8:
            self.last_fast = now
            self.emotion.set("surprised", 1.5, now)
            intents.append(("cursor_fast", ""))

    def _update_look(self, env, dt) -> None:
        cx, cy = env.cursor
        hx, hy = self.x, self.y - env.head_offset
        tx = max(-1.0, min(1.0, (cx - hx) / 320.0))
        ty = max(-1.0, min(1.0, (cy - hy) / 260.0))
        k = min(1.0, dt * 9)
        self.look[0] += (tx - self.look[0]) * k
        self.look[1] += (ty - self.look[1]) * k
        if self.mode in ("idle", "sit", "wave") and abs(cx - hx) > 140:
            self.facing = 1 if cx > hx else -1
