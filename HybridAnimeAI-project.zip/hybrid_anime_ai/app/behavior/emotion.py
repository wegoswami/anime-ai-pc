"""Emotion bookkeeping: timed emotion override, [tag] parsing and a keyword mood guess. No Qt."""
import re

VALID = {"neutral", "happy", "love", "sad", "angry", "surprised", "thinking", "embarrassed", "sleepy",
         "confused", "listening"}
_TAG = re.compile(r"^\s*\[(\w+)\]\s*")
_ALIASES = {"joy": "happy", "excited": "happy", "smile": "happy", "shy": "embarrassed", "blush": "embarrassed",
            "worried": "sad", "upset": "sad", "mad": "angry", "shock": "surprised", "curious": "thinking",
            "calm": "neutral", "tired": "sleepy"}


class EmotionState:
    def __init__(self):
        self.name = "neutral"
        self.until = 0.0

    def set(self, name: str, seconds: float, now: float) -> None:
        name = _ALIASES.get(name, name)
        if name in VALID:
            self.name, self.until = name, now + seconds

    def get(self, now: float) -> str:
        return self.name if now < self.until else "neutral"


def parse_tag(text: str) -> tuple:
    """'[happy] Hello!' -> ('Hello!', 'happy').  Unknown tags are stripped and ignored."""
    m = _TAG.match(text or "")
    if not m:
        return (text or "").strip(), None
    tag = _ALIASES.get(m.group(1).lower(), m.group(1).lower())
    return text[m.end():].strip(), (tag if tag in VALID else None)


_RULES = [
    ("love", r"\blove\b|pyaar|प्यार|♥|❤"),
    ("sad", r"\bsorry\b|\bsad\b|unfortunately|maaf|afsos|dukh|माफ़|दुख"),
    ("angry", r"\bangry\b|gussa|गुस्सा"),
    ("surprised", r"\bwow\b|\bwhoa\b|really\?|sach\?|सच\?|अरे"),
    ("embarrassed", r"thank you|thanks|shukriya|dhanyavaad|शुक्रिया|धन्यवाद|\bblush"),
    ("thinking", r"\bhmm+\b|let me think|sochti|सोचती|सोचता"),
    ("confused", r"not sure|don't know|pata nahi|पता नहीं|confus"),
    ("happy", r"\bhaha|\bhehe|\bgreat\b|awesome|\byay\b|congrat|badhai|mast|मज़ा|बधाई|:\)|!$"),
]


def guess_emotion(text: str) -> str:
    t = (text or "").lower().strip()
    for name, pat in _RULES:
        if re.search(pat, t):
            return name
    return "neutral"
