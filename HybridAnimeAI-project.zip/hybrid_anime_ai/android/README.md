# Earthvasi AI - Android app

Native wrapper around the web app in `../mobile`.
- Floating pet above every app (overlay service), drag to move, tap to talk, long-press to open the app.
- Starts again after phone restart (if enabled in the app settings).
- Real microphone (Android speech recognizer) and Android text-to-speech.
- Commands: open any installed app, call a contact, torch, volume, Wi-Fi/Bluetooth settings, reminders/alarms (ring even when closed).
- Self-update: checks the latest GitHub release of this repo for a newer APK.

Build: GitHub Actions workflow `build-apk-from-zip.yml` (copies `../mobile` into `app/src/main/assets/www` and runs `gradle assembleRelease`).
The APK is signed with `signing/buddy.keystore` so every new APK installs over the old one as an update.
