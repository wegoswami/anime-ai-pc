package com.animebuddy.pet;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/** Reminders / alarms: AlarmManager rings them even when the app is closed; they are re-armed after a reboot. */
final class Remind {
    private Remind() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("rem", Context.MODE_PRIVATE);
    }

    static void schedule(Context c, String id, long at, String text) {
        try {
            JSONArray old = new JSONArray(sp(c).getString("list", "[]"));
            JSONArray a = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                if (!id.equals(old.getJSONObject(i).optString("id"))) a.put(old.getJSONObject(i));
            }
            a.put(new JSONObject().put("id", id).put("at", at).put("text", text));
            sp(c).edit().putString("list", a.toString()).apply();
        } catch (Exception ignored) { }
        arm(c, id, at, text);
    }

    private static PendingIntent pending(Context c, String id, String text) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("id", id);
        i.putExtra("text", text);
        return PendingIntent.getBroadcast(c, id.hashCode(), i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void arm(Context c, String id, long at, String text) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent show = PendingIntent.getActivity(c, 2, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        try {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pending(c, id, text));
        } catch (Exception ignored) { }
    }

    static void cancel(Context c, String id) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pending(c, id, ""));
        remove(c, id);
    }

    static void remove(Context c, String id) {
        try {
            JSONArray old = new JSONArray(sp(c).getString("list", "[]"));
            JSONArray a = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                if (!id.equals(old.getJSONObject(i).optString("id"))) a.put(old.getJSONObject(i));
            }
            sp(c).edit().putString("list", a.toString()).apply();
        } catch (Exception ignored) { }
    }

    static void rearmAll(Context c) {
        try {
            JSONArray old = new JSONArray(sp(c).getString("list", "[]"));
            JSONArray keep = new JSONArray();
            long now = System.currentTimeMillis();
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.getJSONObject(i);
                long at = o.optLong("at");
                if (at > now) {
                    keep.put(o);
                    arm(c, o.optString("id"), at, o.optString("text"));
                }
            }
            sp(c).edit().putString("list", keep.toString()).apply();
        } catch (Exception ignored) { }
    }
}
