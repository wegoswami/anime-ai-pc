package com.animebuddy.pet;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

final class Notif {
    static final String CH_PET = "pet";
    static final String CH_REMIND = "remind";

    private Notif() {}

    static void channels(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel pet = new NotificationChannel(CH_PET, "Anime Buddy (running)", NotificationManager.IMPORTANCE_MIN);
        pet.setShowBadge(false);
        nm.createNotificationChannel(pet);
        NotificationChannel rem = new NotificationChannel(CH_REMIND, "Reminders", NotificationManager.IMPORTANCE_HIGH);
        rem.enableVibration(true);
        nm.createNotificationChannel(rem);
    }

    static void show(Context c, String title, String body) {
        channels(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CH_REMIND)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        try {
            nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), n);
        } catch (Exception ignored) { }
    }
}
