package com.animebuddy.pet;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Things the user shares to the assistant from any other app (files, links, text). */
final class Shared {
    static volatile String pending;          // JSON for the web app, delivered once
    static volatile String mime = "application/octet-stream";
    private static final long MAX = 12L * 1024 * 1024;

    private Shared() {}

    static File file(Context c) { return new File(c.getCacheDir(), "shared.bin"); }

    /** Runs on a worker thread. Returns true if something was queued. */
    static boolean handle(Context c, Intent in) {
        if (in == null || !Intent.ACTION_SEND.equals(in.getAction())) return false;
        try {
            Uri u = in.getParcelableExtra(Intent.EXTRA_STREAM);
            String text = in.getStringExtra(Intent.EXTRA_TEXT);
            JSONObject o = new JSONObject();
            if (u != null) {
                String name = "file";
                Cursor q = c.getContentResolver().query(u, null, null, null, null);
                if (q != null) {
                    try {
                        int i = q.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        if (q.moveToFirst() && i >= 0) name = q.getString(i);
                    } finally {
                        q.close();
                    }
                }
                String type = in.getType() != null ? in.getType() : c.getContentResolver().getType(u);
                mime = type == null ? "application/octet-stream" : type;
                long total = 0;
                InputStream is = c.getContentResolver().openInputStream(u);
                if (is == null) return false;
                FileOutputStream os = new FileOutputStream(file(c));
                byte[] buf = new byte[65536];
                int n;
                while ((n = is.read(buf)) > 0) {
                    total += n;
                    if (total > MAX) { os.close(); is.close(); o.put("kind", "toobig").put("name", name); pending = o.toString(); return true; }
                    os.write(buf, 0, n);
                }
                os.close();
                is.close();
                o.put("kind", "file").put("name", name).put("mime", mime).put("size", total);
                if (text != null) o.put("text", text);
            } else if (text != null) {
                o.put("kind", "text").put("text", text);
            } else {
                return false;
            }
            pending = o.toString();
            return true;
        } catch (Exception e) {
            Prefs.err(c, "share", e);
            return false;
        }
    }

    static String take() {
        String p = pending;
        pending = null;
        return p == null ? "" : p;
    }
}
