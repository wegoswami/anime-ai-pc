package com.animebuddy.pet;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.webkit.WebView;

import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String id = i.getStringExtra("id");
        String text = i.getStringExtra("text");
        if (id == null) return;
        if (text == null) text = "";
        Remind.remove(c, id);
        Notif.show(c, "Anime Buddy", text.isEmpty() ? "⏰ Time ho gaya!" : "⏰ " + text);
        // let the pet say it too, in whichever window is on screen
        WebView target = null;
        if (MainActivity.visible && MainActivity.current != null) target = MainActivity.current.web;
        else if (OverlayService.instance != null) target = OverlayService.instance.web;
        if (target != null) {
            target.evaluateJavascript("window.__nativeReminder&&__nativeReminder(" + JSONObject.quote(id) + "," + JSONObject.quote(text) + ")", null);
        }
    }
}
