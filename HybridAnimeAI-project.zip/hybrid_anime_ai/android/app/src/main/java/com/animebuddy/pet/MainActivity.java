package com.animebuddy.pet;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.webkit.GeolocationPermissions;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class MainActivity extends Activity {
    static volatile MainActivity current;
    static volatile boolean visible = false;

    WebView web;
    private Bridge bridge;
    private ValueCallback<Uri[]> fileCb;
    private GeolocationPermissions.Callback geoCb;
    private String geoOrigin;

    private static final int REQ_FILE = 77, REQ_GEO = 3, REQ_STARTUP = 1, REQ_ONE = 10;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        current = this;
        web = new WebView(this);
        setContentView(web, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        Web.setup(this, web);
        bridge = new Bridge(this, web, false);
        web.addJavascriptInterface(bridge, "Native");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    cb.invoke(origin, true, false);
                } else {
                    geoCb = cb;
                    geoOrigin = origin;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GEO);
                }
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) { r.confirm(); }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override public void onCancel(DialogInterface d) { r.cancel(); }
                        }).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) { r.confirm(); }
                        })
                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) { r.cancel(); }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override public void onCancel(DialogInterface d) { r.cancel(); }
                        }).show();
                return true;
            }
        });
        web.loadUrl(Web.BASE + "index.html");
        shareIn(getIntent());

        if (!Prefs.sp(this).getBoolean("asked", false)) {
            Prefs.sp(this).edit().putBoolean("asked", true).apply();
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"}, REQ_STARTUP);
            } else {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_STARTUP);
            }
        }
    }

    @Override
    protected void onNewIntent(Intent in) {
        super.onNewIntent(in);
        setIntent(in);
        shareIn(in);
    }

    /** Something was shared to us from another app: copy it aside, then tell the web app. */
    private void shareIn(final Intent in) {
        if (in == null || !Intent.ACTION_SEND.equals(in.getAction())) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final boolean ok = Shared.handle(getApplicationContext(), in);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (ok && web != null) web.evaluateJavascript("window.__sharedPoll&&__sharedPoll()", null);
                    }
                });
            }
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        current = this;
        visible = true;
        if (Prefs.sp(this).getBoolean("want", false) && Settings.canDrawOverlays(this)) {
            Prefs.sp(this).edit().putBoolean("want", false).apply();
            OverlayService.wanted = true;
            try {
                startForegroundService(new Intent(this, OverlayService.class));
            } catch (Exception e) {
                OverlayService.wanted = false;
            }
            web.evaluateJavascript("setTimeout(function(){try{toast('Pet chalu! Ab Home dabao, main sab apps ke upar milungi')}catch(e){}},800)", null);
        }
        OverlayService s = OverlayService.instance;
        if (s != null) s.setHidden(true);
        web.evaluateJavascript("window.__resync&&__resync()", null);
    }

    @Override
    protected void onPause() {
        visible = false;
        OverlayService s = OverlayService.instance;
        if (s != null) s.setHidden(false);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (current == this) current = null;
        visible = false;
        if (bridge != null) bridge.shutdown();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__back?window.__back():false)", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (!"true".equals(v)) moveTaskToBack(true);
            }
        });
    }

    /** Asks for one permission / opens the matching system screen. Called from the web settings. */
    void requestFor(String which) {
        try {
            if ("mic".equals(which)) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_ONE);
            } else if ("calls".equals(which)) {
                requestPermissions(new String[]{"android.permission.ANSWER_PHONE_CALLS"}, REQ_ONE);
            } else if ("contacts".equals(which)) {
                requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_ONE);
            } else if ("notif".equals(which)) {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_ONE);
                } else {
                    startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
                }
            } else if ("battery".equals(which)) {
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
            } else if ("details".equals(which)) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            } else if ("overlay".equals(which)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            }
        } catch (Exception ignored) { }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_GEO && geoCb != null) {
            geoCb.invoke(geoOrigin, res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED, false);
            geoCb = null;
        }
        web.evaluateJavascript("window.__permResult&&__permResult()", null);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }
}
