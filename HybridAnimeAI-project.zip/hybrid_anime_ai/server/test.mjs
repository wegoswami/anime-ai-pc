import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import worker, { hmacHex } from "./worker.js";

const db = new DatabaseSync(":memory:");
db.exec(fs.readFileSync("schema.sql", "utf8"));
const stmt = (sql, args = []) => ({
  bind: (...a) => stmt(sql, a),
  run: async () => { const r = db.prepare(sql).run(...args); return { meta: { last_row_id: Number(r.lastInsertRowid) } }; },
  first: async () => db.prepare(sql).get(...args) || null,
  all: async () => ({ results: db.prepare(sql).all(...args) }),
  _exec: () => db.prepare(sql).run(...args),
});
const DB = { prepare: (sql) => stmt(sql), batch: async (list) => { list.forEach((s) => s._exec()); return []; } };
const env = { DB, PUBLIC_URL: "https://api.test", RAZORPAY_KEY_ID: "rzp_test_x", RAZORPAY_KEY_SECRET: "keysecret", RAZORPAY_WEBHOOK_SECRET: "whsecret", ADMIN_TOKEN: "adm-test-token-0123456789abcdef", MAX_DEVICES: "2" };
const call = (method, path, body, headers = {}, fetcher) => worker.fetch(new Request("https://api.test" + path, { method, headers: { "Content-Type": "application/json", ...headers }, body: body && typeof body !== "string" ? JSON.stringify(body) : body }), env, {}, fetcher);
let fails = 0; const ok = (c, m) => { console.log((c ? "ok   " : "FAIL ") + m); if (!c) fails++; };

// 1 usage stats
for (const [id, pf, v] of [["aaaaaaaaaaaa1", "pc", "3.5.1"], ["aaaaaaaaaaaa2", "android", "4.1.0"], ["aaaaaaaaaaaa3", "android", "4.1.0"]]) await call("POST", "/v1/ping", { id, platform: pf, version: v, tier: "free", events: { agent_run: 2 } }, { "cf-ipcountry": "IN" });
ok((await call("POST", "/v1/ping", { id: "short" })).status === 400, "ping rejects bad id");
await call("POST", "/v1/ping", { id: "aaaaaaaaaaaa1", platform: "pc", version: "3.5.1", tier: "free" });   // same device again: still 1 install
// 2 checkout with a fake Razorpay
const fakeRzp = async (url, opt) => url.endsWith("/payment_links") ? new Response(JSON.stringify({ id: "plink_1", short_url: "https://rzp.io/i/abc" }), { status: 200 })
  : new Response(JSON.stringify({ id: "plink_1", notes: { plan: "premium_yearly" }, customer: { email: "a@b.com" }, amount_paid: 99900 }), { status: 200 });
let r = await (await call("POST", "/v1/checkout", { plan: "premium_yearly", id: "aaaaaaaaaaaa1", email: "a@b.com" }, {}, fakeRzp)).json();
ok(r.url === "https://rzp.io/i/abc", "checkout returns the Razorpay link");
ok((await call("POST", "/v1/checkout", { plan: "free" }, {}, fakeRzp)).status === 400, "unknown plan rejected");
// 2b currency: USD ignored until INTL_ENABLED, then used
let sent; const spy = async (u, o) => { if (o && o.body) sent = JSON.parse(o.body); return new Response(JSON.stringify({ id: "plink_2", short_url: "https://rzp.io/i/usd" }), { status: 200 }); };
await call("POST", "/v1/checkout", { plan: "premium_monthly", currency: "USD" }, {}, spy);
ok(sent.currency === "INR" && sent.amount === 39900, "USD request stays INR while INTL disabled");
env.INTL_ENABLED = "1";
await call("POST", "/v1/checkout", { plan: "premium_monthly", currency: "USD" }, {}, spy);
ok(sent.currency === "USD" && sent.amount === 799, "USD checkout once INTL enabled");
await call("POST", "/v1/checkout", { plan: "premium_monthly", currency: "EUR" }, {}, spy);
ok(sent.currency === "INR", "unsupported currency falls back to INR");
env.INTL_ENABLED = "0";
// 3 webhook: bad signature rejected, good one issues a licence once
const evt = JSON.stringify({ event: "payment_link.paid", payload: { payment_link: { entity: { id: "plink_1", notes: { plan: "premium_yearly" }, customer: { email: "a@b.com" }, amount_paid: 99900 } }, payment: { entity: { id: "pay_1" } } } });
ok((await call("POST", "/v1/razorpay-webhook", evt, { "x-razorpay-signature": "bad" })).status === 401, "webhook with a wrong signature is refused");
const sig = await hmacHex("whsecret", evt);
ok((await call("POST", "/v1/razorpay-webhook", evt, { "x-razorpay-signature": sig })).status === 200, "signed webhook accepted");
await call("POST", "/v1/razorpay-webhook", evt, { "x-razorpay-signature": sig });                       // Razorpay retries: must not duplicate
const lic = db.prepare("SELECT * FROM licenses").all();
ok(lic.length === 1 && lic[0].plan === "premium_yearly" && /^EV-[A-Z0-9]{4}(-[A-Z0-9]{4}){3}$/.test(lic[0].key) && lic[0].expires > Date.now(), "one premium licence created (no duplicate on retry)");
// 4 thanks page shows the same key
const q = `razorpay_payment_link_id=plink_1&razorpay_payment_id=pay_1&razorpay_payment_link_status=paid&razorpay_payment_link_reference_id=`;
const tsig = await hmacHex("keysecret", "plink_1||paid|pay_1");
let t = await call("GET", "/thanks?" + q + "&razorpay_signature=" + tsig, null, {}, fakeRzp);
ok(t.status === 200 && (await t.text()).includes(lic[0].key), "thanks page shows the key after a verified payment");
ok((await call("GET", "/thanks?" + q + "&razorpay_signature=deadbeef", null, {}, fakeRzp)).status === 400, "thanks page refuses a forged redirect");
ok(db.prepare("SELECT COUNT(*) c FROM licenses").get().c === 1, "thanks + webhook still one licence");
// 5 licence verification and device limit
const key = lic[0].key;
ok((await (await call("POST", "/v1/license/verify", { key, id: "aaaaaaaaaaaa1" })).json()).valid === true, "valid key verifies");
ok((await (await call("POST", "/v1/license/verify", { key, id: "aaaaaaaaaaaa2" })).json()).valid === true, "second device ok");
ok((await (await call("POST", "/v1/license/verify", { key, id: "aaaaaaaaaaaa3" })).json()).reason === "device_limit", "third device refused (limit 2 in test)");
ok((await (await call("POST", "/v1/license/verify", { key: "EV-NOPE", id: "aaaaaaaaaaaa1" })).json()).valid === false, "unknown key refused");
db.prepare("UPDATE licenses SET expires = ?1").run(Date.now() - 1000);
ok((await (await call("POST", "/v1/license/verify", { key, id: "aaaaaaaaaaaa1" })).json()).reason === "expired", "expired key refused");
db.prepare("UPDATE licenses SET expires = ?1").run(Date.now() + 86400000);
// 6 admin
ok((await call("GET", "/admin/stats")).status === 401 && (await call("GET", "/admin/stats", null, { Authorization: "Bearer wrong" })).status === 401, "admin stats need the token");
const s = await (await call("GET", "/admin/stats", null, { Authorization: "Bearer adm-test-token-0123456789abcdef" })).json();
ok(s.total === 3 && s.paid === 1 && s.free === 2 && s.dau === 3 && s.revenue_total === 999 && s.platforms.length === 2 && s.events[0].n === 6, "dashboard numbers are right: " + JSON.stringify({ t: s.total, p: s.paid, f: s.free, dau: s.dau, rev: s.revenue_total, conv: s.conversion }));
ok((await (await call("GET", "/admin")).text()).includes("Earthvasi dashboard"), "dashboard page served");
// 0 admin licence tools
const A = { Authorization: "Bearer adm-test-token-0123456789abcdef" };
ok((await call("POST", "/admin/license", { action: "grant", plan: "premium_yearly" })).status === 401, "grant needs token");
const gk = (await (await call("POST", "/admin/license", { action: "grant", plan: "premium_yearly", email: "friend@x.com", days: 30 }, A)).json()).key;
ok(/^EV-/.test(gk), "admin can grant a key");
ok((await (await call("POST", "/v1/license/verify", { key: gk, id: "zzzzzzzzzzzz9" })).json()).valid === true, "granted key verifies");
await call("POST", "/admin/license", { action: "revoke", key: gk }, A);
ok((await (await call("POST", "/v1/license/verify", { key: gk, id: "zzzzzzzzzzzz9" })).json()).valid === false, "revoked key refused");
ok((await (await call("GET", "/admin/licenses?q=friend", null, A)).json()).licenses.length === 1, "licence search works");
// 7 tiers + managed AI proxy
const mk = async (plan, ids) => { const k = (await (await call("POST", "/admin/license", { action: "grant", plan, email: plan + "@x.com", days: 30 }, A)).json()).key; for (const i of ids) await call("POST", "/v1/license/verify", { key: k, id: i }); return k; };
const man = await mk("premium_monthly", ["mmmmmmmmmmmm1"]);
ok((await (await call("POST", "/v1/license/verify", { key: man, id: "mmmmmmmmmmmm1" })).json()).tier === "premium", "verify reports the premium tier");
const body = { body: { contents: [{ role: "user", parts: [{ text: "hi" }] }], generationConfig: { maxOutputTokens: 99999 }, tools: [{ x: 1 }], systemInstruction: { parts: [{ text: "s" }] } } };
let fwd; const gem = async (u, o) => { fwd = { u, h: o.headers, b: JSON.parse(o.body) }; return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: "ok" }] } }], usageMetadata: { promptTokenCount: 10, candidatesTokenCount: 5 } }), { status: 200 }); };
env.GEMINI_API_KEY = "SECRETGEM";
ok((await call("POST", "/v1/ai", { key: man, id: "mmmmmmmmmmmm1", kind: "chat", ...body }, {}, gem)).status === 200, "managed licence can use the AI proxy");
ok(fwd.h["x-goog-api-key"] === "SECRETGEM" && !fwd.u.includes("SECRETGEM") && fwd.b.generationConfig.maxOutputTokens === 900 && !fwd.b.tools, "proxy adds our key server-side, caps tokens, drops client tools");
await call("POST", "/v1/ai", { key: man, id: "mmmmmmmmmmmm1", kind: "news", ...body }, {}, gem);
ok(fwd.b.tools && fwd.b.tools[0].google_search, "news kind gets search grounding from the server only");
ok(fwd.b.generationConfig.thinkingConfig.thinkingBudget === 0, "chat/news: thinking is off (fast replies)");
await call("POST", "/v1/ai", { key: man, id: "mmmmmmmmmmmm1", kind: "agent", ...body, body: { ...body.body, generationConfig: { thinkingConfig: { thinkingBudget: 99999 } } } }, {}, gem);
ok(fwd.b.generationConfig.thinkingConfig.thinkingBudget === 256, "agent: small thinking budget, and a client cannot raise it");
{ let n = 0; const picky = async (u, o) => { n++; const b = JSON.parse(o.body); return b.generationConfig.thinkingConfig ? new Response("{}", { status: 400 }) : gem(u, o); };
  env.QUOTA_AGENT = "50"; const r = await call("POST", "/v1/ai", { key: man, id: "mmmmmmmmmmmm1", kind: "agent", ...body }, {}, picky);
  ok(r.status === 200 && n === 2 && !fwd.b.generationConfig.thinkingConfig, "a model that rejects the thinking setting is retried without it"); }
ok((await call("POST", "/v1/ai", { key: man, id: "stranger-device-1", kind: "chat", ...body }, {}, gem)).status === 403, "unregistered device refused");
ok((await call("POST", "/v1/ai", { key: "EV-NOPE", id: "mmmmmmmmmmmm1", kind: "chat", ...body }, {}, gem)).status === 403, "unknown key refused");
env.QUOTA_CHAT = "2"; await call("POST", "/v1/ai", { key: man, id: "mmmmmmmmmmmm1", kind: "chat", ...body }, {}, gem);
ok((await call("POST", "/v1/ai", { key: man, id: "mmmmmmmmmmmm1", kind: "chat", ...body }, {}, gem)).status === 429, "daily quota enforced");
const bad = async () => new Response("{\"error\":{\"message\":\"key SECRETGEM invalid\"}}", { status: 400 });
const rr = await call("POST", "/v1/ai", { key: man, id: "mmmmmmmmmmmm1", kind: "agent", ...body }, {}, bad);
ok(rr.status === 502 && !(await rr.text()).includes("SECRETGEM"), "upstream errors never leak details");
const u = db.prepare("SELECT SUM(n) n, SUM(tin) i FROM usage WHERE key=?1").get(man);
ok(u.n >= 3 && u.i >= 30, "usage + tokens are logged per licence");
const s2 = await (await call("GET", "/admin/stats", null, A)).json();
ok(s2.managed_calls_30d >= 3 && s2.byPlan.some((x) => x.k === "premium_monthly"), "admin shows plans and managed usage");
const csvr = await call("GET", "/admin/export?what=usage", null, A);
ok(csvr.status === 200 && (await csvr.text()).includes(man) && (await call("GET", "/admin/export?what=usage")).status === 401, "CSV export works and needs the token");
await call("POST", "/admin/license", { action: "grant", plan: "premium_yearly", email: "=cmd()" }, A);
ok(!/(^|,)"=cmd/.test(await (await call("GET", "/admin/export?what=licenses", null, A)).text()), "CSV defuses formula injection");
await call("POST", "/v1/checkout", { plan: "premium_yearly" }, {}, spy);
ok(sent.amount === 299900, "managed yearly checkout amount");
// support: tickets, sync, announcements, config, block, audit
const ID = "install-aaaaaaaa1";
const tk = await (await call("POST", "/v1/ticket", { id: ID, kind: "feature", body: "Mujhe <b>dark mode</b> chahiye 🙏", version: "4.7.0", platform: "android" })).json();
ok(tk.ok && tk.ticket > 0, "user can send a query/feature request");
ok((await call("POST", "/v1/ticket", { id: ID, body: "x" })).status === 400, "too-short ticket refused");
for (let i = 0; i < 5; i++) await call("POST", "/v1/ticket", { id: ID, body: "spam spam " + i });
ok((await call("POST", "/v1/ticket", { id: ID, body: "one more spam" })).status === 429, "ticket spam is rate-limited");
ok((await call("GET", "/admin/tickets")).status === 401, "tickets need the admin token");
const al = await (await call("GET", "/admin/tickets", null, A)).json();
ok(al.tickets.some((x) => x.id === tk.ticket && x.body.includes("dark mode")), "admin sees the ticket");
await call("POST", "/admin/ticket", { id: tk.ticket, status: "done", reply: "Next update me aa jayega" }, A);
await call("POST", "/admin/announce", { action: "add", body: "Naya: news feature!", audience: "all", days: 3 }, A);
await call("POST", "/admin/announce", { action: "add", body: "Sirf aapke liye", audience: "id:" + ID }, A);
await call("POST", "/admin/announce", { action: "add", body: "Premium only", audience: "premium" }, A);
await call("POST", "/admin/config", { k: "min_version", v: "4.7.0" }, A);
const sy = await (await call("POST", "/v1/sync", { id: ID, tier: "free" })).json();
ok(sy.tickets.some((x) => x.reply === "Next update me aa jayega" && x.status === "done"), "user sees your reply");
ok(sy.announcements.length === 2 && !sy.announcements.some((x) => x.body === "Premium only"), "announcements respect the audience (all + direct message, not managed)");
ok(sy.config.min_version === "4.7.0" && sy.blocked === false, "remote config reaches the app");
const us = await (await call("GET", "/admin/users?q=install-aaaa", null, A)).json();
ok(us.users.length === 0 || us.users[0].id === ID, "users search works");
await call("POST", "/v1/ping", { id: ID, platform: "android", version: "4.7.0", tier: "free" });
const us2 = await (await call("GET", "/admin/users?q=install-aaaa", null, A)).json();
ok(us2.users.length === 1 && us2.users[0].tickets >= 1, "user shows up with ticket count");
await call("POST", "/admin/user", { id: ID, action: "block", reason: "abuse" }, A);
ok((await (await call("POST", "/v1/sync", { id: ID, tier: "free" })).json()).blocked === true, "blocked user is told so");
ok((await call("POST", "/v1/ticket", { id: ID, body: "blocked users cannot send" })).status === 403, "blocked user cannot send tickets");
ok((await call("POST", "/v1/ai", { key: man, id: ID, kind: "chat", ...body }, {}, gem)).status === 403, "blocked id cannot use the AI proxy");
await call("POST", "/admin/user", { id: ID, action: "unblock" }, A);
await call("POST", "/admin/config", { k: "managed_ai_enabled", v: "0" }, A);
ok((await call("POST", "/v1/ai", { key: man, id: "mmmmmmmmmmmm1", kind: "chat", ...body }, {}, gem)).status === 503, "kill-switch pauses Managed AI");
await call("POST", "/admin/config", { k: "managed_ai_enabled", v: "" }, A);
const au = await (await call("GET", "/admin/audit", null, A)).json();
ok(au.audit.some((x) => x.action === "user_block") && au.audit.some((x) => x.action === "config"), "every admin action is in the audit log");
ok((await (await call("GET", "/admin/export?what=tickets", null, A)).text()).includes("Next update"), "tickets CSV export");
// grant access to anyone + gift auto-activation
const g1 = await (await call("POST", "/admin/license", { action: "grant", plan: "premium_monthly", days: 365, email: "friend@x.com", install: "friend-install-01" }, A)).json();
ok(g1.key, "admin can grant any plan for any number of days");
const sg = await (await call("POST", "/v1/sync", { id: "friend-install-01", tier: "free" })).json();
ok(sg.gift === g1.key, "the gifted install receives the key and can activate it by itself");
await call("POST", "/v1/license/verify", { key: g1.key, id: "friend-install-01" });
ok((await (await call("POST", "/v1/sync", { id: "friend-install-01", tier: "premium" })).json()).gift === null, "gift disappears after activation");
const ex = await (await call("POST", "/admin/license", { action: "extend", key: g1.key, days: 30 }, A)).json();
ok(ex.expires > Date.now() + 390 * 86400000, "extend adds days");
// security
const hdr = await call("GET", "/admin");
ok(hdr.headers.get("content-security-policy").includes("default-src 'none'") && hdr.headers.get("x-frame-options") === "DENY" && hdr.headers.get("x-content-type-options") === "nosniff", "security headers + CSP on the admin page");
const ad = await call("GET", "/admin/stats", null, A);
ok(!ad.headers.get("access-control-allow-origin") && ad.headers.get("cache-control") === "no-store", "admin API: no CORS, never cached");
ok((await call("GET", "/v1/plans")).headers.get("access-control-allow-origin") === "*", "public API keeps CORS for the apps");
env.ADMIN_TOKEN = "short"; ok((await call("GET", "/admin/stats", null, { Authorization: "Bearer short" })).status === 503, "weak admin token is refused"); env.ADMIN_TOKEN = "adm-test-token-0123456789abcdef";
const big = await call("POST", "/v1/ticket", { id: "x".repeat(20) }, { "content-length": "900000" });
ok(big.status === 413, "oversized request refused");
const ip = { "cf-connecting-ip": "6.6.6.6" };
let last = 0; for (let i = 0; i < 9; i++) last = (await call("GET", "/admin/stats", null, { ...ip, Authorization: "Bearer wrong" + i })).status;
ok(last === 429 && (await call("GET", "/admin/stats", null, { ...ip, ...A })).status === 429, "admin brute force: locked out after 8 wrong tokens (even the right one waits)");
ok((await call("GET", "/admin/stats", null, { "cf-connecting-ip": "7.7.7.7", ...A })).status === 200, "other IPs are not affected");
let v = 0; for (let i = 0; i < 42; i++) v = (await call("POST", "/v1/license/verify", { key: "EV-GUESS-" + i, id: "guesser-install-1" }, { "cf-connecting-ip": "8.8.8.8" })).status;
ok(v === 429, "licence-key guessing is rate-limited");
ok((await call("POST", "/admin/user", { id: "a".repeat(12), action: "block" })).status === 401, "admin actions without token are refused");
const xss = await (await call("POST", "/v1/sync", { id: "<script>alert(1)</script>0123" })).json();
ok(xss.error !== undefined || xss.ok, "weird ids are sanitised, not crashing");
const pl = await (await call("GET", "/v1/plans")).json();
ok(pl.plans.premium_monthly.inr === 399 && pl.plans.premium_yearly.inr === 2999 && !pl.plans.byok_monthly && pl.quota.chat === 2, "public plans list for the apps");
process.exit(fails ? 1 : 0);
