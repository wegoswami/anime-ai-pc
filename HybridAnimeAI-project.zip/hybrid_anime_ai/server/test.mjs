import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import worker, { hmacHex } from "./worker.js";

const db = new DatabaseSync(":memory:");
db.exec(fs.readFileSync("schema.sql", "utf8"));
const stmt = (sql, args = []) => ({
  bind: (...a) => stmt(sql, a),
  run: async () => { db.prepare(sql).run(...args); return {}; },
  first: async () => db.prepare(sql).get(...args) || null,
  all: async () => ({ results: db.prepare(sql).all(...args) }),
  _exec: () => db.prepare(sql).run(...args),
});
const DB = { prepare: (sql) => stmt(sql), batch: async (list) => { list.forEach((s) => s._exec()); return []; } };
const env = { DB, PUBLIC_URL: "https://api.test", RAZORPAY_KEY_ID: "rzp_test_x", RAZORPAY_KEY_SECRET: "keysecret", RAZORPAY_WEBHOOK_SECRET: "whsecret", ADMIN_TOKEN: "adm", MAX_DEVICES: "2" };
const call = (method, path, body, headers = {}, fetcher) => worker.fetch(new Request("https://api.test" + path, { method, headers: { "Content-Type": "application/json", ...headers }, body: body && typeof body !== "string" ? JSON.stringify(body) : body }), env, {}, fetcher);
let fails = 0; const ok = (c, m) => { console.log((c ? "ok   " : "FAIL ") + m); if (!c) fails++; };

// 1 usage stats
for (const [id, pf, v] of [["aaaaaaaaaaaa1", "pc", "3.5.1"], ["aaaaaaaaaaaa2", "android", "4.1.0"], ["aaaaaaaaaaaa3", "android", "4.1.0"]]) await call("POST", "/v1/ping", { id, platform: pf, version: v, tier: "free", events: { agent_run: 2 } }, { "cf-ipcountry": "IN" });
ok((await call("POST", "/v1/ping", { id: "short" })).status === 400, "ping rejects bad id");
await call("POST", "/v1/ping", { id: "aaaaaaaaaaaa1", platform: "pc", version: "3.5.1", tier: "free" });   // same device again: still 1 install
// 2 checkout with a fake Razorpay
const fakeRzp = async (url, opt) => url.endsWith("/payment_links") ? new Response(JSON.stringify({ id: "plink_1", short_url: "https://rzp.io/i/abc" }), { status: 200 })
  : new Response(JSON.stringify({ id: "plink_1", notes: { plan: "yearly" }, customer: { email: "a@b.com" }, amount_paid: 99900 }), { status: 200 });
let r = await (await call("POST", "/v1/checkout", { plan: "yearly", id: "aaaaaaaaaaaa1", email: "a@b.com" }, {}, fakeRzp)).json();
ok(r.url === "https://rzp.io/i/abc", "checkout returns the Razorpay link");
ok((await call("POST", "/v1/checkout", { plan: "free" }, {}, fakeRzp)).status === 400, "unknown plan rejected");
// 3 webhook: bad signature rejected, good one issues a licence once
const evt = JSON.stringify({ event: "payment_link.paid", payload: { payment_link: { entity: { id: "plink_1", notes: { plan: "yearly" }, customer: { email: "a@b.com" }, amount_paid: 99900 } }, payment: { entity: { id: "pay_1" } } } });
ok((await call("POST", "/v1/razorpay-webhook", evt, { "x-razorpay-signature": "bad" })).status === 401, "webhook with a wrong signature is refused");
const sig = await hmacHex("whsecret", evt);
ok((await call("POST", "/v1/razorpay-webhook", evt, { "x-razorpay-signature": sig })).status === 200, "signed webhook accepted");
await call("POST", "/v1/razorpay-webhook", evt, { "x-razorpay-signature": sig });                       // Razorpay retries: must not duplicate
const lic = db.prepare("SELECT * FROM licenses").all();
ok(lic.length === 1 && lic[0].plan === "yearly" && /^EV-[A-Z0-9]{4}(-[A-Z0-9]{4}){3}$/.test(lic[0].key) && lic[0].expires > Date.now(), "one yearly licence created (no duplicate on retry)");
// 4 thanks page shows the same key
const q = `razorpay_payment_link_id=plink_1&razorpay_payment_id=pay_1&razorpay_payment_link_status=paid&razorpay_payment_link_reference_id=`;
const tsig = await hmacHex("keysecret", "plink_1||paid|pay_1");
let t = await call("GET", "/thanks?" + q + "&razorpay_signature=" + tsig, null, {}, fakeRzp);
ok(t.status === 200 && (await t.text()).includes(lic[0].key), "thanks page shows the key after a verified payment");
ok((await call("GET", "/thanks?" + q + "&razorpay_signature=deadbeef", null, {}, fakeRzp)).status === 400, "thanks page refuses a forged redirect");
ok(db.prepare("SELECT COUNT(*) c FROM licenses").get().c === 1, "thanks + webhook still one licence");
// 5 licence verification and device limit
const key = lic[0].key;
ok((await (await call("POST", "/v1/license/verify", { key, id: "aaaaaaaaaaaa1" })).json()).valid === true, "valid key verifies");
ok((await (await call("POST", "/v1/license/verify", { key, id: "aaaaaaaaaaaa2" })).json()).valid === true, "second device ok");
ok((await (await call("POST", "/v1/license/verify", { key, id: "aaaaaaaaaaaa3" })).json()).reason === "device_limit", "third device refused (limit 2 in test)");
ok((await (await call("POST", "/v1/license/verify", { key: "EV-NOPE", id: "aaaaaaaaaaaa1" })).json()).valid === false, "unknown key refused");
db.prepare("UPDATE licenses SET expires = ?1").run(Date.now() - 1000);
ok((await (await call("POST", "/v1/license/verify", { key, id: "aaaaaaaaaaaa1" })).json()).reason === "expired", "expired key refused");
db.prepare("UPDATE licenses SET expires = ?1").run(Date.now() + 86400000);
// 6 admin
ok((await call("GET", "/admin/stats")).status === 401 && (await call("GET", "/admin/stats", null, { Authorization: "Bearer wrong" })).status === 401, "admin stats need the token");
const s = await (await call("GET", "/admin/stats", null, { Authorization: "Bearer adm" })).json();
ok(s.total === 3 && s.paid === 1 && s.free === 2 && s.dau === 3 && s.revenue_total === 999 && s.platforms.length === 2 && s.events[0].n === 6, "dashboard numbers are right: " + JSON.stringify({ t: s.total, p: s.paid, f: s.free, dau: s.dau, rev: s.revenue_total, conv: s.conversion }));
ok((await (await call("GET", "/admin")).text()).includes("Earthvasi dashboard"), "dashboard page served");
process.exit(fails ? 1 : 0);
