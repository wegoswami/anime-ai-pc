CREATE TABLE IF NOT EXISTS installs (id TEXT PRIMARY KEY, platform TEXT, version TEXT, tier TEXT, country TEXT, lang TEXT, first_seen INTEGER, last_seen INTEGER);
CREATE TABLE IF NOT EXISTS daily (day TEXT, id TEXT, PRIMARY KEY (day, id));
CREATE TABLE IF NOT EXISTS events (day TEXT, name TEXT, n INTEGER, PRIMARY KEY (day, name));
CREATE TABLE IF NOT EXISTS licenses (key TEXT PRIMARY KEY, plan TEXT, email TEXT, created INTEGER, expires INTEGER, payment_id TEXT UNIQUE, link_id TEXT, status TEXT);
CREATE TABLE IF NOT EXISTS devices (key TEXT, id TEXT, first_seen INTEGER, PRIMARY KEY (key, id));
CREATE TABLE IF NOT EXISTS payments (id TEXT PRIMARY KEY, link_id TEXT, email TEXT, amount INTEGER, plan TEXT, created INTEGER, currency TEXT DEFAULT 'INR');
CREATE INDEX IF NOT EXISTS idx_daily_day ON daily(day);
CREATE INDEX IF NOT EXISTS idx_pay_created ON payments(created);

-- Existing database? run once:  ALTER TABLE payments ADD COLUMN currency TEXT DEFAULT 'INR';
