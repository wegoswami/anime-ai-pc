# Earthvasi API (stats + Pro licences + Razorpay)

Ek chhota server (Cloudflare Workers, free plan se shuru) jo 3 kaam karta hai:
1. **Dashboard** — kitne users, kitne paid/free, roz kitne active, kaunsa feature chal raha hai, revenue.
2. **Razorpay checkout** — app se "pro kharido" bolne par payment link banata hai.
3. **Licence keys** — payment hote hi key banati hai; app us key ko verify karti hai (ek key = max 3 devices).

Isme chats, files, contacts ya API keys kabhi nahi aate. App sirf: random install ID, version, platform, language, aur feature-use ka count bhejti hai (Settings me band kar sakte hain).

## Deploy (ek baar, ~20 minute)
1. https://dash.cloudflare.com par free account banao.
2. PC par Node.js install karo, phir is `server` folder me terminal kholo:
   ```
   npx wrangler login
   npx wrangler d1 create earthvasi          # jo database_id print ho use wrangler.toml me paste karo
   npx wrangler d1 execute earthvasi --remote --file=schema.sql
   ```
3. `wrangler.toml` me `PUBLIC_URL` ko apne worker ka URL do (deploy ke baad dikhta hai, jaise `https://earthvasi-api.NAAM.workers.dev`) aur prices (paise me: 14900 = ₹149) badlo.
4. **Secrets** (ye kabhi GitHub, chat ya app me mat daalna — sirf Cloudflare me):
   ```
   npx wrangler secret put RAZORPAY_KEY_ID
   npx wrangler secret put RAZORPAY_KEY_SECRET
   npx wrangler secret put RAZORPAY_WEBHOOK_SECRET     # koi lamba random text, wahi Razorpay me bhi daalna
   npx wrangler secret put ADMIN_TOKEN                 # dashboard ka password, lamba rakho
   ```
   Pehle Razorpay **Test mode** ki keys (rzp_test_...) daalo. Sab chal jaaye tab Live keys se dobara `secret put` karo.
5. `npx wrangler deploy`
6. **Razorpay Dashboard → Settings → Webhooks → Add**: URL `https://<tumhara-worker>/v1/razorpay-webhook`, event **payment_link.paid**, secret = wahi jo `RAZORPAY_WEBHOOK_SECRET` me daala.
7. Dashboard: `https://<tumhara-worker>/admin` → ADMIN_TOKEN daalo.

## Apps me jodna
- PC: `app/version.py` me `LICENSE_API = "https://<tumhara-worker>"`
- Mobile: `mobile/app.js` ke upar `const LICENSE_API = "https://<tumhara-worker>";`
- Naya version banao aur upload karo. Tab se stats aane lagenge.
- **Pro lock** abhi band hai (`PRO_ENFORCED = false` dono jagah). Jab launch karna ho tab `true` karo; tab "agent" (screen control) aur "natural_voice" Pro ho jaate hain (`PRO_FEATURES` me badal sakte ho).

## User ka flow
"pro kharido yearly" → browser me Razorpay page → payment → page par key dikhti hai (`EV-XXXX-...`) → app me "pro key EV-XXXX-..." bolo ya Settings → Pro key me paste karo. Internet na ho to bhi 14 din tak Pro chalta rehta hai.

## Support (key kho gayi)
Razorpay dashboard me payment dhundho → `licenses` table me email se key nikaalo:
`npx wrangler d1 execute earthvasi --remote --command "SELECT key, plan, email FROM licenses WHERE email LIKE '%a@b.com%'"`

## Zaroori baatein
- Privacy Policy me likho ki anonymous usage counts jaate hain (aur Settings me band ho sakte hain). Legal/tax ke liye CA/vakeel se baat karo.
- Ye licence system "imaandaar users" ke liye hai. App ka code public hone se koi expert lock hata sakta hai; business ke liye yeh normal hai, asli taqat service (AI included, updates, support) me hai.
- Cloudflare free plan ki limit (roz ~1 lakh requests) bahut users tak kaafi hai.

## Test (server ka logic)
`node --experimental-sqlite test.mjs` — nakli database aur nakli Razorpay se 17 checks chalata hai. Asli Cloudflare/Razorpay par aapko ek test payment (test mode) karke dekhna hai.

## Tiers (v2)
- **Free**: local/offline only. **BYOK**: own AI key (`byok_monthly|yearly|lifetime`). **Managed**: our AI (`managed_monthly|yearly`).
- Managed AI: apps call `POST /v1/ai` (licence + registered device + daily quota); the server holds `GEMINI_API_KEY` (Worker secret) and logs token usage in table `usage`.
- Admin: `/admin` shows plans, managed calls and estimated cost (`COST_*`, `USD_INR`), and CSV export (`/admin/export?what=installs|licenses|payments|usage`).
- Upgrading an existing D1: run the new `CREATE TABLE usage ...` line from `schema.sql`.
- Set a monthly budget cap on the Gemini key in Google AI Studio; the per-licence daily quota is your second safety net.

## Control centre (admin page tabs)
- **Users**: search by id/email/key/country/version, block/unblock, add a private note, send one user a direct message (shown inside their app).
- **Queries**: everything users send with "feedback: ..." / "bug: ..." / "suggest: ..." in the app; set status (open / in progress / done / not planned) and reply; the user sees it in the app.
- **Announce**: message to everyone, or only Free / BYOK / Managed, with an end date.
- **Settings** (remote config): `managed_ai_enabled=0` (pause Managed AI instantly), `maintenance` (message to all), `min_version` (ask users to update), anything else you add. Never store secrets here - apps can read it.
- **Audit**: every admin action (grant, revoke, block, reply, config) is logged.
- Existing database: run all `CREATE TABLE IF NOT EXISTS ...` lines of `schema.sql` again in the D1 console (safe to repeat).
- What this cannot do: change user code on their phone/PC. Fixes and new features still ship as an app update; use announcements + `min_version` to tell users.
