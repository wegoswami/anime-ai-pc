# Security guide (Earthvasi backend)

Koi bhi system "100% hack-proof" nahi hota. Ye guide batati hai ki code me kya lagaya gaya hai aur aapko kya karna hai.

## Code me pehle se lagi suraksha
- **Admin login:** token kam se kam 20 akshar ka hona chahiye, warna admin band. 8 galat koshish par us IP ko 15 minute ke liye lock. Sahi token bhi lock ke dauran nahi chalta.
- **Admin API par CORS nahi** aur response kabhi cache nahi hota. Admin page par strict CSP (bahar ka script, image ya frame nahi chalega), framing band.
- **Users ka likha hua text** (queries, notes) admin page me escape hota hai, isliye koi script chala kar admin ko nahi hila sakta.
- **Rate limits (per IP):** licence verify 40/10 min, checkout 10/ghanta, AI 150/10 min, sync 60/ghanta, ticket 20/din. Licence key 16 akshar random (lagbhag 78 bit), guess karna practically nahi.
- **Managed AI:** Gemini key sirf Worker secret me. App ko kabhi nahi milti. Proxy sirf allowed fields aage bhejta hai (tools/model client nahi badal sakta), tokens cap, daily quota, device-wise check, Google ke error me key ka koi nishan nahi.
- **Razorpay webhook** HMAC se verify hota hai; ek payment se do key nahi banti.
- **Har response par:** nosniff, no-referrer, HTTPS-only (HSTS), 700 KB se bada request reject.
- **Audit log:** grant, revoke, block, reply, settings, sab record.
- **Android:** native HTTP fallback sirf AI/licence hosts tak; app ke bahar ke links browser me khulte hain; file access band.

## Aapko ye karna hai (sabse zaroori pehle)
1. **Cloudflare Access se `/admin` ko lock karo** (Zero Trust → Access → Applications → Self-hosted → path `/admin*`, sirf aapka email, free plan me 50 users tak). Phir token ke upar ek aur dewaar rahegi.
2. `ADMIN_TOKEN` 40+ random akshar ka rakho. Password manager me save karo. Kisi ko mat bhejo.
3. **2-step verification (2FA)** chalu karo: GitHub, Cloudflare, Razorpay, Google account. Recovery codes offline rakho.
4. Secrets sirf Worker **Secrets** me. Kabhi GitHub, chat, screenshot, `wrangler.toml` ya zip me nahi. Galti se leak ho jaye to turant rotate karo (Razorpay secret regenerate, Gemini key delete + nayi, ADMIN_TOKEN badlo).
5. **Gemini key par budget/limit** (Google AI Studio / Cloud billing alert). Ye aakhri safety net hai.
6. `earthvasi-server` repo **Private** rakho. GitHub → Settings → Code security: Secret scanning + push protection ON.
7. Cloudflare → Security → WAF → Rate limiting rule: `/v1/*` par per-IP limit (bonus layer). "Bot Fight Mode" ON.
8. D1 ka backup: Cloudflare me `wrangler d1 export earthvasi --output backup.sql` har hafte; file private jagah rakho (usme user ka email hai).
9. Android release APK ko apni **keystore** se sign karo; keystore aur password kahin upload mat karo, 2 jagah backup rakho.
10. Launch se pehle kisi security jaankaar se ek baar review/pen-test karwa lo.

## Jo main nahi kar sakta / honest limits
- PRO lock app ke andar hai; skilled user apne phone/PC par bypass kar sakta hai. Asli suraksha Managed AI hai (wo server par hai).
- Android me PC se jodne ke liye mixed-content (http LAN) allowed hai; sirf apne home Wi-Fi par use karo.
- Maine real attacker ke saamne test nahi kiya; ye code-level aur automated tests hain.
- User ka personal data (email, usage) = aapki zimmedari: privacy policy, zaroorat se zyada data na rakhna, mangne par delete karna (India DPDP). Vakil se confirm karo.
