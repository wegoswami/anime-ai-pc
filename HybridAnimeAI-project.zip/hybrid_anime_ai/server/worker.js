// Earthvasi API: anonymous usage stats, Razorpay checkout + licence keys, private admin dashboard.
// Runs on Cloudflare Workers (free tier is plenty to start). No chats, files or personal data are ever received.

const DAY = 86400000;
// Tiers: FREE = local/offline only (no licence). BYOK = user's own AI key (cheap). MANAGED = our AI through /v1/ai (premium).
// Amounts are paise / cents. BYOK is ~75% below MANAGED. "monthly/yearly/lifetime" are the old names and mean BYOK.
const PLANS = (env) => {
  const P = {
    byok_monthly: { amount: +env.PRICE_BYOK_MONTHLY || 9900, usd: +env.PRICE_BYOK_MONTHLY_USD || 199, days: 31, label: "Earthvasi BYOK - 1 month", tier: "byok" },
    byok_yearly: { amount: +env.PRICE_BYOK_YEARLY || 74900, usd: +env.PRICE_BYOK_YEARLY_USD || 1499, days: 366, label: "Earthvasi BYOK - 1 year", tier: "byok" },
    byok_lifetime: { amount: +env.PRICE_BYOK_LIFETIME || 199900, usd: +env.PRICE_BYOK_LIFETIME_USD || 3999, days: 0, label: "Earthvasi BYOK - Lifetime", tier: "byok" },
    managed_monthly: { amount: +env.PRICE_MANAGED_MONTHLY || 39900, usd: +env.PRICE_MANAGED_MONTHLY_USD || 799, days: 31, label: "Earthvasi Managed AI - 1 month", tier: "managed" },
    managed_yearly: { amount: +env.PRICE_MANAGED_YEARLY || 299900, usd: +env.PRICE_MANAGED_YEARLY_USD || 5999, days: 366, label: "Earthvasi Managed AI - 1 year", tier: "managed" },
  };
  P.monthly = P.byok_monthly; P.yearly = P.byok_yearly; P.lifetime = P.byok_lifetime;
  return P;
};
const tierOf = (plan) => (String(plan).startsWith("managed") ? "managed" : "byok");
const QUOTA = (env) => ({ chat: +env.QUOTA_CHAT || 40, agent: +env.QUOTA_AGENT || 10, news: +env.QUOTA_NEWS || 5, tts: +env.QUOTA_TTS || 20 });
// USD is offered only after you switch INTL_ENABLED="1" (Razorpay must have approved International Payments).
const pickCurrency = (env, want) => (env.INTL_ENABLED === "1" && String(want).toUpperCase() === "USD" ? "USD" : "INR");
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type, Authorization", "Access-Control-Allow-Methods": "GET, POST, OPTIONS" };
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "Content-Type": "application/json", ...CORS } });
const html = (s, status = 200) => new Response(s, { status, headers: { "Content-Type": "text/html; charset=utf-8" } });
const dayStr = (t = Date.now()) => new Date(t + 19800000).toISOString().slice(0, 10);            // India date
const text = (v, n = 1500) => String(v == null ? "" : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").trim().slice(0, n);   // free text (keeps Hindi, emoji, line breaks)
const ipOf = (req) => req.headers.get("cf-connecting-ip") || "";
/* per-IP rate limit kept in D1 (Cloudflare always sets cf-connecting-ip; local tests do not, so they are not limited) */
async function hit(env, req, bucket, max, sec) {
  const ip = ipOf(req); if (!ip) return false;
  const now = Date.now(), win = Math.floor(now / (sec * 1000)), k = bucket + ":" + ip;
  await env.DB.prepare("INSERT INTO rl (k, win, n, exp) VALUES (?1,?2,1,?3) ON CONFLICT(k,win) DO UPDATE SET n = n + 1").bind(k, win, now + sec * 2000).run();
  const r = await env.DB.prepare("SELECT n FROM rl WHERE k = ?1 AND win = ?2").bind(k, win).first();
  if (Math.random() < 0.02) await env.DB.prepare("DELETE FROM rl WHERE exp < ?1").bind(now).run();
  return !!r && r.n > max;
}
const tooMany = () => json({ error: "slow_down" }, 429);
async function adminGate(req, env) {                 // brute-force lock-out + weak-token refusal for every /admin/* call
  if (!env.ADMIN_TOKEN || env.ADMIN_TOKEN.length < 20) return json({ error: "admin_token_too_weak" }, 503);
  const ip = ipOf(req), win = Math.floor(Date.now() / 900000);
  if (ip) {
    const f = await env.DB.prepare("SELECT n FROM rl WHERE k = ?1 AND win = ?2").bind("adminfail:" + ip, win).first();
    if (f && f.n >= 8) return json({ error: "locked_try_later" }, 429);
  }
  if (isAdmin(req, env)) return null;
  if (ip) await env.DB.prepare("INSERT INTO rl (k, win, n, exp) VALUES (?1,?2,1,?3) ON CONFLICT(k,win) DO UPDATE SET n = n + 1").bind("adminfail:" + ip, win, Date.now() + 1800000).run();
  return json({ error: "unauthorized" }, 401);
}
const isAdmin = (req, env) => !!env.ADMIN_TOKEN && safeEq(req.headers.get("authorization") || "", "Bearer " + env.ADMIN_TOKEN);
const audit = (env, action, target, detail) => env.DB.prepare("INSERT INTO audit (at, action, target, detail) VALUES (?1,?2,?3,?4)").bind(Date.now(), action, text(target, 60), text(detail, 300)).run();
const isBlocked = async (env, id) => !!id && !!(await env.DB.prepare("SELECT 1 x FROM blocked WHERE id = ?1").bind(id).first());
const clean = (v, n = 40) => String(v == null ? "" : v).replace(/[^\w .:@+\-]/g, "").slice(0, n);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

async function hmacHex(secret, msg) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(msg));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function safeEq(a, b) { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }
function newKey() {
  const A = "ABCDEFGHJKMNPQRSTVWXYZ23456789", b = crypto.getRandomValues(new Uint8Array(16));
  const s = [...b].map((x) => A[x % A.length]).join("");
  return `EV-${s.slice(0, 4)}-${s.slice(4, 8)}-${s.slice(8, 12)}-${s.slice(12, 16)}`;
}

/* ------------------------------------------------------------------ usage stats */
async function ping(req, env) {
  const b = await req.json().catch(() => null);
  const id = clean(b && b.id, 40);
  if (id.length < 12) return json({ ok: false }, 400);
  const now = Date.now(), tier = ["pro", "byok", "managed"].includes(b.tier) ? b.tier : "free", platform = ["pc", "android", "web"].includes(b.platform) ? b.platform : "other";
  const country = clean(req.headers.get("cf-ipcountry") || "", 2);
  await env.DB.batch([
    env.DB.prepare("INSERT INTO installs (id, platform, version, tier, country, lang, first_seen, last_seen) VALUES (?1,?2,?3,?4,?5,?6,?7,?7) ON CONFLICT(id) DO UPDATE SET platform=?2, version=?3, tier=?4, country=?5, lang=?6, last_seen=?7")
      .bind(id, platform, clean(b.version, 12), tier, country, clean(b.lang, 10), now),
    env.DB.prepare("INSERT OR IGNORE INTO daily (day, id) VALUES (?1, ?2)").bind(dayStr(), id),
  ]);
  const ev = b.events && typeof b.events === "object" ? Object.entries(b.events).slice(0, 12) : [];      // {"agent_run": 3} counters only
  if (ev.length) await env.DB.batch(ev.map(([k, n]) => env.DB.prepare("INSERT INTO events (day, name, n) VALUES (?1,?2,?3) ON CONFLICT(day,name) DO UPDATE SET n = n + ?3").bind(dayStr(), clean(k, 30), Math.max(0, Math.min(1000, +n || 0)))));
  return json({ ok: true });
}

/* ------------------------------------------------------------------ licences */
async function verify(req, env) {
  const b = await req.json().catch(() => null);
  const key = clean(b && b.key, 30).toUpperCase(), id = clean(b && b.id, 40);
  if (!key || id.length < 12) return json({ valid: false, reason: "bad_request" }, 400);
  if (await isBlocked(env, id)) return json({ valid: false, reason: "blocked" });
  const lic = await env.DB.prepare("SELECT * FROM licenses WHERE key = ?1").bind(key).first();
  if (!lic || lic.status !== "active") return json({ valid: false, reason: "unknown_key" });
  if (lic.expires && lic.expires < Date.now()) return json({ valid: false, reason: "expired", plan: lic.plan, expires: lic.expires });
  const dev = await env.DB.prepare("SELECT id FROM devices WHERE key = ?1").bind(key).all();
  const known = dev.results.some((d) => d.id === id);
  if (!known) {
    if (dev.results.length >= (+env.MAX_DEVICES || 3)) return json({ valid: false, reason: "device_limit" });
    await env.DB.prepare("INSERT OR IGNORE INTO devices (key, id, first_seen) VALUES (?1,?2,?3)").bind(key, id, Date.now()).run();
  }
  return json({ valid: true, plan: lic.plan, tier: tierOf(lic.plan), expires: lic.expires || 0, quota: QUOTA(env) });
}

async function issueLicense(env, { paymentId, linkId, email, plan, amount, currency }) {
  const P = PLANS(env)[plan];
  if (!P || !paymentId) return null;
  const old = await env.DB.prepare("SELECT key FROM licenses WHERE payment_id = ?1").bind(paymentId).first();
  if (old) return old.key;                                                      // webhook + thanks page can both call this safely
  const key = newKey(), now = Date.now();
  await env.DB.batch([
    env.DB.prepare("INSERT OR IGNORE INTO licenses (key, plan, email, created, expires, payment_id, link_id, status) VALUES (?1,?2,?3,?4,?5,?6,?7,'active')").bind(key, plan, clean(email, 80), now, P.days ? now + P.days * DAY : 0, paymentId, linkId || ""),
    env.DB.prepare("INSERT OR IGNORE INTO payments (id, link_id, email, amount, plan, created, currency) VALUES (?1,?2,?3,?4,?5,?6,?7)").bind(paymentId, linkId || "", clean(email, 80), amount || P.amount, plan, now, currency === "USD" ? "USD" : "INR"),
  ]);
  return (await env.DB.prepare("SELECT key FROM licenses WHERE payment_id = ?1").bind(paymentId).first()).key;
}



/* ------------------------------------------------------------------ support: tickets, announcements, remote config, sync */
async function ticketNew(req, env) {
  const b = await req.json().catch(() => null), id = clean(b && b.id, 40);
  if (id.length < 12) return json({ error: "bad_request" }, 400);
  const kind = ["bug", "feature", "question"].includes(b.kind) ? b.kind : "question", body = text(b.body, 1500);
  if (body.length < 5) return json({ error: "too_short" }, 400);
  if (await isBlocked(env, id)) return json({ error: "blocked" }, 403);
  const n = await env.DB.prepare("SELECT COUNT(*) c FROM tickets WHERE install = ?1 AND created > ?2").bind(id, Date.now() - DAY).first();
  if (n.c >= 5) return json({ error: "too_many" }, 429);
  const now = Date.now(), r = await env.DB.prepare("INSERT INTO tickets (install, kind, body, status, reply, created, updated, version, platform, replied) VALUES (?1,?2,?3,'open','',?4,?4,?5,?6,0)")
    .bind(id, kind, body, now, clean(b.version, 12), ["pc", "android"].includes(b.platform) ? b.platform : "other").run();
  return json({ ok: true, ticket: r.meta.last_row_id });
}

async function sync(req, env) {
  const b = await req.json().catch(() => null), id = clean(b && b.id, 40);
  if (id.length < 12) return json({ error: "bad_request" }, 400);
  const now = Date.now(), tier = ["byok", "managed"].includes(b.tier) ? b.tier : "free";
  const blocked = await isBlocked(env, id);
  const cfg = Object.fromEntries((await env.DB.prepare("SELECT k, v FROM config").all()).results.map((r) => [r.k, r.v]));
  const ann = (await env.DB.prepare("SELECT id, body, audience FROM announcements WHERE active = 1 AND (starts = 0 OR starts <= ?1) AND (ends = 0 OR ends >= ?1) ORDER BY id DESC LIMIT 20").bind(now).all()).results
    .filter((a) => a.audience === "all" || a.audience === tier || a.audience === "id:" + id).slice(0, 3).map((a) => ({ id: a.id, body: a.body }));
  const tickets = (await env.DB.prepare("SELECT id, kind, body, status, reply, updated FROM tickets WHERE install = ?1 ORDER BY id DESC LIMIT 10").bind(id).all()).results;
  let gift = null;                                   // a plan you gave this install from the admin page: the app activates it by itself
  const g = await env.DB.prepare("SELECT key FROM gifts WHERE id = ?1").bind(id).first();
  if (g) { const used = await env.DB.prepare("SELECT 1 x FROM devices WHERE key = ?1 AND id = ?2").bind(g.key, id).first(); if (used) await env.DB.prepare("DELETE FROM gifts WHERE id = ?1").bind(id).run(); else gift = g.key; }
  return json({ ok: true, blocked, config: cfg, announcements: ann, tickets, gift });
}

async function adminSupport(req, env, url, p) {
  const J = async () => await req.json().catch(() => ({}));
  if (p === "/admin/users") {
    const q = "%" + clean(url.searchParams.get("q"), 40) + "%";
    const rows = (await env.DB.prepare(`SELECT i.id, i.platform, i.version, i.tier, i.country, i.lang, i.first_seen, i.last_seen,
        (SELECT 1 FROM blocked b WHERE b.id = i.id) blocked, (SELECT n.body FROM notes n WHERE n.ref = i.id) note,
        (SELECT d.key FROM devices d WHERE d.id = i.id LIMIT 1) lkey,
        (SELECT l.plan FROM licenses l JOIN devices d ON d.key = l.key WHERE d.id = i.id AND l.status='active' LIMIT 1) plan,
        (SELECT l.email FROM licenses l JOIN devices d ON d.key = l.key WHERE d.id = i.id LIMIT 1) email,
        (SELECT COUNT(*) FROM tickets t WHERE t.install = i.id) tickets
      FROM installs i WHERE i.id LIKE ?1 OR i.country LIKE ?1 OR i.version LIKE ?1 OR EXISTS (SELECT 1 FROM devices d JOIN licenses l ON l.key = d.key WHERE d.id = i.id AND (l.email LIKE ?1 OR l.key LIKE ?1))
      ORDER BY i.last_seen DESC LIMIT 100`).bind(q).all()).results;
    return json({ users: rows });
  }
  if (p === "/admin/user" && req.method === "POST") {
    const b = await J(), id = clean(b.id, 40), act = clean(b.action, 10);
    if (id.length < 12) return json({ error: "bad_request" }, 400);
    if (act === "block") await env.DB.prepare("INSERT OR REPLACE INTO blocked (id, reason, at) VALUES (?1,?2,?3)").bind(id, text(b.reason, 200), Date.now()).run();
    else if (act === "unblock") await env.DB.prepare("DELETE FROM blocked WHERE id = ?1").bind(id).run();
    else if (act === "note") await env.DB.prepare("INSERT OR REPLACE INTO notes (ref, body, at) VALUES (?1,?2,?3)").bind(id, text(b.note, 500), Date.now()).run();
    else return json({ error: "bad_action" }, 400);
    await audit(env, "user_" + act, id, b.reason || b.note || "");
    return json({ ok: true });
  }
  if (p === "/admin/tickets") {
    const st = clean(url.searchParams.get("status"), 10), rows = (await env.DB.prepare("SELECT * FROM tickets " + (st ? "WHERE status = ?1 " : "") + "ORDER BY (status='open') DESC, id DESC LIMIT 100").bind(...(st ? [st] : [])).all()).results;
    return json({ tickets: rows });
  }
  if (p === "/admin/ticket" && req.method === "POST") {
    const b = await J(), id = +b.id, st = ["open", "progress", "done", "rejected"].includes(b.status) ? b.status : null;
    if (!id) return json({ error: "bad_request" }, 400);
    const t = await env.DB.prepare("SELECT id FROM tickets WHERE id = ?1").bind(id).first();
    if (!t) return json({ error: "not_found" }, 404);
    await env.DB.prepare("UPDATE tickets SET status = COALESCE(?1, status), reply = CASE WHEN ?2 = '' THEN reply ELSE ?2 END, updated = ?3 WHERE id = ?4").bind(st, text(b.reply, 1500), Date.now(), id).run();
    await audit(env, "ticket", "#" + id, (st || "") + " " + text(b.reply, 80));
    return json({ ok: true });
  }
  if (p === "/admin/announce") {
    if (req.method === "GET") return json({ announcements: (await env.DB.prepare("SELECT * FROM announcements ORDER BY id DESC LIMIT 50").all()).results });
    const b = await J(), act = clean(b.action, 10);
    if (act === "add") {
      const body = text(b.body, 400), aud = /^(all|free|byok|managed|id:[\w-]{12,40})$/.test(b.audience) ? b.audience : "all";
      if (body.length < 3) return json({ error: "too_short" }, 400);
      const now = Date.now(), ends = +b.days > 0 ? now + Math.min(+b.days, 365) * DAY : 0;
      const r = await env.DB.prepare("INSERT INTO announcements (body, audience, starts, ends, active, created) VALUES (?1,?2,0,?3,1,?4)").bind(body, aud, ends, now).run();
      await audit(env, "announce", aud, body.slice(0, 80));
      return json({ ok: true, id: r.meta.last_row_id });
    }
    if (act === "off" || act === "on") await env.DB.prepare("UPDATE announcements SET active = ?1 WHERE id = ?2").bind(act === "on" ? 1 : 0, +b.id).run();
    else if (act === "delete") await env.DB.prepare("DELETE FROM announcements WHERE id = ?1").bind(+b.id).run();
    else return json({ error: "bad_action" }, 400);
    await audit(env, "announce_" + act, "#" + b.id, "");
    return json({ ok: true });
  }
  if (p === "/admin/config") {
    if (req.method === "GET") return json({ config: (await env.DB.prepare("SELECT k, v FROM config ORDER BY k").all()).results });
    const b = await J(), k = clean(b.k, 30), v = text(b.v, 300);
    if (!k) return json({ error: "bad_request" }, 400);
    if (v === "") await env.DB.prepare("DELETE FROM config WHERE k = ?1").bind(k).run();
    else await env.DB.prepare("INSERT OR REPLACE INTO config (k, v) VALUES (?1,?2)").bind(k, v).run();
    await audit(env, "config", k, v.slice(0, 100));
    return json({ ok: true });
  }
  if (p === "/admin/audit") return json({ audit: (await env.DB.prepare("SELECT * FROM audit ORDER BY id DESC LIMIT 100").all()).results });
  return null;
}

/* ------------------------------------------------------------------ managed AI proxy (our Gemini key never leaves the server) */
const KINDS = { chat: "MODEL_CHAT", agent: "MODEL_AGENT", news: "MODEL_CHAT", tts: "MODEL_TTS" };
const MODEL_DEFAULT = { chat: "gemini-flash-lite-latest", agent: "gemini-flash-latest", news: "gemini-flash-lite-latest", tts: "gemini-2.5-flash-preview-tts" };
async function aiProxy(req, env, fetcher) {
  const b = await req.json().catch(() => null);
  const key = clean(b && b.key, 30).toUpperCase(), id = clean(b && b.id, 40), kind = clean(b && b.kind, 8);
  if (!key || id.length < 12 || !KINDS[kind] || !b.body || typeof b.body !== "object") return json({ error: "bad_request" }, 400);
  if (!env.GEMINI_API_KEY) return json({ error: "not_configured" }, 503);
  if (await isBlocked(env, id)) return json({ error: "blocked" }, 403);
  const paused = await env.DB.prepare("SELECT v FROM config WHERE k = 'managed_ai_enabled'").first();
  if (paused && paused.v === "0") return json({ error: "paused" }, 503);
  const lic = await env.DB.prepare("SELECT * FROM licenses WHERE key = ?1").bind(key).first();
  if (!lic || lic.status !== "active") return json({ error: "unknown_key" }, 403);
  if (lic.expires && lic.expires < Date.now()) return json({ error: "expired" }, 403);
  if (tierOf(lic.plan) !== "managed") return json({ error: "not_managed" }, 403);
  const dev = await env.DB.prepare("SELECT id FROM devices WHERE key = ?1 AND id = ?2").bind(key, id).first();
  if (!dev) return json({ error: "device_not_registered" }, 403);
  const day = dayStr(), limit = QUOTA(env)[kind];
  const row = await env.DB.prepare("SELECT n FROM usage WHERE key = ?1 AND day = ?2 AND kind = ?3").bind(key, day, kind).first();
  if (row && row.n >= limit) return json({ error: "quota", kind, limit }, 429);
  const src = b.body, body = { contents: src.contents, generationConfig: { ...(src.generationConfig || {}) } };         // whitelist: nothing else is forwarded
  if (!Array.isArray(body.contents) || JSON.stringify(body.contents).length > 400000) return json({ error: "bad_request" }, 400);
  if (src.systemInstruction) body.systemInstruction = src.systemInstruction;
  if (kind !== "tts") body.generationConfig.maxOutputTokens = Math.min(+body.generationConfig.maxOutputTokens || 600, kind === "news" ? 1200 : 900);
  else { body.generationConfig = { responseModalities: ["AUDIO"], speechConfig: src.generationConfig && src.generationConfig.speechConfig }; }
  if (kind === "news") body.tools = [{ google_search: {} }];
  const model = env[KINDS[kind]] || MODEL_DEFAULT[kind];
  const r = await (fetcher || fetch)(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, { method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY }, body: JSON.stringify(body) });
  const txt = await r.text();
  if (r.ok) {
    let u = {}; try { u = JSON.parse(txt).usageMetadata || {}; } catch (e) {}
    await env.DB.prepare("INSERT INTO usage (key, day, kind, n, tin, tout) VALUES (?1,?2,?3,1,?4,?5) ON CONFLICT(key,day,kind) DO UPDATE SET n=n+1, tin=tin+?4, tout=tout+?5").bind(key, day, kind, u.promptTokenCount || 0, (u.candidatesTokenCount || 0) + (u.thoughtsTokenCount || 0)).run();
    return new Response(txt, { status: 200, headers: { "Content-Type": "application/json", ...CORS } });
  }
  return json({ error: "upstream", status: r.status }, r.status === 429 ? 503 : 502);                          // never leak Google's message/key hints
}

const rzpAuth = (env) => "Basic " + btoa(`${env.RAZORPAY_KEY_ID}:${env.RAZORPAY_KEY_SECRET}`);

async function checkout(req, env, fetcher) {
  const b = await req.json().catch(() => null), plan = clean(b && b.plan, 20), P = PLANS(env)[plan];
  if (!P) return json({ error: "unknown_plan" }, 400);
  const email = clean(b.email, 80);
  const cur = pickCurrency(env, b.currency);
  const body = { amount: cur === "USD" ? P.usd : P.amount, currency: cur, accept_partial: false, description: P.label, reminder_enable: false, notes: { plan, install_id: clean(b.id, 40) },
    callback_url: env.PUBLIC_URL + "/thanks", callback_method: "get", ...(email ? { customer: { email }, notify: { email: true, sms: false } } : {}) };
  const r = await (fetcher || fetch)("https://api.razorpay.com/v1/payment_links", { method: "POST", headers: { "Content-Type": "application/json", Authorization: rzpAuth(env) }, body: JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.short_url) return json({ error: "razorpay_failed", detail: clean(j.error && j.error.description, 120) }, 502);
  return json({ url: j.short_url, id: j.id });
}

async function webhook(req, env) {
  const raw = await req.text(), sig = req.headers.get("x-razorpay-signature") || "";
  if (!env.RAZORPAY_WEBHOOK_SECRET || !safeEq(sig, await hmacHex(env.RAZORPAY_WEBHOOK_SECRET, raw))) return json({ error: "bad_signature" }, 401);
  const ev = JSON.parse(raw);
  if (ev.event === "payment_link.paid") {
    const pl = ev.payload.payment_link.entity, pay = (ev.payload.payment && ev.payload.payment.entity) || {};
    await issueLicense(env, { paymentId: pay.id || pl.id, linkId: pl.id, email: (pl.customer && pl.customer.email) || pay.email, plan: pl.notes && pl.notes.plan, amount: pl.amount_paid || pl.amount, currency: pl.currency });
  }
  return json({ ok: true });
}

async function thanks(url, env, fetcher) {
  const linkId = clean(url.searchParams.get("razorpay_payment_link_id"), 40), payId = clean(url.searchParams.get("razorpay_payment_id"), 40);
  const sig = url.searchParams.get("razorpay_signature") || "", ref = clean(url.searchParams.get("razorpay_payment_link_reference_id"), 40), status = clean(url.searchParams.get("razorpay_payment_link_status"), 20);
  const expected = await hmacHex(env.RAZORPAY_KEY_SECRET || "x", `${linkId}|${ref}|${status}|${payId}`);
  if (!linkId || !payId || status !== "paid" || !safeEq(sig, expected)) return html(page("Payment", "<p>Payment verify nahi ho paaya. Agar paise kat gaye hain to support se baat karo.</p>"), 400);
  const r = await (fetcher || fetch)("https://api.razorpay.com/v1/payment_links/" + linkId, { headers: { Authorization: rzpAuth(env) } });
  const pl = await r.json().catch(() => ({}));
  const key = await issueLicense(env, { paymentId: payId, linkId, email: pl.customer && pl.customer.email, plan: pl.notes && pl.notes.plan, amount: pl.amount_paid || pl.amount, currency: pl.currency });
  if (!key) return html(page("Payment", "<p>Payment mil gaya par key abhi ban nahi paayi. Kuch minute baad ye page refresh karo.</p>"), 202);
  return html(page("Thank you! 🎉", `<p>Aapki Earthvasi key:</p><p class="key">${esc(key)}</p><p>App me <b>Settings → Pro key</b> me paste karo (PC par bolo: <i>pro key ${esc(key)}</i>). Is page ko save kar lo.</p>`));
}

const page = (title, body) => `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>body{font:16px system-ui;max-width:520px;margin:12vh auto;padding:0 20px;color:#1c1b22}.key{font:700 22px monospace;background:#f1eefb;padding:14px;border-radius:10px;letter-spacing:1px;word-break:break-all}</style><h1>${esc(title)}</h1>${body}`;

/* ------------------------------------------------------------------ admin dashboard */
async function stats(env) {
  const q = async (sql, ...a) => (await env.DB.prepare(sql).bind(...a).all()).results;
  const now = Date.now(), d = (n) => dayStr(now - n * DAY), one = async (sql, ...a) => (await q(sql, ...a))[0] || {};
  const [tot, paid, dau, wau, mau, rev, rev30] = await Promise.all([
    one("SELECT COUNT(*) c FROM installs"), one("SELECT COUNT(*) c FROM licenses WHERE status='active' AND (expires=0 OR expires>?1)", now),
    one("SELECT COUNT(*) c FROM daily WHERE day=?1", d(0)), one("SELECT COUNT(DISTINCT id) c FROM daily WHERE day>=?1", d(6)), one("SELECT COUNT(DISTINCT id) c FROM daily WHERE day>=?1", d(29)),
    one("SELECT COALESCE(SUM(amount),0) s, COUNT(*) c FROM payments WHERE COALESCE(currency,'INR')='INR'"), one("SELECT COALESCE(SUM(amount),0) s, COUNT(*) c FROM payments WHERE COALESCE(currency,'INR')='INR' AND created>=?1", now - 30 * DAY)]);
  const usd = await one("SELECT COALESCE(SUM(amount),0) s, COUNT(*) c FROM payments WHERE currency='USD'");
  const [newByDay, activeByDay, platforms, versions, countries, events, recent] = await Promise.all([
    q("SELECT strftime('%Y-%m-%d', first_seen/1000 + 19800, 'unixepoch') day, COUNT(*) n FROM installs WHERE first_seen>=?1 GROUP BY day ORDER BY day", now - 30 * DAY),
    q("SELECT day, COUNT(*) n FROM daily WHERE day>=?1 GROUP BY day ORDER BY day", d(29)),
    q("SELECT platform k, COUNT(*) n FROM installs GROUP BY platform ORDER BY n DESC"), q("SELECT version k, COUNT(*) n FROM installs GROUP BY version ORDER BY n DESC LIMIT 8"),
    q("SELECT country k, COUNT(*) n FROM installs WHERE country!='' GROUP BY country ORDER BY n DESC LIMIT 8"),
    q("SELECT name k, SUM(n) n FROM events WHERE day>=?1 GROUP BY name ORDER BY n DESC LIMIT 12", d(6)),
    q("SELECT email, plan, amount, created, COALESCE(currency,'INR') currency FROM payments ORDER BY created DESC LIMIT 10")]);
  const byPlan = await q("SELECT plan k, COUNT(*) n FROM licenses WHERE status='active' AND (expires=0 OR expires>?1) GROUP BY plan", now);
  const mu = await one("SELECT COALESCE(SUM(n),0) n, COALESCE(SUM(tin),0) tin, COALESCE(SUM(tout),0) tout FROM usage WHERE day>=?1", d(29));
  const estUsd = (mu.tin * (+env.COST_IN_USD_PER_M || 0.1) + mu.tout * (+env.COST_OUT_USD_PER_M || 0.4)) / 1e6;        // ESTIMATE: set the two COST_* vars from Google's price page
  return { byPlan, managed_calls_30d: mu.n || 0, managed_cost_est_inr_30d: +(estUsd * (+env.USD_INR || 90)).toFixed(2), total: tot.c || 0, paid: paid.c || 0, free: Math.max(0, (tot.c || 0) - (paid.c || 0)), dau: dau.c || 0, wau: wau.c || 0, mau: mau.c || 0,
    conversion: tot.c ? +(100 * (paid.c || 0) / tot.c).toFixed(1) : 0, revenue_total: (rev.s || 0) / 100, payments_total: rev.c || 0, revenue_30d: (rev30.s || 0) / 100, revenue_usd_total: (usd.s || 0) / 100, payments_usd: usd.c || 0, payments_30d: rev30.c || 0,
    newByDay, activeByDay, platforms, versions, countries, events, recent: recent.map((r) => ({ ...r, amount: r.amount / 100 })) };
}

const ADMIN_HTML = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Earthvasi dashboard</title>
<style>:root{--bg:#f6f5fa;--c:#fff;--t:#1c1b22;--m:#6b6878;--a:#6d4aff}@media(prefers-color-scheme:dark){:root{--bg:#14131a;--c:#1e1c27;--t:#eeedf5;--m:#9a97a8}}
body{margin:0;background:var(--bg);color:var(--t);font:15px system-ui}main{max-width:980px;margin:0 auto;padding:20px 16px}h1{font-size:20px}.g{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:14px 0}
.k{background:var(--c);border-radius:12px;padding:14px}.k b{display:block;font-size:26px}.k span{color:var(--m);font-size:13px}.p{background:var(--c);border-radius:12px;padding:14px;margin:10px 0}.p h2{font-size:14px;margin:0 0 8px;color:var(--m)}
table{width:100%;border-collapse:collapse}td{padding:4px 0;border-bottom:1px solid #8883}svg{width:100%;height:90px}input,button{font:inherit;padding:8px;border-radius:8px;border:1px solid #8885}button{background:var(--a);color:#fff;border:0}</style>
<main><h1>📊 Earthvasi dashboard</h1><div id="login"><input id="t" type="password" placeholder="Admin token"> <button onclick="go()">Open</button></div><div id="nav" style="display:none;gap:6px;flex-wrap:wrap;margin:10px 0"><button id=b-dash onclick="tab('dash')">📊 Dashboard</button><button id=b-users onclick="tab('users')">👥 Users</button><button id=b-tickets onclick="tab('tickets')">🎫 Queries</button><button id=b-lic onclick="tab('lic')">🔑 Licences</button><button id=b-announce onclick="tab('announce')">📣 Announce</button><button id=b-settings onclick="tab('settings')">⚙ Settings</button><button id=b-audit onclick="tab('audit')">🧾 Audit</button></div><div id="pane" style="display:none"></div><div id="out"></div></main>
<script>
const $=s=>document.querySelector(s),fm=n=>Number(n).toLocaleString("en-IN");
function spark(rows,key){if(!rows.length)return"<p>No data yet</p>";const m=Math.max(...rows.map(r=>r.n),1),w=300/Math.max(rows.length,1);return'<svg viewBox="0 0 300 90" preserveAspectRatio="none">'+rows.map((r,i)=>'<rect x="'+(i*w+1)+'" y="'+(88-r.n/m*84)+'" width="'+Math.max(w-2,1)+'" height="'+(r.n/m*84)+'" rx="2" fill="#6d4aff"><title>'+r[key]+': '+r.n+'</title></rect>').join("")+"</svg>"}
const tbl=(rows,a="k")=>"<table>"+rows.map(r=>"<tr><td>"+(r[a]||"?")+"</td><td align=right>"+fm(r.n)+"</td></tr>").join("")+"</table>";
async function go(){const t=$("#t").value||sessionStorage.t;if(!t)return;const r=await fetch("/admin/stats",{headers:{Authorization:"Bearer "+t}});if(!r.ok){$("#out").textContent="Wrong token";return}sessionStorage.t=t;$("#login").style.display="none";window.afterLogin&&afterLogin();const s=await r.json();
const K=(a,b)=>'<div class=k><b>'+a+'</b><span>'+b+'</span></div>';
$("#out").innerHTML='<div class=g>'+K(fm(s.total),"Total installs")+K(fm(s.paid),"Paid users")+K(fm(s.free),"Free users")+K(s.conversion+"%","Free → Paid")+K(fm(s.dau),"Active today")+K(fm(s.wau),"Active 7 days")+K(fm(s.mau),"Active 30 days")+K("₹"+fm(s.revenue_30d),"Revenue 30 days ("+s.payments_30d+")")+K("₹"+fm(s.revenue_total),"Revenue total INR ("+s.payments_total+")")+K("$"+fm(s.revenue_usd_total),"Revenue total USD ("+s.payments_usd+")")+'</div>'
+'<div class=p><h2>New installs per day (30 days)</h2>'+spark(s.newByDay,"day")+'</div><div class=p><h2>Active users per day</h2>'+spark(s.activeByDay,"day")+'</div>'
+'<div class=g><div class=p><h2>Platform</h2>'+tbl(s.platforms)+'</div><div class=p><h2>Version</h2>'+tbl(s.versions)+'</div><div class=p><h2>Country</h2>'+tbl(s.countries)+'</div><div class=p><h2>Features used (7 days)</h2>'+tbl(s.events)+'</div></div>'
+'<div class=g><div class=p><h2>Active plans</h2>'+tbl(s.byPlan)+'</div><div class=p><h2>Managed AI (30 days)</h2><table><tr><td>Calls</td><td align=right>'+fm(s.managed_calls_30d)+'</td></tr><tr><td>Est. AI cost</td><td align=right>₹'+fm(s.managed_cost_est_inr_30d)+'</td></tr></table><small>Estimate from token counts x COST_* settings</small></div></div>'
+'<div class=p><h2>Download all data (CSV)</h2>'+["installs","licenses","payments","usage"].map(w=>'<button onclick="dl(\\''+w+'\\')">'+w+'</button> ').join("")+'</div>'
+'<div class=p><h2>Latest payments</h2><table>'+s.recent.map(r=>"<tr><td>"+new Date(r.created).toLocaleDateString("en-IN")+"</td><td>"+(r.email||"-")+"</td><td>"+r.plan+"</td><td align=right>"+(r.currency=="USD"?"$":"₹")+fm(r.amount)+"</td></tr>").join("")+"</table></div>"}
async function dl(w){const r=await fetch("/admin/export?what="+w,{headers:{Authorization:"Bearer "+sessionStorage.t}});const b=await r.blob(),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="earthvasi-"+w+".csv";a.click()}
if(sessionStorage.t){$("#t").value=sessionStorage.t;go()}
</script>
<script>
/* ---- control centre: Users / Tickets / Announce / Settings / Audit (all text from users is escaped before it is shown) */
const esc=v=>String(v==null?"":v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const H=()=>({Authorization:"Bearer "+sessionStorage.t,"Content-Type":"application/json"});
const api=async(p,b)=>{const r=await fetch(p,b?{method:"POST",headers:H(),body:JSON.stringify(b)}:{headers:H()});return r.json()};
const dt=t=>t?new Date(t).toLocaleString("en-IN",{dateStyle:"short",timeStyle:"short"}):"-";
let cur="dash";
function afterLogin(){document.getElementById("nav").style.display="flex";tab("dash")}
function tab(n){cur=n;["dash","users","tickets","lic","announce","settings","audit"].forEach(x=>{const b=document.getElementById("b-"+x);if(b)b.style.opacity=x==n?1:.55});document.getElementById("out").style.display=n=="dash"?"block":"none";const P=document.getElementById("pane");P.style.display=n=="dash"?"none":"block";if(n!="dash")({users:vUsers,tickets:vTickets,lic:vLic,announce:vAnn,settings:vCfg,audit:vAudit})[n]()}
async function vLic(q){q=q||"";const j=await api("/admin/licenses?q="+encodeURIComponent(q));const plans=["byok_monthly","byok_yearly","byok_lifetime","managed_monthly","managed_yearly"];document.getElementById("pane").innerHTML='<div class=p><h2>Give access to someone (free, any plan)</h2><select id=gp>'+plans.map(x=>"<option>"+x+"</option>").join("")+'</select> <input id=gd type=number placeholder="days (blank = plan length)" style="width:150px"> <input id=ge placeholder="email / note" style="width:30%"> <input id=gi placeholder="user id (optional: app activates it by itself)" style="width:40%"> <button onclick="lGrant()">Create</button><div id=gres></div></div><div class=p><h2>Licences ('+j.licenses.length+')</h2><input id=lq placeholder="search key / email / plan" value="'+esc(q)+'" style="width:60%"> <button onclick="vLic(document.getElementById(\\'lq\\').value)">Search</button></div>'+j.licenses.map(l=>'<div class=p><b>'+esc(l.key)+'</b> · '+esc(l.plan)+' · '+esc(l.email||"-")+' · '+(l.status=="active"?"active":"<b style=color:#d33>"+esc(l.status)+"</b>")+'<br><small>till '+(l.expires?dt(l.expires):"lifetime")+' · AI uses (30d) '+l.uses30+'</small><br><button data-k="'+esc(l.key)+'" onclick="lAct(this,\\''+(l.status=="active"?"revoke":"restore")+'\\')">'+(l.status=="active"?"Revoke":"Restore")+'</button> <button data-k="'+esc(l.key)+'" onclick="lAct(this,\\'extend\\')">+30 days</button></div>').join("")}
async function lGrant(){const d=+document.getElementById("gd").value;const r=await api("/admin/license",{action:"grant",plan:document.getElementById("gp").value,days:d||0,email:document.getElementById("ge").value,install:document.getElementById("gi").value.trim()});document.getElementById("gres").innerHTML=r.key?'<p>✅ Key: <b>'+esc(r.key)+'</b> (copy and send it to the person; they say: pro key '+esc(r.key)+')</p>':"<p>Failed: "+esc(r.error)+"</p>"}
async function lAct(b,a){await api("/admin/license",{action:a,key:b.dataset.k,days:30});vLic()}
async function vUsers(q){q=q||"";const j=await api("/admin/users?q="+encodeURIComponent(q));document.getElementById("pane").innerHTML='<div class=p><h2>Users ('+j.users.length+')</h2><input id=uq placeholder="search id / email / key / country / version" value="'+esc(q)+'" style="width:70%"> <button onclick="vUsers(document.getElementById(\\'uq\\').value)">Search</button></div>'+j.users.map(u=>'<div class=p><b>'+esc(u.id.slice(0,10))+'…</b> · '+esc(u.platform)+' v'+esc(u.version)+' · '+esc(u.country||"?")+' · '+esc(u.tier)+(u.plan?' · <b>'+esc(u.plan)+'</b>':"")+(u.email?' · '+esc(u.email):"")+(u.blocked?' · <b style="color:#d33">BLOCKED</b>':"")+'<br><small>first '+dt(u.first_seen)+' · last '+dt(u.last_seen)+' · tickets '+u.tickets+'</small>'+(u.note?'<br><small>📝 '+esc(u.note)+'</small>':"")+'<br><button data-id="'+esc(u.id)+'" onclick="uAct(this,\\''+(u.blocked?"unblock":"block")+'\\')">'+(u.blocked?"Unblock":"Block")+'</button> <button data-id="'+esc(u.id)+'" onclick="uAct(this,\\'note\\')">Note</button> <button data-id="'+esc(u.id)+'" onclick="uMsg(this)">Message</button></div>').join("")}
async function uAct(b,a){const id=b.dataset.id;let body={id,action:a};if(a=="block"){const r=prompt("Reason (optional)");if(r===null)return;body.reason=r}if(a=="note"){const r=prompt("Note for this user");if(r===null)return;body.note=r}await api("/admin/user",body);vUsers()}
async function uMsg(b){const m=prompt("Message to this user (shown in their app):");if(!m)return;await api("/admin/announce",{action:"add",body:m,audience:"id:"+b.dataset.id,days:30});alert("Sent. It shows next time their app syncs.")}
async function vTickets(st){const j=await api("/admin/tickets"+(st?"?status="+st:""));document.getElementById("pane").innerHTML='<div class=p><h2>User queries / requests ('+j.tickets.length+')</h2><button onclick="vTickets()">All</button> <button onclick="vTickets(\\'open\\')">Open</button> <button onclick="vTickets(\\'progress\\')">In progress</button> <button onclick="vTickets(\\'done\\')">Done</button></div>'+j.tickets.map(t=>'<div class=p><b>#'+t.id+'</b> '+esc(t.kind)+' · <b>'+esc(t.status)+'</b> · '+dt(t.created)+' · '+esc(t.platform)+' v'+esc(t.version)+'<br><span style="white-space:pre-wrap">'+esc(t.body)+'</span>'+(t.reply?'<br><small>↪ your reply: '+esc(t.reply)+'</small>':"")+'<br><button onclick="tAct('+t.id+',\\'progress\\')">In progress</button> <button onclick="tAct('+t.id+',\\'done\\')">Done</button> <button onclick="tAct('+t.id+',\\'rejected\\')">Reject</button> <button onclick="tAct('+t.id+',null,1)">Reply</button> <small>user: '+esc(t.install.slice(0,8))+'…</small></div>').join("")}
async function tAct(id,st,reply){let r="";if(reply){r=prompt("Reply (the user sees it in the app):");if(!r)return}await api("/admin/ticket",{id,status:st,reply:r});vTickets()}
async function vAnn(){const j=await api("/admin/announce");document.getElementById("pane").innerHTML='<div class=p><h2>New announcement (shown inside the app)</h2><textarea id=an rows=3 style="width:100%" placeholder="e.g. New feature: say news..."></textarea><br><select id=au><option value=all>Everyone</option><option value=free>Free</option><option value=byok>BYOK</option><option value=managed>Managed</option></select> <input id=ad type=number value=7 style="width:70px"> days <button onclick="annAdd()">Publish</button></div>'+j.announcements.map(a=>'<div class=p>#'+a.id+' · '+esc(a.audience)+' · '+(a.active?"live":"off")+' · till '+(a.ends?dt(a.ends):"always")+'<br>'+esc(a.body)+'<br><button onclick="annAct('+a.id+',\\''+(a.active?"off":"on")+'\\')">'+(a.active?"Turn off":"Turn on")+'</button> <button onclick="annAct('+a.id+',\\'delete\\')">Delete</button></div>').join("")}
async function annAdd(){await api("/admin/announce",{action:"add",body:document.getElementById("an").value,audience:document.getElementById("au").value,days:+document.getElementById("ad").value});vAnn()}
async function annAct(id,a){await api("/admin/announce",{action:a,id});vAnn()}
async function vCfg(){const j=await api("/admin/config");document.getElementById("pane").innerHTML='<div class=p><h2>Remote settings (all apps read these; never put secrets here)</h2><small>managed_ai_enabled = 0 pauses Managed AI · maintenance = message shown to everyone · min_version = ask users below it to update · new_feature = text for "what is new"</small><br><br><input id=ck placeholder="key" style="width:35%"> <input id=cv placeholder="value (empty = delete)" style="width:40%"> <button onclick="cfgSet()">Save</button></div>'+j.config.map(c=>'<div class=p><b>'+esc(c.k)+'</b> = '+esc(c.v)+' <button data-k="'+esc(c.k)+'" onclick="cfgDel(this)">Delete</button></div>').join("")}
async function cfgSet(){await api("/admin/config",{k:document.getElementById("ck").value,v:document.getElementById("cv").value});vCfg()}
async function cfgDel(b){await api("/admin/config",{k:b.dataset.k,v:""});vCfg()}
async function vAudit(){const j=await api("/admin/audit");document.getElementById("pane").innerHTML='<div class=p><h2>Everything you did (latest 100)</h2><table>'+j.audit.map(a=>'<tr><td>'+dt(a.at)+'</td><td>'+esc(a.action)+'</td><td>'+esc(a.target)+'</td><td>'+esc(a.detail)+'</td></tr>').join("")+'</table></div>'}
</script>`;

/* ------------------------------------------------------------------ router */
const CSP = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src data:; base-uri 'none'; form-action 'self'; frame-ancestors 'none'";
function hardened(res, p) {                          // every response: no sniffing, no framing, HTTPS only, nothing sensitive cached; /admin gets no CORS at all
  const r = new Response(res.body, res), h = r.headers;
  h.set("X-Content-Type-Options", "nosniff"); h.set("Referrer-Policy", "no-referrer"); h.set("X-Frame-Options", "DENY");
  h.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  if ((h.get("Content-Type") || "").startsWith("text/html")) h.set("Content-Security-Policy", CSP);
  if (p.startsWith("/admin") || p.startsWith("/v1/license") || p === "/v1/sync" || p === "/thanks") h.set("Cache-Control", "no-store");
  if (p.startsWith("/admin")) { h.delete("Access-Control-Allow-Origin"); h.delete("Access-Control-Allow-Headers"); h.delete("Access-Control-Allow-Methods"); }
  return r;
}
export default {
  async fetch(req, env, ctx, fetcher) {
    const p0 = new URL(req.url).pathname;
    if (+req.headers.get("content-length") > 700000) return hardened(json({ error: "too_large" }, 413), p0);
    return hardened(await handle(req, env, ctx, fetcher), p0);
  },
};
async function handle(req, env, ctx, fetcher) {
    const url = new URL(req.url), p = url.pathname;
    if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
    try {
      if (p.startsWith("/admin/")) { const g = await adminGate(req, env); if (g) return g; }
      if (req.method === "POST" && p === "/v1/license/verify" && await hit(env, req, "verify", 40, 600)) return tooMany();
      if (req.method === "POST" && p === "/v1/checkout" && await hit(env, req, "checkout", 10, 3600)) return tooMany();
      if (req.method === "POST" && p === "/v1/sync" && await hit(env, req, "sync", 60, 3600)) return tooMany();
      if (req.method === "POST" && p === "/v1/ping" && await hit(env, req, "ping", 40, 3600)) return tooMany();
      if (req.method === "POST" && p === "/v1/ai" && await hit(env, req, "ai", 150, 600)) return tooMany();
      if (req.method === "POST" && p === "/v1/ticket" && await hit(env, req, "ticket", 20, 86400)) return tooMany();
      if (req.method === "POST" && p === "/v1/ping") return await ping(req, env);
      if (req.method === "POST" && p === "/v1/license/verify") return await verify(req, env);
      if (req.method === "GET" && p === "/v1/plans") return json({ currency: "INR", plans: Object.fromEntries(Object.entries(PLANS(env)).filter(([k]) => k.includes("_")).map(([k, v]) => [k, { tier: v.tier, inr: v.amount / 100, usd: v.usd / 100, days: v.days }])), quota: QUOTA(env), intl: env.INTL_ENABLED === "1" });
      if (req.method === "POST" && p === "/v1/ticket") return await ticketNew(req, env);
      if (req.method === "POST" && p === "/v1/sync") return await sync(req, env);
      if (p.startsWith("/admin/") && !["/admin/stats", "/admin/export", "/admin/licenses", "/admin/license"].includes(p)) {
        if (!isAdmin(req, env)) return json({ error: "unauthorized" }, 401);
        const r = await adminSupport(req, env, url, p);
        if (r) return r;
      }
      if (req.method === "POST" && p === "/v1/ai") return await aiProxy(req, env, fetcher);
      if (req.method === "POST" && p === "/v1/checkout") return await checkout(req, env, fetcher);
      if (req.method === "POST" && p === "/v1/razorpay-webhook") return await webhook(req, env);
      if (req.method === "GET" && p === "/thanks") return await thanks(url, env, fetcher);
      if (req.method === "GET" && p === "/admin") return html(ADMIN_HTML);
      if (req.method === "GET" && p === "/admin/stats") {
        const auth = req.headers.get("authorization") || "";
        if (!env.ADMIN_TOKEN || !safeEq(auth, "Bearer " + env.ADMIN_TOKEN)) return json({ error: "unauthorized" }, 401);
        return json(await stats(env));
      }
      if (req.method === "GET" && p === "/admin/export") {
        const auth = req.headers.get("authorization") || "";
        if (!env.ADMIN_TOKEN || !safeEq(auth, "Bearer " + env.ADMIN_TOKEN)) return json({ error: "unauthorized" }, 401);
        const Q = { tickets: "SELECT id, install, kind, status, body, reply, created, updated, version, platform FROM tickets ORDER BY id DESC",
          installs: "SELECT id, platform, version, tier, country, lang, first_seen, last_seen FROM installs ORDER BY last_seen DESC",
          licenses: "SELECT l.key, l.plan, l.email, l.created, l.expires, l.status, (SELECT COUNT(*) FROM devices d WHERE d.key=l.key) devices FROM licenses l ORDER BY l.created DESC",
          payments: "SELECT id, email, plan, amount, currency, created FROM payments ORDER BY created DESC",
          usage: "SELECT u.key, l.email, l.plan, u.day, u.kind, u.n, u.tin, u.tout FROM usage u LEFT JOIN licenses l ON l.key=u.key ORDER BY u.day DESC" };
        const w = clean(url.searchParams.get("what"), 12), sql = Q[w];
        if (!sql) return json({ error: "bad_export" }, 400);
        const rows = (await env.DB.prepare(sql).all()).results, cols = rows.length ? Object.keys(rows[0]) : [];
        const cell = (v) => { v = v == null ? "" : String(v); if (/^[=+\-@]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; };            // also defuses spreadsheet formula injection
        return new Response([cols.join(","), ...rows.map((r) => cols.map((c) => cell(r[c])).join(","))].join("\n"), { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="earthvasi-${w}.csv"`, ...CORS } });
      }
      if (p === "/admin/licenses" || p === "/admin/license") {
        const auth = req.headers.get("authorization") || "";
        if (!env.ADMIN_TOKEN || !safeEq(auth, "Bearer " + env.ADMIN_TOKEN)) return json({ error: "unauthorized" }, 401);
        if (req.method === "GET") {
          const q = "%" + clean(url.searchParams.get("q"), 40) + "%";
          const rows = (await env.DB.prepare("SELECT key, plan, email, created, expires, status, (SELECT COALESCE(SUM(n),0) FROM usage u WHERE u.key=licenses.key AND u.day>=?2) uses30 FROM licenses WHERE key LIKE ?1 OR email LIKE ?1 ORDER BY created DESC LIMIT 50").bind(q, dayStr(Date.now() - 30 * DAY)).all()).results;
          return json({ licenses: rows });
        }
        const b = await req.json().catch(() => ({})), act = clean(b.action, 10);
        if (act === "grant") {                                                     // free key for friends / testers / refunds
          const P = PLANS(env)[clean(b.plan, 20)];
          if (!P) return json({ error: "unknown_plan" }, 400);
          const key = newKey(), now = Date.now(), days = +b.days > 0 ? Math.min(+b.days, 3650) : P.days;
          await env.DB.prepare("INSERT INTO licenses (key, plan, email, created, expires, payment_id, link_id, status) VALUES (?1,?2,?3,?4,?5,?6,'','active')").bind(key, clean(b.plan, 20), clean(b.email, 80), now, days ? now + days * DAY : 0, "grant_" + key).run();
          const inst = clean(b.install, 40);
          if (inst.length >= 12) await env.DB.prepare("INSERT OR REPLACE INTO gifts (id, key, at) VALUES (?1,?2,?3)").bind(inst, key, now).run();
          await audit(env, "grant", key, clean(b.plan, 20) + " " + clean(b.email, 60) + (inst ? " -> " + inst.slice(0, 8) : ""));
          return json({ ok: true, key });
        }
        if (act === "extend") {                                                    // +N days from today (or from the current end date, if later)
          const lic = await env.DB.prepare("SELECT expires FROM licenses WHERE key = ?1").bind(clean(b.key, 30)).first();
          if (!lic || !lic.expires) return json({ error: "cannot_extend" }, 400);
          const to = Math.max(Date.now(), lic.expires) + Math.min(Math.max(+b.days || 30, 1), 3650) * DAY;
          await env.DB.prepare("UPDATE licenses SET expires = ?1 WHERE key = ?2").bind(to, clean(b.key, 30)).run();
          await audit(env, "extend", clean(b.key, 30), "+" + (+b.days || 30) + "d");
          return json({ ok: true, expires: to });
        }
        if (act === "revoke" || act === "restore") {
          await env.DB.prepare("UPDATE licenses SET status=?1 WHERE key=?2").bind(act === "revoke" ? "revoked" : "active", clean(b.key, 30)).run();
          await audit(env, act, clean(b.key, 30), "");
          return json({ ok: true });
        }
        return json({ error: "bad_action" }, 400);
      }
      if (req.method === "GET" && p === "/") return json({ ok: true, service: "earthvasi-api" });
      return json({ error: "not_found" }, 404);
    } catch (e) {
      return json({ error: "server_error" }, 500);
    }
}
export { hmacHex, PLANS };
