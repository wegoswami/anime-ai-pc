// Earthvasi API: anonymous usage stats, Razorpay checkout + licence keys, private admin dashboard.
// Runs on Cloudflare Workers (free tier is plenty to start). No chats, files or personal data are ever received.

const DAY = 86400000;
const PLANS = (env) => ({
  monthly: { amount: +env.PRICE_MONTHLY || 14900, usd: +env.PRICE_MONTHLY_USD || 199, days: 31, label: "Earthvasi Pro - 1 month" },
  yearly: { amount: +env.PRICE_YEARLY || 99900, usd: +env.PRICE_YEARLY_USD || 1299, days: 366, label: "Earthvasi Pro - 1 year" },
  lifetime: { amount: +env.PRICE_LIFETIME || 299900, usd: +env.PRICE_LIFETIME_USD || 3999, days: 0, label: "Earthvasi Pro - Lifetime" },
});
// USD is offered only after you switch INTL_ENABLED="1" (Razorpay must have approved International Payments).
const pickCurrency = (env, want) => (env.INTL_ENABLED === "1" && String(want).toUpperCase() === "USD" ? "USD" : "INR");
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type, Authorization", "Access-Control-Allow-Methods": "GET, POST, OPTIONS" };
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "Content-Type": "application/json", ...CORS } });
const html = (s, status = 200) => new Response(s, { status, headers: { "Content-Type": "text/html; charset=utf-8" } });
const dayStr = (t = Date.now()) => new Date(t + 19800000).toISOString().slice(0, 10);            // India date
const clean = (v, n = 40) => String(v == null ? "" : v).replace(/[^\w .:@+\-]/g, "").slice(0, n);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

async function hmacHex(secret, msg) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(msg));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function safeEq(a, b) { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }
function newKey() {
  const A = "ABCDEFGHJKMNPQRSTVWXYZ23456789", b = crypto.getRandomValues(new Uint8Array(16));
  const s = [...b].map((x) => A[x % A.length]).join("");
  return `EV-${s.slice(0, 4)}-${s.slice(4, 8)}-${s.slice(8, 12)}-${s.slice(12, 16)}`;
}

/* ------------------------------------------------------------------ usage stats */
async function ping(req, env) {
  const b = await req.json().catch(() => null);
  const id = clean(b && b.id, 40);
  if (id.length < 12) return json({ ok: false }, 400);
  const now = Date.now(), tier = b.tier === "pro" ? "pro" : "free", platform = ["pc", "android", "web"].includes(b.platform) ? b.platform : "other";
  const country = clean(req.headers.get("cf-ipcountry") || "", 2);
  await env.DB.batch([
    env.DB.prepare("INSERT INTO installs (id, platform, version, tier, country, lang, first_seen, last_seen) VALUES (?1,?2,?3,?4,?5,?6,?7,?7) ON CONFLICT(id) DO UPDATE SET platform=?2, version=?3, tier=?4, country=?5, lang=?6, last_seen=?7")
      .bind(id, platform, clean(b.version, 12), tier, country, clean(b.lang, 10), now),
    env.DB.prepare("INSERT OR IGNORE INTO daily (day, id) VALUES (?1, ?2)").bind(dayStr(), id),
  ]);
  const ev = b.events && typeof b.events === "object" ? Object.entries(b.events).slice(0, 12) : [];      // {"agent_run": 3} counters only
  if (ev.length) await env.DB.batch(ev.map(([k, n]) => env.DB.prepare("INSERT INTO events (day, name, n) VALUES (?1,?2,?3) ON CONFLICT(day,name) DO UPDATE SET n = n + ?3").bind(dayStr(), clean(k, 30), Math.max(0, Math.min(1000, +n || 0)))));
  return json({ ok: true });
}

/* ------------------------------------------------------------------ licences */
async function verify(req, env) {
  const b = await req.json().catch(() => null);
  const key = clean(b && b.key, 30).toUpperCase(), id = clean(b && b.id, 40);
  if (!key || id.length < 12) return json({ valid: false, reason: "bad_request" }, 400);
  const lic = await env.DB.prepare("SELECT * FROM licenses WHERE key = ?1").bind(key).first();
  if (!lic || lic.status !== "active") return json({ valid: false, reason: "unknown_key" });
  if (lic.expires && lic.expires < Date.now()) return json({ valid: false, reason: "expired", plan: lic.plan, expires: lic.expires });
  const dev = await env.DB.prepare("SELECT id FROM devices WHERE key = ?1").bind(key).all();
  const known = dev.results.some((d) => d.id === id);
  if (!known) {
    if (dev.results.length >= (+env.MAX_DEVICES || 3)) return json({ valid: false, reason: "device_limit" });
    await env.DB.prepare("INSERT OR IGNORE INTO devices (key, id, first_seen) VALUES (?1,?2,?3)").bind(key, id, Date.now()).run();
  }
  return json({ valid: true, plan: lic.plan, expires: lic.expires || 0 });
}

async function issueLicense(env, { paymentId, linkId, email, plan, amount, currency }) {
  const P = PLANS(env)[plan];
  if (!P || !paymentId) return null;
  const old = await env.DB.prepare("SELECT key FROM licenses WHERE payment_id = ?1").bind(paymentId).first();
  if (old) return old.key;                                                      // webhook + thanks page can both call this safely
  const key = newKey(), now = Date.now();
  await env.DB.batch([
    env.DB.prepare("INSERT OR IGNORE INTO licenses (key, plan, email, created, expires, payment_id, link_id, status) VALUES (?1,?2,?3,?4,?5,?6,?7,'active')").bind(key, plan, clean(email, 80), now, P.days ? now + P.days * DAY : 0, paymentId, linkId || ""),
    env.DB.prepare("INSERT OR IGNORE INTO payments (id, link_id, email, amount, plan, created, currency) VALUES (?1,?2,?3,?4,?5,?6,?7)").bind(paymentId, linkId || "", clean(email, 80), amount || P.amount, plan, now, currency === "USD" ? "USD" : "INR"),
  ]);
  return (await env.DB.prepare("SELECT key FROM licenses WHERE payment_id = ?1").bind(paymentId).first()).key;
}

const rzpAuth = (env) => "Basic " + btoa(`${env.RAZORPAY_KEY_ID}:${env.RAZORPAY_KEY_SECRET}`);

async function checkout(req, env, fetcher) {
  const b = await req.json().catch(() => null), plan = clean(b && b.plan, 10), P = PLANS(env)[plan];
  if (!P) return json({ error: "unknown_plan" }, 400);
  const email = clean(b.email, 80);
  const cur = pickCurrency(env, b.currency);
  const body = { amount: cur === "USD" ? P.usd : P.amount, currency: cur, accept_partial: false, description: P.label, reminder_enable: false, notes: { plan, install_id: clean(b.id, 40) },
    callback_url: env.PUBLIC_URL + "/thanks", callback_method: "get", ...(email ? { customer: { email }, notify: { email: true, sms: false } } : {}) };
  const r = await (fetcher || fetch)("https://api.razorpay.com/v1/payment_links", { method: "POST", headers: { "Content-Type": "application/json", Authorization: rzpAuth(env) }, body: JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.short_url) return json({ error: "razorpay_failed", detail: clean(j.error && j.error.description, 120) }, 502);
  return json({ url: j.short_url, id: j.id });
}

async function webhook(req, env) {
  const raw = await req.text(), sig = req.headers.get("x-razorpay-signature") || "";
  if (!env.RAZORPAY_WEBHOOK_SECRET || !safeEq(sig, await hmacHex(env.RAZORPAY_WEBHOOK_SECRET, raw))) return json({ error: "bad_signature" }, 401);
  const ev = JSON.parse(raw);
  if (ev.event === "payment_link.paid") {
    const pl = ev.payload.payment_link.entity, pay = (ev.payload.payment && ev.payload.payment.entity) || {};
    await issueLicense(env, { paymentId: pay.id || pl.id, linkId: pl.id, email: (pl.customer && pl.customer.email) || pay.email, plan: pl.notes && pl.notes.plan, amount: pl.amount_paid || pl.amount, currency: pl.currency });
  }
  return json({ ok: true });
}

async function thanks(url, env, fetcher) {
  const linkId = clean(url.searchParams.get("razorpay_payment_link_id"), 40), payId = clean(url.searchParams.get("razorpay_payment_id"), 40);
  const sig = url.searchParams.get("razorpay_signature") || "", ref = clean(url.searchParams.get("razorpay_payment_link_reference_id"), 40), status = clean(url.searchParams.get("razorpay_payment_link_status"), 20);
  const expected = await hmacHex(env.RAZORPAY_KEY_SECRET || "x", `${linkId}|${ref}|${status}|${payId}`);
  if (!linkId || !payId || status !== "paid" || !safeEq(sig, expected)) return html(page("Payment", "<p>Payment verify nahi ho paaya. Agar paise kat gaye hain to support se baat karo.</p>"), 400);
  const r = await (fetcher || fetch)("https://api.razorpay.com/v1/payment_links/" + linkId, { headers: { Authorization: rzpAuth(env) } });
  const pl = await r.json().catch(() => ({}));
  const key = await issueLicense(env, { paymentId: payId, linkId, email: pl.customer && pl.customer.email, plan: pl.notes && pl.notes.plan, amount: pl.amount_paid || pl.amount, currency: pl.currency });
  if (!key) return html(page("Payment", "<p>Payment mil gaya par key abhi ban nahi paayi. Kuch minute baad ye page refresh karo.</p>"), 202);
  return html(page("Thank you! 🎉", `<p>Aapki Earthvasi Pro key:</p><p class="key">${esc(key)}</p><p>App me <b>Settings → Pro key</b> me paste karo (PC par bolo: <i>pro key ${esc(key)}</i>). Is page ko save kar lo.</p>`));
}

const page = (title, body) => `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>body{font:16px system-ui;max-width:520px;margin:12vh auto;padding:0 20px;color:#1c1b22}.key{font:700 22px monospace;background:#f1eefb;padding:14px;border-radius:10px;letter-spacing:1px;word-break:break-all}</style><h1>${esc(title)}</h1>${body}`;

/* ------------------------------------------------------------------ admin dashboard */
async function stats(env) {
  const q = async (sql, ...a) => (await env.DB.prepare(sql).bind(...a).all()).results;
  const now = Date.now(), d = (n) => dayStr(now - n * DAY), one = async (sql, ...a) => (await q(sql, ...a))[0] || {};
  const [tot, paid, dau, wau, mau, rev, rev30] = await Promise.all([
    one("SELECT COUNT(*) c FROM installs"), one("SELECT COUNT(*) c FROM licenses WHERE status='active' AND (expires=0 OR expires>?1)", now),
    one("SELECT COUNT(*) c FROM daily WHERE day=?1", d(0)), one("SELECT COUNT(DISTINCT id) c FROM daily WHERE day>=?1", d(6)), one("SELECT COUNT(DISTINCT id) c FROM daily WHERE day>=?1", d(29)),
    one("SELECT COALESCE(SUM(amount),0) s, COUNT(*) c FROM payments WHERE COALESCE(currency,'INR')='INR'"), one("SELECT COALESCE(SUM(amount),0) s, COUNT(*) c FROM payments WHERE COALESCE(currency,'INR')='INR' AND created>=?1", now - 30 * DAY)]);
  const usd = await one("SELECT COALESCE(SUM(amount),0) s, COUNT(*) c FROM payments WHERE currency='USD'");
  const [newByDay, activeByDay, platforms, versions, countries, events, recent] = await Promise.all([
    q("SELECT strftime('%Y-%m-%d', first_seen/1000 + 19800, 'unixepoch') day, COUNT(*) n FROM installs WHERE first_seen>=?1 GROUP BY day ORDER BY day", now - 30 * DAY),
    q("SELECT day, COUNT(*) n FROM daily WHERE day>=?1 GROUP BY day ORDER BY day", d(29)),
    q("SELECT platform k, COUNT(*) n FROM installs GROUP BY platform ORDER BY n DESC"), q("SELECT version k, COUNT(*) n FROM installs GROUP BY version ORDER BY n DESC LIMIT 8"),
    q("SELECT country k, COUNT(*) n FROM installs WHERE country!='' GROUP BY country ORDER BY n DESC LIMIT 8"),
    q("SELECT name k, SUM(n) n FROM events WHERE day>=?1 GROUP BY name ORDER BY n DESC LIMIT 12", d(6)),
    q("SELECT email, plan, amount, created, COALESCE(currency,'INR') currency FROM payments ORDER BY created DESC LIMIT 10")]);
  return { total: tot.c || 0, paid: paid.c || 0, free: Math.max(0, (tot.c || 0) - (paid.c || 0)), dau: dau.c || 0, wau: wau.c || 0, mau: mau.c || 0,
    conversion: tot.c ? +(100 * (paid.c || 0) / tot.c).toFixed(1) : 0, revenue_total: (rev.s || 0) / 100, payments_total: rev.c || 0, revenue_30d: (rev30.s || 0) / 100, revenue_usd_total: (usd.s || 0) / 100, payments_usd: usd.c || 0, payments_30d: rev30.c || 0,
    newByDay, activeByDay, platforms, versions, countries, events, recent: recent.map((r) => ({ ...r, amount: r.amount / 100 })) };
}

const ADMIN_HTML = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Earthvasi dashboard</title>
<style>:root{--bg:#f6f5fa;--c:#fff;--t:#1c1b22;--m:#6b6878;--a:#6d4aff}@media(prefers-color-scheme:dark){:root{--bg:#14131a;--c:#1e1c27;--t:#eeedf5;--m:#9a97a8}}
body{margin:0;background:var(--bg);color:var(--t);font:15px system-ui}main{max-width:980px;margin:0 auto;padding:20px 16px}h1{font-size:20px}.g{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:14px 0}
.k{background:var(--c);border-radius:12px;padding:14px}.k b{display:block;font-size:26px}.k span{color:var(--m);font-size:13px}.p{background:var(--c);border-radius:12px;padding:14px;margin:10px 0}.p h2{font-size:14px;margin:0 0 8px;color:var(--m)}
table{width:100%;border-collapse:collapse}td{padding:4px 0;border-bottom:1px solid #8883}svg{width:100%;height:90px}input,button{font:inherit;padding:8px;border-radius:8px;border:1px solid #8885}button{background:var(--a);color:#fff;border:0}</style>
<main><h1>📊 Earthvasi dashboard</h1><div id="login"><input id="t" type="password" placeholder="Admin token"> <button onclick="go()">Open</button></div><div id="out"></div></main>
<script>
const $=s=>document.querySelector(s),fm=n=>Number(n).toLocaleString("en-IN");
function spark(rows,key){if(!rows.length)return"<p>No data yet</p>";const m=Math.max(...rows.map(r=>r.n),1),w=300/Math.max(rows.length,1);return'<svg viewBox="0 0 300 90" preserveAspectRatio="none">'+rows.map((r,i)=>'<rect x="'+(i*w+1)+'" y="'+(88-r.n/m*84)+'" width="'+Math.max(w-2,1)+'" height="'+(r.n/m*84)+'" rx="2" fill="#6d4aff"><title>'+r[key]+': '+r.n+'</title></rect>').join("")+"</svg>"}
const tbl=(rows,a="k")=>"<table>"+rows.map(r=>"<tr><td>"+(r[a]||"?")+"</td><td align=right>"+fm(r.n)+"</td></tr>").join("")+"</table>";
async function go(){const t=$("#t").value||sessionStorage.t;if(!t)return;const r=await fetch("/admin/stats",{headers:{Authorization:"Bearer "+t}});if(!r.ok){$("#out").textContent="Wrong token";return}sessionStorage.t=t;$("#login").style.display="none";const s=await r.json();
const K=(a,b)=>'<div class=k><b>'+a+'</b><span>'+b+'</span></div>';
$("#out").innerHTML='<div class=g>'+K(fm(s.total),"Total installs")+K(fm(s.paid),"Paid users")+K(fm(s.free),"Free users")+K(s.conversion+"%","Free → Paid")+K(fm(s.dau),"Active today")+K(fm(s.wau),"Active 7 days")+K(fm(s.mau),"Active 30 days")+K("₹"+fm(s.revenue_30d),"Revenue 30 days ("+s.payments_30d+")")+K("₹"+fm(s.revenue_total),"Revenue total INR ("+s.payments_total+")")+K("$"+fm(s.revenue_usd_total),"Revenue total USD ("+s.payments_usd+")")+'</div>'
+'<div class=p><h2>New installs per day (30 days)</h2>'+spark(s.newByDay,"day")+'</div><div class=p><h2>Active users per day</h2>'+spark(s.activeByDay,"day")+'</div>'
+'<div class=g><div class=p><h2>Platform</h2>'+tbl(s.platforms)+'</div><div class=p><h2>Version</h2>'+tbl(s.versions)+'</div><div class=p><h2>Country</h2>'+tbl(s.countries)+'</div><div class=p><h2>Features used (7 days)</h2>'+tbl(s.events)+'</div></div>'
+'<div class=p><h2>Latest payments</h2><table>'+s.recent.map(r=>"<tr><td>"+new Date(r.created).toLocaleDateString("en-IN")+"</td><td>"+(r.email||"-")+"</td><td>"+r.plan+"</td><td align=right>"+(r.currency=="USD"?"$":"₹")+fm(r.amount)+"</td></tr>").join("")+"</table></div>"}
if(sessionStorage.t){$("#t").value=sessionStorage.t;go()}
</script>`;

/* ------------------------------------------------------------------ router */
export default {
  async fetch(req, env, ctx, fetcher) {
    const url = new URL(req.url), p = url.pathname;
    if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
    try {
      if (req.method === "POST" && p === "/v1/ping") return await ping(req, env);
      if (req.method === "POST" && p === "/v1/license/verify") return await verify(req, env);
      if (req.method === "POST" && p === "/v1/checkout") return await checkout(req, env, fetcher);
      if (req.method === "POST" && p === "/v1/razorpay-webhook") return await webhook(req, env);
      if (req.method === "GET" && p === "/thanks") return await thanks(url, env, fetcher);
      if (req.method === "GET" && p === "/admin") return html(ADMIN_HTML);
      if (req.method === "GET" && p === "/admin/stats") {
        const auth = req.headers.get("authorization") || "";
        if (!env.ADMIN_TOKEN || !safeEq(auth, "Bearer " + env.ADMIN_TOKEN)) return json({ error: "unauthorized" }, 401);
        return json(await stats(env));
      }
      if (req.method === "GET" && p === "/") return json({ ok: true, service: "earthvasi-api" });
      return json({ error: "not_found" }, 404);
    } catch (e) {
      return json({ error: "server_error" }, 500);
    }
  },
};
export { hmacHex, PLANS };
