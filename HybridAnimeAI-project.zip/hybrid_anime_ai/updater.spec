# -*- mode: python ; coding: utf-8 -*-
# Build:  pyinstaller --noconfirm --clean updater.spec   -> dist/updater.exe (single small file)
a = Analysis(
    ["updater/updater_helper.py"],
    pathex=["."],
    binaries=[],
    datas=[],
    hiddenimports=[],
    excludes=["tkinter", "unittest", "email", "http", "xml", "pydoc"],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="updater",
    debug=False,
    strip=False,
    upx=False,
    console=False,
)
