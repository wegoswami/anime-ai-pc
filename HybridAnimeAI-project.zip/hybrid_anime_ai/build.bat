@echo off
REM ============================================================
REM  Hybrid Anime AI Assistant - one-command Windows build
REM  Prereqs: Python 3.11/3.12 (64-bit), Inno Setup 6 (https://jrsoftware.org/isdl.php)
REM  Output : release\HybridAnimeAI-Setup-<version>.exe   (the installer you ship)
REM           release\HybridAnimeAI-<version>.zip + version.json  (upload these to your website)
REM ============================================================
setlocal
cd /d "%~dp0"

if not exist .venv (
    py -3.11 -m venv .venv || py -3 -m venv .venv || goto :fail
)
call .venv\Scripts\activate.bat || goto :fail

python -m pip install --upgrade pip || goto :fail
pip install -r requirements-build.txt || goto :fail

REM Placeholder characters + icon (skips anything that already exists)
python tools\make_placeholder_gifs.py || goto :fail

REM 1) tiny stand-alone updater.exe
pyinstaller --noconfirm --clean updater.spec || goto :fail

REM 2) the main app (onedir)
pyinstaller --noconfirm --clean HybridAnimeAI.spec || goto :fail
copy /Y dist\updater.exe dist\HybridAnimeAI\updater.exe || goto :fail

REM 3) OTA package + version.json + installer\version.iss
python tools\make_release.py %* || goto :fail

REM 4) single-file installer
set ISCC="%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist %ISCC% set ISCC="%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist %ISCC% set ISCC="%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
%ISCC% installer\setup.iss || goto :fail

echo.
echo BUILD OK. See the "release" folder.
exit /b 0

:fail
echo.
echo BUILD FAILED.
exit /b 1
