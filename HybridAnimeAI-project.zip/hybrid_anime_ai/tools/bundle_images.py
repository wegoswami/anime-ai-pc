"""Developer helper: build built-in image characters from a folder of pictures.
usage: python tools/bundle_images.py   (edit the CATALOG below)"""
import json, sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.avatar.importer import _prepare

ROOT = Path(__file__).resolve().parent.parent / "assets" / "characters"


def make(src: Image.Image, cid, name, gender, persona, remove_bg=True, accent="#ff8fc0"):
    d = ROOT / cid
    d.mkdir(parents=True, exist_ok=True)
    img = _prepare(src, remove_bg)
    if max(img.size) > 560:
        img.thumbnail((560, 560), Image.Resampling.LANCZOS)
    img.save(d / "avatar.png", optimize=True)
    spec = {"id": cid, "name": name, "type": "image", "file": "avatar.png", "gender": gender,
            "voice_gender": "female" if gender == "girl" else "male", "personality": persona, "accent": accent}
    (d / "character.json").write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")
