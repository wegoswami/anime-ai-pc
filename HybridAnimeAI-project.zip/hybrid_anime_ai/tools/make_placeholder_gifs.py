"""Create assets/app.ico (the installer / exe icon) if it does not exist.

(File name kept so existing build scripts and the GitHub workflow keep working. Characters are now drawn by
the app itself and need no image files.)
"""
import math
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
S = 256


def face() -> Image.Image:
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse((24, 20, 232, 236), fill=(255, 143, 192))
    d.ellipse((52, 56, 204, 220), fill=(255, 228, 212))
    d.pieslice((40, 24, 216, 150), 180, 360, fill=(255, 143, 192))
    for cx in (100, 156):
        d.ellipse((cx - 17, 118, cx + 17, 170), fill=(255, 255, 255))
        d.ellipse((cx - 12, 126, cx + 12, 168), fill=(79, 155, 255))
        d.ellipse((cx - 5, 132, cx + 3, 140), fill=(255, 255, 255))
    d.arc((108, 170, 148, 196), 20, 160, fill=(150, 60, 80), width=5)
    return im


def main() -> None:
    (ROOT / "assets").mkdir(exist_ok=True)
    ico = ROOT / "assets" / "app.ico"
    if not ico.exists():
        face().save(ico, sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)])
    print("Icon ready:", ico)


if __name__ == "__main__":
    main()
