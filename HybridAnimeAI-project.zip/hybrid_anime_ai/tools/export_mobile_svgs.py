"""Draws a creature/vector character in every mobile state with the SVG-recording Qt shim -> mobile/chars/<id>/<state>.svg
Usage: python tools/export_mobile_svgs.py <id> [<id> ...]   (or no ids = all characters)"""
import json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tests" / "qtshim")); sys.path.insert(1, str(ROOT))
from PyQt6.QtGui import QPainter
from app.avatar.state import AvatarState, CANVAS_W, CANVAS_H
from app.avatar.factory import create_avatar

STATES = {
    "neutral": dict(), "happy": dict(emotion="happy"), "love": dict(emotion="love"), "sad": dict(emotion="sad"),
    "angry": dict(emotion="angry"), "surprised": dict(emotion="surprised"), "thinking": dict(emotion="thinking"),
    "embarrassed": dict(emotion="embarrassed"), "sleepy": dict(emotion="sleepy"), "confused": dict(emotion="confused"),
    "listening": dict(emotion="listening", listening=True),
    "talk": dict(emotion="happy", speaking=True, mouth=0.9), "talk2": dict(emotion="happy", speaking=True, mouth=0.25),
    "walk1": dict(pose="walk", walk_phase=1.0), "walk2": dict(pose="walk", walk_phase=4.1),
    "sit": dict(pose="sit_ground"), "sleep": dict(pose="sleep", emotion="sleepy"), "wave": dict(pose="wave", emotion="happy"),
    "held": dict(pose="held", emotion="surprised"),
}

def main(ids):
    for f in sorted((ROOT / "assets" / "characters").glob("*/character.json")):
        spec = json.loads(f.read_text())
        if ids and spec["id"] not in ids:
            continue
        av = create_avatar(spec)
        out = ROOT / "mobile" / "chars" / spec["id"]
        out.mkdir(parents=True, exist_ok=True)
        for name, kw in STATES.items():
            p = QPainter(int(CANVAS_W), int(CANVAS_H))
            av.paint(p, CANVAS_W, CANVAS_H, AvatarState(t=1.3, **kw))
            svg = p.to_svg().replace('<rect width="100%" height="100%" fill="#c8d2e6"/>', "", 1)      # transparent background
            (out / f"{name}.svg").write_text(svg, encoding="utf-8")
        print("exported", spec["id"])

if __name__ == "__main__":
    main(set(sys.argv[1:]))
