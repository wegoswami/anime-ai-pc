"""Create the OTA package after a PyInstaller build.

Usage:  python tools/make_release.py [--base-url https://your-domain.com/hybrid-anime-ai] [--notes "text"]

Produces in ./release:
  HybridAnimeAI-<ver>.zip   contents of dist/HybridAnimeAI (flat)  -> upload to your server
  version.json              manifest the app polls                   -> upload to UPDATE_MANIFEST_URL
and writes installer/version.iss for Inno Setup.
"""
import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist" / "HybridAnimeAI"
OUT = ROOT / "release"


def read_version() -> str:
    text = (ROOT / "app" / "version.py").read_text(encoding="utf-8")
    return re.search(r'APP_VERSION\s*=\s*"([^"]+)"', text).group(1)


def read_manifest_url() -> str:
    text = (ROOT / "app" / "version.py").read_text(encoding="utf-8")
    return re.search(r'UPDATE_MANIFEST_URL\s*=\s*"([^"]+)"', text).group(1)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="", help="Folder URL that will hold the zip (HTTPS)")
    ap.add_argument("--notes", default="Bug fixes and improvements.")
    a = ap.parse_args()

    if not (DIST / "HybridAnimeAI.exe").exists():
        raise SystemExit("dist/HybridAnimeAI/HybridAnimeAI.exe not found - run PyInstaller first.")

    version = read_version()
    import os
    repo = os.environ.get("GITHUB_REPOSITORY", "")
    base = a.base_url.rstrip("/") or (f"https://github.com/{repo}/releases/download/v{version}" if repo
                                      else read_manifest_url().rsplit("/", 1)[0])
    OUT.mkdir(exist_ok=True)
    zip_path = OUT / f"HybridAnimeAI-{version}.zip"

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for f in sorted(DIST.rglob("*")):
            if f.is_file():
                z.write(f, f.relative_to(DIST).as_posix())

    digest = hashlib.sha256()
    with open(zip_path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            digest.update(chunk)

    manifest = {
        "version": version,
        "url": f"{base}/{zip_path.name}",
        "sha256": digest.hexdigest(),
        "size": zip_path.stat().st_size,
        "notes": a.notes,
    }
    (OUT / "version.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    (ROOT / "installer" / "version.iss").write_text(f'#define AppVersion "{version}"\n', encoding="utf-8")
    print(f"Release {version}: {zip_path.name} ({zip_path.stat().st_size / 1e6:.1f} MB)")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
