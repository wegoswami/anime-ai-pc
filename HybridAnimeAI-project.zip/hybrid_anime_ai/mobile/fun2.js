/* Fun 2: coins + daily missions, shop (themes and room items), things-I-remember, mood diary + comfort,
   tic-tac-toe, word chain, weekly report. Offline; wraps Fun.handle. */
(() => {
  if (!window.Fun) return;
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  const J = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } };
  const S = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
  const today = () => new Date().toISOString().slice(0, 10);
  const base = Fun.handle;

  /* ---------- state ---------- */
  const eco = () => J("haa_eco", { coins: 0, own: [], theme: "", room: [], day: "", chats: 0, games: 0, mood: 0, done: [] });
  const svE = (o) => S("haa_eco", o);
  const norm = () => { const e = eco(); if (e.day !== today()) { e.day = today(); e.chats = 0; e.games = 0; e.mood = 0; e.done = []; svE(e); } return e; };
  const facts = () => J("haa_facts", []);
  const moods = () => J("haa_moods", []);

  const THEMES = { space: ["🌌 Space", 60, "linear-gradient(#050514,#1b1250 60%,#3a2a7a)"], sunset: ["🌇 Sunset", 40, "linear-gradient(#ff7e5f,#feb47b 55%,#ffd9a8)"], garden: ["🌿 Garden", 40, "linear-gradient(#8fd9a8,#d7f5c8)"], sakura: ["🌸 Sakura", 50, "linear-gradient(#ffc1d9,#ffe9f1)"], ocean: ["🌊 Ocean", 50, "linear-gradient(#2b8fd6,#9be3ff)"] };
  const ITEMS = { plant: ["🪴", "Plant", 30], sofa: ["🛋️", "Sofa", 50], books: ["📚", "Books", 40], frame: ["🖼️", "Photo frame", 60], teddy: ["🧸", "Teddy", 80], lamp: ["🕯️", "Lamp", 50], cactus: ["🌵", "Cactus", 30], gift: ["🎁", "Gift box", 70] };
  const MISSIONS = [["chats", 3, 5, "3 baatein karo"], ["games", 1, 10, "1 game khelo"], ["mood", 1, 5, "apna mood batao"]];

  const ui = { room: null };
  function applyLook() {
    const e = eco(), st = document.getElementById("stage"); if (!st) return;
    let tag = document.getElementById("themecss"); if (!tag) { tag = document.createElement("style"); tag.id = "themecss"; document.head.appendChild(tag); }
    tag.textContent = e.theme && THEMES[e.theme] ? `#stage #sky{background:${THEMES[e.theme][2]}!important}` : "";
    if (!ui.room) { ui.room = document.createElement("div"); ui.room.id = "room"; const fl = document.getElementById("floor"); fl ? fl.after(ui.room) : st.appendChild(ui.room); }
    ui.room.innerHTML = e.room.map((k, i) => `<span style="left:${6 + (i * 13) % 80}%">${ITEMS[k] ? ITEMS[k][0] : ""}</span>`).join("");
  }
  const css = document.createElement("style");
  css.textContent = "#room{position:absolute;left:0;right:0;bottom:calc(10% - 4px);height:44px;pointer-events:none;z-index:1}#room span{position:absolute;bottom:0;font-size:30px;filter:drop-shadow(0 3px 2px rgba(0,0,0,.25));animation:rise .5s ease}";
  document.head.appendChild(css);

  const earn = (n) => { const e = norm(); e.coins += n; svE(e); return e.coins; };
  function missionReport(e) { return MISSIONS.map(([k, need, rew, lab]) => `${e.done.includes(k) ? "✅" : "⬜"} ${lab} (+${rew}🪙) ${Math.min(e[k], need)}/${need}`).join("\n"); }
  function checkMissions() {
    const e = norm(), out = [];
    for (const [k, need, rew, lab] of MISSIONS) if (!e.done.includes(k) && e[k] >= need) { e.done.push(k); e.coins += rew; out.push(`🎁 Mission poora: ${lab} +${rew}🪙`); }
    if (out.length && MISSIONS.every(([k]) => e.done.includes(k)) && !e.done.includes("bonus")) { e.done.push("bonus"); e.coins += 10; out.push("🌟 Aaj ke saare mission poore! Bonus +10🪙"); }
    if (out.length) svE(e); return out;
  }

  /* ---------- tic-tac-toe ---------- */
  let ttt = null, chain = null;
  const LINES = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  const NUM = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"];
  const winner = (b) => { for (const [a, c, d] of LINES) if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a]; return b.every(Boolean) ? "draw" : null; };
  const board = (b) => [0, 3, 6].map((r) => [0, 1, 2].map((c) => b[r + c] === "X" ? "❌" : b[r + c] === "O" ? "⭕" : NUM[r + c]).join("")).join("\n");
  function botMove(b) {
    const free = b.map((v, i) => v ? -1 : i).filter((i) => i >= 0);
    for (const m of ["O", "X"]) for (const i of free) { const t = b.slice(); t[i] = m; if (winner(t) === m) return i; }
    if (!b[4]) return 4; const cor = free.filter((i) => [0,2,6,8].includes(i)); return cor.length ? pick(cor) : pick(free);
  }
  const WORDS = "apple elephant tiger rabbit tree eagle egg game energy yellow water river rain night tea apricot orange earth hat table eye ear rose sun nest tent train nose enter rocket tomato ocean never run nice engine exam mango office eraser rice ice cat tool lion nature egg garden net tap pen night tulip pizza ant tower road dog green nut tank king grass sky yes snake ear radio olive"  .split(" ");
  const used = () => chain.used;

  /* ---------- text handlers ---------- */
  function handle(raw, n, l, R) {
    const e0 = norm();
    // multi-turn: tic-tac-toe
    if (ttt && /^(?:stop|band|quit|exit|bas)\b/.test(n)) { ttt = null; return R("Tic-tac-toe band 👍", "happy"); }
    if (ttt && /^[1-9]$/.test(n)) {
      const i = +n - 1; if (ttt[i]) return R("Wo jagah bhari hai, doosri chuno.\n" + board(ttt), "thinking");
      ttt[i] = "X"; let w = winner(ttt);
      if (!w) { ttt[botMove(ttt)] = "O"; w = winner(ttt); }
      const b = board(ttt);
      if (w) { ttt = null; const g = eco(); g.games++; if (w === "X") { g.coins += 8; } svE(g);
        return R(`${b}\n\n${w === "X" ? "🎉 Aap jeete! +8🪙" : w === "O" ? "😝 Main jeet gayi!" : "🤝 Barabar!"} Phir se? bolo "tic tac toe"`, w === "X" ? "surprised" : "happy"); }
      return R(`${b}\n\nAapki baari: 1-9 likho`, "thinking");
    }
    if (/^(?:tic tac toe|ttt|noughts and crosses)\s*$/.test(n)) { chain = null; ttt = Array(9).fill(""); return R(`❌ aap, ⭕ main. Number likho (1-9):\n${board(ttt)}`, "happy"); }
    // word chain
    if (chain && /^(?:stop|band|quit|exit|bas)\b/.test(n)) { const s = chain.score; chain = null; return R(`Word chain khatam! Aapne ${s} shabd jode 👏`, "happy"); }
    if (chain && /^[a-z]{2,}$/.test(n)) {
      if (n[0] !== chain.last) return R(`Shabd '${chain.last.toUpperCase()}' se shuru hona chahiye 🙂`, "thinking");
      if (chain.used.includes(n)) return R("Ye shabd ho chuka hai, doosra bolo.", "thinking");
      chain.used.push(n); chain.score++; const last = n[n.length - 1];
      const w = WORDS.find((x) => x[0] === last && !chain.used.includes(x));
      if (!w) { const s = chain.score; chain = null; earn(s * 2); return R(`Mere paas '${last.toUpperCase()}' se koi shabd nahi bacha — aap jeete! 🎉 Score ${s}, +${s * 2}🪙`, "surprised"); }
      chain.used.push(w); chain.last = w[w.length - 1];
      return R(`${w.toUpperCase()}! ➡️ ab '${chain.last.toUpperCase()}' se shabd bolo`, "happy");
    }
    if (/^(?:word chain|antakshari|shabd khel|word game)\s*$/.test(n)) { ttt = null; chain = { used: ["apple"], last: "e", score: 0 }; return R("🔤 Word chain! Main bolti hoon APPLE ➡️ ab aap 'E' se koi English shabd bolo. (band karne ke liye: stop)", "happy"); }

    const done = () => { const e = norm(); e.chats++; svE(e); return e; };
    let res = null;

    // coins, missions, shop
    if (/^(?:coins?|mere coins|wallet|paise kitne|balance)\s*$/.test(n)) res = R(`🪙 Aapke paas ${e0.coins} coins hain.\nAur kamane ke liye "missions" bolo, kharchne ke liye "shop".`, "happy");
    else if (/^(?:missions?|aaj ke mission|daily missions?|tasks? aaj)\s*$/.test(n)) res = R("🎯 Aaj ke missions:\n" + missionReport(e0), "happy");
    else if (/^(?:shop|dukaan|store|market|kharidari)\s*$/.test(n)) {
      res = R("🛍️ Shop (bolo: kharido <naam>)\n\n🎨 Themes:\n" + Object.entries(THEMES).map(([k, v]) => `• ${k} — ${v[0]} — ${v[1]}🪙`).join("\n") + "\n\n🏠 Room items:\n" + Object.entries(ITEMS).map(([k, v]) => `• ${k} — ${v[0]} — ${v[2]}🪙`).join("\n") + `\n\nAapke paas: ${e0.coins}🪙`, "happy");
    } else if (/^(?:kharido|buy|khareedo|lo)\s+([a-z]+)\s*$/.test(n)) {
      const k = n.split(" ")[1], e = norm();
      if (THEMES[k]) { if (e.own.includes(k)) { e.theme = k; svE(e); applyLook(); res = R(`${THEMES[k][0]} theme laga diya ✨`, "love"); } else if (e.coins < THEMES[k][1]) res = R(`Abhi ${THEMES[k][1] - e.coins} coins aur chahiye 🪙 ("missions" se kamao)`, "thinking"); else { e.coins -= THEMES[k][1]; e.own.push(k); e.theme = k; svE(e); applyLook(); res = R(`${THEMES[k][0]} theme mil gaya aur laga bhi diya! 🎉`, "love"); } }
      else if (ITEMS[k]) { if (e.room.includes(k)) res = R("Ye aapke ghar me pehle se hai 🙂", "happy"); else if (e.coins < ITEMS[k][2]) res = R(`Abhi ${ITEMS[k][2] - e.coins} coins aur chahiye 🪙`, "thinking"); else { e.coins -= ITEMS[k][2]; e.room.push(k); svE(e); applyLook(); res = R(`${ITEMS[k][0]} ${ITEMS[k][1]} ghar me rakh diya! 🏠`, "love"); } }
      else res = R("Ye cheez shop me nahi hai. 'shop' bolo.", "confused");
    } else if (/^(?:theme)\s+(default|normal|reset)\s*$/.test(n)) { const e = norm(); e.theme = ""; svE(e); applyLook(); res = R("Pehle wala aasmaan wapas 🌤️", "happy"); }

    // memory
    else if (/^(?:yaad rakho|yaad rakhna|remember)\s+(.{3,160})$/.test(raw.trim().toLowerCase().replace(/[:,]/g, " ").replace(/\s+/g, " ")) || /^(?:yaad rakho|yaad rakhna|remember)\b/.test(n)) {
      const t = raw.replace(/^\s*(?:yaad\s+rakh(?:o|na)|remember)\s*[:,-]?\s*/i, "").trim();
      if (t.length < 3) res = R("Kya yaad rakhun? Bolo: yaad rakho meri exam 5 December ko", "thinking");
      else { const f = facts(); f.push({ t, d: today() }); S("haa_facts", f.slice(-40)); res = R(`📝 Yaad kar liya: "${t}"`, "love"); }
    } else if (/^(?:mujhe kya yaad hai|meri yaadein|yaadein|what do you remember|kya yaad hai)\s*$/.test(n)) { const f = facts(); res = R(f.length ? "🧠 Mujhe ye yaad hai:\n" + f.map((x, i) => `${i + 1}. ${x.t}`).join("\n") : "Abhi kuch nahi yaad. Bolo: yaad rakho …", "thinking"); }
    else if (/^(?:bhool jao|sab bhool jao|forget everything|yaadein mita do)\s*$/.test(n)) { S("haa_facts", []); res = R("Sab bhula diya 🫥", "sad"); }

    // mood diary + comfort
    else if (/^(?:mera )?mood\s+(?:hai\s+)?(khush|happy|theek|okay|ok|badhiya|udaas|sad|gussa|angry|thaka|tired|bore|stressed|tension)\b/.test(n)) {
      const w = n.match(/(khush|happy|theek|okay|ok|badhiya|udaas|sad|gussa|angry|thaka|tired|bore|stressed|tension)/)[1];
      const sc = /khush|happy|badhiya/.test(w) ? 5 : /theek|okay|ok/.test(w) ? 3 : /bore/.test(w) ? 2 : 1;
      const m = moods(); m.push({ d: today(), s: sc, w }); S("haa_moods", m.slice(-120)); const e = norm(); e.mood++; svE(e);
      res = R(sc >= 4 ? "Waah, khush rehna! 😄 Isi ko banaye rakho." : sc === 3 ? "Theek hai, aur behtar bhi ho sakta hai 🙂 Chalo ek joke?" : "Samajh sakti hoon 💗 Bolo 'saans lo' (breathing) ya 'joke' — main saath hoon.", sc >= 4 ? "happy" : "sad");
    } else if (/^(?:mood report|mood diary|mera mood graph)\s*$/.test(n)) {
      const m = moods().slice(-7); if (!m.length) res = R("Abhi mood diary khali hai. Bolo: mera mood khush", "thinking");
      else { const avg = (m.reduce((a, b) => a + b.s, 0) / m.length).toFixed(1); res = R("📈 Pichhle moods:\n" + m.map((x) => `${x.d.slice(5)} ${"█".repeat(x.s)}${"░".repeat(5 - x.s)} ${x.w}`).join("\n") + `\nAverage: ${avg}/5`, "happy"); }
    } else if (/^(?:saans lo|breathing|breathe|relax|calm|shaant)\s*$/.test(n)) res = R("🌬️ 4-4-6 breathing:\n1) 4 count tak naak se saans andar\n2) 4 count roko\n3) 6 count me muh se dheere chhodo\nIse 5 baar karo. Main yahin hoon 💗", "love");
    else if (n.split(" ").length <= 8 && /\b(udaas|dukhi|akela|akeli|tension|stress|ghabra|depress|rona|ro raha|ro rahi|thak gaya|thak gayi|bore ho|bore ho raha|gussa)\b/.test(n) && !/\b(mood|kharcha|reminder)\b/.test(n)) {
      res = R(pick(["Main yahin hoon 💗 Chaho to batao kya hua? Ya 'joke' / 'saans lo' bolo.", "Thoda mushkil din lag raha hai na… koi baat nahi. Mere saath 'saans lo' try karo?", "Aap akele nahi ho. Kuch bhi bolo, main sunungi 🤗"]), "sad");
    }

    // weekly report
    else if (/^(?:weekly report|is hafte ka report|hafte ka report|report)\s*$/.test(n)) {
      const m = moods().filter((x) => (Date.now() - new Date(x.d)) / 864e5 < 7), s = J("haa_fun", { streak: 0, games: 0, wins: 0 });
      res = R(`🗓️ Is hafte ka report\n🔥 Streak: ${s.streak} din\n🎮 Games: ${s.games} (jeete ${s.wins})\n🪙 Coins: ${e0.coins}\n🏠 Ghar ke items: ${e0.room.length}\n😊 Mood avg: ${m.length ? (m.reduce((a, b) => a + b.s, 0) / m.length).toFixed(1) + "/5" : "—"}\nShabaash, aise hi lage raho! 💪`, "love");
    }
    else if (/^(?:games?|khel|fun)\s*[?.!]*$/.test(n)) { const r = base(raw, n, l, R); if (r) { r.text += "\n• tic tac toe  • word chain  • missions  • shop  • mood report  • saans lo  • yaad rakho …"; res = r; } }

    if (!res) res = base(raw, n, l, R);
    if (!res) { /* ordinary chat still counts for the daily mission */ done(); return null; }
    done();
    return res;
  }

  // game counter (from base module) -> missions and coins
  let lastG = (J("haa_fun", { games: 0 }).games) || 0, lastW = (J("haa_fun", { wins: 0 }).wins) || 0;
  Fun.handle = function (raw, n, l, R) {
    const r = handle(raw, n, l, R);
    const s = J("haa_fun", { games: 0, wins: 0 }), e = norm();
    if ((s.games || 0) > lastG) { e.games += s.games - lastG; if ((s.wins || 0) > lastW) e.coins += 5 * (s.wins - lastW); svE(e); }
    lastG = s.games || 0; lastW = s.wins || 0;
    const ms = checkMissions();
    if (ms.length) { if (r) r.text += "\n\n" + ms.join("\n"); else try { setTimeout(() => Brain.proactive(ms.join("\n"), "love", 0, "mission"), 600); } catch (x) {} }
    return r;
  };
  // the coins earned for a daily check-in, and a "remember" callback in the pet's own chatter
  const boot0 = Fun.boot;
  Fun.boot = function () {
    boot0(); applyLook();
    const e = norm(); if (!e.done.includes("login")) { e.done.push("login"); e.coins += 10; svE(e); }
    setInterval(() => { try { const f = facts(); if (f.length && Math.random() < 0.15 && !document.hidden && Pet.mode !== "sleep" && Date.now() - (Brain.lastTouch || 0) > 30000) Brain.proactive(`Mujhe yaad hai aapne kaha tha: "${pick(f).t}" 💗`, "love", 600000, "fact"); } catch (x) {} }, 60000);
  };
  window.Fun2 = { applyLook, eco };
})();
