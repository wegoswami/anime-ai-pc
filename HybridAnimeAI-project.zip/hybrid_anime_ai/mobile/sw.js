/* Service worker: offline app shell + automatic updates.
   Bump VERSION on every release: browsers fetch this file, see it changed, install the new worker,
   swap the caches and the page reloads itself. */
const VERSION = "2.4.0";
const SHELL = "haa-shell-" + VERSION;
const MEDIA = "haa-media-v1";            // characters & icons survive app updates (they rarely change)
const CORE = ["./", "index.html", "app.js", "style.css", "manifest.webmanifest", "characters.json", "offline-worker.js", "icons/icon-192.png", "icons/icon-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(SHELL).then((c) => c.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k.startsWith("haa-shell-") && k !== SHELL) await caches.delete(k);
    await self.clients.claim();
  })());
});
self.addEventListener("fetch", (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method === "GET" && url.hostname === "cdn.jsdelivr.net") {        // offline-AI library: download once, keep forever
    e.respondWith(caches.open(MEDIA).then(async (c) => { const hit = await c.match(req); if (hit) return hit; const res = await fetch(req); if (res.ok) c.put(req, res.clone()); return res; }));
    return;
  }
  if (req.method !== "GET" || url.origin !== location.origin) return;       // Gemini calls etc. go straight to the network
  const isMedia = /\/(chars|icons)\//.test(url.pathname);
  if (isMedia) {                                                            // cache-first
    e.respondWith(caches.open(MEDIA).then(async (c) => {
      const hit = await c.match(req); if (hit) return hit;
      const res = await fetch(req); if (res.ok) c.put(req, res.clone()); return res;
    }).catch(() => caches.match(req)));
    return;
  }
  e.respondWith((async () => {                                              // network-first so updates show immediately
    try {
      const res = await fetch(req, { cache: "no-cache" });
      if (res.ok) { const c = await caches.open(SHELL); c.put(req, res.clone()); }
      return res;
    } catch (err) {
      return (await caches.match(req, { ignoreSearch: true })) || (req.mode === "navigate" ? caches.match("index.html") : Response.error());
    }
  })());
});
self.addEventListener("notificationclick", (e) => { e.notification.close(); e.waitUntil(self.clients.matchAll({ type: "window" }).then((l) => (l[0] ? l[0].focus() : self.clients.openWindow("./")))); });
