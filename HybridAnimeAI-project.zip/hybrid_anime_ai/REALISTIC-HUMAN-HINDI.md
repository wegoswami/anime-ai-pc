# Realistic insaan jaisa assistant banana (cartoon nahi)

**Sach:** main code se asli insaan ki photo-jaisi tasveer nahi bana sakta — app ke 34 characters cartoon/vector hain. Realistic human ke liye
aapko **asli jaisi tasveerein** chahiye. App ab ek "photo pack" samajhta hai: kai photos = ek realistic character jo mood ke hisaab se chehra badalta hai.

## Kaise banayein (5 min)
1. Kisi AI image tool (jo commercial use allow kare) me ek **kaalpanik (fictional) insaan** banwayein. **Kisi asli insaan / celebrity / dost ki photo mat lo** (unki ijazat ke bina galat aur kanooni risk hai).
2. Prompt (English me): `photorealistic portrait of a friendly Indian woman, 25, shoulders-up, plain light-grey background, soft studio light, looking at camera, <expression>` — har baar **same face** rakhne ke liye ek hi tool me pehli image ko reference bana kar sirf expression badlo.
3. Ye expressions banwayein, file ka naam me mood likho:
   - `meera_neutral.png` (shaant), `meera_happy.png` (muskurahat), `meera_talk.png` (muh thoda khula)
   - optional: `_sad`, `_angry`, `_surprised`, `_thinking`, `_sleepy`, `_love`, `_embarrassed`, `_confused`, `_listening`
4. **Sab photos ek saath select** karke import karo (Android: Characters → ➕, PC: Settings → Characters → Add). App unhe ek character bana deti hai. Jo mood na ho wo neutral use hota hai.
5. Plain/solid background ho to app use hata deti hai; warna photo rounded card me dikhegi.

## Tips
- Saari photos ka size/framing same rakho, tabhi switch smooth lagega.
- Sirf 3 photos (neutral, happy, talk) bhi kaafi hain.
- Aawaz ke liye Settings me natural voice (Premium) chuno.
