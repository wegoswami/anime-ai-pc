; Inno Setup 6 script. Compile with:  ISCC.exe installer\setup.iss
; (build.bat / GitHub Actions do it; tools\make_release.py writes version.iss first)
#include "version.iss"

[Setup]
AppId={{8F3A6C1E-5B2D-4E7A-9C40-1D2E3F4A5B6C}
AppName=Hybrid Anime AI Assistant
AppVersion={#AppVersion}
AppPublisher=Your Company
; Per-user install => no admin prompt, and the OTA updater can overwrite files later.
PrivilegesRequired=lowest
DefaultDirName={localappdata}\Programs\HybridAnimeAI
DefaultGroupName=Hybrid Anime AI Assistant
DisableProgramGroupPage=yes
OutputDir=..\release
OutputBaseFilename=HybridAnimeAI-Setup-{#AppVersion}
SetupIconFile=..\assets\app.ico
; Shows up in Windows Settings -> Apps -> Installed apps with an Uninstall button
UninstallDisplayName=Hybrid Anime AI Assistant
UninstallDisplayIcon={app}\HybridAnimeAI.exe
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=yes

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Shortcuts:"
Name: "autostart"; Description: "Start the assistant when I sign in to Windows"; GroupDescription: "Options:"

[Files]
Source: "..\dist\HybridAnimeAI\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\Hybrid Anime AI Assistant"; Filename: "{app}\HybridAnimeAI.exe"
Name: "{group}\Uninstall Hybrid Anime AI Assistant"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Hybrid Anime AI Assistant"; Filename: "{app}\HybridAnimeAI.exe"; Tasks: desktopicon

[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; \
  ValueName: "HybridAnimeAI"; ValueData: """{app}\HybridAnimeAI.exe"""; Tasks: autostart; Flags: uninsdeletevalue

[Run]
Filename: "{app}\HybridAnimeAI.exe"; Description: "Launch Hybrid Anime AI Assistant"; Flags: nowait postinstall skipifsilent

[UninstallRun]
; make sure the pet is not running, otherwise its files cannot be deleted
Filename: "{sys}\taskkill.exe"; Parameters: "/F /IM HybridAnimeAI.exe"; Flags: runhidden; RunOnceId: "KillApp"

[UninstallDelete]
; also remove files that were added by over-the-air updates after install
Type: filesandordirs; Name: "{app}"

[Code]
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then
  begin
    if MsgBox('Also delete your saved settings, chat setup and logs?' + #13#10 +
              '(Choose No if you plan to reinstall later.)',
              mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES then
      DelTree(ExpandConstant('{userappdata}\HybridAnimeAI'), True, True, True);
  end;
end;
