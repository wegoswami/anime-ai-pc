# -*- mode: python ; coding: utf-8 -*-
# Build:  pyinstaller --noconfirm --clean HybridAnimeAI.spec
import os
from PyInstaller.utils.hooks import collect_all

datas = [("assets", "assets")]
binaries = []
hiddenimports = [
    "edge_tts", "aiohttp", "certifi", "pyttsx3.drivers", "pyttsx3.drivers.sapi5", "pyttsx3.drivers.dummy",
    "comtypes", "comtypes.client", "win32com", "win32com.client", "pythoncom", "pywintypes",
    # standard modules that user plugins commonly import (plugins are loaded from files at run time)
    "random", "json", "datetime", "urllib.request", "urllib.parse", "subprocess", "math", "csv", "statistics",
    "textwrap", "html", "base64", "hashlib", "ctypes", "sqlite3", "zipfile", "webbrowser", "PIL.ImageGrab", "pypdf",
]

for pkg in ("google.generativeai", "google.ai.generativelanguage", "google.api_core",
            "google.auth", "grpc", "sounddevice", "faster_whisper", "ctranslate2", "onnxruntime", "av",
            "tokenizers", "huggingface_hub", "numpy"):
    try:
        d, b, h = collect_all(pkg)
        datas += d
        binaries += b
        hiddenimports += h
    except Exception as exc:  # package optional / not installed
        print(f"[spec] skipped {pkg}: {exc}")

icon = "assets/app.ico" if os.path.exists("assets/app.ico") else None

a = Analysis(
    ["main.py"],
    pathex=["."],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter", "matplotlib", "IPython", "torch", "tensorflow"],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,       # onedir: lets the updater replace files cleanly
    name="HybridAnimeAI",
    debug=False,
    strip=False,
    upx=False,
    console=False,               # no console window
    icon=icon,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="HybridAnimeAI",
)
