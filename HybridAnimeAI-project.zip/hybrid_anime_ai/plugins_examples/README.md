# Plugins

A plugin is one `.py` file with `NAME`, `TRIGGERS` (regexes) and `run(text, ctx)` that returns the reply.
`ctx` offers: `ctx.lang`, `ctx.cfg` (no API keys), `ctx.say()`, `ctx.open_url()`, `ctx.remember()`, `ctx.search_memory()`, `ctx.run_command()`.
Put files in `%APPDATA%\HybridAnimeAI\plugins\` or say "install plugin https://github.com/you/repo" (asks for confirmation).
"update plugins" re-downloads them. A crashing or hanging plugin is isolated and disabled; it can never crash the app.
