"""Example plugin. Copy this file into %APPDATA%\HybridAnimeAI\plugins\ (or say: install plugin <github link>)."""
import random

NAME = "Coin flip"
VERSION = "1.0"
TRIGGERS = [r"\bflip a coin\b", r"\bsikka uchh?alo\b", r"\bheads or tails\b"]


def run(text, ctx):
    side = random.choice(["Heads", "Tails"])
    return f"{side}!" if ctx.lang == "en" else f"{side} aaya!"
