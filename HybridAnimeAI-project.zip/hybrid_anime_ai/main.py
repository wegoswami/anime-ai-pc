"""Earthvasi Personal AI - entry point."""
import logging
import logging.handlers
import sys
from pathlib import Path

from PyQt6.QtCore import QLockFile, QTimer
from PyQt6.QtWidgets import QApplication

from app import config as config_mod
from app.characters import get_character
from app.controller import Assistant, UpdateRunner
from app.core import updater
from app.system import winapi
from app.paths import data_dir
from app.ui.pet_window import PetWindow
from app.ui.settings_dialog import SettingsDialog
from app.version import APP_NAME


def setup_logging() -> None:
    handler = logging.handlers.RotatingFileHandler(data_dir() / "app.log", maxBytes=1_000_000,
                                                   backupCount=2, encoding="utf-8")
    logging.basicConfig(level=logging.INFO, handlers=[handler],
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    def hook(exc_type, exc, tb):
        logging.getLogger("crash").critical("Unhandled exception", exc_info=(exc_type, exc, tb))

    sys.excepthook = hook


def run_settings(cfg: dict, tracker=None, first_run: bool = False):
    dlg = SettingsDialog(cfg, tracker, first_run)
    if dlg.exec() and dlg.result_config:
        config_mod.save_config(dlg.result_config)
        return dlg.result_config
    return None


def main() -> int:
    setup_logging()
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setQuitOnLastWindowClosed(False)

    lock = QLockFile(str(data_dir() / "app.lock"))
    lock.setStaleLockTime(5000)
    if not lock.tryLock(1500):
        return 0  # already running

    cfg = config_mod.load_config()
    if not (config_mod.config_exists() and cfg.get("setup_complete")):
        cfg = run_settings(cfg, None, first_run=True)
        if cfg is None:
            return 0

    assistant = Assistant(cfg)
    char = get_character(cfg.get("character", ""))
    if char:
        assistant.apply_character(char)
    window = PetWindow(cfg, assistant)
    window.show()

    def open_settings():
        new_cfg = run_settings(window.cfg, assistant.tracker)
        if new_cfg:
            window.cfg.update(new_cfg)
            assistant.update_config(window.cfg, get_character(window.cfg.get("character", "")))
            window.apply_config(window.cfg)
            assistant.set_hands_free(bool(window.cfg.get("hands_free")))
            window.bubble.show_text("Settings saved!")
            assistant.provision()          # pick up a newly chosen voice model

    from app.core import hotkey
    hotkey.install(app, window.cfg.get("hotkey", "alt+space"), lambda: (window.show(), window.toggle_input()))
    window.open_settings.connect(open_settings)
    window.quit_app.connect(app.quit)
    assistant.hands_free_changed.connect(lambda on: window.cfg.__setitem__("hands_free", on))

    # ---- OTA updater
    runner = UpdateRunner(lambda: window.cfg)
    runner.progress.connect(lambda t, p, d: window.bubble.show_progress(t, p, d))
    runner.failed.connect(lambda m: window.bubble.finish(m, 6000))
    runner.no_update.connect(lambda: window.bubble.show_text("You're on the latest version ✨"))

    def apply_update(staged: str, version: str):
        window.bubble.show_progress(f"Installing v{version}", 100, "Restarting…")
        try:
            updater.launch_helper(Path(staged))
        except Exception as exc:  # noqa: BLE001
            logging.getLogger(__name__).exception("Could not launch updater")
            window.bubble.finish(f"Update failed: {exc}", 6000)
            return
        assistant.tracker.save()
        lock.unlock()
        QTimer.singleShot(700, app.quit)

    runner.restart_needed.connect(apply_update)
    window.check_updates.connect(lambda: runner.start(manual=True))
    window.update_from_file.connect(runner.install_local)

    # silent updates: downloaded in the background, installed when the user is away from the PC
    pending = {}

    def on_ready(staged: str, version: str):
        if not window.cfg.get("auto_update", True):
            return
        if not pending:
            window.bubble.show_text(f"Update v{version} is ready - I'll install it when you take a break ✨")
        pending.update(staged=staged, version=version)

    def install_when_idle():
        if pending and winapi.idle_seconds() > 120 and not assistant.speaking:
            staged, version = pending.pop("staged"), pending.pop("version")
            apply_update(staged, version)

    runner.ready.connect(on_ready)
    idle_timer = QTimer(window)
    idle_timer.timeout.connect(install_when_idle)
    idle_timer.start(30_000)
    recheck = QTimer(window)
    recheck.timeout.connect(lambda: runner.start(manual=False) if window.cfg.get("auto_update", True) else None)
    recheck.start(4 * 3600 * 1000)                                  # look again every 4 hours

    # ---- start-up tasks
    QTimer.singleShot(1200, assistant.greet)
    QTimer.singleShot(2500, lambda: runner.start(manual=False))     # silent update check on every launch
    QTimer.singleShot(4000, assistant.warm_up)                      # models into RAM -> fast first answer
    QTimer.singleShot(7000, assistant.provision)
    QTimer.singleShot(60_000, assistant.refresh_models)             # weekly offline-model refresh                    # offline voice + chat models (once)
    if cfg.get("hands_free"):
        QTimer.singleShot(3000, lambda: assistant.set_hands_free(True))

    app.aboutToQuit.connect(assistant.tracker.save)
    code = app.exec()
    lock.unlock()
    return code


if __name__ == "__main__":
    sys.exit(main())
