# Hybrid Anime AI Assistant v2

Windows desktop pet: ek anime character jo screen par chalta hai, windows par baithta hai, cursor dekhta hai, emotions dikhata hai, aapse khud baat karta hai aur voice/text se kaam karta hai.

## Features
- 27 built-in characters: 10 vector-drawn (chalte/baithte hain, emotions + poses) aur 17 detailed anime-art characters (image puppet)
- Apni image upload karo (PNG, JPG, WEBP, BMP, TIFF, GIF) - background auto-remove, AI ke saath use hota hai
- Voice: offline Whisper (language auto-detect), hands-free + wake word, Windows TTS
- Online Gemini / offline Ollama (gemma2:2b) auto-switch
- Windows par baithna, cursor follow, "aap kya kar rahe the" activity journal, proactive baatein, break reminders
- Hindi / Hinglish / English commands: app kholna, volume, screenshot, search, reminders, shutdown (confirmation ke saath)
- OTA updater

## Auto-update (online + offline)
- Online: har build GitHub Release (`v<APP_VERSION>`) publish karta hai. App har launch par aur har 4 ghante me check karke update background me download karta hai, aur aap PC se door hon (2 min idle) tab khud install karke restart hota hai. Repo **public** honi chahiye.
- Offline: tray menu -> "Update from a file" se `HybridAnimeAI-<version>.zip` chuno, ya zip ko `%APPDATA%\HybridAnimeAI\updates\inbox\` me daal do.
- Offline AI model har hafte (online hone par) khud refresh hota hai. Models start par RAM me pre-load hote hain (tez pehla jawab).
- Naya version release karne ke liye: `app/version.py` me APP_VERSION badhao -> zip upload -> Actions -> Run workflow.

## Mobile app
`mobile/` folder = Android/iPhone ke liye installable web app (PWA). Dekho `mobile/README.md`.

- Windows: ab "battery kitni hai" aur "mausam kaisa hai" commands bhi chalte hain.

## Mic "can't access" error
Windows Settings -> Privacy & security -> Microphone -> "Let desktop apps access your microphone" ON karo. App ki Settings -> Voice tab me mic device chuno aur Test dabao.

## First run
- Whisper model (~480 MB "small") pehli baar download hota hai; chhota model Settings me chun sakte ho.
- Ollama offline mode ke liye pehli baar download hota hai.
- Installer unsigned hai, isliye SmartScreen "More info -> Run anyway" dikha sakta hai.

## Build (Windows)
    pip install -r requirements-build.txt
    python tools/make_placeholder_gifs.py
    build.bat
Ya GitHub me zip upload karke Actions -> Run workflow -> artifact download karo.

## Tests (headless)
    python tests/run_all.py

## Limits
Real 3D/VRM models support nahi hain; characters 2D vector/image puppet hain. Update URL `app/version.py` me set karo.
